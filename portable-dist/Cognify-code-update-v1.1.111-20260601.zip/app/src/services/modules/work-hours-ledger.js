function roundMinutes(value = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, Math.round(number)) : 0;
}

function firstFiniteNumber(...values) {
  for (const value of values) {
    if (value === null || value === undefined || value === '') {
      continue;
    }
    const number = Number(value);
    if (Number.isFinite(number)) {
      return number;
    }
  }
  return null;
}

function clampToRange(minutes, rangeMinutes = null) {
  const value = roundMinutes(minutes);
  const range = Number(rangeMinutes);
  if (!Number.isFinite(range) || range <= 0) {
    return value;
  }
  return Math.min(roundMinutes(range), value);
}

function safePcAvailableMinutesFromSummary(summary = {}) {
  const active = roundMinutes(firstFiniteNumber(summary.active_minutes, summary.estimated_active_minutes));
  const reportedIdle = roundMinutes(firstFiniteNumber(summary.idle_minutes, summary.input_idle_minutes));
  const rawInputIdle = roundMinutes(firstFiniteNumber(summary.raw_input_idle_minutes, reportedIdle));
  const idle = Math.max(reportedIdle, rawInputIdle);
  const captured = roundMinutes(summary.captured_minutes_estimate);
  const range = firstFiniteNumber(summary.range_minutes);
  const localEvidence = clampToRange(Math.max(active + idle, captured), range);
  const runtime = firstFiniteNumber(summary.runtime_available_minutes);
  const explicit = firstFiniteNumber(
    summary.gross_pc_available_minutes,
    summary.work_minutes_breakdown?.gross_pc_available_minutes
  );

  if (explicit !== null) {
    const trustedExplicit = Boolean(summary.pc_available_source) ||
      (runtime !== null && runtime > 0) ||
      summary.source === 'cognify-runtime-availability' ||
      summary.official_time_source === 'cognify-runtime-availability';
    if (!trustedExplicit) {
      return clampToRange(Math.min(explicit, localEvidence), range);
    }
    return clampToRange(explicit, range);
  }

  if (runtime !== null && runtime > 0) {
    return clampToRange(runtime, range);
  }

  return localEvidence;
}

function buildWorkHoursLedger({
  pcAvailableMinutes = 0,
  idleMinutes = 0,
  manualAddedMinutes = 0,
  rangeMinutes = null
} = {}) {
  const pcAvailable = clampToRange(pcAvailableMinutes, rangeMinutes);
  const idleDeducted = Math.min(pcAvailable, roundMinutes(idleMinutes));
  const manualRequested = roundMinutes(manualAddedMinutes);
  const manualRestored = Math.min(idleDeducted, manualRequested);
  const pcAvailableWork = Math.max(0, pcAvailable - idleDeducted);
  const totalWork = Math.min(pcAvailable, pcAvailableWork + manualRestored);

  return {
    pc_available_minutes: pcAvailable,
    idle_deducted_minutes: idleDeducted,
    manual_requested_minutes: manualRequested,
    manual_restored_minutes: manualRestored,
    pc_available_work_minutes: pcAvailableWork,
    work_minutes: totalWork
  };
}

module.exports = {
  buildWorkHoursLedger,
  clampToRange,
  roundMinutes,
  safePcAvailableMinutesFromSummary
};
