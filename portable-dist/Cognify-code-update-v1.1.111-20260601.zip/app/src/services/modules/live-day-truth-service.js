const fs = require('fs');
const path = require('path');
const {
  buildWorkHoursLedger,
  safePcAvailableMinutesFromSummary
} = require('./work-hours-ledger');

const SCHEMA_VERSION = 1;
const DEFAULT_RECENT_WINDOW_MS = 10 * 60 * 1000;
const DEFAULT_MIN_CURRENT_REFRESH_MS = 60 * 1000;
const DEFAULT_CURRENT_SYNC_BUDGET_MS = 1200;
const DEFAULT_CLOSED_HOUR_SYNC_BUDGET_MS = 5000;
const DEFAULT_CURRENT_MAX_WINDOWS = 4;
const DEFAULT_CLOSED_HOUR_MAX_WINDOWS = 12;
const DEFAULT_RETRY_BASE_MS = 15 * 60 * 1000;
const DEFAULT_RETRY_MAX_MS = 60 * 60 * 1000;
const MINUTE_MS = 60 * 1000;
const ACTIVE_MINUTE_THRESHOLD_MS = 30 * 1000;
const CLASSIFICATION_KEYS = ['work', 'meeting', 'social', 'other', 'unclear'];

class LiveDayTruthService {
  constructor(storagePath, services = {}, options = {}) {
    this.basePath = path.join(storagePath, 'live-truth');
    this.services = services;
    this.recentWindowMs = Number(options.recentWindowMs || DEFAULT_RECENT_WINDOW_MS);
    this.minCurrentRefreshMs = Number(options.minCurrentRefreshMs || DEFAULT_MIN_CURRENT_REFRESH_MS);
    this.currentSyncBudgetMs = Number(options.currentSyncBudgetMs || DEFAULT_CURRENT_SYNC_BUDGET_MS);
    this.closedHourSyncBudgetMs = Number(options.closedHourSyncBudgetMs || DEFAULT_CLOSED_HOUR_SYNC_BUDGET_MS);
    this.currentMaxWindows = Number(options.currentMaxWindows || DEFAULT_CURRENT_MAX_WINDOWS);
    this.closedHourMaxWindows = Number(options.closedHourMaxWindows || DEFAULT_CLOSED_HOUR_MAX_WINDOWS);
    this.retryBaseMs = Number(options.retryBaseMs || DEFAULT_RETRY_BASE_MS);
    this.retryMaxMs = Number(options.retryMaxMs || DEFAULT_RETRY_MAX_MS);
    this.inFlight = null;
    fs.mkdirSync(this.basePath, { recursive: true });
  }

  getTodayState({ now = new Date() } = {}) {
    const bounds = this._todayBounds(now);
    const day = this._loadDay(bounds.date);
    return this._stateFromDay(day, bounds);
  }

  getVerifiedHour(startTime, endTime) {
    const start = new Date(startTime);
    const end = new Date(endTime);
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
      return null;
    }
    const day = this._loadDay(this._dateKey(start));
    const entry = day.hours[this._hourKey(start)];
    if (!entry || entry.status !== 'verified' || entry.sync_complete !== true) {
      return null;
    }
    const entryStartMs = new Date(entry.start_time).getTime();
    const entryEndMs = new Date(entry.end_time).getTime();
    if (Math.abs(entryStartMs - start.getTime()) > 1000 || Math.abs(entryEndMs - end.getTime()) > 1000) {
      return null;
    }
    return entry;
  }

  getAccountedHour(startTime, endTime) {
    const start = new Date(startTime);
    const end = new Date(endTime);
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
      return null;
    }
    const day = this._loadDay(this._dateKey(start));
    const hour = {
      key: this._hourKey(start),
      startTime: start.toISOString(),
      endTime: end.toISOString()
    };
    const entry = day.hours[hour.key]
      ? this._finalizeStatusWithLocalEvidence(this._withRuntimeAvailabilityEvidence(day.hours[hour.key]), { current: false })
      : this._runtimeAvailabilityEntry(hour, { current: false });
    if (!entry || !this._summaryEligibleHours([entry], '').length) {
      return null;
    }
    const entryStartMs = new Date(entry.start_time).getTime();
    const entryEndMs = new Date(entry.end_time).getTime();
    if (Math.abs(entryStartMs - start.getTime()) > 1000) {
      return null;
    }
    if (Math.abs(entryEndMs - end.getTime()) > 1000) {
      const requestedEndMs = end.getTime();
      const coversPartialRequestedHour = entryEndMs > entryStartMs && entryEndMs <= requestedEndMs + 1000;
      if (!coversPartialRequestedHour) {
        return null;
      }
    }
    if (!Number(entry.summary?.range_minutes || 0)) {
      return null;
    }
    return entry;
  }

  async refreshCurrent({ source = 'timer', now = new Date(), force = false } = {}) {
    return this._runExclusive(async () => {
      const bounds = this._todayBounds(now);
      const day = this._loadDay(bounds.date);
      const hour = this._currentHourRange(bounds, now);
      const existing = day.hours[hour.key];
      const refreshedAtMs = new Date(existing?.last_sync_at || existing?.built_at || 0).getTime();
      if (!force && Number.isFinite(refreshedAtMs) && (Date.now() - refreshedAtMs) < this.minCurrentRefreshMs) {
        return { skipped: true, reason: 'fresh', state: this._stateFromDay(day, bounds) };
      }

      const status = this._cachedCaptureStatus();
      const hourStartMs = new Date(hour.startTime).getTime();
      const syncStartMs = existing
        ? Math.max(hourStartMs, new Date(now).getTime() - this.recentWindowMs)
        : hourStartMs;
      let query = { records: [], sync: this._syncSummary(hour.startTime, hour.endTime), system_process_records: [] };
      if (status.running) {
        query = await this.services.activity.getRangeData(new Date(syncStartMs).toISOString(), hour.endTime, {
          sync: true,
          maxDurationMs: this.currentSyncBudgetMs,
          maxWindows: this.currentMaxWindows
        });
      }

      const sync = query.sync || this._syncSummary(hour.startTime, hour.endTime);
      const storedRecords = this._storedRecords(hour.startTime, hour.endTime);
      const currentStatus = this._currentHourStatus({
        captureRunning: status.running,
        captureUnknown: status.unknown,
        records: storedRecords,
        sync
      });
      const entry = this._finalizeStatusWithLocalEvidence(await this._buildHourEntry(hour, {
        status: currentStatus,
        source,
        sync,
        syncRequested: status.running,
        statusDetail: this._statusDetail(currentStatus, {
          sync,
          captureRunning: status.running,
          captureUnknown: status.unknown
        }),
        records: storedRecords
      }), { current: true });
      day.hours[hour.key] = entry;
      day.updated_at = new Date().toISOString();
      this._saveDay(day);
      return { ok: true, hour: hour.key, state: this._stateFromDay(day, bounds) };
    });
  }

  async verifyNextClosedHour({ source = 'timer', now = new Date() } = {}) {
    return this._runExclusive(async () => {
      const bounds = this._todayBounds(now);
      const day = this._loadDay(bounds.date);
      const hour = this._nextClosedHourToVerify(day, bounds, now);
      if (!hour) {
        return { skipped: true, reason: 'no_closed_hour_debt', state: this._stateFromDay(day, bounds) };
      }

      const status = this._cachedCaptureStatus();
      let query = {
        records: this._storedRecords(hour.startTime, hour.endTime),
        sync: this._syncSummary(hour.startTime, hour.endTime),
        system_process_records: []
      };
      if (status.running) {
        query = await this.services.activity.getRangeData(hour.startTime, hour.endTime, {
          sync: true,
          maxDurationMs: this.closedHourSyncBudgetMs,
          maxWindows: this.closedHourMaxWindows
        });
      }

      const sync = query.sync || this._syncSummary(hour.startTime, hour.endTime);
      const coverageComplete = this._syncCoversRange(hour.startTime, hour.endTime, sync);
      const records = query.records || this._storedRecords(hour.startTime, hour.endTime);
      const existing = day.hours[hour.key] || null;
      const statusName = this._closedHourStatus({
        captureRunning: status.running,
        captureUnknown: status.unknown,
        coverageComplete,
        records,
        sync
      });
      const locallyFinalizedEntry = this._finalizeStatusWithLocalEvidence(await this._buildHourEntry(hour, {
        status: statusName,
        source,
        sync,
        syncRequested: status.running,
        statusDetail: this._statusDetail(statusName, {
          sync,
          captureRunning: status.running,
          captureUnknown: status.unknown
        }),
        records
      }), { current: false });
      const entry = this._applyVerificationAttempt(locallyFinalizedEntry, existing, locallyFinalizedEntry.status);
      day.hours[hour.key] = entry;
      day.updated_at = new Date().toISOString();
      this._saveDay(day);
      return { ok: true, hour: hour.key, status: statusName, state: this._stateFromDay(day, bounds) };
    });
  }

  async refreshStoredRange(startTime, endTime, { source = 'stored-range', now = new Date() } = {}) {
    const start = new Date(startTime);
    const end = new Date(endTime);
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
      return { skipped: true, reason: 'invalid_range' };
    }

    return this._runExclusive(async () => {
      const status = this._cachedCaptureStatus();
      const updatedHours = [];
      const dateKeys = this._dateKeysInRange(start, end);

      for (const dateKey of dateKeys) {
        const bounds = this._boundsForDateKey(dateKey, now);
        const day = this._loadDay(bounds.date);
        const dayStartMs = new Date(bounds.startTime).getTime();
        const dayEndMs = new Date(bounds.endTime).getTime();
        const rangeStartMs = Math.max(start.getTime(), dayStartMs);
        const rangeEndMs = Math.min(end.getTime(), dayEndMs);
        if (!Number.isFinite(rangeStartMs) || !Number.isFinite(rangeEndMs) || rangeEndMs <= rangeStartMs) {
          continue;
        }

        const hourStart = new Date(rangeStartMs);
        hourStart.setMinutes(0, 0, 0);
        const hourEnd = new Date(rangeEndMs);
        if (hourEnd.getMinutes() || hourEnd.getSeconds() || hourEnd.getMilliseconds()) {
          hourEnd.setHours(hourEnd.getHours() + 1, 0, 0, 0);
        }
        const hours = this._hourRanges(hourStart.toISOString(), new Date(Math.min(hourEnd.getTime(), dayEndMs)).toISOString());
        const nowDateKey = this._dateKey(now);
        const currentKey = dateKey === nowDateKey ? this._hourKey(now) : '';

        for (const hour of hours) {
          const current = hour.key === currentKey && dateKey === nowDateKey;
          const records = this._storedRecords(hour.startTime, hour.endTime);
          const sync = this._syncSummary(hour.startTime, hour.endTime);
          const coverageComplete = this._syncCoversRange(hour.startTime, hour.endTime, sync);
          const statusName = current
            ? this._currentHourStatus({
              captureRunning: status.running,
              captureUnknown: status.unknown,
              records,
              sync
            })
            : this._closedHourStatus({
              captureRunning: status.running,
              captureUnknown: status.unknown,
              coverageComplete,
              records,
              sync
            });
          const entry = this._finalizeStatusWithLocalEvidence(await this._buildHourEntry(hour, {
            status: statusName,
            source,
            sync,
            syncRequested: false,
            statusDetail: this._statusDetail(statusName, {
              sync,
              captureRunning: status.running,
              captureUnknown: status.unknown
            }),
            records
          }), { current });

          day.hours[hour.key] = entry;
          updatedHours.push({
            date: dateKey,
            hour: hour.key,
            status: entry.status,
            work_minutes: entry.summary?.work_minutes || 0,
            pc_available_minutes: entry.summary?.gross_pc_available_minutes || 0
          });
        }

        if (updatedHours.some((item) => item.date === dateKey)) {
          day.updated_at = new Date().toISOString();
          this._saveDay(day);
        }
      }

      return {
        ok: true,
        hours: updatedHours,
        state: this.getTodayState({ now })
      };
    });
  }

  _runExclusive(action) {
    if (this.inFlight) {
      return Promise.resolve({ skipped: true, reason: 'in_flight' });
    }
    const run = Promise.resolve().then(action);
    this.inFlight = run;
    return run.finally(() => {
      if (this.inFlight === run) {
        this.inFlight = null;
      }
    });
  }

  async _buildHourEntry(hour, { status, source, sync, syncRequested, statusDetail, records }) {
    const safeRecords = Array.isArray(records) ? records : [];
    const idleIntervals = this.services.systemIdle.getIntervalsInRange(hour.startTime, hour.endTime);
    const focusIntervals = this.services.focusEvents?.getActiveIntervals?.(hour.startTime, hour.endTime) || [];
    const runtimeAvailabilityIntervals = this.services.runtimeAvailability?.getIntervalsInRange?.(hour.startTime, hour.endTime) || [];
    const passiveWorkIntervals = this.services.focusEvents?.getPassiveWorkIntervals?.(hour.startTime, hour.endTime, {
      classifier: this.services.classifier
    }) || [];
    const summary = this._buildMinuteTruthSummary(hour, safeRecords, {
      idleIntervals,
      focusIntervals,
      passiveWorkIntervals,
      runtimeAvailabilityIntervals
    });

    return {
      schema_version: SCHEMA_VERSION,
      key: hour.key,
      status,
      start_time: hour.startTime,
      end_time: hour.endTime,
      built_at: new Date().toISOString(),
      last_sync_at: syncRequested ? new Date().toISOString() : null,
      source,
      status_detail: statusDetail || null,
      record_count: safeRecords.length,
      sync_requested: Boolean(syncRequested),
      sync_complete: this._syncCoversRange(hour.startTime, hour.endTime, sync),
      sync: this._compactSync(sync),
      summary: this._compactSummary(summary)
    };
  }

  _runtimeAvailabilityEntry(hour, { current = false } = {}) {
    const summary = this._runtimeAvailabilitySummary(hour);
    if (!summary) {
      return null;
    }
    return {
      schema_version: SCHEMA_VERSION,
      key: hour.key,
      status: current ? 'capturing' : 'runtime_available',
      start_time: hour.startTime,
      end_time: hour.endTime,
      built_at: new Date().toISOString(),
      last_sync_at: null,
      source: 'runtime-availability',
      status_detail: current
        ? null
        : 'Counted from Cognify runtime availability while capture evidence is still being reviewed.',
      record_count: 0,
      sync_requested: false,
      sync_complete: false,
      sync: this._compactSync(this._syncSummary(hour.startTime, hour.endTime)),
      summary: this._compactSummary(summary),
      synthetic: true
    };
  }

  _runtimeAvailabilitySummary(hour) {
    const intervals = this.services.runtimeAvailability?.getIntervalsInRange?.(hour.startTime, hour.endTime) || [];
    const startMs = new Date(hour.startTime).getTime();
    const endMs = new Date(hour.endTime).getTime();
    const normalized = this._normalizeIntervals(intervals, startMs, endMs);
    const availableMinutes = this._intervalMinutes(normalized);
    if (availableMinutes <= 0) {
      return null;
    }
    const rangeMinutes = Number.isFinite(startMs) && Number.isFinite(endMs) && endMs > startMs
      ? Math.max(1, Math.round((endMs - startMs) / MINUTE_MS))
      : availableMinutes;
    const idleIntervals = this._normalizeIntervals(
      this.services.systemIdle?.getIntervalsInRange?.(hour.startTime, hour.endTime) || [],
      startMs,
      endMs
    );
    const idleMinutes = Math.min(availableMinutes, this._intervalMinutes(idleIntervals));
    const hasInputStateEvidence = idleMinutes > 0;
    const ledgerAvailableMinutes = hasInputStateEvidence ? availableMinutes : 0;
    const ledger = buildWorkHoursLedger({
      pcAvailableMinutes: ledgerAvailableMinutes,
      idleMinutes,
      manualAddedMinutes: 0,
      rangeMinutes
    });
    return {
      source: 'cognify-runtime-availability',
      official_time_source: 'cognify-runtime-availability',
      pc_available_source: 'runtime_availability',
      activity_events: 0,
      captured_activity_events: 0,
      focus_backed_activity_events: 0,
      manual_timing_event_count: 0,
      apps_used: [],
      app_display_names: [],
      websites_visited: [],
      range_start: hour.startTime,
      range_end: hour.endTime,
      range_minutes: rangeMinutes,
      runtime_available_minutes: availableMinutes,
      raw_input_idle_minutes: idleMinutes,
      passive_work_candidate_minutes: 0,
      input_idle_minutes: idleMinutes,
      captured_minutes_estimate: 0,
      accounted_minutes: ledger.pc_available_minutes,
      gross_pc_available_minutes: ledger.pc_available_minutes,
      missing_minutes: Math.max(0, rangeMinutes - ledger.pc_available_minutes),
      coverage_complete: ledger.pc_available_minutes >= rangeMinutes,
      coverage_percent: rangeMinutes > 0 ? Math.min(100, Math.round((ledger.pc_available_minutes / rangeMinutes) * 100)) : 0,
      active_minutes: 0,
      estimated_active_minutes: 0,
      focus_minutes: 0,
      messaging_minutes: 0,
      social_minutes: 0,
      idle_minutes: idleMinutes,
      other_minutes: 0,
      unclear_minutes: 0,
      pc_work_minutes: 0,
      pc_messaging_minutes: 0,
      confirmed_non_work_minutes: 0,
      manual_net_added_work_minutes: ledger.manual_restored_minutes,
      manual_timing_blocks: this._compactManualTimingBlocks({}),
      work_minutes: ledger.work_minutes,
      work_minutes_breakdown: {
        pc_work_minutes: 0,
        pc_messaging_minutes: 0,
        pc_active_work_minutes: ledger.pc_available_work_minutes,
        gross_pc_available_minutes: ledger.pc_available_minutes,
        idle_minutes: ledger.idle_deducted_minutes,
        confirmed_non_work_minutes: 0,
        manual_net_added_minutes: ledger.manual_restored_minutes,
        total_work_minutes: ledger.work_minutes
      },
      classified_minutes: this._emptyClassified(),
      focus_score: this._focusScore({ work: 0 }, 0)
    };
  }

  _stateFromDay(day, bounds) {
    const now = new Date(bounds.endTime);
    const expected = this._hourRanges(bounds.startTime, bounds.endTime);
    const currentKey = this._hourKey(now);
    const expectedClosed = expected.filter((hour) => hour.key !== currentKey);
    const hours = expected
      .map((hour) => {
        const entry = day.hours[hour.key];
        if (entry) {
          return this._finalizeStatusWithLocalEvidence(this._withRuntimeAvailabilityEvidence(entry, {
            startTime: hour.startTime,
            endTime: hour.key === currentKey ? bounds.endTime : hour.endTime
          }), { current: hour.key === currentKey });
        }
        return this._runtimeAvailabilityEntry(hour, { current: hour.key === currentKey });
      })
      .filter(Boolean)
      .sort((left, right) => String(left.start_time).localeCompare(String(right.start_time)));
    const entriesByKey = new Map(hours.map((hour) => [hour.key, hour]));
    const closedEntries = expectedClosed.map((hour) => entriesByKey.get(hour.key)).filter(Boolean);
    const missingHours = expectedClosed
      .filter((hour) => !entriesByKey.has(hour.key))
      .map((hour) => hour.key);
    const gapHours = closedEntries
      .filter((hour) => ['partial', 'gap', 'offline', 'failed', 'stale'].includes(hour.status))
      .map((hour) => hour.key);
    const pendingHours = expectedClosed
      .filter((hour) => {
        const entry = entriesByKey.get(hour.key);
        return !entry || entry.status !== 'verified';
      })
      .map((hour) => hour.key);
    const current = entriesByKey.get(currentKey) || null;
    const verifiedEntries = closedEntries.filter((hour) => hour.status === 'verified');
    const verifiedUntil = (() => {
      // Walk all expected closed hours in start-time order from midnight and stop
      // at the first gap (hour not verified). This prevents reporting a time
      // beyond an unverified hole (e.g. 9–10 verified, 11–12 gap, 12–1 verified
      // must NOT report "verified until 1pm").
      let lastVerifiedEnd = null;
      for (const closedHour of expectedClosed) {
        const entry = entriesByKey.get(closedHour.key);
        if (!entry || entry.status !== 'verified') {
          break;
        }
        lastVerifiedEnd = entry.end_time;
      }
      return lastVerifiedEnd;
    })();

    return {
      schema_version: SCHEMA_VERSION,
      date: bounds.date,
      range_start: bounds.startTime,
      range_end: bounds.endTime,
      generated_at: new Date().toISOString(),
      source: 'live-day-truth',
      verified_until: verifiedUntil,
      current_hour: current,
      hours,
      summary: this._mergeSummary(bounds, this._summaryEligibleHours(hours, currentKey)),
      cache: {
        hour_count: hours.length,
        expected_hours: expected.length,
        closed_expected_hours: expectedClosed.length,
        verified_hours: verifiedEntries.length,
        missing_hours: missingHours,
        pending_hours: pendingHours,
        gap_hours: gapHours,
        complete: pendingHours.length === 0 && gapHours.length === 0,
        current_status: current?.status || 'pending'
      },
      health: this._health({ current, pendingHours, gapHours, missingHours, entriesByKey })
    };
  }

  _health({ current, pendingHours, gapHours, missingHours, entriesByKey }) {
    if (current?.status === 'offline') {
      return {
        status: 'attention',
        label: 'Capture offline',
        detail: current.status_detail || 'Current capture is offline.'
      };
    }
    const blockingGapHours = gapHours.filter((key) => {
      const entry = entriesByKey?.get?.(key);
      return !this._hasLocalTelemetryEvidence(entry?.summary || {});
    });
    if (blockingGapHours.length) {
      return {
        status: 'checking',
        label: `${blockingGapHours.length} review gap${blockingGapHours.length === 1 ? '' : 's'}`,
        detail: `No local telemetry evidence is available for ${blockingGapHours.length} closed hour(s); these rows are not counted as PC Available.`
      };
    }
    if (missingHours.length || pendingHours.length) {
      return {
        status: 'checking',
        label: 'Checking day',
        detail: `${pendingHours.length} closed hour(s) still need verification.`
      };
    }
    if (gapHours.length) {
      return {
        status: 'checking',
        label: `${gapHours.length} review gap${gapHours.length === 1 ? '' : 's'}`,
        detail: `Closed hour evidence is incomplete for ${gapHours.length} hour(s), but local telemetry keeps PC Available and Work Hours accounted.`
      };
    }
    return {
      status: 'ok',
      label: 'Truth verified',
      detail: 'Closed hours are verified; current hour is being captured.'
    };
  }

  _nextClosedHourToVerify(day, bounds, now) {
    const currentKey = this._hourKey(now);
    const nowMs = new Date(now).getTime();
    const hours = this._hourRanges(bounds.startTime, bounds.endTime)
      .filter((hour) => hour.key !== currentKey)
      .reverse();
    return hours.find((hour) => {
      const entry = day.hours[hour.key];
      if (!entry) {
        return true;
      }
      if (entry.status === 'verified' && entry.sync_complete === true) {
        return false;
      }
      const retryAtMs = new Date(entry.next_retry_after || 0).getTime();
      return !Number.isFinite(retryAtMs) || retryAtMs <= nowMs;
    }) || null;
  }

  _currentHourStatus({ captureRunning, captureUnknown, records, sync }) {
    if (!captureRunning) {
      return 'offline';
    }
    if (captureUnknown && this._queryLooksOffline(sync, records)) {
      return 'offline';
    }
    return 'capturing';
  }

  _closedHourStatus({ captureRunning, captureUnknown, coverageComplete, records, sync }) {
    if (coverageComplete) {
      return 'verified';
    }
    if (!captureRunning) {
      return 'offline';
    }
    if (captureUnknown && this._queryLooksOffline(sync, records)) {
      return 'offline';
    }
    const windows = Array.isArray(sync?.windows) ? sync.windows : [];
    if (!records?.length && windows.some((window) => window.fetch_failed)) {
      return 'gap';
    }
    return records?.length ? 'partial' : 'stale';
  }

  _statusDetail(status, { sync, captureRunning, captureUnknown }) {
    if (status === 'verified') {
      return null;
    }
    if (status === 'capturing') {
      return null;
    }
    if (!captureRunning || status === 'offline') {
      return captureUnknown
        ? 'Capture API did not respond during verification.'
        : 'Capture API was offline during verification.';
    }
    if (status === 'gap') {
      return 'Screenpipe query failed and no local evidence exists for this hour.';
    }
    if (status === 'partial') {
      return 'Some activity exists, but Screenpipe coverage is incomplete.';
    }
    if (sync?.incomplete_window_count) {
      return `${sync.incomplete_window_count} sync window(s) are incomplete.`;
    }
    return 'Hour is waiting for verification.';
  }

  _applyVerificationAttempt(entry, previous, status) {
    const nowIso = new Date().toISOString();
    const previousAttempts = Math.max(0, Number(previous?.verification_attempts || 0));
    entry.last_attempt_at = nowIso;
    if (status === 'verified') {
      entry.verification_attempts = previousAttempts;
      entry.next_retry_after = null;
      return entry;
    }

    const attempts = previousAttempts + 1;
    entry.verification_attempts = attempts;
    entry.next_retry_after = new Date(Date.now() + this._retryDelayMs(status, attempts)).toISOString();
    return entry;
  }

  _withRuntimeAvailabilityEvidence(entry, options = {}) {
    if (!entry?.summary || !entry.start_time || !entry.end_time) {
      return entry;
    }
    const rangeStart = options.startTime || entry.start_time;
    const rangeEnd = options.endTime || entry.end_time;
    const startMs = new Date(rangeStart).getTime();
    const endMs = new Date(rangeEnd).getTime();
    const expandedRange = Number.isFinite(startMs) && Number.isFinite(endMs) && endMs > startMs
      ? Math.max(1, Math.round((endMs - startMs) / MINUTE_MS))
      : 0;
    const runtimeMinutes = this.services.runtimeAvailability?.getAvailableMinutes?.(rangeStart, rangeEnd) || 0;
    if (runtimeMinutes <= 0) {
      return entry;
    }
    const summary = { ...entry.summary };
    const active = this._metricValue(summary.active_minutes, summary.estimated_active_minutes);
    const idle = this._policyIdleMinutes(summary);
    const manual = this._metricValue(
      summary.manual_net_added_work_minutes,
      Number(summary.manual_timing_blocks?.net_added_work_minutes || 0) +
        Number(summary.manual_timing_blocks?.net_added_meeting_minutes || 0)
    );
    const captured = this._metricValue(summary.captured_minutes_estimate);
    const range = Math.max(this._metricValue(summary.range_minutes, runtimeMinutes), expandedRange);
    const localAvailable = Math.min(range, Math.max(active + idle, captured));
    const hasInputStateEvidence = localAvailable > 0 || manual > 0;
    const available = hasInputStateEvidence
      ? Math.min(range, Math.max(localAvailable, runtimeMinutes))
      : 0;
    const accounted = hasInputStateEvidence
      ? Math.max(this._metricValue(summary.accounted_minutes), available, active + idle, captured)
      : Math.max(active + idle, captured);
    const ledger = buildWorkHoursLedger({
      pcAvailableMinutes: available,
      idleMinutes: idle,
      manualAddedMinutes: manual,
      rangeMinutes: range
    });

    summary.range_start = rangeStart;
    summary.range_end = rangeEnd;
    summary.range_minutes = range;
    summary.runtime_available_minutes = Math.max(this._metricValue(summary.runtime_available_minutes), runtimeMinutes);
    summary.pc_available_source = runtimeMinutes > 0 ? 'runtime_availability' : 'local_collector_evidence';
    summary.gross_pc_available_minutes = ledger.pc_available_minutes;
    summary.accounted_minutes = Math.min(range, accounted);
    summary.missing_minutes = Math.max(0, range - summary.accounted_minutes);
    summary.coverage_complete = range > 0 && summary.missing_minutes === 0;
    summary.coverage_percent = range > 0 ? Math.min(100, Math.round((summary.accounted_minutes / range) * 100)) : 0;
    summary.manual_net_added_work_minutes = ledger.manual_restored_minutes;
    summary.work_minutes = ledger.work_minutes;
    summary.work_minutes_breakdown = {
      ...(summary.work_minutes_breakdown || {}),
      pc_active_work_minutes: ledger.pc_available_work_minutes,
      gross_pc_available_minutes: ledger.pc_available_minutes,
      idle_minutes: ledger.idle_deducted_minutes,
      manual_net_added_minutes: ledger.manual_restored_minutes,
      total_work_minutes: ledger.work_minutes
    };
    return { ...entry, start_time: rangeStart, end_time: rangeEnd, summary: this._compactSummary(summary) };
  }

  _finalizeStatusWithLocalEvidence(entry, { current = false } = {}) {
    const summary = entry?.summary || {};
    if (current && ['offline', 'stale', 'gap'].includes(entry.status) && this._hasLocalTelemetryEvidence(summary)) {
      return {
        ...entry,
        status: 'capturing',
        status_detail: null
      };
    }
    if (!current && entry.status !== 'verified' && summary.coverage_complete === true) {
      return {
        ...entry,
        status: 'verified',
        status_detail: null,
        sync_complete: true
      };
    }
    return entry;
  }

  _hasLocalTelemetryEvidence(summary = {}) {
    return this._hasCollectorEvidence(summary) || Number(summary.runtime_available_minutes || 0) > 0;
  }

  _hasCollectorEvidence(summary = {}) {
    return (
      Number(summary.activity_events || 0) > 0 ||
      Number(summary.focus_backed_activity_events || 0) > 0 ||
      Number(summary.captured_activity_events || 0) > 0 ||
      this._policyIdleMinutes(summary) > 0 ||
      Number(summary.manual_timing_event_count || summary.manual_timing_blocks?.event_count || 0) > 0
    );
  }

  _retryDelayMs(status, attempts) {
    const multiplier = Math.max(1, Math.min(4, Number(attempts || 1)));
    const base = status === 'offline' ? this.retryBaseMs * 2 : this.retryBaseMs;
    return Math.min(this.retryMaxMs, base * multiplier);
  }

  _queryLooksOffline(sync = {}, records = []) {
    if (Array.isArray(records) && records.length) {
      return false;
    }
    const windows = Array.isArray(sync?.windows) ? sync.windows : [];
    return windows.length > 0 && windows.every((window) => (
      window.fetch_failed && !window.budget_exhausted
    ));
  }

  _summaryEligibleHours(hours = [], currentKey = '') {
    return hours.filter((hour) => {
      if (!hour?.summary) {
        return false;
      }
      if (hour.status === 'verified' || (hour.key === currentKey && hour.status === 'capturing')) {
        return true;
      }
      // Verification status is diagnostic. If local focus/activity/idle/manual telemetry exists,
      // the hour still contributes to PC Available and Work Hours; missing evidence is review-only.
      return this._hasLocalTelemetryEvidence(hour.summary);
    });
  }

  _buildMinuteTruthSummary(hour, records = [], options = {}) {
    const startMs = new Date(hour.startTime).getTime();
    const endMs = new Date(hour.endTime).getTime();
    const rangeMinutes = Number.isFinite(startMs) && Number.isFinite(endMs) && endMs > startMs
      ? Math.max(1, Math.round((endMs - startMs) / MINUTE_MS))
      : 0;
    const rawIdleIntervals = this._normalizeIntervals(options.idleIntervals || [], startMs, endMs);
    const runtimeAvailabilityIntervals = this._normalizeIntervals(options.runtimeAvailabilityIntervals || [], startMs, endMs);
    const passiveWorkIntervals = this._normalizePassiveWorkIntervals(options.passiveWorkIntervals || [], startMs, endMs);
    const idleIntervals = rawIdleIntervals;
    const focusIntervals = this._normalizeIntervals(options.focusIntervals || [], startMs, endMs)
      .map((interval) => ({ ...interval, source: 'focus' }));
    const summaryDateKey = this._dateKey(new Date(startMs));
    const visibleRecords = records.filter((record) => this._isVisibleRecord(record));
    const manualRecords = visibleRecords.filter((record) => (
      this._isManualRecord(record) && this._manualRecordBelongsToDate(record, summaryDateKey)
    ));
    const pcRecords = visibleRecords.filter((record) => !this._isManualRecord(record));
    const pcWindows = this._pcAllocationWindows(pcRecords, startMs, endMs)
      .map((window) => ({ ...window, source: 'pc' }));
    const focusWindows = focusIntervals.map((interval) => ({
      startMs: interval.startMs,
      endMs: interval.endMs,
      source: 'focus',
      record: {
        source: 'windows_focus_evidence',
        activity_type: 'focus_evidence',
        app_name: interval.process_name || '',
        window_title: interval.window_title || '',
        timestamp_start: new Date(interval.startMs).toISOString(),
        timestamp_end: new Date(interval.endMs).toISOString(),
        duration_ms_estimate: interval.endMs - interval.startMs
      }
    }));
    const slots = this._minuteSlots(startMs, endMs);
    const minuteStats = new Map(slots.map((slot) => [slot.key, {
      ...slot,
      idleMs: this._overlapMs(slot.startMs, slot.endMs, idleIntervals),
      capturedMs: 0,
      confirmedNonWorkMs: 0,
      classMs: this._emptyClassified(),
      appMs: new Map()
    }]));

    pcWindows.forEach((window) => this._addWindowEvidence(window, minuteStats, { captured: true }));
    focusWindows.forEach((window) => this._addWindowEvidence(window, minuteStats, { captured: false }));

    const activeMinuteKeys = new Set();
    const capturedMinuteKeys = new Set();
    const idleMinuteKeys = new Set();
    const classifiedMinutes = this._emptyClassified();
    const confirmedNonWorkMinuteKeys = new Set();
    const appTimeline = new Map();

    minuteStats.forEach((stat, key) => {
      if (stat.capturedMs >= ACTIVE_MINUTE_THRESHOLD_MS) {
        capturedMinuteKeys.add(key);
      }
      const classifiedMs = CLASSIFICATION_KEYS.reduce((sum, item) => sum + Number(stat.classMs[item] || 0), 0);
      const idle = stat.idleMs >= ACTIVE_MINUTE_THRESHOLD_MS;
      if (classifiedMs >= ACTIVE_MINUTE_THRESHOLD_MS && !idle) {
        activeMinuteKeys.add(key);
        const classification = this._dominantClassification(stat.classMs);
        classifiedMinutes[classification] += 1;
        if (stat.confirmedNonWorkMs >= ACTIVE_MINUTE_THRESHOLD_MS) {
          confirmedNonWorkMinuteKeys.add(key);
        }
        const appName = this._dominantAppName(stat.appMs);
        if (appName) {
          this._addAppTimelineMinute(appTimeline, appName, classification);
        }
      } else if (idle) {
        idleMinuteKeys.add(key);
      }
    });

    const manualTimingBlocks = this._manualTimingSummary(manualRecords, {
      startMs,
      endMs,
      idleIntervals,
      pcActiveMinuteKeys: activeMinuteKeys
    });
    const manualMeetingItems = this._manualMeetingItems(manualTimingBlocks);
    const activeMinutes = activeMinuteKeys.size;
    const focusMinutes = Math.min(activeMinutes, classifiedMinutes.work);
    const pcWorkMinutes = focusMinutes;
    const messagingMinutes = Math.max(0, Math.round(Number(classifiedMinutes.meeting || 0))) +
      Math.max(0, Math.round(Number(manualTimingBlocks.meeting_minutes || 0)));
    const socialMinutes = Math.max(0, Math.round(Number(classifiedMinutes.social || 0)));
    const otherMinutes = Math.max(0, Math.round(Number(classifiedMinutes.other || 0)));
    const unclearMinutes = Math.max(0, Math.round(Number(classifiedMinutes.unclear || 0)));
    const idleMinutes = idleMinuteKeys.size;
    const rawInputIdleMinutes = this._intervalMinutes(rawIdleIntervals);
    const runtimeAvailableMinutes = this._intervalMinutes(runtimeAvailabilityIntervals);
    const passiveWorkCandidateMinutes = this._intervalMinutes(passiveWorkIntervals);
    const manualNetWorkMinutes = manualTimingBlocks.net_added_minutes;
    const confirmedNonWorkMinutes = Math.min(activeMinutes, confirmedNonWorkMinuteKeys.size);
    const capturedMinutes = Math.min(rangeMinutes, capturedMinuteKeys.size);
    // PC Available prefers Cognify runtime pulses. Without runtime evidence,
    // fall back only to concrete local collector evidence, never to missing gaps.
    const grossPcAvailableMinutes = runtimeAvailabilityIntervals.length
      ? Math.max(0, Math.min(rangeMinutes, runtimeAvailableMinutes))
      : Math.max(0, Math.min(rangeMinutes, Math.max(activeMinutes + idleMinutes, capturedMinutes)));
    const pcAvailableSource = runtimeAvailabilityIntervals.length
      ? 'runtime_availability'
      : (grossPcAvailableMinutes > 0 ? 'local_collector_evidence' : 'none');
    const coverage = this._minuteCoverageSummary({
      rangeMinutes,
      capturedMinutes,
      activeMinutes,
      idleMinutes,
      availableMinutes: grossPcAvailableMinutes
    });
    const workLedger = buildWorkHoursLedger({
      pcAvailableMinutes: grossPcAvailableMinutes,
      idleMinutes: coverage.input_idle_minutes,
      manualAddedMinutes: manualNetWorkMinutes,
      rangeMinutes
    });
    // Work Hours = PC Available - idle + manual work/meeting minutes that overlapped idle slots.
    const pcAvailableWorkMinutes = workLedger.pc_available_work_minutes;
    const apps = this._unique([
      ...pcRecords.map((record) => record.app_name),
      ...focusIntervals.map((interval) => interval.process_name)
    ]);
    const websites = this._unique(pcRecords.map((record) => record.url_if_available).filter(Boolean));

    return {
      source: 'live-truth-minute-rollup',
      official_time_source: 'live-truth-minute-rollup',
      pc_available_source: pcAvailableSource,
      activity_events: pcWindows.length + focusWindows.length,
      captured_activity_events: pcRecords.length,
      focus_backed_activity_events: focusWindows.length,
      manual_timing_event_count: manualRecords.length,
      major_work_blocks: [],
      apps_used: apps,
      app_display_names: apps.map((app) => this._displayAppName(app)),
      app_timeline: Array.from(appTimeline.values()),
      websites_visited: websites,
      browser_activity: {
        event_count: pcRecords.filter((record) => this._isBrowserRecord(record)).length,
        sites: websites,
        windows: this._unique(pcRecords.filter((record) => this._isBrowserRecord(record)).map((record) => record.window_title).filter(Boolean)),
        apps: this._unique(pcRecords.filter((record) => this._isBrowserRecord(record)).map((record) => record.app_name).filter(Boolean))
      },
      files_documents_seen: this._unique(pcRecords.map((record) => record.file_path_if_available).filter(Boolean)),
      meetings_or_calls: {
        event_count: messagingMinutes,
        total_minutes: messagingMinutes,
        items: manualMeetingItems
      },
      important_decisions: [],
      tasks_created: [],
      pending_follow_ups: [],
      range_start: hour.startTime,
      range_end: hour.endTime,
      range_minutes: rangeMinutes,
      raw_input_idle_minutes: rawInputIdleMinutes,
      runtime_available_minutes: grossPcAvailableMinutes,
      passive_work_candidate_minutes: passiveWorkCandidateMinutes,
      input_idle_minutes: coverage.input_idle_minutes,
      idle_adjusted: idleIntervals.length > 0,
      focus_adjusted: focusIntervals.length > 0,
      focus_evidence: {
        interval_count: focusIntervals.length,
        total_minutes: this._intervalMinutes(focusIntervals),
        backed_minutes: Math.min(activeMinutes, this._intervalMinutes(focusIntervals)),
        apps: this._unique(focusIntervals.map((interval) => interval.process_name).filter(Boolean))
      },
      measurement_confidence: this._measurementConfidenceSummary({
        rangeMinutes,
        capturedMinutes,
        activeMinutes,
        inputIdleMinutes: coverage.input_idle_minutes,
        rawInputIdleMinutes,
        passiveWorkCandidateMinutes,
        missingMinutes: coverage.missing_minutes,
        focusBackedEventCount: focusWindows.length
      }),
      captured_minutes_estimate: capturedMinutes,
      accounted_minutes: coverage.accounted_minutes,
      gross_pc_available_minutes: grossPcAvailableMinutes,
      missing_minutes: coverage.missing_minutes,
      coverage_complete: coverage.coverage_complete,
      coverage_percent: coverage.coverage_percent,
      minute_partition: coverage.minute_partition,
      passive_candidate_minutes: coverage.passive_candidate_minutes,
      active_minutes: activeMinutes,
      estimated_active_minutes: activeMinutes,
      estimated_active_label: this._formatDuration(activeMinutes),
      focus_minutes: focusMinutes,
      messaging_minutes: messagingMinutes,
      social_minutes: socialMinutes,
      idle_minutes: coverage.input_idle_minutes,
      other_minutes: otherMinutes,
      unclear_minutes: unclearMinutes,
      pc_work_minutes: pcWorkMinutes,
      pc_messaging_minutes: classifiedMinutes.meeting,
      confirmed_non_work_minutes: confirmedNonWorkMinutes,
      manual_timing_blocks: manualTimingBlocks,
      manual_timing_minutes: manualTimingBlocks.total_minutes,
      manual_net_added_work_minutes: workLedger.manual_restored_minutes,
      work_minutes: workLedger.work_minutes,
      work_label: this._formatDuration(workLedger.work_minutes),
      work_minutes_breakdown: {
        pc_work_minutes: pcWorkMinutes,
        pc_messaging_minutes: classifiedMinutes.meeting,
        pc_active_work_minutes: pcAvailableWorkMinutes,
        gross_pc_available_minutes: grossPcAvailableMinutes,
        idle_minutes: workLedger.idle_deducted_minutes,
        confirmed_non_work_minutes: confirmedNonWorkMinutes,
        manual_net_added_minutes: workLedger.manual_restored_minutes,
        total_work_minutes: workLedger.work_minutes
      },
      pc_classified_minutes: classifiedMinutes,
      classified_minutes: classifiedMinutes,
      focus_score: this._focusScore({ work: focusMinutes }, activeMinutes),
      time_distribution_estimate: {},
      possible_distractions: websites.filter((url) => /youtube|reddit|x\.com|facebook/i.test(url)),
      recommended_next_actions: []
    };
  }

  _addWindowEvidence(window = {}, minuteStats = new Map(), { captured = false } = {}) {
    const classificationResult = this._classifyRecord(window.record);
    const classification = this._classificationKey(classificationResult.classification || classificationResult);
    const isConfirmedNonWork = this._isConfirmedNonWorkClassification(classificationResult);
    const appName = window.record?.app_name || window.record?.process_name || '';
    // Compute the hour's start from the first slot key so we can derive slot indices.
    const firstSlotKey = minuteStats.keys().next().value;
    if (!firstSlotKey) {
      return;
    }
    const hourStartMs = new Date(firstSlotKey).getTime();
    if (!Number.isFinite(hourStartMs) || !Number.isFinite(window.startMs) || !Number.isFinite(window.endMs)) {
      return;
    }
    const firstSlot = Math.max(0, Math.floor((window.startMs - hourStartMs) / MINUTE_MS));
    const lastSlot = Math.min(minuteStats.size - 1, Math.floor((window.endMs - hourStartMs) / MINUTE_MS));
    if (firstSlot > lastSlot) {
      return;
    }
    const slotKeys = Array.from(minuteStats.keys());
    for (let index = firstSlot; index <= lastSlot; index += 1) {
      const stat = minuteStats.get(slotKeys[index]);
      if (!stat) {
        continue;
      }
      const overlap = this._overlapMs(stat.startMs, stat.endMs, [window]);
      if (overlap <= 0) {
        continue;
      }
      if (captured) {
        stat.capturedMs += overlap;
      }
      if (stat.idleMs >= ACTIVE_MINUTE_THRESHOLD_MS) {
        continue;
      }
      stat.classMs[classification] += overlap;
      if (isConfirmedNonWork) {
        stat.confirmedNonWorkMs += overlap;
      }
      if (appName) {
        stat.appMs.set(appName, (stat.appMs.get(appName) || 0) + overlap);
      }
    }
  }

  _pcAllocationWindows(records = [], startMs, endMs) {
    const sorted = records
      .map((record) => ({ record, timeMs: this._recordStartMs(record) }))
      .filter((item) => Number.isFinite(item.timeMs))
      .sort((left, right) => left.timeMs - right.timeMs);
    const windows = sorted.map((item) => ({
      record: item.record,
      startMs: item.timeMs,
      endMs: item.timeMs
    }));

    if (!windows.length) {
      return [];
    }
    if (windows.length === 1) {
      windows[0].endMs = windows[0].startMs + ACTIVE_MINUTE_THRESHOLD_MS;
      return this._clipWindows(windows, startMs, endMs);
    }

    windows[0].startMs = Math.min(windows[0].startMs, sorted[0].timeMs - 15000);
    windows[windows.length - 1].endMs = Math.max(
      windows[windows.length - 1].endMs,
      sorted[sorted.length - 1].timeMs + 15000
    );

    for (let index = 0; index < sorted.length - 1; index += 1) {
      const current = sorted[index].timeMs;
      const next = sorted[index + 1].timeMs;
      const gapMs = Math.min(Math.max(0, next - current), 2 * MINUTE_MS);
      const leftShare = Math.floor(gapMs / 2);
      const rightShare = gapMs - leftShare;
      windows[index].endMs = Math.max(windows[index].endMs, current + leftShare);
      windows[index + 1].startMs = Math.min(windows[index + 1].startMs, next - rightShare);
    }

    return this._clipWindows(windows, startMs, endMs);
  }

  _clipWindows(windows = [], startMs, endMs) {
    return windows
      .map((window) => ({
        ...window,
        startMs: Math.max(window.startMs, startMs),
        endMs: Math.min(window.endMs, endMs)
      }))
      .filter((window) => (
        Number.isFinite(window.startMs) &&
        Number.isFinite(window.endMs) &&
        window.endMs > window.startMs
      ));
  }

  _manualTimingSummary(records = [], options = {}) {
    const startMs = Number(options.startMs);
    const endMs = Number(options.endMs);
    const idleIntervals = options.idleIntervals || [];
    const pcActiveMinuteKeys = options.pcActiveMinuteKeys || new Set();
    const kindMinutes = {
      work: new Set(),
      meeting: new Set(),
      break: new Set(),
      other: new Set()
    };
    const allManualMinutes = new Set();
    const netWorkMinutes = new Set();
    const netMeetingMinutes = new Set();
    const overlappingPcMinutes = new Set();
    const idleOverlapMinutes = new Set();
    const items = [];

    records.forEach((record) => {
      const interval = this._recordIntervalMs(record);
      if (!Number.isFinite(interval.startMs) || !Number.isFinite(interval.endMs) || interval.endMs <= interval.startMs) {
        return;
      }
      const clippedStartMs = Number.isFinite(startMs) ? Math.max(interval.startMs, startMs) : interval.startMs;
      const clippedEndMs = Number.isFinite(endMs) ? Math.min(interval.endMs, endMs) : interval.endMs;
      if (clippedEndMs <= clippedStartMs) {
        return;
      }
      const kind = this._manualRecordKind(record);
      const minuteKeys = this._minuteSlots(clippedStartMs, clippedEndMs)
        .filter((minute) => this._overlapMs(minute.startMs, minute.endMs, [{ startMs: clippedStartMs, endMs: clippedEndMs }]) >= ACTIVE_MINUTE_THRESHOLD_MS)
        .map((minute) => minute.key);
      minuteKeys.forEach((key) => {
        allManualMinutes.add(key);
        kindMinutes[kind].add(key);
        const overlapsIdle = this._minuteOverlapsIntervals(key, idleIntervals);
        if (pcActiveMinuteKeys.has(key)) {
          overlappingPcMinutes.add(key);
        }
        if (overlapsIdle) {
          idleOverlapMinutes.add(key);
        }
        if (kind === 'work' && overlapsIdle) {
          netWorkMinutes.add(key);
        }
        if (kind === 'meeting' && overlapsIdle) {
          netMeetingMinutes.add(key);
        }
      });
      items.push({
        start: new Date(clippedStartMs).toISOString(),
        end: new Date(clippedEndMs).toISOString(),
        kind,
        title: record.window_title || record.ocr_text || record.app_name || 'Manual Timing Block',
        minutes: minuteKeys.length,
        net_added_minutes: minuteKeys.filter((key) => (
          (kind === 'work' || kind === 'meeting') && this._minuteOverlapsIntervals(key, idleIntervals)
        )).length,
        overlapping_pc_active_minutes: minuteKeys.filter((key) => pcActiveMinuteKeys.has(key)).length
      });
    });

    return {
      event_count: records.length,
      total_minutes: allManualMinutes.size,
      work_minutes: kindMinutes.work.size,
      meeting_minutes: kindMinutes.meeting.size,
      break_minutes: kindMinutes.break.size,
      other_minutes: kindMinutes.other.size,
      net_added_work_minutes: netWorkMinutes.size,
      net_added_meeting_minutes: netMeetingMinutes.size,
      net_added_minutes: netWorkMinutes.size + netMeetingMinutes.size,
      overlapping_pc_active_minutes: overlappingPcMinutes.size,
      idle_overlap_minutes: idleOverlapMinutes.size,
      items
    };
  }

  _minuteCoverageSummary({ rangeMinutes = 0, capturedMinutes = 0, activeMinutes = 0, idleMinutes = 0, availableMinutes = null } = {}) {
    const range = Math.max(0, Math.round(Number(rangeMinutes) || 0));
    const active = Math.min(range, Math.max(0, Math.round(Number(activeMinutes) || 0)));
    const idle = Math.min(
      Math.max(0, Math.round(Number(idleMinutes) || 0)),
      Math.max(0, range - active)
    );
    const captured = Math.min(range, Math.max(0, Math.round(Number(capturedMinutes) || 0)));
    const available = availableMinutes === null || availableMinutes === undefined
      ? 0
      : Math.min(range, Math.max(0, Math.round(Number(availableMinutes) || 0)));
    const accounted = Math.min(range, Math.max(captured, active + idle, available));
    const missing = Math.max(0, range - accounted);
    return {
      input_idle_minutes: idle,
      accounted_minutes: accounted,
      gross_pc_available_minutes: available,
      missing_minutes: missing,
      coverage_complete: range > 0 && missing === 0,
      coverage_percent: range > 0 ? Math.min(100, Math.round((accounted / range) * 100)) : 0,
      minute_partition: {
        active_minutes: active,
        passive_candidate_minutes: Math.max(0, captured - active),
        input_idle_minutes: idle,
        missing_minutes: missing
      },
      passive_candidate_minutes: Math.max(0, captured - active)
    };
  }

  _focusScore(classifiedMinutes = {}, activeMinutes = 0) {
    const totalActiveMinutes = Math.max(0, Math.round(Number(activeMinutes) || 0));
    const deepWorkMinutes = Math.min(totalActiveMinutes, Math.max(0, Math.round(Number(classifiedMinutes.work || 0))));
    const score = totalActiveMinutes > 0 ? deepWorkMinutes / totalActiveMinutes : 0;
    const scorePercent = Math.round(score * 100);
    return {
      deep_work_minutes: deepWorkMinutes,
      total_active_minutes: totalActiveMinutes,
      score,
      score_percent: scorePercent,
      label: totalActiveMinutes > 0 ? `${scorePercent}%` : '0%',
      formula: 'Deep Work / Total Active Time'
    };
  }

  _workMinutesFromAvailable(availableMinutes = 0, idleMinutes = 0) {
    return buildWorkHoursLedger({
      pcAvailableMinutes: availableMinutes,
      idleMinutes
    }).pc_available_work_minutes;
  }

  _confirmedNonWorkMinutes(summary = {}) {
    if (Number.isFinite(Number(summary.confirmed_non_work_minutes))) {
      return Math.max(0, Math.round(Number(summary.confirmed_non_work_minutes || 0)));
    }
    if (Number.isFinite(Number(summary.work_minutes_breakdown?.confirmed_non_work_minutes))) {
      return Math.max(0, Math.round(Number(summary.work_minutes_breakdown.confirmed_non_work_minutes || 0)));
    }
    return Math.max(0, Math.round(
      Number(summary.classified_minutes?.social || 0) + Number(summary.classified_minutes?.other || 0)
    ));
  }

  _addAppTimelineMinute(timeline = new Map(), appName = '', classification = 'unclear') {
    const key = appName || 'Unknown';
    if (!timeline.has(key)) {
      timeline.set(key, {
        app_id: key,
        app_name: key,
        dates: [],
        event_count: 0,
        total_time_ms_estimate: 0,
        total_time_minutes_estimate: 0,
        classified_ms: this._emptyClassified(),
        classified_minutes: this._emptyClassified(),
        classification,
        items: []
      });
    }
    const entry = timeline.get(key);
    const safeClassification = this._classificationKey(classification);
    entry.event_count += 1;
    entry.total_time_ms_estimate += MINUTE_MS;
    entry.total_time_minutes_estimate += 1;
    entry.classified_ms[safeClassification] += MINUTE_MS;
    entry.classified_minutes[safeClassification] += 1;
    entry.classification = this._dominantClassification(entry.classified_ms);
  }

  _dominantClassification(classified = {}) {
    const entries = CLASSIFICATION_KEYS
      .map((key) => ({ key, value: Number(classified[key] || 0) }))
      .sort((left, right) => right.value - left.value);
    if (!entries[0]?.value || entries[0].value === entries[1]?.value) {
      return 'unclear';
    }
    return entries[0].key;
  }

  _dominantAppName(appMs = new Map()) {
    return Array.from(appMs.entries())
      .sort((left, right) => Number(right[1] || 0) - Number(left[1] || 0))[0]?.[0] || '';
  }

  _classifyRecord(record = {}) {
    const existing = this._classificationKey(record.classification);
    if (existing !== 'unclear') {
      return {
        classification: existing,
        confidence: record.classification_confidence || (existing === 'social' ? 'high' : 'medium')
      };
    }
    if (record.meeting_flag) {
      return { classification: 'meeting', confidence: 'high' };
    }
    if (record.social_flag) {
      return { classification: 'social', confidence: 'high' };
    }
    if (this._isManualRecord(record)) {
      const kind = this._manualRecordKind(record);
      return {
        classification: kind === 'break' ? 'other' : this._classificationKey(kind),
        confidence: 'high'
      };
    }
    try {
      const result = this.services.classifier?.classifyRecord?.(record);
      if (result?.classification) {
        return {
          ...result,
          classification: this._classificationKey(result.classification)
        };
      }
    } catch {
      // Classification is advisory for the cheap truth rollup.
    }
    const text = `${record.app_name || ''} ${record.window_title || ''} ${record.url_if_available || ''}`.toLowerCase();
    if (/\b(teams|zoom|meet|slack|whatsapp|calendar|outlook)\b/.test(text)) {
      return { classification: 'meeting', confidence: 'medium' };
    }
    if (/\b(youtube|instagram|facebook|twitter|x\.com|reddit|netflix)\b/.test(text)) {
      return { classification: 'social', confidence: 'high' };
    }
    return { classification: 'unclear', confidence: 'low' };
  }

  _isConfirmedNonWorkClassification(result = {}) {
    const classification = this._classificationKey(result.classification || result);
    if (classification !== 'social' && classification !== 'other') {
      return false;
    }
    return String(result.confidence || '').toLowerCase() === 'high';
  }

  _classificationKey(value) {
    const normalized = String(value || 'unclear').toLowerCase();
    return CLASSIFICATION_KEYS.includes(normalized) ? normalized : 'unclear';
  }

  _manualRecordKind(record = {}) {
    const explicit = this._normalizeManualKind(record.manual_kind);
    if (explicit) {
      return explicit;
    }
    const text = `${record.app_name || ''} ${record.window_title || ''} ${record.ocr_text || ''}`.toLowerCase();
    if (/\b(meeting|call|chat)\b/.test(text)) {
      return 'meeting';
    }
    if (/\b(break|lunch|walk|away)\b/.test(text)) {
      return 'break';
    }
    if (/\b(other|manual entry)\b/.test(text)) {
      return 'other';
    }
    return 'work';
  }

  _normalizeManualKind(value) {
    const normalized = String(value || '').trim().toLowerCase();
    return ['work', 'meeting', 'break', 'other'].includes(normalized) ? normalized : '';
  }

  _manualRecordBelongsToDate(record = {}, dateKey = '') {
    if (!dateKey) {
      return true;
    }
    const explicit = String(record.manual_local_date_key || '').trim();
    if (explicit) {
      return explicit === dateKey;
    }
    const inferred = this._dateKey(new Date(record.timestamp_start || record.timestamp || record.timestamp_end || 0));
    return inferred === dateKey;
  }

  _isVisibleRecord(record = {}) {
    return record?.timestamp_start && !this._isExcludedAppName(record.app_name);
  }

  _isExcludedAppName(appName) {
    const normalized = String(appName || '').trim().toLowerCase().replace(/^\[|\]$/g, '');
    return normalized === 'system process';
  }

  _isManualRecord(record = {}) {
    return record.source === 'manual' || record.activity_type === 'manual' || record.type === 'manual';
  }

  _isBrowserRecord(record = {}) {
    return /chrome|edge|firefox|browser|brave|opera/i.test(record.app_name || '') || Boolean(record.url_if_available);
  }

  _recordStartMs(record = {}) {
    return new Date(record.timestamp_start || record.timestamp || record.timestamp_end || 0).getTime();
  }

  _recordIntervalMs(record = {}) {
    const startMs = this._recordStartMs(record);
    if (!Number.isFinite(startMs)) {
      return { startMs: Number.NaN, endMs: Number.NaN };
    }
    const explicitEndMs = new Date(record.timestamp_end || 0).getTime();
    const durationMs = Number(record.duration_ms_estimate || 0);
    const endMs = Math.max(
      Number.isFinite(explicitEndMs) ? explicitEndMs : startMs,
      startMs + Math.max(0, durationMs)
    );
    return { startMs, endMs: endMs > startMs ? endMs : startMs };
  }

  _normalizeIntervals(intervals = [], rangeStartMs, rangeEndMs) {
    return intervals
      .map((interval) => {
        const startMs = Number.isFinite(Number(interval.startMs))
          ? Number(interval.startMs)
          : new Date(interval.start || interval.start_time || interval.timestamp_start || 0).getTime();
        const endMs = Number.isFinite(Number(interval.endMs))
          ? Number(interval.endMs)
          : new Date(interval.end || interval.end_time || interval.timestamp_end || 0).getTime();
        return { ...interval, startMs, endMs };
      })
      .filter((interval) => (
        Number.isFinite(interval.startMs) &&
        Number.isFinite(interval.endMs) &&
        interval.endMs > interval.startMs
      ))
      .map((interval) => ({
        ...interval,
        startMs: Math.max(interval.startMs, rangeStartMs),
        endMs: Math.min(interval.endMs, rangeEndMs)
      }))
      .filter((interval) => interval.endMs > interval.startMs);
  }

  _normalizePassiveWorkIntervals(intervals = [], rangeStartMs, rangeEndMs) {
    return this._normalizeIntervals(intervals, rangeStartMs, rangeEndMs)
      .filter((interval) => {
        if (interval.passive_work_evidence !== true && interval.source !== 'focus_idle_work_evidence') {
          return false;
        }
        const classification = this._classificationKey(interval.classification);
        if (classification !== 'work' && classification !== 'meeting') {
          return false;
        }
        return String(interval.classification_confidence || '').toLowerCase() === 'high';
      });
  }

  _subtractIntervals(baseIntervals = [], subtractIntervals = []) {
    if (!subtractIntervals.length) {
      return baseIntervals;
    }
    const subtractors = this._mergeIntervalsByMs(subtractIntervals);
    const result = [];
    baseIntervals.forEach((base) => {
      let segments = [{ startMs: base.startMs, endMs: base.endMs }];
      subtractors.forEach((subtract) => {
        segments = segments.flatMap((segment) => {
          if (subtract.endMs <= segment.startMs || subtract.startMs >= segment.endMs) {
            return [segment];
          }
          const pieces = [];
          if (subtract.startMs > segment.startMs) {
            pieces.push({ startMs: segment.startMs, endMs: subtract.startMs });
          }
          if (subtract.endMs < segment.endMs) {
            pieces.push({ startMs: subtract.endMs, endMs: segment.endMs });
          }
          return pieces;
        });
      });
      segments
        .filter((segment) => segment.endMs > segment.startMs)
        .forEach((segment) => result.push({ ...base, startMs: segment.startMs, endMs: segment.endMs }));
    });
    return result;
  }

  _mergeIntervalsByMs(intervals = []) {
    const sorted = intervals
      .filter((interval) => Number.isFinite(interval.startMs) && Number.isFinite(interval.endMs) && interval.endMs > interval.startMs)
      .sort((left, right) => left.startMs - right.startMs);
    const merged = [];
    sorted.forEach((interval) => {
      const previous = merged[merged.length - 1];
      if (!previous || interval.startMs > previous.endMs) {
        merged.push({ startMs: interval.startMs, endMs: interval.endMs });
        return;
      }
      previous.endMs = Math.max(previous.endMs, interval.endMs);
    });
    return merged;
  }

  _minuteSlots(startMs, endMs) {
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return [];
    }
    const slots = [];
    const cursor = new Date(startMs);
    cursor.setSeconds(0, 0);
    while (cursor.getTime() < endMs) {
      const slotStartMs = cursor.getTime();
      const slotEndMs = Math.min(slotStartMs + MINUTE_MS, endMs);
      slots.push({
        key: new Date(slotStartMs).toISOString(),
        startMs: slotStartMs,
        endMs: slotEndMs
      });
      cursor.setTime(slotStartMs + MINUTE_MS);
    }
    return slots;
  }

  _minuteOverlapsIntervals(minuteKey, intervals = []) {
    const startMs = new Date(minuteKey).getTime();
    if (!Number.isFinite(startMs)) {
      return false;
    }
    return this._overlapMs(startMs, startMs + MINUTE_MS, intervals) >= ACTIVE_MINUTE_THRESHOLD_MS;
  }

  _overlapMs(startMs, endMs, intervals = []) {
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return 0;
    }
    return intervals.reduce((sum, interval) => {
      const overlapStart = Math.max(startMs, interval.startMs);
      const overlapEnd = Math.min(endMs, interval.endMs);
      return sum + Math.max(0, overlapEnd - overlapStart);
    }, 0);
  }

  _intervalMinutes(intervals = []) {
    return Math.round(intervals.reduce((sum, interval) => (
      sum + Math.max(0, Number(interval.endMs || 0) - Number(interval.startMs || 0))
    ), 0) / MINUTE_MS);
  }

  _measurementConfidenceSummary({
    rangeMinutes = 0,
    capturedMinutes = 0,
    activeMinutes = 0,
    inputIdleMinutes = 0,
    rawInputIdleMinutes = 0,
    passiveWorkCandidateMinutes = 0,
    missingMinutes = 0,
    focusBackedEventCount = 0
  } = {}) {
    const range = Math.max(0, Math.round(Number(rangeMinutes) || 0));
    const missing = Math.max(0, Math.round(Number(missingMinutes) || 0));
    const passive = Math.max(0, Math.round(Number(passiveWorkCandidateMinutes) || 0));
    const rawIdle = Math.max(0, Math.round(Number(rawInputIdleMinutes) || 0));
    let score = 100;
    if (range > 0) {
      score -= Math.min(45, Math.round((missing / range) * 60));
      score -= Math.min(10, Math.round((passive / range) * 15));
    }
    if (focusBackedEventCount > 0) {
      score -= 5;
    }
    score = Math.max(0, Math.min(100, score));
    const caveats = [];
    if (missing > 0) {
      caveats.push(`${missing}m had no capture/focus/idle evidence.`);
    }
    if (passive > 0) {
      caveats.push(`${passive}m input-idle had foreground work evidence, but idle was still deducted unless manually restored.`);
    }
    return {
      score,
      level: score >= 85 ? 'high' : (score >= 65 ? 'medium' : 'low'),
      range_minutes: range,
      captured_minutes: Math.max(0, Math.round(Number(capturedMinutes) || 0)),
      active_minutes: Math.max(0, Math.round(Number(activeMinutes) || 0)),
      input_idle_minutes: Math.max(0, Math.round(Number(inputIdleMinutes) || 0)),
      raw_input_idle_minutes: rawIdle,
      passive_work_candidate_minutes: passive,
      missing_minutes: missing,
      caveats
    };
  }

  _displayAppName(appName = '') {
    const clean = String(appName || '').trim();
    return clean.replace(/\.exe$/i, '') || clean;
  }

  _formatDuration(minutes) {
    const value = Math.max(0, Math.round(Number(minutes) || 0));
    if (value >= 60) {
      const hours = Math.floor(value / 60);
      const mins = value % 60;
      return mins ? `${hours}h ${mins}m` : `${hours}h`;
    }
    return `${value}m`;
  }

  _mergeSummary(bounds, hours) {
    const summaries = hours.map((hour) => hour.summary || {});
    const classified = this._mergeClassified(summaries.map((summary) => summary.classified_minutes));
    const estimatedActive = this._sum(summaries, (summary) => (
      this._metricValue(summary.active_minutes, summary.estimated_active_minutes)
    ));
    const focusMinutes = this._sum(summaries, (summary) => (
      this._metricValue(
        summary.focus_minutes,
        summary.focus_score?.deep_work_minutes,
        summary.pc_work_minutes,
        summary.classified_minutes?.work
      )
    ));
    const pcWork = this._sum(summaries, (summary) => (
      this._metricValue(
        summary.pc_work_minutes,
        summary.focus_minutes,
        summary.focus_score?.deep_work_minutes,
        summary.classified_minutes?.work
      )
    ));
    const pcMessaging = this._sum(summaries, (summary) => (
      this._metricValue(summary.pc_messaging_minutes, summary.classified_minutes?.meeting)
    ));
    const confirmedNonWork = this._sum(summaries, (summary) => this._confirmedNonWorkMinutes(summary));
    const rawInputIdle = this._sum(summaries, (summary) => (
      this._metricValue(summary.raw_input_idle_minutes, summary.input_idle_minutes)
    ));
    const runtimeAvailable = this._sum(summaries, (summary) => summary.runtime_available_minutes);
    const passiveWorkCandidate = this._sum(summaries, (summary) => summary.passive_work_candidate_minutes);
    const manualNet = this._sum(summaries, (summary) => (
      this._metricValue(
        summary.manual_net_added_work_minutes,
        Number(summary.manual_timing_blocks?.net_added_work_minutes || 0) +
          Number(summary.manual_timing_blocks?.net_added_meeting_minutes || 0)
      )
    ));
    const messagingMinutes = this._sum(summaries, (summary) => (
      this._metricValue(
        summary.messaging_minutes,
        Number(summary.classified_minutes?.meeting || 0) +
          Number(summary.manual_timing_blocks?.meeting_minutes || summary.manual_timing_blocks?.net_added_meeting_minutes || 0)
      )
    ));
    const meetingItems = summaries.flatMap((summary) => summary.meetings_or_calls?.items || []).slice(0, 80);
    const socialMinutes = this._sum(summaries, (summary) => (
      this._metricValue(summary.social_minutes, summary.classified_minutes?.social)
    ));
    const otherMinutes = this._sum(summaries, (summary) => (
      this._metricValue(summary.other_minutes, summary.classified_minutes?.other)
    ));
    const unclearMinutes = this._sum(summaries, (summary) => (
      this._metricValue(summary.unclear_minutes, summary.classified_minutes?.unclear)
    ));
    const rangeMinutes = Math.max(1, Math.round((new Date(bounds.endTime) - new Date(bounds.startTime)) / 60000));
    const idleMinutes = this._sum(summaries, (summary) => (
      this._policyIdleMinutes(summary)
    ));
    const capturedMinutes = this._sum(summaries, (summary) => summary.captured_minutes_estimate);
    // Closed-hour merge preserves PC Available separately from legacy active_minutes.
    const grossPcAvailableMinutes = Math.min(
      rangeMinutes,
      this._sum(summaries, (summary) => safePcAvailableMinutesFromSummary(summary))
    );
    const accounted = Math.min(rangeMinutes, Math.max(capturedMinutes, estimatedActive + idleMinutes, grossPcAvailableMinutes));
    const missing = Math.max(0, rangeMinutes - accounted);
    const workLedger = buildWorkHoursLedger({
      pcAvailableMinutes: grossPcAvailableMinutes,
      idleMinutes,
      manualAddedMinutes: manualNet,
      rangeMinutes
    });
    const pcAvailableWorkMinutes = workLedger.pc_available_work_minutes;

    return {
      source: 'live-truth-minute-rollup',
      official_time_source: 'live-truth-minute-rollup',
      pc_available_source: runtimeAvailable > 0 ? 'runtime_availability' : 'local_collector_evidence',
      activity_events: this._sum(summaries, (summary) => summary.activity_events),
      captured_activity_events: this._sum(summaries, (summary) => summary.captured_activity_events),
      apps_used: this._unique(summaries.flatMap((summary) => summary.apps_used || [])),
      app_display_names: this._unique(summaries.flatMap((summary) => summary.app_display_names || [])),
      websites_visited: this._unique(summaries.flatMap((summary) => summary.websites_visited || [])),
      range_start: bounds.startTime,
      range_end: bounds.endTime,
      range_minutes: rangeMinutes,
      runtime_available_minutes: runtimeAvailable,
      raw_input_idle_minutes: rawInputIdle,
      passive_work_candidate_minutes: passiveWorkCandidate,
      input_idle_minutes: idleMinutes,
      captured_minutes_estimate: capturedMinutes,
      accounted_minutes: accounted,
      gross_pc_available_minutes: grossPcAvailableMinutes,
      missing_minutes: missing,
      coverage_complete: missing === 0,
      coverage_percent: Math.min(100, Math.round((accounted / rangeMinutes) * 100)),
      active_minutes: estimatedActive,
      estimated_active_minutes: estimatedActive,
      focus_minutes: focusMinutes,
      messaging_minutes: messagingMinutes,
      social_minutes: socialMinutes,
      idle_minutes: idleMinutes,
      other_minutes: otherMinutes,
      unclear_minutes: unclearMinutes,
      pc_work_minutes: pcWork,
      pc_messaging_minutes: pcMessaging,
      confirmed_non_work_minutes: confirmedNonWork,
      manual_net_added_work_minutes: workLedger.manual_restored_minutes,
      work_minutes: workLedger.work_minutes,
      work_minutes_breakdown: {
        pc_work_minutes: pcWork,
        pc_messaging_minutes: pcMessaging,
        pc_active_work_minutes: pcAvailableWorkMinutes,
        gross_pc_available_minutes: workLedger.pc_available_minutes,
        idle_minutes: workLedger.idle_deducted_minutes,
        confirmed_non_work_minutes: confirmedNonWork,
        manual_net_added_minutes: workLedger.manual_restored_minutes,
        total_work_minutes: workLedger.work_minutes
      },
      meetings_or_calls: {
        event_count: messagingMinutes,
        total_minutes: messagingMinutes,
        items: meetingItems
      },
      classified_minutes: classified,
      measurement_confidence: this._measurementConfidenceSummary({
        rangeMinutes,
        capturedMinutes,
        activeMinutes: estimatedActive,
        inputIdleMinutes: idleMinutes,
        rawInputIdleMinutes: rawInputIdle,
        passiveWorkCandidateMinutes: passiveWorkCandidate,
        missingMinutes: missing
      }),
      focus_score: this._focusScore({ work: focusMinutes }, estimatedActive)
    };
  }

  _compactSummary(summary = {}) {
    const activeMinutes = this._metricValue(summary.active_minutes, summary.estimated_active_minutes);
    const reportedIdleMinutes = this._metricValue(summary.idle_minutes, summary.input_idle_minutes);
    const rawInputIdleMinutes = this._metricValue(summary.raw_input_idle_minutes, reportedIdleMinutes);
    const idleMinutes = Math.max(reportedIdleMinutes, rawInputIdleMinutes);
    const grossPcAvailableMinutes = safePcAvailableMinutesFromSummary(summary);
    const focusMinutes = this._metricValue(
      summary.focus_minutes,
      summary.focus_score?.deep_work_minutes,
      summary.pc_work_minutes,
      summary.classified_minutes?.work
    );
    const pcWorkMinutes = this._metricValue(
      summary.pc_work_minutes,
      summary.focus_minutes,
      summary.focus_score?.deep_work_minutes,
      summary.classified_minutes?.work
    );
    const pcMessagingMinutes = this._metricValue(summary.pc_messaging_minutes, summary.classified_minutes?.meeting);
    const manualNetWork = this._metricValue(
      summary.manual_net_added_work_minutes,
      Number(summary.manual_timing_blocks?.net_added_work_minutes || 0) +
        Number(summary.manual_timing_blocks?.net_added_meeting_minutes || 0)
    );
    const workLedger = buildWorkHoursLedger({
      pcAvailableMinutes: grossPcAvailableMinutes,
      idleMinutes,
      manualAddedMinutes: manualNetWork,
      rangeMinutes: summary.range_minutes
    });
    const pcActiveWorkMinutes = workLedger.pc_available_work_minutes;
    const workMinutes = workLedger.work_minutes;
    const messagingMinutes = this._metricValue(
      summary.messaging_minutes,
      Number(summary.classified_minutes?.meeting || 0) +
        Number(summary.manual_timing_blocks?.meeting_minutes || summary.manual_timing_blocks?.net_added_meeting_minutes || 0)
    );
    const socialMinutes = this._metricValue(summary.social_minutes, summary.classified_minutes?.social);
    const passiveWorkCandidateMinutes = this._metricValue(summary.passive_work_candidate_minutes);
    const otherMinutes = this._metricValue(summary.other_minutes, summary.classified_minutes?.other);
    const unclearMinutes = this._metricValue(summary.unclear_minutes, summary.classified_minutes?.unclear);
    const confirmedNonWorkMinutes = this._confirmedNonWorkMinutes(summary);
    return {
      source: summary.source || null,
      official_time_source: summary.official_time_source || null,
      activity_events: Number(summary.activity_events || 0),
      captured_activity_events: Number(summary.captured_activity_events || 0),
      focus_backed_activity_events: Number(summary.focus_backed_activity_events || 0),
      apps_used: summary.apps_used || [],
      app_display_names: summary.app_display_names || [],
      websites_visited: summary.websites_visited || [],
      meetings_or_calls: this._compactMeetings(summary.meetings_or_calls, messagingMinutes),
      range_start: summary.range_start,
      range_end: summary.range_end,
      range_minutes: Number(summary.range_minutes || 0),
      runtime_available_minutes: Number(summary.runtime_available_minutes || 0),
      pc_available_source: summary.pc_available_source || null,
      raw_input_idle_minutes: rawInputIdleMinutes,
      passive_work_candidate_minutes: passiveWorkCandidateMinutes,
      input_idle_minutes: idleMinutes,
      captured_minutes_estimate: Number(summary.captured_minutes_estimate || 0),
      accounted_minutes: Number(summary.accounted_minutes || 0),
      gross_pc_available_minutes: grossPcAvailableMinutes,
      missing_minutes: Number(summary.missing_minutes || 0),
      coverage_complete: Boolean(summary.coverage_complete),
      coverage_percent: Number(summary.coverage_percent || 0),
      active_minutes: activeMinutes,
      estimated_active_minutes: activeMinutes,
      focus_minutes: focusMinutes,
      messaging_minutes: messagingMinutes,
      social_minutes: socialMinutes,
      idle_minutes: idleMinutes,
      other_minutes: otherMinutes,
      unclear_minutes: unclearMinutes,
      pc_work_minutes: pcWorkMinutes,
      pc_messaging_minutes: pcMessagingMinutes,
      confirmed_non_work_minutes: confirmedNonWorkMinutes,
      pc_classified_minutes: summary.pc_classified_minutes || summary.classified_minutes || this._emptyClassified(),
      manual_timing_blocks: this._compactManualTimingBlocks(summary.manual_timing_blocks),
      manual_timing_minutes: Number(summary.manual_timing_minutes || summary.manual_timing_blocks?.total_minutes || 0),
      manual_net_added_work_minutes: workLedger.manual_restored_minutes,
      work_minutes: workMinutes,
      work_minutes_breakdown: {
        pc_work_minutes: pcWorkMinutes,
        pc_messaging_minutes: pcMessagingMinutes,
        pc_active_work_minutes: pcActiveWorkMinutes,
        gross_pc_available_minutes: workLedger.pc_available_minutes,
        idle_minutes: workLedger.idle_deducted_minutes,
        confirmed_non_work_minutes: confirmedNonWorkMinutes,
        manual_net_added_minutes: workLedger.manual_restored_minutes,
        total_work_minutes: workMinutes
      },
      classified_minutes: summary.classified_minutes || this._emptyClassified(),
      measurement_confidence: summary.measurement_confidence || this._measurementConfidenceSummary({
        rangeMinutes: Number(summary.range_minutes || 0),
        capturedMinutes: Number(summary.captured_minutes_estimate || 0),
        activeMinutes,
        inputIdleMinutes: idleMinutes,
        rawInputIdleMinutes,
        passiveWorkCandidateMinutes,
        missingMinutes: Number(summary.missing_minutes || 0)
      }),
      focus_score: this._focusScore({ work: focusMinutes }, activeMinutes)
    };
  }

  _compactManualTimingBlocks(blocks = {}) {
    return {
      event_count: Number(blocks.event_count || 0),
      total_minutes: Number(blocks.total_minutes || 0),
      work_minutes: Number(blocks.work_minutes || 0),
      meeting_minutes: Number(blocks.meeting_minutes || 0),
      break_minutes: Number(blocks.break_minutes || 0),
      other_minutes: Number(blocks.other_minutes || 0),
      net_added_work_minutes: Number(blocks.net_added_work_minutes || 0),
      net_added_meeting_minutes: Number(blocks.net_added_meeting_minutes || 0),
      net_added_minutes: Number(blocks.net_added_minutes || 0),
      overlapping_pc_active_minutes: Number(blocks.overlapping_pc_active_minutes || 0),
      idle_overlap_minutes: Number(blocks.idle_overlap_minutes || 0),
      items: (blocks.items || []).slice(0, 80)
    };
  }

  _manualMeetingItems(blocks = {}) {
    return (blocks.items || [])
      .filter((item) => item?.kind === 'meeting')
      .map((item) => ({
        title: item.title || 'Manual Meeting',
        start: item.start || null,
        end: item.end || null,
        minutes: Number(item.minutes || 0),
        total_time_minutes_estimate: Number(item.minutes || 0),
        net_added_minutes: Number(item.net_added_minutes || 0),
        source: 'manual',
        manual: true
      }))
      .filter((item) => item.minutes > 0)
      .slice(0, 80);
  }

  _compactMeetings(meetings = {}, fallbackMinutes = 0) {
    const items = (meetings.items || []).slice(0, 80);
    const totalMinutes = Number.isFinite(Number(meetings.total_minutes))
      ? Number(meetings.total_minutes || 0)
      : Number(fallbackMinutes || 0);
    return {
      event_count: Number(meetings.event_count || items.length || 0),
      total_minutes: totalMinutes,
      items
    };
  }

  _compactSync(sync = {}) {
    return {
      complete: Boolean(sync.complete),
      incomplete_window_count: Number(sync.incomplete_window_count || 0),
      windows: (sync.windows || []).map((window) => ({
        start_time: window.start_time,
        end_time: window.end_time,
        fetched_count: Number(window.fetched_count || 0),
        complete: Boolean(window.complete),
        fetch_failed: Boolean(window.fetch_failed),
        limit_hit: Boolean(window.limit_hit),
        budget_exhausted: Boolean(window.budget_exhausted),
        budget_reason: window.budget_reason || null
      })).slice(0, 80)
    };
  }

  _syncCoversRange(startTime, endTime, sync = {}) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return false;
    }
    const windows = (sync.windows || [])
      .filter((window) => window.complete)
      .map((window) => ({
        start: new Date(window.start_time).getTime(),
        end: new Date(window.end_time).getTime()
      }))
      .filter((window) => Number.isFinite(window.start) && Number.isFinite(window.end))
      .sort((left, right) => left.start - right.start);
    let coveredUntil = startMs;
    for (const window of windows) {
      if (window.end < coveredUntil) {
        continue;
      }
      if (window.start > coveredUntil + 1000) {
        return false;
      }
      coveredUntil = Math.max(coveredUntil, window.end);
      if (coveredUntil >= endMs - 1000) {
        return true;
      }
    }
    return false;
  }

  _storedRecords(startTime, endTime) {
    return this.services.activityStore?.queryRange?.(startTime, endTime) || [];
  }

  _syncSummary(startTime, endTime) {
    return this.services.activityStore?.getSyncSummary?.(startTime, endTime) || {
      complete: false,
      incomplete_window_count: 0,
      windows: []
    };
  }

  _cachedCaptureStatus() {
    const status = this.services.screenpipe?.getCachedStatus?.() || {};
    const hasKnownStatus = Object.prototype.hasOwnProperty.call(status, 'running') ||
      Object.prototype.hasOwnProperty.call(status, 'apiAvailable') ||
      Object.prototype.hasOwnProperty.call(status, 'pending');
    if (!hasKnownStatus || status.pending === true) {
      return {
        running: false,
        unknown: true,
        detail: status.lastError || status.searchError || null
      };
    }
    return {
      running: status.running !== false && status.apiAvailable !== false,
      unknown: false,
      detail: status.lastError || status.searchError || null
    };
  }

  _todayBounds(now = new Date()) {
    const end = new Date(now);
    const start = new Date(end);
    start.setHours(0, 0, 0, 0);
    return {
      date: this._dateKey(start),
      startTime: start.toISOString(),
      endTime: end.toISOString()
    };
  }

  _boundsForDateKey(dateKey, now = new Date()) {
    const [year, month, day] = String(dateKey || '').split('-').map((part) => Number(part));
    const start = Number.isInteger(year) && Number.isInteger(month) && Number.isInteger(day)
      ? new Date(year, month - 1, day, 0, 0, 0, 0)
      : new Date(now);
    start.setHours(0, 0, 0, 0);
    const end = new Date(start);
    end.setDate(end.getDate() + 1);
    const nowValue = new Date(now);
    if (this._dateKey(nowValue) === this._dateKey(start) && nowValue < end) {
      return {
        date: this._dateKey(start),
        startTime: start.toISOString(),
        endTime: nowValue.toISOString()
      };
    }
    return {
      date: this._dateKey(start),
      startTime: start.toISOString(),
      endTime: end.toISOString()
    };
  }

  _dateKeysInRange(start, end) {
    const startValue = new Date(start);
    const endValue = new Date(end);
    if (!Number.isFinite(startValue.getTime()) || !Number.isFinite(endValue.getTime()) || endValue <= startValue) {
      return [];
    }
    const keys = [];
    const cursor = new Date(startValue);
    cursor.setHours(0, 0, 0, 0);
    while (cursor < endValue) {
      keys.push(this._dateKey(cursor));
      cursor.setDate(cursor.getDate() + 1);
    }
    return keys;
  }

  _currentHourRange(bounds, now = new Date()) {
    const start = new Date(now);
    start.setMinutes(0, 0, 0);
    const end = new Date(now);
    return {
      key: this._hourKey(start),
      startTime: start.toISOString(),
      endTime: end.toISOString()
    };
  }

  _hourRanges(startTime, endTime) {
    const start = new Date(startTime);
    const end = new Date(endTime);
    const ranges = [];
    for (let cursor = new Date(start); cursor < end; cursor.setHours(cursor.getHours() + 1)) {
      const hourEnd = new Date(cursor);
      hourEnd.setHours(hourEnd.getHours() + 1);
      ranges.push({
        key: this._hourKey(cursor),
        startTime: cursor.toISOString(),
        endTime: (hourEnd > end ? end : hourEnd).toISOString()
      });
    }
    return ranges;
  }

  _hourKey(date = new Date()) {
    return String(new Date(date).getHours()).padStart(2, '0');
  }

  _dateKey(date = new Date()) {
    const value = new Date(date);
    return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, '0')}-${String(value.getDate()).padStart(2, '0')}`;
  }

  _dayPath(date) {
    return path.join(this.basePath, `${date}.json`);
  }

  _loadDay(date) {
    const filePath = this._dayPath(date);
    if (fs.existsSync(filePath)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        if (parsed?.schema_version === SCHEMA_VERSION && parsed.date === date) {
          return { ...parsed, hours: parsed.hours || {} };
        }
      } catch {
        // Rebuild corrupt state lazily.
      }
    }
    return {
      schema_version: SCHEMA_VERSION,
      date,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      hours: {}
    };
  }

  _saveDay(day) {
    const filePath = this._dayPath(day.date);
    const tempPath = `${filePath}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(day), 'utf8');
    fs.renameSync(tempPath, filePath);
  }

  _sum(items, pick) {
    return Math.round(items.reduce((sum, item) => sum + Number(pick(item) || 0), 0));
  }

  _metricValue(...values) {
    for (const value of values) {
      if (value === undefined || value === null || value === '') {
        continue;
      }
      const number = Number(value);
      if (Number.isFinite(number)) {
        return Math.max(0, Math.round(number));
      }
    }
    return 0;
  }

  _policyIdleMinutes(summary = {}) {
    const reportedIdle = this._metricValue(summary?.idle_minutes, summary?.input_idle_minutes);
    const rawIdle = this._metricValue(summary?.raw_input_idle_minutes, reportedIdle);
    return Math.max(reportedIdle, rawIdle);
  }

  _unique(items = []) {
    return Array.from(new Set(items.filter(Boolean)));
  }

  _emptyClassified() {
    return { work: 0, meeting: 0, social: 0, other: 0, unclear: 0 };
  }

  _mergeClassified(groups = []) {
    return groups.reduce((merged, group = {}) => {
      Object.keys(merged).forEach((key) => {
        merged[key] += Number(group[key] || 0);
      });
      return merged;
    }, this._emptyClassified());
  }
}

module.exports = { LiveDayTruthService };
