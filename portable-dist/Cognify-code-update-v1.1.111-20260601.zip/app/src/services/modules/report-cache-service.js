const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {
  buildWorkHoursLedger,
  safePcAvailableMinutesFromSummary
} = require('./work-hours-ledger');

const CACHE_SCHEMA_VERSION = 10;

class ReportCacheService {
  constructor(storagePath, services = {}) {
    this.cachePath = path.join(storagePath, 'report-cache');
    this.services = services;
    this.dailyInFlight = new Map();
    this.dailyDayLocks = new Map();
    fs.mkdirSync(this.cachePath, { recursive: true });
  }

  async dailyReport({ startTime, endTime, force = false, sync = true, warmCurrentHourOnly = false, includeTasks = true, staleOk = false, syncMaxDurationMs = null, syncMaxWindows = null } = {}) {
    const inFlightKey = JSON.stringify({
      startTime,
      endTime,
      force: Boolean(force),
      sync: Boolean(sync),
      warmCurrentHourOnly: Boolean(warmCurrentHourOnly),
      includeTasks: Boolean(includeTasks),
      staleOk: Boolean(staleOk),
      syncMaxDurationMs: Number(syncMaxDurationMs) || null,
      syncMaxWindows: Number(syncMaxWindows) || null
    });
    if (!force && this.dailyInFlight.has(inFlightKey)) {
      return this.dailyInFlight.get(inFlightKey);
    }

    const promise = staleOk && !force
      ? this._dailyReport({ startTime, endTime, force, sync, warmCurrentHourOnly, includeTasks, staleOk, syncMaxDurationMs, syncMaxWindows })
      : this._withDailyDayLock(this._dayRange(startTime, endTime).date, () => (
        this._dailyReport({ startTime, endTime, force, sync, warmCurrentHourOnly, includeTasks, staleOk, syncMaxDurationMs, syncMaxWindows })
      ));
    if (!force) {
      this.dailyInFlight.set(inFlightKey, promise);
      promise.then(() => {
        if (this.dailyInFlight.get(inFlightKey) === promise) {
          this.dailyInFlight.delete(inFlightKey);
        }
      }, () => {
        if (this.dailyInFlight.get(inFlightKey) === promise) {
          this.dailyInFlight.delete(inFlightKey);
        }
      });
    }
    return promise;
  }

  async _withDailyDayLock(date, action) {
    const previous = this.dailyDayLocks.get(date) || Promise.resolve();
    const run = previous.catch(() => {}).then(action);
    this.dailyDayLocks.set(date, run);
    try {
      return await run;
    } finally {
      if (this.dailyDayLocks.get(date) === run) {
        this.dailyDayLocks.delete(date);
      }
    }
  }

  async _dailyReport({ startTime, endTime, force = false, sync = true, warmCurrentHourOnly = false, includeTasks = true, staleOk = false, syncMaxDurationMs = null, syncMaxWindows = null } = {}) {
    const range = this._dayRange(startTime, endTime);
    const cache = this._loadDayCache(range.date);
    const hours = this._hourRanges(range.startTime, range.endTime);
    const builtHours = [];
    const systemProcessRecords = [];
    let latestSync = null;

    for (const hour of hours) {
      const cached = cache.hours[hour.key];
      if ((!force || (warmCurrentHourOnly && !hour.isCurrent)) && cached && (staleOk || !this._isHourStale(hour, cached, range.nowMs, { includeTasks }))) {
        builtHours.push({ ...cached, cache_status: 'hit' });
        continue;
      }

      const liveTruthHour = this._liveTruthHour(hour, { includeTasks });
      if (liveTruthHour) {
        cache.hours[hour.key] = liveTruthHour;
        builtHours.push(liveTruthHour);
        continue;
      }

      if (staleOk || (warmCurrentHourOnly && !hour.isCurrent)) {
        continue;
      }

      const built = await this._buildHour(hour, { sync, includeTasks, force, syncMaxDurationMs, syncMaxWindows });
      cache.hours[hour.key] = built;
      builtHours.push(built);
      latestSync = built.sync || latestSync;
      systemProcessRecords.push(...(built.system_process_records || []));
    }

    cache.updated_at = new Date().toISOString();
    cache.range_start = range.startTime;
    cache.range_end = range.endTime;
    if (!staleOk && (!warmCurrentHourOnly || builtHours.some((hour) => hour.cache_status !== 'hit'))) {
      this._saveDayCache(range.date, cache);
    }

    const value = this._mergeDay(range, builtHours);
    const coverage = this._coverage(hours, builtHours);
    return {
      message: 'Daily report is ready from cached hourly activity.',
      context_count: value.context_count,
      tasks: value.tasks,
      summary: value.summary,
      sync: latestSync || this.services.activityStore?.getSyncSummary?.(range.startTime, range.endTime) || null,
      system_process_records: systemProcessRecords,
      suggestions: value.suggestions,
      cache: {
        hit_hours: builtHours.filter((hour) => hour.cache_status === 'hit').length,
        built_hours: builtHours.filter((hour) => hour.cache_status !== 'hit').length,
        hour_count: builtHours.length,
        expected_hours: hours.length,
        covered_hours: coverage.covered_hours,
        missing_hours: coverage.missing_hours,
        complete: coverage.complete,
        schema_version: CACHE_SCHEMA_VERSION,
        generated_at: new Date().toISOString()
      }
    };
  }

  invalidateRange(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return { invalidated: 0 };
    }

    const start = new Date(startMs);
    const end = new Date(endMs);
    const touched = new Set();
    for (let cursor = new Date(start); cursor <= end; cursor.setDate(cursor.getDate() + 1)) {
      const date = this._dateKey(cursor);
      const cache = this._loadDayCache(date);
      let changed = false;
      Object.keys(cache.hours || {}).forEach((hourKey) => {
        const hour = cache.hours[hourKey];
        const hourStartMs = new Date(hour.start_time).getTime();
        const hourEndMs = new Date(hour.end_time).getTime();
        if (hourStartMs < endMs && hourEndMs > startMs) {
          delete cache.hours[hourKey];
          changed = true;
        }
      });
      if (changed) {
        cache.updated_at = new Date().toISOString();
        this._saveDayCache(date, cache);
        touched.add(date);
      }
    }

    return { invalidated: touched.size };
  }

  async _buildHour(hour, options = {}) {
    const shouldSync = options.sync !== false && this._shouldSyncHour(hour, options);
    const query = await this.services.activity.getRangeData(hour.startTime, hour.endTime, {
      sync: shouldSync,
      maxDurationMs: shouldSync ? (Number(options.syncMaxDurationMs) || 15000) : 0,
      maxWindows: shouldSync ? (Number(options.syncMaxWindows) || 40) : 0
    });
    const records = query.records || [];
    const context = this.services.aiContextBuilder.build(records);
    const idleIntervals = this.services.systemIdle.getIntervalsInRange(hour.startTime, hour.endTime);
    const focusIntervals = this.services.focusEvents?.getActiveIntervals?.(hour.startTime, hour.endTime) || [];
    const passiveWorkIntervals = this.services.focusEvents?.getPassiveWorkIntervals?.(hour.startTime, hour.endTime, {
      classifier: this.services.classifier
    }) || [];
    const tasks = options.includeTasks === false ? [] : await this.services.tasks.extract(context, {
      maxRecords: 500,
      maxLines: 1200,
      maxCandidates: 40,
      maxRelatedScanLines: 1200
    });
    const summary = await this.services.dailySummary.generate(context, {
      startTime: hour.startTime,
      endTime: hour.endTime,
      idleIntervals,
      focusIntervals,
      passiveWorkIntervals,
      includeTasks: options.includeTasks !== false,
      tasks
    });

    return {
      schema_version: CACHE_SCHEMA_VERSION,
      cache_status: 'built',
      key: hour.key,
      start_time: hour.startTime,
      end_time: hour.endTime,
      built_at: new Date().toISOString(),
      record_count: records.length,
      record_fingerprint: this._recordFingerprint(records),
      summary: this._compactSummary(summary),
      tasks,
      tasks_built: options.includeTasks !== false,
      sync_requested: shouldSync,
      sync: query.sync,
      system_process_records: query.system_process_records || []
    };
  }

  _liveTruthHour(hour = {}, options = {}) {
    if (options.includeTasks !== false || !this.services.liveTruth) {
      return null;
    }
    const liveHour = this.services.liveTruth.getAccountedHour
      ? this.services.liveTruth.getAccountedHour(hour.startTime, hour.endTime)
      : this.services.liveTruth.getVerifiedHour?.(hour.startTime, hour.endTime);
    if (!liveHour) {
      return null;
    }
    const expectedMinutes = Math.max(0, Math.round((new Date(hour.endTime).getTime() - new Date(hour.startTime).getTime()) / 60000));
    const liveRangeMinutes = Number(liveHour.summary?.range_minutes || 0);
    if (expectedMinutes > 0 && liveRangeMinutes > 0 && liveRangeMinutes < expectedMinutes) {
      return null;
    }
    return {
      schema_version: CACHE_SCHEMA_VERSION,
      cache_status: 'live-truth',
      key: hour.key,
      start_time: hour.startTime,
      end_time: hour.endTime,
      built_at: liveHour.built_at || new Date().toISOString(),
      record_count: Number(liveHour.record_count || 0),
      record_fingerprint: `live-truth:${liveHour.key}:${liveHour.built_at || liveHour.last_sync_at || ''}`,
      summary: this._compactSummary(liveHour.summary || {}),
      tasks: [],
      tasks_built: false,
      sync_requested: Boolean(liveHour.sync_requested),
      sync: liveHour.sync || null,
      system_process_records: []
    };
  }

  _shouldSyncHour(hour = {}, options = {}) {
    if (options.force) {
      return true;
    }
    if (hour.isCurrent) {
      return true;
    }
    const endMs = new Date(hour.endTime || 0).getTime();
    if (!Number.isFinite(endMs)) {
      return false;
    }
    return (Date.now() - endMs) <= (10 * 60 * 1000);
  }

  _mergeDay(range, hours = []) {
    const sortedHours = hours
      .filter(Boolean)
      .sort((left, right) => String(left.start_time).localeCompare(String(right.start_time)))
      .map((hour) => ({ ...hour, cache_status: hour.cache_status || 'hit' }));

    const classifiedMs = this._mergeClassifiedMs(sortedHours.map((hour) => hour.summary?.classified_ms));
    const activeMs = this._sum(sortedHours, (hour) => hour.summary?.active_ms_estimate);
    const estimatedActiveMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(hour.summary?.active_minutes, hour.summary?.estimated_active_minutes)
    )) || this._roundMinutes(activeMs);
    const classifiedMinutes = this._rebalanceClassificationMinutes(classifiedMs, estimatedActiveMinutes);
    const focusMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(
        hour.summary?.focus_minutes,
        hour.summary?.focus_score?.deep_work_minutes,
        hour.summary?.pc_work_minutes,
        hour.summary?.classified_minutes?.work
      )
    ));
    const pcWorkMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(
        hour.summary?.pc_work_minutes,
        hour.summary?.focus_minutes,
        hour.summary?.focus_score?.deep_work_minutes,
        hour.summary?.classified_minutes?.work
      )
    ));
    const pcMessagingMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(hour.summary?.pc_messaging_minutes, hour.summary?.classified_minutes?.meeting)
    ));
    const confirmedNonWorkMinutes = this._sum(sortedHours, (hour) => this._confirmedNonWorkMinutes(hour.summary));
    const manualTimingBlocks = this._mergeManualTimingBlocks(sortedHours);
    const manualNetMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(
        hour.summary?.manual_net_added_work_minutes,
        Number(hour.summary?.manual_timing_blocks?.net_added_work_minutes || 0) +
          Number(hour.summary?.manual_timing_blocks?.net_added_meeting_minutes || 0)
      )
    ));
    const totalWorkMinutes = this._sum(sortedHours, (hour) => this._workLedgerFromSummary(hour.summary).work_minutes);
    const messagingMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(
        hour.summary?.messaging_minutes,
        Number(hour.summary?.classified_minutes?.meeting || 0) +
          Number(hour.summary?.manual_timing_blocks?.meeting_minutes || hour.summary?.manual_timing_blocks?.net_added_meeting_minutes || 0)
      )
    ));
    const socialMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(hour.summary?.social_minutes, hour.summary?.classified_minutes?.social)
    ));
    const otherMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(hour.summary?.other_minutes, hour.summary?.classified_minutes?.other)
    ));
    const unclearMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(hour.summary?.unclear_minutes, hour.summary?.classified_minutes?.unclear)
    ));
    const capturedMinutes = this._sum(sortedHours, (hour) => hour.summary?.captured_minutes_estimate);
    const rawInputIdleMinutes = this._sum(sortedHours, (hour) => (
      this._metricValue(hour.summary?.raw_input_idle_minutes, hour.summary?.input_idle_minutes)
    ));
    const passiveWorkCandidateMinutes = this._sum(sortedHours, (hour) => hour.summary?.passive_work_candidate_minutes);
    const rangeMinutes = Math.max(1, Math.round((new Date(range.endTime) - new Date(range.startTime)) / 60000));
    const idleMinutes = this._sum(sortedHours, (hour) => (
      this._policyIdleMinutes(hour.summary)
    ));
    const grossPcAvailableMinutes = Math.min(
      rangeMinutes,
      this._sum(sortedHours, (hour) => safePcAvailableMinutesFromSummary(hour.summary || {}))
    );
    const coverage = this._minuteCoverageSummary({
      rangeMinutes,
      capturedMinutes,
      activeMinutes: estimatedActiveMinutes,
      idleMinutes,
      availableMinutes: grossPcAvailableMinutes
    });
    const dayWorkLedger = buildWorkHoursLedger({
      pcAvailableMinutes: grossPcAvailableMinutes,
      idleMinutes: coverage.input_idle_minutes,
      manualAddedMinutes: manualNetMinutes,
      rangeMinutes
    });
    const finalWorkMinutes = Math.min(totalWorkMinutes, dayWorkLedger.work_minutes);

    const summary = {
      activity_events: this._sum(sortedHours, (hour) => hour.summary?.activity_events),
      manual_timing_event_count: this._sum(sortedHours, (hour) => hour.summary?.manual_timing_event_count),
      major_work_blocks: [],
      apps_used: this._unique(sortedHours.flatMap((hour) => hour.summary?.apps_used || [])),
      app_display_names: this._unique(sortedHours.flatMap((hour) => hour.summary?.app_display_names || [])),
      app_timeline: this._mergeAppTimeline(sortedHours.flatMap((hour) => hour.summary?.app_timeline || [])),
      websites_visited: this._unique(sortedHours.flatMap((hour) => hour.summary?.websites_visited || [])),
      browser_activity: this._mergeBrowserActivity(sortedHours),
      files_documents_seen: this._unique(sortedHours.flatMap((hour) => hour.summary?.files_documents_seen || [])),
      meetings_or_calls: this._mergeMeetings(sortedHours),
      important_decisions: [],
      tasks_created: this._dedupeTasks(sortedHours.flatMap((hour) => hour.tasks || [])),
      pending_follow_ups: [],
      range_start: range.startTime,
      range_end: range.endTime,
      range_minutes: rangeMinutes,
      pc_available_source: sortedHours.some((hour) => Number(hour.summary?.runtime_available_minutes || 0) > 0)
        ? 'runtime_availability'
        : 'local_collector_evidence',
      raw_input_idle_minutes: rawInputIdleMinutes,
      passive_work_candidate_minutes: passiveWorkCandidateMinutes,
      input_idle_minutes: coverage.input_idle_minutes,
      idle_adjusted: sortedHours.some((hour) => hour.summary?.idle_adjusted),
      captured_minutes_estimate: capturedMinutes,
      accounted_minutes: coverage.accounted_minutes,
      gross_pc_available_minutes: grossPcAvailableMinutes,
      missing_minutes: coverage.missing_minutes,
      coverage_complete: coverage.coverage_complete,
      coverage_percent: coverage.coverage_percent,
      minute_partition: coverage.minute_partition,
      passive_candidate_minutes: coverage.passive_candidate_minutes,
      active_ms_estimate: activeMs,
      active_minutes: estimatedActiveMinutes,
      estimated_active_minutes: estimatedActiveMinutes,
      classified_ms: classifiedMs,
      focus_minutes: focusMinutes,
      messaging_minutes: messagingMinutes,
      social_minutes: socialMinutes,
      idle_minutes: coverage.input_idle_minutes,
      other_minutes: otherMinutes,
      unclear_minutes: unclearMinutes,
      pc_work_minutes: pcWorkMinutes,
      pc_messaging_minutes: pcMessagingMinutes,
      confirmed_non_work_minutes: confirmedNonWorkMinutes,
      manual_timing_blocks: manualTimingBlocks,
      manual_timing_minutes: manualTimingBlocks.total_minutes,
      manual_net_added_work_minutes: dayWorkLedger.manual_restored_minutes,
      work_minutes: finalWorkMinutes,
      work_minutes_breakdown: {
        pc_work_minutes: pcWorkMinutes,
        pc_messaging_minutes: pcMessagingMinutes,
        pc_active_work_minutes: dayWorkLedger.pc_available_work_minutes,
        gross_pc_available_minutes: dayWorkLedger.pc_available_minutes,
        idle_minutes: dayWorkLedger.idle_deducted_minutes,
        confirmed_non_work_minutes: confirmedNonWorkMinutes,
        manual_net_added_minutes: dayWorkLedger.manual_restored_minutes,
        total_work_minutes: finalWorkMinutes
      },
      pc_classified_minutes: classifiedMinutes,
      classified_minutes: classifiedMinutes,
      measurement_confidence: this._measurementConfidenceSummary({
        rangeMinutes,
        capturedMinutes,
        activeMinutes: estimatedActiveMinutes,
        inputIdleMinutes: coverage.input_idle_minutes,
        rawInputIdleMinutes,
        passiveWorkCandidateMinutes,
        missingMinutes: coverage.missing_minutes,
        childSummaries: sortedHours.map((hour) => hour.summary || {})
      }),
      time_distribution_estimate: {},
      non_work_observations: this._mergeNonWorkObservations(sortedHours.map((hour) => hour.summary?.non_work_observations)),
      possible_distractions: this._unique(sortedHours.flatMap((hour) => hour.summary?.possible_distractions || [])),
      recommended_next_actions: []
    };
    summary.estimated_active_label = this._formatDuration(summary.estimated_active_minutes);
    summary.work_label = this._formatDuration(summary.work_minutes);
    summary.focus_score = this._focusScore({ work: summary.focus_minutes }, summary.estimated_active_minutes);
    summary.pending_follow_ups = summary.tasks_created;
    summary.recommended_next_actions = summary.tasks_created.slice(0, 5).map((task) => `Follow up: ${task.task_title}`);

    return {
      context_count: this._sum(sortedHours, (hour) => hour.record_count),
      tasks: summary.tasks_created,
      summary,
      suggestions: this._suggestions(summary.tasks_created)
    };
  }

  _compactSummary(summary = {}) {
    const activeMinutes = this._metricValue(summary.active_minutes, summary.estimated_active_minutes);
    const focusMinutes = this._metricValue(
      summary.focus_minutes,
      summary.focus_score?.deep_work_minutes,
      summary.pc_work_minutes,
      summary.classified_minutes?.work
    );
    const pcWorkMinutes = this._metricValue(
      summary.pc_work_minutes,
      summary.focus_minutes,
      summary.focus_score?.deep_work_minutes,
      summary.classified_minutes?.work
    );
    const pcMessagingMinutes = this._metricValue(summary.pc_messaging_minutes, summary.classified_minutes?.meeting);
    const manualNetWork = this._metricValue(
      summary.manual_net_added_work_minutes,
      Number(summary.manual_timing_blocks?.net_added_work_minutes || 0) +
        Number(summary.manual_timing_blocks?.net_added_meeting_minutes || 0)
    );
    const reportedIdleMinutes = this._metricValue(summary.idle_minutes, summary.input_idle_minutes);
    const rawInputIdleMinutes = this._metricValue(summary.raw_input_idle_minutes, reportedIdleMinutes);
    const idleMinutes = Math.max(reportedIdleMinutes, rawInputIdleMinutes);
    const grossPcAvailableMinutes = safePcAvailableMinutesFromSummary(summary);
    const workLedger = buildWorkHoursLedger({
      pcAvailableMinutes: grossPcAvailableMinutes,
      idleMinutes,
      manualAddedMinutes: manualNetWork,
      rangeMinutes: summary.range_minutes
    });
    const pcActiveWorkMinutes = workLedger.pc_available_work_minutes;
    const workMinutes = workLedger.work_minutes;
    const messagingMinutes = this._metricValue(
      summary.messaging_minutes,
      Number(summary.classified_minutes?.meeting || 0) +
        Number(summary.manual_timing_blocks?.meeting_minutes || summary.manual_timing_blocks?.net_added_meeting_minutes || 0)
    );
    const socialMinutes = this._metricValue(summary.social_minutes, summary.classified_minutes?.social);
    const passiveWorkCandidateMinutes = this._metricValue(summary.passive_work_candidate_minutes);
    const otherMinutes = this._metricValue(summary.other_minutes, summary.classified_minutes?.other);
    const unclearMinutes = this._metricValue(summary.unclear_minutes, summary.classified_minutes?.unclear);
    const confirmedNonWorkMinutes = this._confirmedNonWorkMinutes(summary);
    return {
      source: summary.source || null,
      official_time_source: summary.official_time_source || null,
      activity_events: summary.activity_events || 0,
      apps_used: summary.apps_used || [],
      app_display_names: summary.app_display_names || [],
      app_timeline: summary.app_timeline || [],
      websites_visited: summary.websites_visited || [],
      browser_activity: summary.browser_activity || {},
      files_documents_seen: summary.files_documents_seen || [],
      meetings_or_calls: summary.meetings_or_calls || { event_count: 0, total_minutes: 0, items: [] },
      range_start: summary.range_start,
      range_end: summary.range_end,
      range_minutes: summary.range_minutes || 0,
      runtime_available_minutes: summary.runtime_available_minutes || 0,
      pc_available_source: summary.pc_available_source || null,
      raw_input_idle_minutes: rawInputIdleMinutes,
      passive_work_candidate_minutes: passiveWorkCandidateMinutes,
      input_idle_minutes: idleMinutes,
      idle_adjusted: Boolean(summary.idle_adjusted),
      captured_minutes_estimate: summary.captured_minutes_estimate || 0,
      accounted_minutes: summary.accounted_minutes || 0,
      gross_pc_available_minutes: grossPcAvailableMinutes,
      missing_minutes: summary.missing_minutes || 0,
      coverage_complete: Boolean(summary.coverage_complete),
      coverage_percent: summary.coverage_percent || 0,
      minute_partition: summary.minute_partition || {
        active_minutes: activeMinutes,
        passive_candidate_minutes: summary.passive_candidate_minutes || 0,
        input_idle_minutes: idleMinutes,
        missing_minutes: summary.missing_minutes || 0
      },
      passive_candidate_minutes: summary.passive_candidate_minutes || 0,
      active_ms_estimate: this._summaryActiveMs(summary),
      active_minutes: activeMinutes,
      estimated_active_minutes: activeMinutes,
      classified_ms: this._summaryClassifiedMs(summary),
      focus_minutes: focusMinutes,
      messaging_minutes: messagingMinutes,
      social_minutes: socialMinutes,
      idle_minutes: idleMinutes,
      other_minutes: otherMinutes,
      unclear_minutes: unclearMinutes,
      pc_work_minutes: pcWorkMinutes,
      pc_messaging_minutes: pcMessagingMinutes,
      confirmed_non_work_minutes: confirmedNonWorkMinutes,
      manual_timing_event_count: summary.manual_timing_event_count || summary.manual_timing_blocks?.event_count || 0,
      manual_timing_blocks: this._compactManualTimingBlocks(summary.manual_timing_blocks),
      manual_timing_minutes: summary.manual_timing_minutes || summary.manual_timing_blocks?.total_minutes || 0,
      manual_net_added_work_minutes: workLedger.manual_restored_minutes,
      work_minutes: workMinutes,
      work_minutes_breakdown: {
        pc_work_minutes: pcWorkMinutes,
        pc_messaging_minutes: pcMessagingMinutes,
        pc_active_work_minutes: pcActiveWorkMinutes,
        gross_pc_available_minutes: workLedger.pc_available_minutes,
        idle_minutes: workLedger.idle_deducted_minutes,
        confirmed_non_work_minutes: confirmedNonWorkMinutes,
        manual_net_added_minutes: workLedger.manual_restored_minutes,
        total_work_minutes: workMinutes
      },
      pc_classified_minutes: summary.pc_classified_minutes || summary.classified_minutes || this._emptyClassifiedMinutes(),
      classified_minutes: summary.classified_minutes || this._emptyClassifiedMinutes(),
      measurement_confidence: summary.measurement_confidence || this._measurementConfidenceSummary({
        rangeMinutes: summary.range_minutes || 0,
        capturedMinutes: summary.captured_minutes_estimate || 0,
        activeMinutes,
        inputIdleMinutes: idleMinutes,
        rawInputIdleMinutes,
        passiveWorkCandidateMinutes,
        missingMinutes: summary.missing_minutes || 0
      }),
      focus_score: this._focusScore({ work: focusMinutes }, activeMinutes),
      non_work_observations: summary.non_work_observations || {
        detection_only: true,
        affects_work_hours: false,
        total_minutes: 0,
        category_minutes: [],
        items: []
      },
      possible_distractions: summary.possible_distractions || []
    };
  }

  _mergeNonWorkObservations(observations = []) {
    const byKey = new Map();
    observations
      .filter((observation) => observation && Array.isArray(observation.items))
      .forEach((observation) => {
        observation.items.forEach((item) => {
          const key = `${item.category || ''}|${item.app_name || ''}|${item.title || ''}|${item.host || ''}`;
          if (!byKey.has(key)) {
            byKey.set(key, {
              category: item.category || 'Other',
              app_name: item.app_name || 'Unknown',
              title: item.title || 'Untitled',
              host: item.host || '',
              rule: item.rule || '',
              minutes: 0
            });
          }
          byKey.get(key).minutes += Math.max(0, Math.round(Number(item.minutes || 0)));
        });
      });
    const items = Array.from(byKey.values())
      .filter((item) => item.minutes > 0)
      .sort((left, right) => right.minutes - left.minutes)
      .slice(0, 20);
    const categoryTotals = new Map();
    items.forEach((item) => {
      categoryTotals.set(item.category, (categoryTotals.get(item.category) || 0) + item.minutes);
    });
    return {
      detection_only: true,
      affects_work_hours: false,
      total_minutes: items.reduce((sum, item) => sum + item.minutes, 0),
      category_minutes: Array.from(categoryTotals.entries())
        .map(([label, minutes]) => ({ label, minutes }))
        .sort((left, right) => right.minutes - left.minutes),
      items
    };
  }

  _mergeAppTimeline(groups = []) {
    const byApp = new Map();
    groups.forEach((group) => {
      const key = group.app_id || group.app_name || 'Unknown';
      if (!byApp.has(key)) {
        byApp.set(key, {
          app_id: group.app_id || key,
          app_name: group.app_name || key,
          dates: new Set(),
          event_count: 0,
          total_time_ms_estimate: 0,
          confirmed_non_work_minutes: 0,
          classified_ms: this._emptyClassifiedMs(),
          classified_minutes: this._emptyClassifiedMinutes(),
          items: []
        });
      }
      const entry = byApp.get(key);
      (group.dates || []).forEach((date) => entry.dates.add(date));
      entry.event_count += Number(group.event_count || 0);
      entry.total_time_ms_estimate += Number(group.total_time_ms_estimate || 0);
      entry.confirmed_non_work_minutes += Number(group.confirmed_non_work_minutes || 0);
      entry.classified_ms = this._mergeClassifiedMs([entry.classified_ms, group.classified_ms || {}]);
      entry.classified_minutes = this._mergeClassifiedMinutes([entry.classified_minutes, group.classified_minutes || {}]);
      entry.items.push(...(group.items || []));
    });

    return Array.from(byApp.values())
      .map((group) => {
        const totalMinutes = Object.values(group.classified_minutes).reduce((sum, value) => sum + Number(value || 0), 0);
        const classification = this._dominantClassification(group.classified_minutes);
        return {
          ...group,
          dates: Array.from(group.dates),
          total_time_minutes_estimate: totalMinutes,
          total_time_label: this._formatDuration(totalMinutes),
          confirmed_non_work_minutes: Math.min(totalMinutes, Math.round(Number(group.confirmed_non_work_minutes || 0))),
          classification,
          classification_confidence: classification === 'unclear' ? 'low' : 'medium',
          items: group.items.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 60)
        };
      })
      .filter((group) => group.total_time_minutes_estimate > 0)
      .sort((left, right) => Number(right.total_time_minutes_estimate || 0) - Number(left.total_time_minutes_estimate || 0));
  }

  _mergeBrowserActivity(hours = []) {
    const browser = {
      event_count: this._sum(hours, (hour) => hour.summary?.browser_activity?.event_count),
      apps_used: this._unique(hours.flatMap((hour) => hour.summary?.browser_activity?.apps_used || [])),
      browser_names: this._unique(hours.flatMap((hour) => hour.summary?.browser_activity?.browser_names || [])),
      sites: this._unique(hours.flatMap((hour) => hour.summary?.browser_activity?.sites || [])),
      windows: this._unique(hours.flatMap((hour) => hour.summary?.browser_activity?.windows || [])).slice(0, 20),
      recent_events: hours.flatMap((hour) => hour.summary?.browser_activity?.recent_events || []).slice(-10)
    };
    return browser;
  }

  _mergeMeetings(hours = []) {
    const items = hours.flatMap((hour) => hour.summary?.meetings_or_calls?.items || []);
    const totalMinutes = this._sum(hours, (hour) => hour.summary?.meetings_or_calls?.total_minutes);
    return {
      event_count: items.length,
      total_minutes: totalMinutes,
      total_label: this._formatDuration(totalMinutes),
      items
    };
  }

  _mergeManualTimingBlocks(hours = []) {
    const blocks = hours.map((hour) => hour.summary?.manual_timing_blocks || {});
    return {
      event_count: this._sum(blocks, (block) => block.event_count),
      total_minutes: this._sum(blocks, (block) => block.total_minutes),
      work_minutes: this._sum(blocks, (block) => block.work_minutes),
      meeting_minutes: this._sum(blocks, (block) => block.meeting_minutes),
      break_minutes: this._sum(blocks, (block) => block.break_minutes),
      other_minutes: this._sum(blocks, (block) => block.other_minutes),
      net_added_work_minutes: this._sum(blocks, (block) => block.net_added_work_minutes),
      net_added_meeting_minutes: this._sum(blocks, (block) => block.net_added_meeting_minutes),
      net_added_minutes: this._sum(blocks, (block) => block.net_added_minutes),
      overlapping_pc_active_minutes: this._sum(blocks, (block) => block.overlapping_pc_active_minutes),
      idle_overlap_minutes: this._sum(blocks, (block) => block.idle_overlap_minutes),
      items: blocks.flatMap((block) => block.items || []).slice(0, 80)
    };
  }

  _compactManualTimingBlocks(blocks = {}) {
    return {
      event_count: Number(blocks.event_count || 0),
      total_minutes: Number(blocks.total_minutes || 0),
      work_minutes: Number(blocks.work_minutes || 0),
      meeting_minutes: Number(blocks.meeting_minutes || 0),
      break_minutes: Number(blocks.break_minutes || 0),
      other_minutes: Number(blocks.other_minutes || 0),
      net_added_work_minutes: Number(blocks.net_added_work_minutes || 0),
      net_added_meeting_minutes: Number(blocks.net_added_meeting_minutes || 0),
      net_added_minutes: Number(blocks.net_added_minutes || 0),
      overlapping_pc_active_minutes: Number(blocks.overlapping_pc_active_minutes || 0),
      idle_overlap_minutes: Number(blocks.idle_overlap_minutes || 0),
      items: (blocks.items || []).slice(0, 80)
    };
  }

  _dedupeTasks(tasks = []) {
    const byKey = new Map();
    tasks.forEach((task) => {
      const key = String(task.task_title || '').toLowerCase().replace(/\s+/g, ' ').trim();
      if (key && !byKey.has(key)) {
        byKey.set(key, task);
      }
    });
    return Array.from(byKey.values());
  }

  _suggestions(tasks = []) {
    const pending = tasks.filter((task) => task.status === 'pending').length;
    if (!pending) {
      return ['No likely pending follow-ups detected in the selected range.'];
    }
    return [`You have ${pending} likely pending follow-up(s).`, 'Review high-priority pending follow-ups first.'];
  }

  _minuteCoverageSummary({ rangeMinutes = 0, capturedMinutes = 0, activeMinutes = 0, idleMinutes = 0, availableMinutes = 0 } = {}) {
    const range = Math.max(0, Math.round(Number(rangeMinutes) || 0));
    const active = Math.min(range, Math.max(0, Math.round(Number(activeMinutes) || 0)));
    const idle = Math.min(
      Math.max(0, Math.round(Number(idleMinutes) || 0)),
      Math.max(0, range - active)
    );
    const captured = Math.min(range, Math.max(0, Math.round(Number(capturedMinutes) || 0)));
    const available = Math.min(range, Math.max(0, Math.round(Number(availableMinutes) || 0)));
    const accounted = Math.min(range, Math.max(captured, active + idle, available));
    const passive = Math.max(0, accounted - active - idle);
    const missing = Math.max(0, range - accounted);

    return {
      accounted_minutes: accounted,
      gross_pc_available_minutes: available,
      active_minutes: active,
      passive_candidate_minutes: passive,
      input_idle_minutes: idle,
      missing_minutes: missing,
      coverage_complete: range > 0 && missing === 0,
      coverage_percent: range > 0 ? Math.min(100, Math.round((accounted / range) * 100)) : 0,
      minute_partition: {
        active_minutes: active,
        passive_candidate_minutes: passive,
        input_idle_minutes: idle,
        missing_minutes: missing
      }
    };
  }

  _measurementConfidenceSummary({
    rangeMinutes = 0,
    capturedMinutes = 0,
    activeMinutes = 0,
    inputIdleMinutes = 0,
    rawInputIdleMinutes = 0,
    passiveWorkCandidateMinutes = 0,
    missingMinutes = 0,
    childSummaries = []
  } = {}) {
    const range = Math.max(0, Math.round(Number(rangeMinutes) || 0));
    const missing = Math.max(0, Math.round(Number(missingMinutes) || 0));
    const passive = Math.max(0, Math.round(Number(passiveWorkCandidateMinutes) || 0));
    const rawIdle = Math.max(0, Math.round(Number(rawInputIdleMinutes) || 0));
    let score = 100;
    if (range > 0) {
      score -= Math.min(45, Math.round((missing / range) * 60));
      score -= Math.min(10, Math.round((passive / range) * 15));
    }
    if ((childSummaries || []).some((summary) => summary.measurement_confidence?.level === 'low')) {
      score -= 10;
    }
    score = Math.max(0, Math.min(100, score));
    const caveats = [];
    if (missing > 0) {
      caveats.push(`${missing}m had no capture/focus/idle evidence.`);
    }
    if (passive > 0) {
      caveats.push(`${passive}m input-idle had foreground work evidence, but idle was still deducted unless manually restored.`);
    }
    return {
      score,
      level: score >= 85 ? 'high' : (score >= 65 ? 'medium' : 'low'),
      range_minutes: range,
      captured_minutes: Math.max(0, Math.round(Number(capturedMinutes) || 0)),
      active_minutes: Math.max(0, Math.round(Number(activeMinutes) || 0)),
      input_idle_minutes: Math.max(0, Math.round(Number(inputIdleMinutes) || 0)),
      raw_input_idle_minutes: rawIdle,
      passive_work_candidate_minutes: passive,
      missing_minutes: missing,
      caveats
    };
  }

  _focusScore(classifiedMinutes = {}, activeMinutes = 0) {
    const totalActiveMinutes = Math.max(0, Math.round(Number(activeMinutes) || 0));
    const deepWorkMinutes = Math.min(totalActiveMinutes, Math.max(0, Math.round(Number(classifiedMinutes.work || 0))));
    const scorePercent = totalActiveMinutes > 0 ? Math.round((deepWorkMinutes / totalActiveMinutes) * 100) : 0;
    return {
      deep_work_minutes: deepWorkMinutes,
      total_active_minutes: totalActiveMinutes,
      score: totalActiveMinutes > 0 ? deepWorkMinutes / totalActiveMinutes : 0,
      score_percent: scorePercent,
      label: totalActiveMinutes > 0 ? `${scorePercent}%` : '0%',
      formula: 'Deep Work / Total Active Time'
    };
  }

  _workMinutesFromAvailable(availableMinutes = 0, idleMinutes = 0) {
    return buildWorkHoursLedger({
      pcAvailableMinutes: availableMinutes,
      idleMinutes
    }).pc_available_work_minutes;
  }

  _workLedgerFromSummary(summary = {}) {
    const manual = this._metricValue(
      summary?.manual_net_added_work_minutes,
      Number(summary?.manual_timing_blocks?.net_added_work_minutes || 0) +
        Number(summary?.manual_timing_blocks?.net_added_meeting_minutes || 0)
    );
    return buildWorkHoursLedger({
      pcAvailableMinutes: safePcAvailableMinutesFromSummary(summary || {}),
      idleMinutes: this._policyIdleMinutes(summary),
      manualAddedMinutes: manual,
      rangeMinutes: summary?.range_minutes
    });
  }

  _policyIdleMinutes(summary = {}) {
    const reportedIdle = this._metricValue(summary?.idle_minutes, summary?.input_idle_minutes);
    const rawIdle = this._metricValue(summary?.raw_input_idle_minutes, reportedIdle);
    return Math.max(reportedIdle, rawIdle);
  }

  _confirmedNonWorkMinutes(summary = {}) {
    if (Number.isFinite(Number(summary?.confirmed_non_work_minutes))) {
      return Math.max(0, Math.round(Number(summary.confirmed_non_work_minutes || 0)));
    }
    if (Number.isFinite(Number(summary?.work_minutes_breakdown?.confirmed_non_work_minutes))) {
      return Math.max(0, Math.round(Number(summary.work_minutes_breakdown.confirmed_non_work_minutes || 0)));
    }
    return Math.max(0, Math.round(
      Number(summary?.classified_minutes?.social || 0) + Number(summary?.classified_minutes?.other || 0)
    ));
  }

  _isHourStale(hour, cached, nowMs, options = {}) {
    if (!cached || cached.schema_version !== CACHE_SCHEMA_VERSION) {
      return true;
    }
    if (this._hasIncompleteHourCoverage(hour, cached)) {
      return true;
    }
    if (this._hasImpossibleZeroSummary(cached)) {
      return true;
    }
    if (options.includeTasks && cached.tasks_built === false) {
      return true;
    }
    if (hour.isCurrent) {
      const builtMs = new Date(cached.built_at || 0).getTime();
      return !Number.isFinite(builtMs) || (nowMs - builtMs) > (5 * 60 * 1000);
    }
    return false;
  }

  _hasIncompleteHourCoverage(hour = {}, cached = {}) {
    const expectedStartMs = new Date(hour.startTime || 0).getTime();
    const expectedEndMs = new Date(hour.endTime || 0).getTime();
    const cachedStartMs = new Date(cached.start_time || 0).getTime();
    const cachedEndMs = new Date(cached.end_time || 0).getTime();
    if (
      !Number.isFinite(expectedStartMs) ||
      !Number.isFinite(expectedEndMs) ||
      !Number.isFinite(cachedStartMs) ||
      !Number.isFinite(cachedEndMs)
    ) {
      return true;
    }
    if (cachedStartMs !== expectedStartMs || cachedEndMs !== expectedEndMs) {
      return true;
    }

    const expectedMinutes = Math.max(0, Math.round((expectedEndMs - expectedStartMs) / 60000));
    const cachedRangeMinutes = Number(cached.summary?.range_minutes || 0);
    return cachedRangeMinutes > 0 && cachedRangeMinutes < expectedMinutes;
  }

  _hasImpossibleZeroSummary(cached = {}) {
    const recordCount = Number(cached.record_count || 0);
    const summary = cached.summary || {};
    if (recordCount <= 0) {
      return false;
    }

    const activeMs = Number(summary.active_ms_estimate || 0);
    const activeMinutes = Number(summary.estimated_active_minutes || 0);
    const capturedMinutes = Number(summary.captured_minutes_estimate || 0);
    const idleMinutes = Number(summary.input_idle_minutes || 0);
    const rangeMinutes = Number(summary.range_minutes || 0);
    const classifiedMs = summary.classified_ms || {};
    const classifiedMinutes = summary.classified_minutes || {};
    const manualTimingMinutes = Number(summary.manual_timing_blocks?.total_minutes || summary.manual_timing_minutes || 0);
    const hasClassifiedMs = Object.values(classifiedMs).some((value) => Number(value || 0) > 0);
    const hasClassifiedMinutes = Object.values(classifiedMinutes).some((value) => Number(value || 0) > 0);

    if (activeMs > 0 || activeMinutes > 0 || hasClassifiedMs || hasClassifiedMinutes || manualTimingMinutes > 0) {
      return false;
    }
    return capturedMinutes <= 0 || idleMinutes < rangeMinutes;
  }

  _hourRanges(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();
    const ranges = [];
    let cursor = new Date(startMs);
    cursor.setMinutes(0, 0, 0);
    const nowMs = Date.now();

    while (cursor.getTime() < endMs) {
      const hourStartMs = Math.max(cursor.getTime(), startMs);
      const next = new Date(cursor.getTime() + 60 * 60 * 1000);
      const hourEndMs = Math.min(next.getTime(), endMs);
      const key = String(cursor.getHours()).padStart(2, '0');
      ranges.push({
        key,
        startTime: new Date(hourStartMs).toISOString(),
        endTime: new Date(hourEndMs).toISOString(),
        isCurrent: hourStartMs <= nowMs && nowMs < next.getTime()
      });
      cursor = next;
    }
    return ranges;
  }

  _dayRange(startTime, endTime) {
    const nowMs = Date.now();
    const start = startTime ? new Date(startTime) : new Date();
    if (!startTime) {
      start.setHours(0, 0, 0, 0);
    }
    const requestedEnd = endTime ? new Date(endTime) : new Date();
    const end = new Date(Math.min(requestedEnd.getTime(), nowMs));
    return {
      date: this._dateKey(start),
      startTime: start.toISOString(),
      endTime: end.toISOString(),
      nowMs
    };
  }

  _loadDayCache(date) {
    const filePath = this._dayCachePath(date);
    if (!fs.existsSync(filePath)) {
      return { schema_version: CACHE_SCHEMA_VERSION, date, hours: {} };
    }
    try {
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      if (parsed?.schema_version !== CACHE_SCHEMA_VERSION || !parsed.hours) {
        return { schema_version: CACHE_SCHEMA_VERSION, date, hours: {} };
      }
      return parsed;
    } catch {
      return { schema_version: CACHE_SCHEMA_VERSION, date, hours: {} };
    }
  }

  _saveDayCache(date, cache) {
    const filePath = this._dayCachePath(date);
    const tmpPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
    try {
      fs.writeFileSync(tmpPath, JSON.stringify(cache, null, 2), 'utf8');
      fs.renameSync(tmpPath, filePath);
    } finally {
      if (fs.existsSync(tmpPath)) {
        try {
          fs.unlinkSync(tmpPath);
        } catch {
          // Best effort cleanup for interrupted cache writes.
        }
      }
    }
  }

  _dayCachePath(date) {
    return path.join(this.cachePath, `${date}.json`);
  }

  _dateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  _recordFingerprint(records = []) {
    const hash = crypto.createHash('sha1');
    records.forEach((record) => {
      hash.update(String(record.record_key || record.id || record.timestamp_start || ''));
      hash.update('|');
    });
    return hash.digest('hex');
  }

  _sum(items = [], getter) {
    return items.reduce((sum, item) => sum + Number(getter(item) || 0), 0);
  }

  _metricValue(...values) {
    for (const value of values) {
      if (value === undefined || value === null || value === '') {
        continue;
      }
      const number = Number(value);
      if (Number.isFinite(number)) {
        return Math.max(0, Math.round(number));
      }
    }
    return 0;
  }

  _unique(values = []) {
    return [...new Set(values.filter(Boolean))];
  }

  _mergeClassifiedMinutes(values = []) {
    return ['work', 'meeting', 'social', 'other', 'unclear'].reduce((merged, key) => {
      merged[key] = values.reduce((sum, value) => sum + Math.max(0, Math.round(Number(value?.[key] || 0))), 0);
      return merged;
    }, this._emptyClassifiedMinutes());
  }

  _mergeClassifiedMs(values = []) {
    return ['work', 'meeting', 'social', 'other', 'unclear'].reduce((merged, key) => {
      merged[key] = values.reduce((sum, value) => sum + Number(value?.[key] || 0), 0);
      return merged;
    }, this._emptyClassifiedMs());
  }

  _rebalanceClassificationMinutes(classifiedMs = {}, targetMinutes = 0) {
    const keys = ['work', 'meeting', 'social', 'other', 'unclear'];
    const distributed = this._distributeRoundedMinutes(keys.map((key) => Number(classifiedMs[key] || 0)));
    const base = keys.reduce((value, key, index) => {
      value[key] = distributed[index] || 0;
      return value;
    }, this._emptyClassifiedMinutes());
    return this._reconcileClassificationMinutes(base, targetMinutes);
  }

  _reconcileClassificationMinutes(minutes = {}, targetMinutes = 0) {
    const keys = ['work', 'meeting', 'social', 'other', 'unclear'];
    const target = Math.max(0, Math.round(Number(targetMinutes) || 0));
    const adjusted = keys.reduce((value, key) => {
      value[key] = Math.max(0, Math.round(Number(minutes[key]) || 0));
      return value;
    }, this._emptyClassifiedMinutes());

    let total = keys.reduce((sum, key) => sum + adjusted[key], 0);
    if (target <= 0) {
      return this._emptyClassifiedMinutes();
    }
    if (total < target) {
      adjusted.unclear += target - total;
      return adjusted;
    }
    if (total > target) {
      let overflow = total - target;
      for (const key of ['unclear', 'other', 'social', 'meeting', 'work']) {
        const take = Math.min(adjusted[key], overflow);
        adjusted[key] -= take;
        overflow -= take;
        if (!overflow) {
          break;
        }
      }
    }
    return adjusted;
  }

  _distributeRoundedMinutes(msValues = []) {
    const exact = msValues.map((value) => Math.max(0, Number(value || 0)) / 60000);
    const roundedTotal = Math.round(exact.reduce((sum, value) => sum + value, 0));
    const floors = exact.map((value) => Math.floor(value));
    let assigned = floors.reduce((sum, value) => sum + value, 0);
    const order = exact
      .map((value, index) => ({ index, remainder: value - floors[index] }))
      .sort((left, right) => right.remainder - left.remainder);

    for (const entry of order) {
      if (assigned >= roundedTotal) {
        break;
      }
      floors[entry.index] += 1;
      assigned += 1;
    }
    return floors;
  }

  _roundMinutes(ms) {
    return Math.max(0, Math.round(Number(ms || 0) / 60000));
  }

  _summaryActiveMs(summary = {}) {
    if (Number.isFinite(Number(summary.active_minutes))) {
      return Math.max(0, Number(summary.active_minutes || 0) * 60000);
    }
    if (Number.isFinite(Number(summary.estimated_active_minutes))) {
      return Math.max(0, Number(summary.estimated_active_minutes || 0) * 60000);
    }

    const groups = summary.app_timeline || [];
    const fromTimeline = groups.reduce((sum, group) => sum + Number(group.total_time_ms_estimate || 0), 0);
    if (fromTimeline > 0) {
      return fromTimeline;
    }
    return Math.max(0, Number(summary.estimated_active_minutes || 0) * 60000);
  }

  _summaryClassifiedMs(summary = {}) {
    const groups = summary.app_timeline || [];
    const fromTimeline = this._mergeClassifiedMs(groups.map((group) => group.classified_ms || {}));
    if (Object.values(fromTimeline).some((value) => Number(value) > 0)) {
      return fromTimeline;
    }
    const minutes = summary.classified_minutes || {};
    return ['work', 'meeting', 'social', 'other', 'unclear'].reduce((value, key) => {
      value[key] = Math.max(0, Number(minutes[key] || 0) * 60000);
      return value;
    }, this._emptyClassifiedMs());
  }

  _coverage(expectedHours = [], hours = []) {
    const covered = new Set(hours.filter(Boolean).map((hour) => hour.key));
    const missing = expectedHours
      .filter((hour) => !covered.has(hour.key))
      .map((hour) => hour.key);
    return {
      covered_hours: covered.size,
      missing_hours: missing,
      complete: missing.length === 0
    };
  }

  _emptyClassifiedMinutes() {
    return { work: 0, meeting: 0, social: 0, other: 0, unclear: 0 };
  }

  _emptyClassifiedMs() {
    return { work: 0, meeting: 0, social: 0, other: 0, unclear: 0 };
  }

  _dominantClassification(minutes = {}) {
    const entries = Object.entries(this._emptyClassifiedMinutes())
      .map(([key]) => ({ key, value: Number(minutes[key] || 0) }))
      .sort((left, right) => right.value - left.value);
    if (!entries[0]?.value || entries[0].value === entries[1]?.value) {
      return 'unclear';
    }
    return entries[0].key;
  }

  _formatDuration(minutes) {
    const value = Math.max(0, Math.round(Number(minutes) || 0));
    const hours = Math.floor(value / 60);
    const mins = value % 60;
    if (!hours) return `${mins}m`;
    if (!mins) return `${hours}h`;
    return `${hours}h ${mins}m`;
  }
}

module.exports = { ReportCacheService };
