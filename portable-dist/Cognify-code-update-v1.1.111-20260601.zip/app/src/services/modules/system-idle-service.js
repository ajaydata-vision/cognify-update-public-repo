const fs = require('fs');
const path = require('path');

class SystemIdleService {
  constructor(storagePath, options = {}) {
    this.basePath = path.join(storagePath, 'system-idle');
    this.activeStatePath = path.join(this.basePath, 'active-state.json');
    this.thresholdSeconds = Number(options.thresholdSeconds || 5 * 60);
    this.pollMs = Number(options.pollMs || 10 * 1000);
    this.inferGapSeconds = Number(options.inferGapSeconds || 10 * 60);
    this.activeStateSaveIntervalMs = Number(options.activeStateSaveIntervalMs || 30 * 1000);
    this.activeStateStaleMs = Number(options.activeStateStaleMs || Math.max(
      this.inferGapSeconds * 1000,
      this.pollMs * 6,
      this.activeStateSaveIntervalMs * 4
    ));
    this.getIdleSeconds = options.getIdleSeconds || (() => 0);
    this.activityStore = options.activityStore || null;
    this.onIntervalClosed = typeof options.onIntervalClosed === 'function'
      ? options.onIntervalClosed
      : null;
    this.clock = options.clock || (() => new Date());
    this.timer = null;
    this.activeInterval = null;
    this.externalIdleStarts = new Map();
    this.lastActiveStateSaveMs = 0;
    this.lastPollAt = null;
    this.lastPollError = null;
    this.lastIntervalClosedAt = null;
    this.sessionStartedAt = null;
    fs.mkdirSync(this.basePath, { recursive: true });
    this._restoreActiveState();
  }

  start() {
    if (this.timer) {
      return;
    }

    this.sessionStartedAt = this.clock();
    this._poll();
    this.timer = setInterval(() => this._poll(), this.pollMs);
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }

    if (this.activeInterval) {
      this._closeInterval(this.clock(), 'shutdown');
    }
    Array.from(this.externalIdleStarts.keys()).forEach((reason) => {
      this._closeExternalIdle(reason, this.clock());
    });
  }

  getTodaySummary() {
    this._poll();
    return this.getSummaryForDate(this._localDateKey(this.clock()));
  }

  getIntervalsInRange(startTime, endTime) {
    this._poll();
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return [];
    }

    const intervals = [];
    this._dateKeysInRange(new Date(startMs), new Date(endMs)).forEach((dateKey) => {
      intervals.push(...this._readIntervals(dateKey));
    });

    const activeSegment = this._activeSegmentForRange(new Date(startMs), new Date(endMs));
    if (activeSegment) {
      intervals.push({
        start: activeSegment.start.toISOString(),
        end: activeSegment.end.toISOString(),
        duration_seconds: Math.max(0, Math.round((activeSegment.end.getTime() - activeSegment.start.getTime()) / 1000)),
        active: true,
        source: 'system_idle'
      });
    }

    return this._mergeIntervals(intervals
      .map((interval) => this._clipInterval(interval, startMs, endMs))
      .filter(Boolean)
      .sort((left, right) => new Date(left.start).getTime() - new Date(right.start).getTime()));
  }

  getEvidenceGapIntervalsInRange(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return [];
    }
    return this._mergeIntervals(this._inferredActivityGapIntervals(startMs, endMs)
      .map((interval) => this._clipInterval(interval, startMs, endMs))
      .filter(Boolean)
      .sort((left, right) => new Date(left.start).getTime() - new Date(right.start).getTime()));
  }

  getSummaryForDate(dateKey) {
    this._poll();
    const intervals = this._readIntervals(dateKey);
    const now = this.clock();

    const activeSegment = this._activeSegmentForDate(dateKey, now);
    if (activeSegment) {
      intervals.push({
        start: activeSegment.start.toISOString(),
        end: activeSegment.end.toISOString(),
        duration_seconds: Math.max(0, Math.round((activeSegment.end.getTime() - activeSegment.start.getTime()) / 1000)),
        active: true,
        source: 'system_idle'
      });
    }

    const bounds = this._localDayBounds(dateKey);
    const mergedIntervals = this._mergeIntervals(intervals);
    const evidenceGapIntervals = this.getEvidenceGapIntervalsInRange(
      bounds.start.toISOString(),
      new Date(Math.min(bounds.end.getTime(), now.getTime())).toISOString()
    );
    const totalSeconds = mergedIntervals.reduce((sum, interval) => sum + Number(interval.duration_seconds || 0), 0);
    return {
      date: dateKey,
      threshold_seconds: this.thresholdSeconds,
      inferred_gap_seconds: this.inferGapSeconds,
      total_idle_seconds: totalSeconds,
      total_idle_minutes: Math.round(totalSeconds / 60),
      active: Boolean(this.activeInterval),
      active_since: this.activeInterval ? this.activeInterval.start.toISOString() : null,
      intervals: mergedIntervals,
      evidence_gap_intervals: evidenceGapIntervals
    };
  }

  getHealth() {
    const now = this.clock();
    const nowMs = now.getTime();
    const lastPollMs = new Date(this.lastPollAt || 0).getTime();
    const stale = !this.timer || !Number.isFinite(lastPollMs) || (nowMs - lastPollMs) > Math.max(this.pollMs * 4, 60 * 1000);
    return {
      ok: !stale && !this.lastPollError,
      label: 'Idle Telemetry',
      detail: stale
        ? 'Idle telemetry is stale or not polling.'
        : (this.lastPollError || `Idle telemetry polling every ${Math.round(this.pollMs / 1000)}s.`),
      running: Boolean(this.timer),
      active: Boolean(this.activeInterval),
      active_since: this.activeInterval ? this.activeInterval.start.toISOString() : null,
      last_poll_at: this.lastPollAt,
      last_interval_closed_at: this.lastIntervalClosedAt,
      threshold_seconds: this.thresholdSeconds,
      error: this.lastPollError
    };
  }

  ensureFresh() {
    if (!this.timer) {
      this.start();
      return { ok: Boolean(this.timer), action: 'start' };
    }
    const before = this.getHealth();
    if (before.ok) {
      return { ok: true, action: 'none' };
    }
    this._poll();
    const after = this.getHealth();
    return {
      ok: Boolean(after.ok),
      action: 'poll_stale',
      error: after.error || null
    };
  }

  markExternalIdleStart(reason = 'external', at = this.clock()) {
    const safeReason = this._safeReason(reason);
    const when = at instanceof Date ? at : new Date(at);
    if (!Number.isFinite(when.getTime()) || this.externalIdleStarts.has(safeReason)) {
      return { started: false };
    }
    this.externalIdleStarts.set(safeReason, when);
    return { started: true, reason: safeReason, start: when.toISOString() };
  }

  markExternalIdleEnd(reason = 'external', at = this.clock()) {
    return this._closeExternalIdle(this._safeReason(reason), at);
  }

  markTelemetryUnavailable(reason = 'telemetry_unavailable', at = this.clock()) {
    const when = at instanceof Date ? at : new Date(at);
    if (!Number.isFinite(when.getTime())) {
      return { marked: false, reason: 'invalid_time' };
    }
    const hadActive = Boolean(this.activeInterval);
    if (hadActive) {
      this._closeInterval(when, this._safeReason(reason), { suppressNudge: true });
    }
    this.sessionStartedAt = null;
    return {
      marked: true,
      reason: this._safeReason(reason),
      closed_active: hadActive,
      at: when.toISOString()
    };
  }

  markTelemetryAvailable(reason = 'telemetry_available', at = this.clock()) {
    const when = at instanceof Date ? at : new Date(at);
    if (!Number.isFinite(when.getTime())) {
      return { marked: false, reason: 'invalid_time' };
    }
    this.sessionStartedAt = when;
    return {
      marked: true,
      reason: this._safeReason(reason),
      at: when.toISOString()
    };
  }

  _activeSegmentForDate(dateKey, now) {
    if (!this.activeInterval) {
      return null;
    }

    const bounds = this._localDayBounds(dateKey);
    const start = this.activeInterval.start > bounds.start ? this.activeInterval.start : bounds.start;
    const end = now < bounds.end ? now : bounds.end;
    if (end <= start) {
      return null;
    }

    return { start, end };
  }

  _activeSegmentForRange(start, end) {
    if (!this.activeInterval) {
      return null;
    }

    const segmentStart = this.activeInterval.start > start ? this.activeInterval.start : start;
    const segmentEnd = this.clock() < end ? this.clock() : end;
    if (segmentEnd <= segmentStart) {
      return null;
    }

    return { start: segmentStart, end: segmentEnd };
  }

  _clipInterval(interval, rangeStartMs, rangeEndMs) {
    const startMs = new Date(interval.start).getTime();
    const endMs = new Date(interval.end).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= rangeStartMs || startMs >= rangeEndMs) {
      return null;
    }

    const clippedStartMs = Math.max(startMs, rangeStartMs);
    const clippedEndMs = Math.min(endMs, rangeEndMs);
    if (clippedEndMs <= clippedStartMs) {
      return null;
    }

    return {
      ...interval,
      start: new Date(clippedStartMs).toISOString(),
      end: new Date(clippedEndMs).toISOString(),
      duration_seconds: Math.round((clippedEndMs - clippedStartMs) / 1000)
    };
  }

  _poll() {
    let idleSeconds = 0;
    try {
      idleSeconds = Number(this.getIdleSeconds() || 0);
      this.lastPollError = null;
    } catch (error) {
      idleSeconds = 0;
      this.lastPollError = error?.message || String(error);
    }

    const now = this.clock();
    this.lastPollAt = now.toISOString();
    if (idleSeconds >= this.thresholdSeconds) {
      if (!this.activeInterval) {
        const inferredStart = new Date(now.getTime() - ((idleSeconds - this.thresholdSeconds) * 1000));
        const start = this._capStartToTelemetrySession(inferredStart);
        this.activeInterval = { start };
        this._saveActiveState(now, { force: true });
        return;
      }
      this._saveActiveState(now);
      return;
    }

    if (this.activeInterval) {
      this._closeInterval(now, 'input');
    }
  }

  _closeInterval(end, reason, options = {}) {
    if (!this.activeInterval) {
      return;
    }

    const start = this.activeInterval.start;
    this.activeInterval = null;
    this._clearActiveState();
    if (end <= start) {
      return;
    }

    this._writeSplitInterval(start, end, reason);
    this.lastIntervalClosedAt = end.toISOString();
    if (options.emit !== false && this.onIntervalClosed) {
      const payload = {
        start: start.toISOString(),
        end: end.toISOString(),
        duration_seconds: Math.max(0, Math.round((end.getTime() - start.getTime()) / 1000)),
        reason,
        source: 'system_idle'
      };
      if (options.suppressNudge) {
        payload.suppress_nudge = true;
      }
      this.onIntervalClosed(payload);
    }
  }

  _closeExternalIdle(reason, at = this.clock()) {
    const safeReason = this._safeReason(reason);
    const start = this.externalIdleStarts.get(safeReason);
    const end = at instanceof Date ? at : new Date(at);
    this.externalIdleStarts.delete(safeReason);
    if (!start || !Number.isFinite(end.getTime()) || end <= start) {
      return { closed: false };
    }
    this._writeSplitInterval(start, end, safeReason);
    return {
      closed: true,
      reason: safeReason,
      start: start.toISOString(),
      end: end.toISOString(),
      duration_seconds: Math.round((end.getTime() - start.getTime()) / 1000)
    };
  }

  _safeReason(reason = '') {
    const value = String(reason || '').trim().toLowerCase().replace(/[^a-z0-9_-]+/g, '_');
    return value || 'external';
  }

  _writeSplitInterval(start, end, reason) {
    let cursor = new Date(start);

    while (cursor < end) {
      const dateKey = this._localDateKey(cursor);
      const nextDay = this._nextLocalMidnight(cursor);
      const segmentEnd = nextDay < end ? nextDay : end;
      this._appendInterval(dateKey, {
        start: cursor.toISOString(),
        end: segmentEnd.toISOString(),
        duration_seconds: Math.max(0, Math.round((segmentEnd.getTime() - cursor.getTime()) / 1000)),
        threshold_seconds: this.thresholdSeconds,
        reason,
        source: 'system_idle'
      });
      cursor = segmentEnd;
    }
  }

  _restoreActiveState() {
    if (!fs.existsSync(this.activeStatePath)) {
      return;
    }

    try {
      const state = JSON.parse(fs.readFileSync(this.activeStatePath, 'utf8'));
      const start = new Date(state.start);
      const lastSeen = this._activeStateLastSeen(state);
      if (Number.isFinite(start.getTime())) {
        if (this._isRestoredActiveStateStale(lastSeen)) {
          this._closeRestoredStaleInterval(start, lastSeen);
          this._clearActiveState();
          return;
        }
        this.activeInterval = { start };
        if (Number.isFinite(lastSeen.getTime())) {
          this.lastActiveStateSaveMs = lastSeen.getTime();
        }
      }
    } catch {
      this.activeInterval = null;
    }
  }

  _saveActiveState(lastSeen = this.clock(), options = {}) {
    if (!this.activeInterval) {
      return;
    }

    const lastSeenMs = lastSeen.getTime();
    if (
      !options.force &&
      Number.isFinite(lastSeenMs) &&
      this.lastActiveStateSaveMs > 0 &&
      (lastSeenMs - this.lastActiveStateSaveMs) < this.activeStateSaveIntervalMs
    ) {
      return;
    }

    fs.writeFileSync(this.activeStatePath, JSON.stringify({
      start: this.activeInterval.start.toISOString(),
      last_seen: lastSeen.toISOString(),
      threshold_seconds: this.thresholdSeconds
    }, null, 2), 'utf8');
    this.lastActiveStateSaveMs = Number.isFinite(lastSeenMs) ? lastSeenMs : Date.now();
  }

  _clearActiveState() {
    if (fs.existsSync(this.activeStatePath)) {
      fs.unlinkSync(this.activeStatePath);
    }
    this.lastActiveStateSaveMs = 0;
  }

  _activeStateLastSeen(state = {}) {
    const explicit = new Date(state.last_seen);
    if (Number.isFinite(explicit.getTime())) {
      return explicit;
    }
    try {
      const stats = fs.statSync(this.activeStatePath);
      if (Number.isFinite(stats.mtimeMs)) {
        return new Date(stats.mtimeMs);
      }
    } catch {
      // Fall through to invalid date.
    }
    return new Date(Number.NaN);
  }

  _isRestoredActiveStateStale(lastSeen) {
    const lastSeenMs = lastSeen instanceof Date ? lastSeen.getTime() : Number.NaN;
    const nowMs = this.clock().getTime();
    return Number.isFinite(lastSeenMs) &&
      Number.isFinite(nowMs) &&
      this.activeStateStaleMs > 0 &&
      (nowMs - lastSeenMs) > this.activeStateStaleMs;
  }

  _closeRestoredStaleInterval(start, lastSeen) {
    if (!(start instanceof Date) || !(lastSeen instanceof Date) || lastSeen <= start) {
      return;
    }
    this._writeSplitInterval(start, lastSeen, 'telemetry_stopped');
    this.lastIntervalClosedAt = lastSeen.toISOString();
    if (this.onIntervalClosed) {
      this.onIntervalClosed({
        start: start.toISOString(),
        end: lastSeen.toISOString(),
        duration_seconds: Math.max(0, Math.round((lastSeen.getTime() - start.getTime()) / 1000)),
        reason: 'telemetry_stopped',
        source: 'system_idle',
        suppress_nudge: true
      });
    }
  }

  _capStartToTelemetrySession(start) {
    const sessionStart = this.sessionStartedAt instanceof Date ? this.sessionStartedAt : null;
    if (!sessionStart || !Number.isFinite(sessionStart.getTime()) || start >= sessionStart) {
      return start;
    }
    return new Date(sessionStart);
  }

  _inferredActivityGapIntervals(rangeStartMs, rangeEndMs) {
    if (!this.activityStore || !Number.isFinite(rangeStartMs) || !Number.isFinite(rangeEndMs) || rangeEndMs <= rangeStartMs) {
      return [];
    }

    const records = this.activityStore.queryRange(new Date(rangeStartMs).toISOString(), new Date(rangeEndMs).toISOString())
      .map((record) => this._recordCoverageInterval(record, rangeStartMs, rangeEndMs))
      .filter((interval) => interval)
      .sort((left, right) => left.startMs - right.startMs);

    if (!records.length) {
      return [];
    }

    const intervals = [];
    let coveredUntilMs = records[0].endMs;
    records.slice(1).forEach((record) => {
      this._pushInferredGap(intervals, coveredUntilMs, record.startMs);
      coveredUntilMs = Math.max(coveredUntilMs, record.endMs);
    });
    this._pushInferredGap(intervals, coveredUntilMs, rangeEndMs);
    return intervals;
  }

  _recordCoverageInterval(record, rangeStartMs, rangeEndMs) {
    if (!record) {
      return null;
    }

    const startMs = new Date(record.timestamp_start).getTime();
    if (!Number.isFinite(startMs)) {
      return null;
    }

    const explicitEndMs = new Date(record.timestamp_end).getTime();
    const estimatedEndMs = startMs + Math.max(0, Number(record.duration_ms_estimate) || 0);
    const endMs = Number.isFinite(explicitEndMs) && explicitEndMs > startMs
      ? explicitEndMs
      : Math.max(startMs, estimatedEndMs);
    const clippedStartMs = Math.max(rangeStartMs, startMs);
    const clippedEndMs = Math.min(rangeEndMs, endMs);
    if (!Number.isFinite(clippedEndMs) || clippedEndMs < clippedStartMs) {
      return null;
    }

    return {
      startMs: clippedStartMs,
      endMs: clippedEndMs
    };
  }

  _pushInferredGap(intervals, startMs, endMs) {
    const durationSeconds = Math.round((endMs - startMs) / 1000);
    if (durationSeconds < this.inferGapSeconds) {
      return;
    }

    intervals.push({
      start: new Date(startMs).toISOString(),
      end: new Date(endMs).toISOString(),
      duration_seconds: durationSeconds,
      threshold_seconds: this.inferGapSeconds,
      reason: 'activity_gap',
      source: 'activity_gap'
    });
  }

  _mergeIntervals(intervals = []) {
    const sorted = intervals
      .map((interval) => ({
        ...interval,
        startMs: new Date(interval.start).getTime(),
        endMs: new Date(interval.end).getTime()
      }))
      .filter((interval) => Number.isFinite(interval.startMs) && Number.isFinite(interval.endMs) && interval.endMs > interval.startMs)
      .sort((left, right) => left.startMs - right.startMs);

    const merged = [];
    sorted.forEach((interval) => {
      const last = merged[merged.length - 1];
      if (!last || interval.startMs > last.endMs) {
        merged.push({ ...interval });
        return;
      }

      last.endMs = Math.max(last.endMs, interval.endMs);
      last.end = new Date(last.endMs).toISOString();
      last.duration_seconds = Math.round((last.endMs - last.startMs) / 1000);
      if (last.source !== interval.source) {
        last.source = 'combined';
      }
    });

    return merged.map(({ startMs, endMs, ...interval }) => interval);
  }

  _appendInterval(dateKey, interval) {
    if (interval.duration_seconds <= 0) {
      return;
    }

    fs.appendFileSync(this._logPath(dateKey), `${JSON.stringify(interval)}\n`, 'utf8');
  }

  _readIntervals(dateKey) {
    const filePath = this._logPath(dateKey);
    if (!fs.existsSync(filePath)) {
      return [];
    }

    return fs.readFileSync(filePath, 'utf8')
      .split('\n')
      .filter(Boolean)
      .map((line) => {
        try {
          return JSON.parse(line);
        } catch {
          return null;
        }
      })
      .filter(Boolean);
  }

  _logPath(dateKey) {
    return path.join(this.basePath, `${dateKey}.jsonl`);
  }

  _localDateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  _nextLocalMidnight(date) {
    const next = new Date(date);
    next.setHours(24, 0, 0, 0);
    return next;
  }

  _localDayBounds(dateKey) {
    const [year, month, day] = String(dateKey).split('-').map((value) => Number(value));
    const start = new Date(year, month - 1, day, 0, 0, 0, 0);
    const end = new Date(year, month - 1, day + 1, 0, 0, 0, 0);
    return { start, end };
  }

  _dateKeysInRange(start, end) {
    const keys = [];
    const cursor = new Date(start);
    cursor.setHours(0, 0, 0, 0);
    const endDay = new Date(end);
    endDay.setHours(0, 0, 0, 0);

    while (cursor <= endDay) {
      keys.push(this._localDateKey(cursor));
      cursor.setDate(cursor.getDate() + 1);
    }

    return keys;
  }
}

module.exports = { SystemIdleService };
