function normalizeActivity(record) {
  const payload = record && record.content ? record.content : record;
  const inferredAppName = inferAppName(payload, record);

  return {
    id: payload.id || payload.frame_id || payload.audio_id || null,
    timestamp_start: payload.timestamp_start || payload.timestamp || null,
    timestamp_end: payload.timestamp_end || payload.timestamp || null,
    app_name: inferredAppName,
    window_title: payload.window_name || payload.window_title || null,
    url_if_available: payload.browser_url || payload.url_if_available || null,
    ocr_text: record.text || record.ocr_text || payload.text || payload.ocr_text || null,
    transcript_text: record.transcription || record.transcript_text || payload.transcription || payload.transcript_text || null,
    file_path_if_available: payload.file_path || null,
    activity_type: payload.content_type || record.activity_type || payload.activity_type || record.type || payload.type || 'unknown',
    sensitivity_level: record.sensitivity_level || payload.sensitivity_level || 'normal',
    source: record.source || payload.source || (record.type === 'manual' || payload.type === 'manual' ? 'manual' : 'screenpipe'),
    confidence_score: Number(payload.confidence_score ?? record.confidence_score ?? 0.75),
    duration_ms_estimate: Number(payload.duration_ms_estimate ?? record.duration_ms_estimate ?? 0),
    manual_kind: payload.manual_kind || record.manual_kind || null,
    manual_local_date_key: payload.manual_local_date_key || record.manual_local_date_key || null,
    manual_parent_id: payload.manual_parent_id || record.manual_parent_id || null,
    manual_segment_index: payload.manual_segment_index ?? record.manual_segment_index ?? null,
    manual_segment_count: payload.manual_segment_count ?? record.manual_segment_count ?? null
  };
}

function inferAppName(payload = {}, record = {}) {
  if (payload.app_name) {
    return payload.app_name;
  }

  const title = String(payload.window_name || payload.window_title || '').toLowerCase();
  const text = String(record.text || record.ocr_text || payload.text || payload.ocr_text || '').toLowerCase();
  if (
    title.includes('remote desktop connection') ||
    /remote desktop connection|another connection was made to the remote computer/.test(text)
  ) {
    return 'mstsc.exe';
  }

  return null;
}

module.exports = { normalizeActivity };
