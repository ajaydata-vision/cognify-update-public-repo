# Screenpipe Companion MVP

Windows-first floating AI desktop assistant prototype built on top of Screenpipe.

## What it does

- Floating always-on-top AI orb with recording status
- Collapsible widget and click-to-open panel
- Chat panel for recent-activity Q&A, explicit time-range queries, and Screenpipe diagnostics
- Daily summary generation
- Task extraction from OCR/transcript text
- Pause/resume + delete-range action from the panel
- Privacy filters (excluded apps/domains, private-window filtering, redaction)
- Audit logging of assistant suggestions/actions

## Run

```bash
npm install
npm start
```

## Verify

```bash
curl http://127.0.0.1:3030/health
npm test
```

## Docs

- Screenpipe discovery report: `docs/SCREENPIPE_DISCOVERY_REPORT.md`
- Architecture and plan: `docs/ARCHITECTURE_AND_PLAN.md`
