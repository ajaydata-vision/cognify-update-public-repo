if (new URLSearchParams(window.location.search).has('opaque')) {
  document.body.classList.add('opaque');
}

const closeButton = document.getElementById('close');
const noteText = document.getElementById('noteText');
const saveButton = document.getElementById('save');
const swatches = document.getElementById('swatches');
const notesList = document.getElementById('notesList');
const noteCount = document.getElementById('noteCount');
const noteSearch = document.getElementById('noteSearch');
const clearSearch = document.getElementById('clearSearch');

let selectedColor = 'blue';
let allNotes = [];

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatNoteTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return 'Unknown time';
  }

  return date.toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });
}

function searchMatches(note, query) {
  if (!query) {
    return true;
  }

  return String(note.text || '').toLowerCase().includes(query);
}

function visibleNotes() {
  const query = noteSearch.value.trim().toLowerCase();
  return allNotes.filter((note) => searchMatches(note, query));
}

function renderNotes(notes = allNotes) {
  allNotes = notes;
  const visible = visibleNotes();
  noteCount.textContent = noteSearch.value.trim() ? `${visible.length}/${allNotes.length}` : String(allNotes.length);
  if (!visible.length) {
    notesList.innerHTML = noteSearch.value.trim()
      ? '<div class="empty">No matching notes found.</div>'
      : '<div class="empty">No notes yet. Capture quick ideas, reminders, or manager-facing points here.</div>';
    return;
  }

  notesList.innerHTML = visible.map((note) => `
    <div class="note ${escapeHtml(note.color || 'blue')}">
      <div class="note-ribbon"></div>
      <div class="note-body">
        <div class="note-text">${escapeHtml(note.text || '')}</div>
        <div class="note-meta">
          <span>${escapeHtml(formatNoteTime(note.updated_at || note.created_at))}</span>
          <button class="note-delete" data-delete="${escapeHtml(note.id)}">Delete</button>
        </div>
      </div>
    </div>
  `).join('');

  notesList.querySelectorAll('[data-delete]').forEach((button) => {
    button.addEventListener('click', async () => {
      const result = await window.assistantApi.deleteNote(button.dataset.delete);
      allNotes = result.notes || [];
      renderNotes();
    });
  });
}

async function refreshNotes() {
  const result = await window.assistantApi.getNotes().catch(() => ({ notes: [] }));
  allNotes = result.notes || [];
  renderNotes();
}

async function saveNote() {
  const text = noteText.value.trim();
  if (!text) {
    noteText.focus();
    return;
  }

  saveButton.disabled = true;
  saveButton.textContent = 'Saving';
  try {
    const result = await window.assistantApi.saveNote({ text, color: selectedColor });
    noteText.value = '';
    allNotes = result.notes || [];
    noteSearch.value = '';
    renderNotes();
  } finally {
    saveButton.disabled = false;
    saveButton.textContent = 'Save Note';
    noteText.focus();
  }
}

swatches.addEventListener('click', (event) => {
  const button = event.target.closest('[data-color]');
  if (!button) {
    return;
  }

  selectedColor = button.dataset.color || 'blue';
  swatches.querySelectorAll('.swatch').forEach((swatch) => {
    swatch.classList.toggle('active', swatch === button);
  });
});

closeButton.addEventListener('click', () => {
  window.assistantApi.hideNotes();
});

saveButton.addEventListener('click', saveNote);

noteSearch.addEventListener('input', () => renderNotes());

clearSearch.addEventListener('click', () => {
  noteSearch.value = '';
  renderNotes();
  noteSearch.focus();
});

noteText.addEventListener('keydown', (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
    event.preventDefault();
    saveNote();
  }
});

refreshNotes();
