if (new URLSearchParams(window.location.search).has('opaque')) {
  document.body.classList.add('opaque');
}

const shell = document.getElementById('shell');
const closeButton = document.getElementById('close');
const healthRing = document.getElementById('healthRing');
const healthScore = document.getElementById('healthScore');
const healthTitle = document.getElementById('healthTitle');
const healthCopy = document.getElementById('healthCopy');
const checks = document.getElementById('checks');
const runningSince = document.getElementById('runningSince');
const runningMeta = document.getElementById('runningMeta');
const startupCopy = document.getElementById('startupCopy');
const startupToggle = document.getElementById('startupToggle');
const updateCopy = document.getElementById('updateCopy');
const updateToggle = document.getElementById('updateToggle');
const updateProgress = document.getElementById('updateProgress');
const updateProgressBar = document.getElementById('updateProgressBar');
let repairInFlight = null;
let startupStatus = { enabled: false, supported: false };
let updatePollTimer = null;
let refreshTimer = null;
let refreshInFlight = null;

function initialDiagnostics() {
  const now = new Date().toISOString();
  return {
    checked_at: now,
    running_since: now,
    localhost: { ok: true, label: 'Localhost API', detail: 'Checking in background', informational: true },
    screenpipe: { ok: true, label: 'Screenpipe', detail: 'Checking in background', informational: true },
    screenpipe_ownership: { ok: true, label: 'Screenpipe Ownership', detail: 'Checking in background', informational: true },
    search_api: { ok: true, label: 'Search API', detail: 'Deferred for responsiveness', informational: true },
    ffmpeg: { ok: true, label: 'FFmpeg', detail: 'Checking in background', informational: true },
    low_ram_mode: { ok: true, label: 'Low RAM Mode', detail: 'Checking profile', informational: true },
    activity_store: { ok: true, label: 'Activity Store', detail: 'Checking in background', informational: true },
    listening: { ok: true, label: 'Listening', detail: 'Checking in background', informational: true },
    screenpipe_memory: { ok: true, label: 'Screenpipe RAM', detail: 'Sampling in background', informational: true },
    recording: { ok: true, label: 'Recording', detail: 'Checking in background', informational: true },
    sqlite: { ok: true, label: 'SQLite', detail: 'Checking in background', informational: true },
    updater: {}
  };
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function compactDetail(item = {}) {
  const detail = String(item.detail || (item.ok ? 'OK' : 'Needs attention'));
  if (item.label === 'FFmpeg' && detail.includes('Found:')) {
    return 'Found locally';
  }
  return detail;
}

function actionForItem(item = {}) {
  if (item.ok) {
    return null;
  }

  if (item.label === 'Localhost API') {
    return { action: 'start-localhost', label: 'Start' };
  }
  if (item.label === 'Screenpipe') {
    return { action: 'start-screenpipe', label: 'Start' };
  }
  if (item.label === 'Recording') {
    return { action: 'resume-recording', label: 'Resume' };
  }
  return null;
}

function renderChecks(items = []) {
  checks.innerHTML = items.map((item) => {
    const action = actionForItem(item);
    const statusClass = item.informational ? 'info' : (item.ok ? 'ok' : 'bad');
    return `
      <div class="check ${statusClass}">
        <span class="dot"></span>
        <div>
          <div class="check-title">${escapeHtml(item.label || 'Status')}</div>
          <div class="check-copy">${escapeHtml(compactDetail(item))}</div>
        </div>
        ${action ? `<button class="check-action" data-action="${escapeHtml(action.action)}">${escapeHtml(action.label)}</button>` : ''}
      </div>
    `;
  }).join('');

  checks.querySelectorAll('[data-action]').forEach((button) => {
    button.addEventListener('click', () => runRepair(button.dataset.action, button));
  });
}

function formatTime(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return '--';
  }

  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function formatUptime(startValue, endValue) {
  const start = new Date(startValue);
  const end = new Date(endValue);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    return 'Uptime unavailable';
  }

  const minutes = Math.max(0, Math.round((end.getTime() - start.getTime()) / 60000));
  if (minutes >= 60) {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins ? `${hours}h ${mins}m uptime` : `${hours}h uptime`;
  }

  return `${minutes}m uptime`;
}

function renderHealth(diagnostics = {}) {
  const items = [
    diagnostics.localhost,
    diagnostics.screenpipe,
    diagnostics.screenpipe_ownership,
    diagnostics.search_api,
    diagnostics.ffmpeg,
    diagnostics.low_ram_mode,
    diagnostics.activity_store,
    diagnostics.listening,
    diagnostics.screenpipe_memory,
    diagnostics.recording,
    diagnostics.sqlite
  ].filter((item) => item && !(item.informational && /warming up|sampling in background|deferred/i.test(String(item.detail || ''))));
  const runtimeItems = items.filter((item) => !item.informational);
  const okCount = runtimeItems.filter((item) => item.ok).length;
  const percent = runtimeItems.length ? Math.round((okCount / runtimeItems.length) * 100) : 100;

  shell.classList.toggle('bad-state', percent < 100);
  healthRing.style.setProperty('--health', `${Math.round((percent / 100) * 360)}deg`);
  healthScore.textContent = `${percent}%`;
  healthTitle.textContent = percent === 100 ? 'Everything is in place' : 'Needs attention';
  healthCopy.textContent = runtimeItems.length
    ? `${okCount} of ${runtimeItems.length} runtime checks are healthy.`
    : 'Runtime checks are loading.';
  runningSince.textContent = formatTime(diagnostics.running_since);
  runningMeta.textContent = `${formatUptime(diagnostics.running_since, diagnostics.checked_at)} | Last checked ${formatTime(diagnostics.checked_at)}`;
  renderStartup(startupStatus);
  renderUpdate(diagnostics.updater);
  renderChecks(items);
}

async function refresh(options = {}) {
  if (document.hidden) {
    return null;
  }
  if (refreshInFlight) {
    return refreshInFlight;
  }

  refreshInFlight = (async () => {
    const diagnostics = await window.assistantApi.getDiagnostics({
      force: Boolean(options.force)
    }).catch(() => ({}));
    window.assistantApi.getStartupStatus()
      .then((startup) => {
        startupStatus = startup || { enabled: false, supported: false };
        renderStartup(startupStatus);
      })
      .catch(() => {});
    renderHealth(diagnostics);
    return diagnostics;
  })();

  try {
    return await refreshInFlight;
  } finally {
    refreshInFlight = null;
  }
}

function renderStartup(status = {}) {
  if (!status.supported) {
    startupCopy.textContent = 'Launcher not found on this install.';
    startupToggle.textContent = 'Unavailable';
    startupToggle.disabled = true;
    startupToggle.classList.remove('remove');
    return;
  }

  startupToggle.disabled = false;
  startupToggle.textContent = status.enabled ? 'Remove' : 'Add';
  startupToggle.classList.toggle('remove', Boolean(status.enabled));
  startupCopy.textContent = status.enabled
    ? 'Cognify starts automatically after sign-in.'
    : 'Add Cognify to Windows startup.';
}

async function toggleStartup() {
  startupToggle.disabled = true;
  const nextEnabled = !startupStatus.enabled;
  startupToggle.textContent = nextEnabled ? 'Adding' : 'Removing';
  try {
    startupStatus = await window.assistantApi.toggleStartup(nextEnabled);
    renderStartup(startupStatus);
  } catch (error) {
    startupCopy.textContent = error?.message || 'Startup update failed.';
  } finally {
    startupToggle.disabled = false;
  }
}

function renderUpdate(state = {}) {
  const status = state.status || 'idle';
  const detail = state.detail || 'No update check has run yet.';
  const busy = ['checking', 'downloading', 'verifying', 'extracting', 'backing-up', 'applying'].includes(status);
  const progress = Number(state.progress_percent);
  updateCopy.textContent = detail;
  updateToggle.disabled = busy;
  updateToggle.textContent = busy ? updateButtonLabel(status) : 'Get Update';
  if (updateProgress && updateProgressBar) {
    updateProgress.classList.toggle('visible', busy || status === 'applied');
    updateProgressBar.style.width = `${Math.max(0, Math.min(100, Number.isFinite(progress) ? progress : (status === 'applied' ? 100 : 8)))}%`;
  }
}

function updateButtonLabel(status) {
  if (status === 'downloading') {
    return 'Downloading';
  }
  if (status === 'verifying') {
    return 'Verifying';
  }
  if (status === 'extracting') {
    return 'Extracting';
  }
  if (status === 'backing-up') {
    return 'Backing Up';
  }
  if (status === 'applying') {
    return 'Applying';
  }
  return 'Checking';
}

function startUpdatePolling() {
  if (updatePollTimer) {
    return;
  }

  updatePollTimer = setInterval(async () => {
    const state = await window.assistantApi.getUpdateState().catch(() => null);
    if (state) {
      renderUpdate(state);
    }
  }, 800);
}

function stopUpdatePolling() {
  if (!updatePollTimer) {
    return;
  }

  clearInterval(updatePollTimer);
  updatePollTimer = null;
}

async function runGetUpdate() {
  updateToggle.disabled = true;
  updateToggle.textContent = 'Checking';
  updateCopy.textContent = 'Checking GitHub for Cognify updates...';
  startUpdatePolling();
  try {
    const state = await window.assistantApi.getUpdate();
    renderUpdate(state);
  } catch (error) {
    renderUpdate(error?.state || { status: 'failed', detail: error?.message || 'Update check failed.' });
  } finally {
    stopUpdatePolling();
    await refresh();
  }
}

async function runRepair(action, button) {
  if (repairInFlight) {
    return;
  }

  repairInFlight = action;
  const previousText = button?.textContent || '';
  if (button) {
    button.disabled = true;
    button.textContent = 'Working';
  }

  try {
    await window.assistantApi.repairHealth(action);
    for (let index = 0; index < 8; index += 1) {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      const diagnostics = await refresh() || {};
      const items = [diagnostics.localhost, diagnostics.screenpipe, diagnostics.ffmpeg, diagnostics.listening, diagnostics.screenpipe_memory, diagnostics.recording].filter(Boolean);
      if (items.every((item) => item.ok)) {
        return;
      }
    }
  } finally {
    repairInFlight = null;
    if (button) {
      button.disabled = false;
      button.textContent = previousText;
    }
    await refresh();
  }
}

closeButton.addEventListener('click', () => {
  window.assistantApi.hideHealth();
});

startupToggle.addEventListener('click', toggleStartup);
updateToggle.addEventListener('click', runGetUpdate);

refreshTimer = setInterval(refresh, 300000);
renderStartup(startupStatus);
renderUpdate({});
renderHealth(initialDiagnostics());
refresh();

window.addEventListener('beforeunload', () => {
  clearInterval(refreshTimer);
});
