const { app, BrowserWindow, ipcMain, shell, screen, Tray, Menu, nativeImage, clipboard, powerMonitor, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const https = require('https');
const crypto = require('crypto');
const os = require('os');
const { execFileSync, spawn } = require('child_process');
const { createServices } = require('./services');
const { effectiveScreenpipeRetention } = require('./services/modules/settings-service');
const {
  prepareManualActivityBlock,
  manualActivitySaveResponse,
  manualConsumedSlots,
  manualSlotAlreadyConsumed,
  isManualTimingRecord
} = require('./services/modules/manual-activity-service');
const {
  buildWorkHoursLedger,
  safePcAvailableMinutesFromSummary
} = require('./services/modules/work-hours-ledger');

let nudgeAnalysisModule = null;
let roleClassificationModule = null;
let nudgeDetailModule = null;
let weeklyPerformanceEvidenceModule = null;
let performanceRuleEngineModule = null;
let hodAppraisalDraftModule = null;
let myWeeklyReportModule = null;

function nudgeAnalysis() {
  if (!nudgeAnalysisModule) {
    nudgeAnalysisModule = require('./services/modules/nudge-analysis-service');
  }
  return nudgeAnalysisModule;
}

function roleClassification() {
  if (!roleClassificationModule) {
    roleClassificationModule = require('./services/modules/role-classification-service');
  }
  return roleClassificationModule;
}

function nudgeDetails() {
  if (!nudgeDetailModule) {
    nudgeDetailModule = require('./services/modules/nudge-detail-service');
  }
  return nudgeDetailModule;
}

function weeklyPerformanceEvidence() {
  if (!weeklyPerformanceEvidenceModule) {
    weeklyPerformanceEvidenceModule = require('./services/modules/weekly-performance-evidence-service');
  }
  return weeklyPerformanceEvidenceModule;
}

function performanceRuleEngine() {
  if (!performanceRuleEngineModule) {
    performanceRuleEngineModule = require('./services/modules/performance-rule-engine');
  }
  return performanceRuleEngineModule;
}

function hodAppraisalDraft() {
  if (!hodAppraisalDraftModule) {
    hodAppraisalDraftModule = require('./services/modules/hod-appraisal-draft-service');
  }
  return hodAppraisalDraftModule;
}

function myWeeklyReport() {
  if (!myWeeklyReportModule) {
    myWeeklyReportModule = require('./services/modules/my-weekly-report-service');
  }
  return myWeeklyReportModule;
}

const configuredUserDataDir = String(process.env.COGNIFY_USER_DATA_DIR || '').trim();
if (configuredUserDataDir) {
  fs.mkdirSync(configuredUserDataDir, { recursive: true });
  app.setPath('userData', configuredUserDataDir);
  app.setPath('sessionData', path.join(configuredUserDataDir, 'session-data'));
}

const EXIT_TASK_ARG = '--cognify-exit';
const startupTracePath = path.join(__dirname, '..', 'startup-trace.log');
const widgetStatePath = path.join(app.getPath('userData'), 'widget-state.json');
const exitRequestPath = path.join(app.getPath('userData'), 'exit-request.json');
const instanceHeartbeatPath = path.join(app.getPath('userData'), 'instance-heartbeat.json');
const DEFAULT_UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/ajaydata-vision/cognify-update-public-repo/main/update.txt';
const DEFAULT_UPDATE_MANIFEST_FALLBACK_URLS = Object.freeze([
  DEFAULT_UPDATE_MANIFEST_URL,
  'https://github.com/ajaydata-vision/cognify-update-public-repo/raw/main/update.txt',
  'https://api.github.com/repos/ajaydata-vision/cognify-update-public-repo/contents/update.txt?ref=main'
]);
const MAX_APP_UPDATE_BYTES = 300 * 1024 * 1024;
const SNAPSHOT_WINDOW_WIDTH = 320;
const SNAPSHOT_WINDOW_HEIGHT = 640;
const WORK_HOURS_WINDOW_WIDTH = 360;
const WORK_HOURS_WINDOW_HEIGHT = SNAPSHOT_WINDOW_HEIGHT;
const WORK_SUMMARY_WINDOW_WIDTH = 1040;
const WORK_SUMMARY_WINDOW_HEIGHT = 720;
const WIDGET_WINDOW_SIZE = 72;
const REPORT_WINDOW_WIDTH = 820;
const REPORT_WINDOW_HEIGHT = 640;
const NUDGE_WINDOW_WIDTH = 304;
const NUDGE_WINDOW_HEIGHT = 132;
const NUDGE_MANUAL_WINDOW_HEIGHT = 268;
const NUDGE_DETAIL_WINDOW_WIDTH = 360;
const NUDGE_DETAIL_WINDOW_HEIGHT = 316;
const SCREENPIPE_PORT_MIN = 3030;
const SCREENPIPE_PORT_MAX = 4029;
const SCREENPIPE_PROCESS_STOP_TIMEOUT_MS = 7000;
const SCREENPIPE_PROCESS_QUERY_TIMEOUT_MS = 3000;
const EXIT_REQUEST_MAX_AGE_MS = 60 * 1000;
const INSTANCE_HEARTBEAT_MAX_AGE_MS = 10 * 1000;

let widgetWindow;
let setupWindow;
let snapshotWindow;
let panelWindow;
let reportWindow;
let healthWindow;
let notesWindow;
let workHoursWindow;
let nudgeWindow;
let nudgeDetailWindow;
let services;
let dragState = null;
let debugLogPath;
let perfLogPath;
let tray;
let isQuitting = false;
let isRelaunching = false;
let keepSnapshotVisible = false;
let pendingPanelMode = 'reports';
let appStartedAt = new Date().toISOString();
let screenpipeStartInFlight = null;
let updateCheckInFlight = null;
let focusTrendCache = null;
let todayStatsCache = null;
let todayCategorySnapshotCache = null;
let activitySummaryCache = null;
let diagnosticsCache = null;
let focusTrendInFlight = null;
let todayStatsInFlight = null;
let todayCategorySnapshotInFlight = null;
let activitySummaryInFlight = null;
let diagnosticsInFlight = null;
let roleClassificationCache = null;
let performanceRulesCache = null;
let myWeeklyReportConfigCache = null;
const activityReportInFlight = new Map();
let heavyReportInFlight = null;

function isCompleteCategorySnapshot(value) {
  return Boolean(value && value.cache && value.cache.complete !== false && value.cache.pending !== true);
}
let nudgeTimer = null;
let nudgeHideTimer = null;
let exitRequestTimer = null;
let instanceHeartbeatTimer = null;
let meetingAudioTimer = null;
let screenpipeMemoryTimer = null;
let ffmpegPriorityTimer = null;
let reportCacheWarmTimer = null;
let reportCacheBackfillTimer = null;
let sqliteImportRetryTimer = null;
let liveTruthCurrentTimer = null;
let liveTruthRepairTimer = null;
let liveTruthCurrentStartupTimer = null;
let liveTruthRepairStartupTimer = null;
let dailyLogStartupTimer = null;
let dailyLogTimer = null;
let dailyLogPreparedSendTimer = null;
let updateCheckTimer = null;
let allowSetupWindowClose = false;
const hiddenWindowDestroyTimers = new Map();
let reportCacheBackfillInFlight = false;
let meetingAudioCheckInFlight = false;
let screenpipeMemoryCheckInFlight = false;
let reportCacheWarmInFlight = false;
let dailyLogInFlight = false;
let ffmpegPriorityCheckInFlight = false;
let pendingDailyProgressNudge = null;
let pendingDailyProgressTimer = null;
let readinessWarmRequested = false;
let startupBackgroundStarted = false;
let runtimeModeStarted = false;
let systemIdleStarted = false;
let runtimeAvailabilityStarted = false;
let windowsFocusStarted = false;
let windowsFocusStartTimer = null;
let windowsFocusWatchdogTimer = null;
let reportCacheWarmStartRequested = false;
let readinessWarmAllowedAtMs = 0;
let readinessWarmTimer = null;
let readinessWarmDueAtMs = 0;
let readinessWarmSource = null;
let lastActivityIngestWarmAtMs = 0;
let currentNudge = null;
let peakProductivityCache = null;
let panelNormalBounds = null;
let reportNormalBounds = null;
let meetingAudioActive = false;
let meetingAudioLastSeenAt = 0;
let screenpipeMemoryState = { privateBytes: 0, workingSetBytes: 0, pid: null, checkedAt: null, restarts: [], cpuSeconds: null, cpuPercent: null, highCpuSamples: 0, cpuRestarts: [], staleFrameRestarts: [] };
let screenpipeLastStopState = null;
let screenpipeProcessCache = null;
let screenLockStartedAtMs = null;
let screenSuspendStartedAtMs = null;
let screenpipeUnlockRestartTimer = null;
let screenpipeLastUnlockRestartAtMs = 0;
let screenpipeLastSpawnAtMs = 0;
const dismissedNudges = new Map();
const shownNudges = new Map();
const PERF_SLOW_MS = 750;
const TODAY_STATS_CACHE_MS = 10 * 60 * 1000;
const TODAY_CATEGORY_CACHE_MS = 2 * 60 * 1000;
const ACTIVITY_SUMMARY_CACHE_MS = 2 * 60 * 1000;
const FOCUS_TREND_CACHE_MS = 15 * 60 * 1000;
const DIAGNOSTICS_CACHE_MS = 10000;
const TELEMETRY_DIAGNOSTICS_CACHE_MS = 30 * 1000;
const MAX_REPORT_RANGE_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_DAILY_REPORT_RANGE_MS = 24 * 60 * 60 * 1000;
const NUDGE_START_DELAY_MS = 5 * 60 * 1000;
const NUDGE_MONITOR_INTERVAL_MS = 5 * 60 * 1000;
const ROLE_DETECTION_WINDOW_MS = 2 * 24 * 60 * 60 * 1000;
const ROLE_ONBOARDING_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;
const ROLE_FIRST_PROMPT_CONFIDENCE = 75;
const ROLE_RECLASSIFY_CONFIDENCE = 70;
const ROLE_RECLASSIFY_COOLDOWN_MS = 30 * 24 * 60 * 60 * 1000;
const MEETING_AUDIO_CHECK_MS = 60 * 1000;
const MEETING_AUDIO_IDLE_MS = 5 * 60 * 1000;
const SCREENPIPE_MEMORY_CHECK_MS = 10 * 60 * 1000;
const SCREENPIPE_MEMORY_HEALTHY_CHECK_MS = 15 * 60 * 1000;
const SCREENPIPE_MEMORY_PRESSURE_CHECK_MS = 10 * 60 * 1000;
const SCREENPIPE_CPU_BASELINE_CHECK_MS = 5 * 60 * 1000;
const REPORT_CACHE_WARM_DELAY_MS = 5 * 60 * 1000;
const REPORT_CACHE_WARM_INTERVAL_MS = 30 * 60 * 1000;
const READINESS_INGEST_WARM_MIN_MS = 5 * 60 * 1000;
const REPORT_CACHE_BACKFILL_DELAY_MS = 60 * 1000;
const REPORT_CACHE_BACKFILL_IDLE_MIN_MS = 7 * 60 * 1000;
const REPORT_CACHE_BACKFILL_SYNC_BUDGET_MS = 1200;
const REPORT_CACHE_BACKFILL_SYNC_WINDOWS = 4;
const LIVE_TRUTH_CURRENT_STARTUP_DELAY_MS = 5 * 60 * 1000;
const LIVE_TRUTH_REPAIR_STARTUP_DELAY_MS = 15 * 60 * 1000;
const LIVE_TRUTH_CURRENT_INTERVAL_MS = 10 * 60 * 1000;
const LIVE_TRUTH_REPAIR_INTERVAL_MS = 30 * 60 * 1000;
const LIVE_TRUTH_MIN_FREE_MEMORY_BYTES = 512 * 1024 * 1024;
const SQLITE_RECENT_IMPORT_DAYS = 3;
const DAILY_LOG_STARTUP_DELAY_MS = 90 * 1000;
const DAILY_LOG_CHECK_INTERVAL_MS = 60 * 60 * 1000;
const DAILY_LOG_SEND_AFTER_PREPARE_DELAY_MS = 5 * 60 * 1000;
const UPDATE_CHECK_INTERVAL_MS = 60 * 60 * 1000;
const WINDOWS_FOCUS_START_DELAY_MS = 2 * 60 * 1000;
const WINDOWS_FOCUS_WATCHDOG_INTERVAL_MS = 60 * 1000;
const WINDOWS_FOCUS_STALE_AFTER_MS = 3 * 60 * 1000;
const WINDOWS_FOCUS_STARTUP_GRACE_MS = 5 * 60 * 1000;
const POPUP_WINDOW_IDLE_DESTROY_MS = 2 * 60 * 1000;
const WORK_WINDOW_IDLE_DESTROY_MS = 3 * 60 * 1000;
const SCREENPIPE_MEMORY_WARN_BYTES = 1.5 * 1024 * 1024 * 1024;
const SCREENPIPE_MEMORY_RESTART_BYTES = 2.5 * 1024 * 1024 * 1024;
const SCREENPIPE_CPU_WARN_PERCENT = 15;
const SCREENPIPE_CPU_AUDIO_DISABLE_PERCENT = 25;
const SCREENPIPE_CPU_RESTART_PERCENT = 25;
const SCREENPIPE_CPU_RESTART_WINDOW_MS = 60 * 60 * 1000;
const SCREENPIPE_CPU_RESTART_MAX_PER_WINDOW = 1;
const SCREENPIPE_PROCESS_CACHE_MS = 5 * 60 * 1000;
const SCREENPIPE_RESOURCE_SAMPLE_STALE_MS = 20 * 60 * 1000;
const SCREENPIPE_STALE_FRAME_SAMPLE_COUNT = 12;
const SCREENPIPE_STALE_FRAME_MIN_SPAN_MS = 2 * 60 * 1000;
const SCREENPIPE_STALE_FRAME_RESTART_WINDOW_MS = 60 * 60 * 1000;
const SCREENPIPE_STALE_FRAME_RESTART_MAX_PER_WINDOW = 1;
const SCREENPIPE_UNLOCK_RESTART_MIN_LOCK_MS = 10 * 60 * 1000;
const SCREENPIPE_UNLOCK_RESTART_DELAY_MS = 8 * 1000;
const SCREENPIPE_UNLOCK_RESTART_COOLDOWN_MS = 30 * 60 * 1000;
const SCREENPIPE_COMPACTION_INTERVAL_MS = 5 * 60 * 1000;
const SCREENPIPE_FFMPEG_PRIORITY_LOOKAHEAD_MS = 15 * 1000;
const SCREENPIPE_FFMPEG_INITIAL_COMPACTION_DELAY_MS = 60 * 1000;
const SCREENPIPE_FFMPEG_PRIORITY_BURST_MS = 90 * 1000;
const SCREENPIPE_FFMPEG_PRIORITY_CHECK_MS = 1000;
const SCREENPIPE_FFMPEG_PRIORITY_FALLBACK_MS = 5 * 60 * 1000;
const SCREENPIPE_FFMPEG_PRIORITY_TIMEOUT_MS = 1500;
const SCREENPIPE_FFMPEG_PRIORITY_CLASS = 'Idle';
const LOW_RAM_TOTAL_MEMORY_BYTES = 9 * 1024 * 1024 * 1024;
const LOW_RAM_BACKGROUND_MIN_FREE_BYTES = 1024 * 1024 * 1024;
const LOW_RAM_POPUP_WINDOW_IDLE_DESTROY_MS = 30 * 1000;
const LOW_RAM_WORK_WINDOW_IDLE_DESTROY_MS = 60 * 1000;
const LOW_RAM_LIVE_TRUTH_CURRENT_INTERVAL_MS = 30 * 60 * 1000;
const LOW_RAM_LIVE_TRUTH_CURRENT_STARTUP_DELAY_MS = 15 * 60 * 1000;
const ROLE_CLASSIFICATION_CACHE_MS = 4 * 60 * 60 * 1000;
const SCREENPIPE_VIDEO_QUALITY = 'low';
const SCREENPIPE_VISION_FORCE_DISABLED = process.env.COGNIFY_EXPERIMENTAL_SCREENPIPE_VISION !== '1';
const SCREENPIPE_DEFAULT_LANGUAGE = 'english';
const AUDIO_DISABLED_AT_STARTUP = true;
const COGNIFY_ICON_DATA_URL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAT3SURBVFhH7ZZdUJRlGIY99NBDDj3sTGYCQbRYtVQQgYFAsBwkLBjR2jJ+RBRiUFPRHUMIDVgjcgO1VWD5WSWEMPpBSaXBMRiKwEVxdgWDpfi+527eb/n+3oUVnDzrnnnOdr7rft73fp53lyz5X8+pkAb4B9XDsJqVFYYQK/z53/ynCm3D0sAWYcfKZrIE2UT3qgbC6nrCmiuEV6yE0EsEwwXC2hqyrjsvpIWasYz/xnPrZbuQFmAXHUHNhOBGwnzwdTWE9RbC618RNlSLrk1fCMZQM5by31uwVrRhWcA1sSvQTlgcnLCpihB2jhBeIfZFmbGc//YztaINywOuCYM83GAj5PxEuDQAdD4AOkeAzmHA1g8c6iTEX1ThmysJEeWELWdEV9RnMPCMeeXp3Bued5Mw/Bfw5O/Zmvau8WmgqocQUT+KMOsoIstnEFVGiC4VXTGf4iWe5SUWNv7Yw+2E1hEN2Ad8zC0gfawVrz6wSGW4b0PU59OIKSHEFouDUaZnhDPALhi18OhWwvCkHt77GDjZTXjvKsFoJ3zQQii6QegaApon/lTgcoW19CG2mPDGKULcSTLxTEVS91zaOxx6eGUvYeOFuQPH7nxP94CXgYirvRI83kSIPyG6447Bj2dLCrQLaVp4YQ8p4LEpYPe386ddCVzVFNYOWhX4a45alN92SvCtJwiJxwnbjtIRni0pqImaZPjGJsIjt9p52R1v+K4GQlYzYc9lDzzyLEmBi6ycQsqtuyhz3sUvT52YmAL2VStwvHVE7OPZUvK1Gy6vW+2+5xF0xx5TS/h5BDrdewikf83STrOBI7T3QYKzOt8uwwnbDxOSDnETsbKRgrVLpm5QTfsnP+o7vz2qh8sadgFbyzxwdudF9aQY+K4XKryQkFQwE60zsKpuJlq74VjX8nilNKpwYyPxXJ2O2jxwdufvV6oGhsegwHcUEJLyBKPOQEidkKZdr7+Pqwa2WdXAFXf5NlD7A3SBcz5Vr2GPyQNPziekHEC+zsCay0KCdrf/+lg1kHxFTfvBFt8GSltUeFqxegIPnVDhB4GU/cjWGWBvuvZhuf6HaiC3VR21GDPh4QSP9eifGSC1TE378ZpZA5PArXtQ4DtzgXf2UYLOQGgt/LSvWgmbgtn12toPZc7ZqGVaCa5Jb/ipBu2oES62kwR/OgnUd0CF5wBpmRSsM8C0rkbsktPOjp3BpXIDOY3qnLNR215OMHeQdOfnrpOucwbPKCM4JzxwViUWFf5uNjl4tqT1FjFfu+Hq+jxwVkNOILFSP+dy2jUbThm1OwMqvPc3FZ6aLXVv5tmSQs3w21AtuuXAxVcThlyqiXujQEatbzjrXAt3jgM5Jg08C9j1kY//j2FVZNLu9twGUgywmnADdTeBAzWE5NMeeFIRoeBLz51rj52VxcbDycozdQo3w29zhejQ7vYiO8HxxAOXx0ou7ZzLgZM7nwPu3v3hAv6UbDlLwZFnRLccOHbnb5cTbtz3NjAXnN2517FnAOl7udHzpchSISG6RHTzgSu6QrB2Ad1aM5PA3X6g+Xug4hsucAqc23wLUWwxDLHFomu+wLG0Z5Zq1qtmzrXHvqjOecWdhl+ciSxzweWHxQfcuqA7X4i2HYN/4lEyv3lYdPiGkys1iyzpexfxN3yxSiqk4KSPBWNynpjPXrWU/cjfmU3G1KwXCH1R+hcdxhanVe52fwAAAABJRU5ErkJggg==';
let cognifyIconImage = null;
let remoteDesktopSessionCache = null;

const hasExitTaskArg = process.argv.includes(EXIT_TASK_ARG);
function traceStartup(message, payload = {}) {
  try {
    fs.appendFileSync(startupTracePath, `${JSON.stringify({ time: new Date().toISOString(), message, payload })}\n`, 'utf8');
  } catch {
    // Ignore trace failures.
  }
}

try {
  app.disableHardwareAcceleration();
  app.commandLine.appendSwitch('disable-gpu');
  app.commandLine.appendSwitch('disable-gpu-compositing');
  traceStartup('hardware_acceleration_disabled');
} catch (error) {
  traceStartup('hardware_acceleration_disable_failed', { error: error?.message || String(error) });
}

function shouldUseOpaquePopupWindow() {
  if (process.env.COGNIFY_OPAQUE_POPUPS === '1') {
    return true;
  }
  if (process.env.COGNIFY_OPAQUE_POPUPS === '0') {
    return false;
  }
  if (process.platform !== 'win32') {
    return false;
  }
  if (remoteDesktopSessionCache !== null) {
    return remoteDesktopSessionCache;
  }
  const sessionName = String(process.env.SESSIONNAME || '').toLowerCase();
  const clientName = String(process.env.CLIENTNAME || '').trim();
  if (sessionName.startsWith('rdp-') || sessionName.includes('rdp-tcp') || Boolean(clientName)) {
    remoteDesktopSessionCache = true;
    return true;
  }
  try {
    const result = execFileSync('powershell.exe', [
      '-NoProfile',
      '-Command',
      'Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SystemInformation]::TerminalServerSession'
    ], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 1500
    }).trim();
    remoteDesktopSessionCache = /^true$/i.test(result);
    return remoteDesktopSessionCache;
  } catch {
    remoteDesktopSessionCache = false;
    return false;
  }
}

function popupWindowTransparencyOptions() {
  const opaque = shouldUseOpaquePopupWindow();
  return {
    transparent: !opaque,
    backgroundColor: opaque ? '#0f141b' : '#00000000',
    opaqueFallback: opaque
  };
}

function perfLog(event, payload = {}) {
  try {
    const target = perfLogPath || path.join(app.getPath('userData'), 'perf-debug.log');
    fs.appendFileSync(target, `${JSON.stringify({
      timestamp: new Date().toISOString(),
      event,
      payload
    })}\n`, 'utf8');
  } catch {
    // Ignore performance logging failures.
  }
}

function writeExitRequest(reason = 'exit_task') {
  try {
    fs.mkdirSync(path.dirname(exitRequestPath), { recursive: true });
    fs.writeFileSync(exitRequestPath, JSON.stringify({
      requestedAt: new Date().toISOString(),
      pid: process.pid,
      reason
    }), 'utf8');
    traceStartup('exit_request_written', { reason });
    return true;
  } catch (error) {
    traceStartup('exit_request_write_failed', { reason, error: error?.message || String(error) });
    return false;
  }
}

function removeExitRequest() {
  try {
    if (fs.existsSync(exitRequestPath)) {
      fs.unlinkSync(exitRequestPath);
      traceStartup('exit_request_removed');
    }
  } catch (error) {
    traceStartup('exit_request_remove_failed', { error: error?.message || String(error) });
  }
}

function consumeExitRequest() {
  if (hasExitTaskArg || isQuitting) {
    return false;
  }

  if (!fs.existsSync(exitRequestPath)) {
    return false;
  }
  let request;
  try {
    request = JSON.parse(fs.readFileSync(exitRequestPath, 'utf8'));
  } catch {
    return false;
  }

  const requestedAtMs = Date.parse(request?.requestedAt || 0);
  const ageMs = Date.now() - requestedAtMs;
  if (!Number.isFinite(requestedAtMs) || ageMs < 0 || ageMs > EXIT_REQUEST_MAX_AGE_MS) {
    removeExitRequest();
    return false;
  }

  traceStartup('exit_request_consumed', { request });
  removeExitRequest();
  quitApp();
  return true;
}

function startExitRequestWatcher() {
  if (exitRequestTimer || hasExitTaskArg) {
    return;
  }

  consumeExitRequest();
  exitRequestTimer = setInterval(consumeExitRequest, 5000);
}

function readInstanceHeartbeat() {
  try {
    return JSON.parse(fs.readFileSync(instanceHeartbeatPath, 'utf8'));
  } catch {
    return null;
  }
}

function hasFreshInstanceHeartbeat() {
  const heartbeat = readInstanceHeartbeat();
  const updatedAtMs = Date.parse(heartbeat?.updatedAt || 0);
  const ageMs = Date.now() - updatedAtMs;
  return Boolean(
    heartbeat?.pid &&
    heartbeat.pid !== process.pid &&
    Number.isFinite(updatedAtMs) &&
    ageMs >= 0 &&
    ageMs <= INSTANCE_HEARTBEAT_MAX_AGE_MS
  );
}

function writeInstanceHeartbeat() {
  try {
    fs.mkdirSync(path.dirname(instanceHeartbeatPath), { recursive: true });
    fs.writeFileSync(instanceHeartbeatPath, JSON.stringify({
      pid: process.pid,
      updatedAt: new Date().toISOString()
    }), 'utf8');
  } catch (error) {
    traceStartup('instance_heartbeat_write_failed', { error: error?.message || String(error) });
  }
}

function startInstanceHeartbeat() {
  if (instanceHeartbeatTimer || hasExitTaskArg) {
    return;
  }

  writeInstanceHeartbeat();
  instanceHeartbeatTimer = setInterval(writeInstanceHeartbeat, 10000);
}

function stopInstanceHeartbeat() {
  if (instanceHeartbeatTimer) {
    clearInterval(instanceHeartbeatTimer);
    instanceHeartbeatTimer = null;
  }

  const heartbeat = readInstanceHeartbeat();
  if (heartbeat?.pid !== process.pid) {
    return;
  }

  try {
    fs.unlinkSync(instanceHeartbeatPath);
    traceStartup('instance_heartbeat_removed');
  } catch (error) {
    traceStartup('instance_heartbeat_remove_failed', { error: error?.message || String(error) });
  }
}

async function measurePerf(label, action, { slowMs = PERF_SLOW_MS, always = false } = {}) {
  const startedAt = Date.now();
  try {
    const result = await action();
    const durationMs = Date.now() - startedAt;
    if (always || durationMs >= slowMs) {
      perfLog('perf_timing', { label, duration_ms: durationMs, ok: true });
    }
    return result;
  } catch (error) {
    const durationMs = Date.now() - startedAt;
    perfLog('perf_timing', {
      label,
      duration_ms: durationMs,
      ok: false,
      error: error?.message || String(error)
    });
    throw error;
  }
}

function handleTimed(channel, handler, options = {}) {
  ipcMain.handle(channel, (event, ...args) => measurePerf(channel, () => handler(event, ...args), options));
}

function getCognifyIconPath() {
  const candidates = [
    path.join(__dirname, 'renderer', 'assets', 'cognify-mark.ico'),
    path.join(__dirname, 'renderer', 'assets', 'cognify-mark-256.png')
  ];
  return candidates.find((candidate) => fs.existsSync(candidate)) || null;
}

function getCognifyIcon() {
  if (!cognifyIconImage || cognifyIconImage.isEmpty()) {
    const iconPath = getCognifyIconPath();
    cognifyIconImage = iconPath
      ? nativeImage.createFromPath(iconPath)
      : nativeImage.createFromDataURL(COGNIFY_ICON_DATA_URL);
    if (!cognifyIconImage || cognifyIconImage.isEmpty()) {
      cognifyIconImage = nativeImage.createFromDataURL(COGNIFY_ICON_DATA_URL);
    }
    cognifyIconImage.setTemplateImage(false);
  }
  return cognifyIconImage;
}

function isOnboardingComplete() {
  try {
    return Boolean(services?.settings?.getSettings?.().onboarding?.completedAt);
  } catch {
    return false;
  }
}

function shouldShowSetupMode() {
  return Boolean(services) && !isOnboardingComplete();
}

function validateReportRange(startTime, endTime) {
  const startMs = new Date(startTime).getTime();
  const endMs = new Date(endTime).getTime();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) {
    throw new Error('Valid startTime and endTime are required.');
  }
  if (endMs <= startMs) {
    throw new Error('endTime must be later than startTime.');
  }
  if ((endMs - startMs) > MAX_REPORT_RANGE_MS) {
    throw new Error('Activity report range cannot be more than 7 days.');
  }
  return { startMs, endMs };
}

function validateDailyReportRange(startTime, endTime) {
  const range = validateReportRange(startTime, endTime);
  if ((range.endMs - range.startMs) > MAX_DAILY_REPORT_RANGE_MS) {
    throw new Error('Daily Report supports one day at a time. Use Timeline or My Weekly Report for multi-day review.');
  }
  return range;
}

function createWidgetWindow() {
  const bounds = resolveWidgetBounds();
  widgetWindow = new BrowserWindow({
    x: bounds.x,
    y: bounds.y,
    width: WIDGET_WINDOW_SIZE,
    height: WIDGET_WINDOW_SIZE,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    resizable: false,
    hasShadow: false,
    show: false,
    skipTaskbar: true,
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  traceStartup('widget_load_requested', { bounds });
  widgetWindow.webContents.on('dom-ready', () => {
    traceStartup('widget_dom_ready');
  });
  widgetWindow.webContents.on('did-finish-load', () => {
    traceStartup('widget_did_finish_load');
  });
  widgetWindow.webContents.on('did-fail-load', (_event, errorCode, errorDescription) => {
    traceStartup('widget_did_fail_load', { errorCode, errorDescription });
  });
  widgetWindow.webContents.on('render-process-gone', (_event, details) => {
    traceStartup('widget_render_process_gone', details || {});
  });
  widgetWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  widgetWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  widgetWindow.once('ready-to-show', () => {
    traceStartup('widget_ready_to_show');
    if (!widgetWindow || widgetWindow.isDestroyed()) {
      return;
    }
    if (!isOnboardingComplete()) {
      traceStartup('widget_hidden_until_onboarding_complete');
      return;
    }

    const nextBounds = resolveWidgetBounds();
    widgetWindow.setBounds(nextBounds);
    ensureWidgetVisible({ focus: false });
    traceStartup('widget_shown', { bounds: widgetWindow.getBounds() });
    startStartupBackgroundWork();
  });
  widgetWindow.on('move', persistWidgetBounds);
  widgetWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      quitApp();
    }
  });
}

function defaultWidgetBounds() {
  const cursor = screen.getCursorScreenPoint();
  const display = screen.getDisplayNearestPoint(cursor);
  const area = display?.workArea || { x: 0, y: 0, width: 1280, height: 720 };
  const width = WIDGET_WINDOW_SIZE;
  const height = WIDGET_WINDOW_SIZE;
  const margin = 20;
  return {
    x: area.x + Math.max(0, area.width - width - margin),
    y: area.y + Math.max(0, area.height - height - margin),
    width,
    height
  };
}

function resolveWidgetBounds() {
  const fallback = defaultWidgetBounds();
  const saved = readWidgetBounds();
  if (!saved || !areBoundsVisible(saved)) {
    return fallback;
  }

  return {
    x: Math.round(saved.x),
    y: Math.round(saved.y),
    width: fallback.width,
    height: fallback.height
  };
}

function readWidgetBounds() {
  try {
    const parsed = JSON.parse(fs.readFileSync(widgetStatePath, 'utf8'));
    if (!parsed || !Number.isFinite(parsed.x) || !Number.isFinite(parsed.y)) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function persistWidgetBounds() {
  if (!widgetWindow || widgetWindow.isDestroyed()) {
    return;
  }

  try {
    const bounds = widgetWindow.getBounds();
    fs.writeFileSync(widgetStatePath, JSON.stringify({
      x: bounds.x,
      y: bounds.y
    }), 'utf8');
  } catch {
    // Ignore persistence failures.
  }
}

function areBoundsVisible(bounds) {
  if (!bounds || !Number.isFinite(bounds.x) || !Number.isFinite(bounds.y)) {
    return false;
  }

  const center = {
    x: Math.round(bounds.x + 48),
    y: Math.round(bounds.y + 48)
  };
  const display = screen.getDisplayNearestPoint(center);
  const area = display?.workArea;
  if (!area) {
    return false;
  }

  return (
    center.x >= area.x &&
    center.x <= area.x + area.width &&
    center.y >= area.y &&
    center.y <= area.y + area.height
  );
}

function ensureWidgetVisible({ focus = false } = {}) {
  if (!widgetWindow || widgetWindow.isDestroyed()) {
    return;
  }
  if (!isOnboardingComplete()) {
    traceStartup('widget_show_blocked_until_onboarding_complete');
    return;
  }

  const safeBounds = resolveWidgetBounds();
  widgetWindow.setBounds(safeBounds);
  widgetWindow.showInactive();
  widgetWindow.moveTop();
  if (focus) {
    widgetWindow.focus();
  }
}

function screenpipeProcessMemory(settings = services?.settings?.getSettings?.() || {}) {
  if (process.platform !== 'win32') {
    return { pid: null, privateBytes: 0, workingSetBytes: 0 };
  }

  try {
    const dataDir = screenpipeDataDir();
    const port = String(screenpipePortFromSettings(settings));
    const script = [
      `$dataDir = ${singleQuotePowerShell(dataDir)}`,
      `$port = ${singleQuotePowerShell(port)}`,
      "$currentSessionId = (Get-Process -Id $PID).SessionId",
      "$pattern = '(^|\\s)--port\\s+' + [regex]::Escape($port) + '(\\s|$)'",
      "$cimProcesses = @()",
      "try { $cimProcesses = Get-CimInstance Win32_Process -Filter \"Name = 'screenpipe.exe'\" -ErrorAction Stop } catch {}",
      "$p = $cimProcesses | Where-Object {",
      "  $cmd = [string]$_.CommandLine",
      "  $sameSession = [int]$_.SessionId -eq [int]$currentSessionId",
      "  $sameSession -and ($cmd.IndexOf($dataDir, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and ($cmd -match $pattern)",
      "} | Select-Object -First 1",
      "$processId = $null",
      "if ($p) { $processId = $p.ProcessId }",
      "if (-not $processId) {",
      "  $screenpipePackagePattern = '@screenpipe\\cli-win32-x64\\bin\\screenpipe.exe'",
      "  $fallback = Get-Process -Name screenpipe -ErrorAction SilentlyContinue | Where-Object {",
      "    $exe = [string]$_.Path",
      "    ([int]$_.SessionId -eq [int]$currentSessionId) -and ($exe.IndexOf($screenpipePackagePattern, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and (($exe.IndexOf('\\companion-agent\\', [StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($exe.IndexOf('\\Cognify\\', [StringComparison]::OrdinalIgnoreCase) -ge 0))",
      "  } | Sort-Object StartTime -Descending | Select-Object -First 1",
      "  if ($fallback) { $processId = $fallback.Id }",
      "}",
      "if ($processId) { $p = Get-Process -Id $processId -ErrorAction SilentlyContinue | Select-Object -First 1 Id,PrivateMemorySize64,WorkingSet64,CPU }",
      "if ($p) { $p | ConvertTo-Json -Compress }"
    ].join('; ');
    const output = execFileSync('powershell.exe', ['-NoProfile', '-Command', script], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: SCREENPIPE_PROCESS_QUERY_TIMEOUT_MS
    }).trim();
    if (!output) {
      return { pid: null, privateBytes: 0, workingSetBytes: 0 };
    }
    const parsed = JSON.parse(output);
    return {
      pid: parsed.Id || null,
      privateBytes: Number(parsed.PrivateMemorySize64 || 0),
      workingSetBytes: Number(parsed.WorkingSet64 || 0),
      cpuSeconds: Number.isFinite(Number(parsed.CPU)) ? Number(parsed.CPU) : null
    };
  } catch {
    return { pid: null, privateBytes: 0, workingSetBytes: 0 };
  }
}

async function sampleScreenpipeProcessMemory(settings = services?.settings?.getSettings?.() || {}) {
  if (process.platform !== 'win32') {
    return { pid: null, privateBytes: 0, workingSetBytes: 0 };
  }

  const dataDir = screenpipeDataDir();
  const port = String(screenpipePortFromSettings(settings));
  const script = [
    `$dataDir = ${singleQuotePowerShell(dataDir)}`,
    `$port = ${singleQuotePowerShell(port)}`,
    "$currentSessionId = (Get-Process -Id $PID).SessionId",
    "$pattern = '(^|\\s)--port\\s+' + [regex]::Escape($port) + '(\\s|$)'",
    "$cimProcesses = @()",
    "try { $cimProcesses = Get-CimInstance Win32_Process -Filter \"Name = 'screenpipe.exe'\" -ErrorAction Stop } catch {}",
    "$p = $cimProcesses | Where-Object {",
    "  $cmd = [string]$_.CommandLine",
    "  $sameSession = [int]$_.SessionId -eq [int]$currentSessionId",
    "  $sameSession -and ($cmd.IndexOf($dataDir, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and ($cmd -match $pattern)",
    "} | Select-Object -First 1",
    "$processId = $null",
    "if ($p) { $processId = $p.ProcessId }",
    "if (-not $processId) {",
    "  $screenpipePackagePattern = '@screenpipe\\cli-win32-x64\\bin\\screenpipe.exe'",
    "  $fallback = Get-Process -Name screenpipe -ErrorAction SilentlyContinue | Where-Object {",
    "    $exe = [string]$_.Path",
    "    ([int]$_.SessionId -eq [int]$currentSessionId) -and ($exe.IndexOf($screenpipePackagePattern, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and (($exe.IndexOf('\\companion-agent\\', [StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($exe.IndexOf('\\Cognify\\', [StringComparison]::OrdinalIgnoreCase) -ge 0))",
    "  } | Sort-Object StartTime -Descending | Select-Object -First 1",
    "  if ($fallback) { $processId = $fallback.Id }",
    "}",
    "if ($processId) { $p = Get-Process -Id $processId -ErrorAction SilentlyContinue | Select-Object -First 1 Id,PrivateMemorySize64,WorkingSet64,CPU }",
    "if ($p) { $p | ConvertTo-Json -Compress }"
  ].join('; ');

  return new Promise((resolve) => {
    let stdout = '';
    let settled = false;
    const child = spawn('powershell.exe', ['-NoProfile', '-Command', script], {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });
    const finish = (value) => {
      if (settled) {
        return;
      }
      settled = true;
      resolve(value);
    };
    const timeout = setTimeout(() => {
      try {
        child.kill();
      } catch {
        // Best effort timeout cleanup.
      }
      finish({ pid: null, privateBytes: 0, workingSetBytes: 0 });
    }, SCREENPIPE_PROCESS_QUERY_TIMEOUT_MS);

    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      stdout += chunk;
    });
    child.on('error', () => {
      clearTimeout(timeout);
      finish({ pid: null, privateBytes: 0, workingSetBytes: 0 });
    });
    child.on('close', () => {
      clearTimeout(timeout);
      try {
        const text = String(stdout || '').trim();
        if (!text) {
          finish({ pid: null, privateBytes: 0, workingSetBytes: 0 });
          return;
        }
        const parsed = JSON.parse(text);
        finish({
          pid: parsed.Id || null,
          privateBytes: Number(parsed.PrivateMemorySize64 || 0),
          workingSetBytes: Number(parsed.WorkingSet64 || 0),
          cpuSeconds: Number.isFinite(Number(parsed.CPU)) ? Number(parsed.CPU) : null
        });
      } catch {
        finish({ pid: null, privateBytes: 0, workingSetBytes: 0 });
      }
    });
  });
}

function screenpipeMemoryPressureBytes(memory = {}) {
  return Number(memory.workingSetBytes || 0);
}

function screenpipeCpuPercent(previous = {}, current = {}, checkedAtMs = Date.now()) {
  const previousCpu = Number(previous.cpuSeconds);
  const currentCpu = Number(current.cpuSeconds);
  const previousAtMs = Date.parse(previous.checkedAt || '');
  if (!Number.isFinite(previousCpu) || !Number.isFinite(currentCpu) || !Number.isFinite(previousAtMs)) {
    return null;
  }
  const elapsedSeconds = Math.max(1, (checkedAtMs - previousAtMs) / 1000);
  const cpuDeltaSeconds = currentCpu - previousCpu;
  if (!Number.isFinite(cpuDeltaSeconds) || cpuDeltaSeconds < 0) {
    return null;
  }
  const coreCount = Math.max(1, os.cpus?.().length || 1);
  return Math.max(0, Math.min(100, Math.round((cpuDeltaSeconds / elapsedSeconds / coreCount) * 100)));
}

function canRestartScreenpipeForCpu(now = Date.now()) {
  screenpipeMemoryState.cpuRestarts = (screenpipeMemoryState.cpuRestarts || [])
    .filter((timestamp) => now - timestamp < SCREENPIPE_CPU_RESTART_WINDOW_MS);
  return screenpipeMemoryState.cpuRestarts.length < SCREENPIPE_CPU_RESTART_MAX_PER_WINDOW;
}

function canRestartScreenpipeForStaleFrames(now = Date.now()) {
  screenpipeMemoryState.staleFrameRestarts = (screenpipeMemoryState.staleFrameRestarts || [])
    .filter((timestamp) => now - timestamp < SCREENPIPE_STALE_FRAME_RESTART_WINDOW_MS);
  return screenpipeMemoryState.staleFrameRestarts.length < SCREENPIPE_STALE_FRAME_RESTART_MAX_PER_WINDOW;
}

function latestScreenpipeFrameSamples(limit = SCREENPIPE_STALE_FRAME_SAMPLE_COUNT) {
  const dayDir = path.join(screenpipeDataDir(), 'data', 'data', localDateKey(new Date()));
  if (!fs.existsSync(dayDir)) {
    return [];
  }
  try {
    return fs.readdirSync(dayDir)
      .filter((name) => /\.jpe?g$/i.test(name))
      .map((name) => {
        const filePath = path.join(dayDir, name);
        const stat = fs.statSync(filePath);
        return {
          path: filePath,
          name,
          size: stat.size,
          mtimeMs: stat.mtimeMs
        };
      })
      .sort((left, right) => right.mtimeMs - left.mtimeMs)
      .slice(0, limit);
  } catch {
    return [];
  }
}

function screenpipeStaleFrameDiagnostics() {
  const frames = latestScreenpipeFrameSamples();
  if (frames.length < SCREENPIPE_STALE_FRAME_SAMPLE_COUNT) {
    return { stale: false, reason: 'insufficient_frames', frameCount: frames.length };
  }
  const newestMs = frames[0].mtimeMs;
  const oldestMs = frames[frames.length - 1].mtimeMs;
  if (!Number.isFinite(newestMs) || !Number.isFinite(oldestMs) || (newestMs - oldestMs) < SCREENPIPE_STALE_FRAME_MIN_SPAN_MS) {
    return { stale: false, reason: 'sample_span_too_short', frameCount: frames.length };
  }
  const hashes = new Set();
  for (const frame of frames) {
    try {
      hashes.add(crypto.createHash('sha256').update(fs.readFileSync(frame.path)).digest('hex'));
      if (hashes.size > 1) {
        return { stale: false, reason: 'frames_vary', frameCount: frames.length, distinctHashes: hashes.size };
      }
    } catch {
      return { stale: false, reason: 'hash_failed', frameCount: frames.length };
    }
  }
  return {
    stale: true,
    reason: 'identical_recent_frames',
    frameCount: frames.length,
    distinctHashes: hashes.size,
    newest: new Date(newestMs).toISOString(),
    oldest: new Date(oldestMs).toISOString(),
    sample: frames[0]?.name || null
  };
}

function formatMemoryMb(bytes) {
  return `${Math.round(Number(bytes || 0) / 1024 / 1024)} MB`;
}

function lowRamModeInfo() {
  const override = String(process.env.COGNIFY_LOW_RAM_MODE || '').trim().toLowerCase();
  const forcedOn = ['1', 'true', 'yes', 'on'].includes(override);
  const forcedOff = ['0', 'false', 'no', 'off'].includes(override);
  const totalBytes = os.totalmem();
  const autoEnabled = Number.isFinite(totalBytes) && totalBytes > 0 && totalBytes <= LOW_RAM_TOTAL_MEMORY_BYTES;
  const enabled = forcedOn || (!forcedOff && autoEnabled);
  return {
    enabled,
    forced: forcedOn ? 'on' : (forcedOff ? 'off' : ''),
    auto: autoEnabled,
    total_bytes: totalBytes,
    threshold_bytes: LOW_RAM_TOTAL_MEMORY_BYTES,
    reason: enabled
      ? (forcedOn ? 'forced-on' : 'system-memory')
      : (forcedOff ? 'forced-off' : 'normal-memory')
  };
}

function isLowRamMode() {
  return lowRamModeInfo().enabled;
}

function effectiveHiddenWindowDestroyMs(key, delayMs) {
  if (!isLowRamMode()) {
    return delayMs;
  }
  if (key === 'panel' || key === 'report') {
    return Math.min(delayMs, LOW_RAM_WORK_WINDOW_IDLE_DESTROY_MS);
  }
  return Math.min(delayMs, LOW_RAM_POPUP_WINDOW_IDLE_DESTROY_MS);
}

function lowRamBackgroundGate({ requireIdle = false, source = 'background' } = {}) {
  if (!isLowRamMode()) {
    return { ok: true, low_ram: false };
  }
  if (isQuitting) {
    return { ok: false, reason: 'quitting', low_ram: true };
  }
  if (isUserFacingWindowVisible()) {
    return { ok: false, reason: 'user-window-visible', low_ram: true };
  }
  if (requireIdle && !isSystemIdleNow()) {
    return { ok: false, reason: 'user-active', low_ram: true };
  }
  const freeBytes = freeSystemMemoryBytes();
  if (freeBytes !== null && freeBytes < LOW_RAM_BACKGROUND_MIN_FREE_BYTES) {
    return { ok: false, reason: 'low-free-memory', low_ram: true, freeBytes, source };
  }
  return { ok: true, low_ram: true, freeBytes, source };
}

function screenpipeRetentionDiagnostics(settings = {}) {
  const retention = effectiveScreenpipeRetention(settings);
  return {
    ok: true,
    label: 'Raw Retention',
    detail: `Raw target ${retention.effectiveRawTargetDays}d, Screenpipe cap ${retention.screenpipeCliRetentionDays}d, evidence ${retention.retentionDays}d`,
    informational: true,
    evidence_days: retention.retentionDays,
    raw_target_days: retention.effectiveRawTargetDays,
    configured_raw_target_days: retention.screenpipeRawRetentionDays,
    screenpipe_cli_retention_days: retention.screenpipeCliRetentionDays,
    report_cache_days: retention.reportCacheRetentionDays,
    audio_minimum_applied: Boolean(retention.audioRequested && retention.effectiveRawTargetDays > retention.screenpipeRawRetentionDays)
  };
}

function screenpipeOwnershipDiagnostics(screenpipeProcess = {}, status = {}) {
  const running = Boolean(screenpipeProcess.running);
  const owned = Boolean(screenpipeProcess.owned);
  const apiAvailable = Boolean(status.apiAvailable);
  const ok = running ? owned : !apiAvailable;
  return {
    ok,
    label: 'Screenpipe Ownership',
    detail: running
      ? (owned
        ? `Owned private process${screenpipeProcess.pid ? `, pid ${screenpipeProcess.pid}` : ''}`
        : `Screenpipe process is not confirmed as Cognify-owned${screenpipeProcess.pid ? `, pid ${screenpipeProcess.pid}` : ''}`)
      : (apiAvailable ? 'Capture API reachable but owned process is not confirmed' : 'No owned Screenpipe process sampled'),
    informational: !running && !apiAvailable,
    pid: screenpipeProcess.pid || null,
    owned,
    match: screenpipeProcess.match || null,
    last_stop: screenpipeLastStopState || null
  };
}

function setProcessBelowNormalPriority(pid, label = 'process') {
  const safePid = Math.round(Number(pid || 0));
  if (process.platform !== 'win32' || !safePid) {
    return;
  }

  try {
    const script = [
      `$p = Get-Process -Id ${safePid} -ErrorAction Stop`,
      "$p.PriorityClass = 'BelowNormal'",
      '$p.PriorityClass'
    ].join('; ');
    const priority = execFileSync('powershell.exe', ['-NoProfile', '-Command', script], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 1500
    }).trim();
    traceStartup('process_priority_set', { label, pid: safePid, priority });
  } catch (error) {
    traceStartup('process_priority_set_failed', { label, pid: safePid, error: error?.message || String(error) });
  }
}

function screenpipeFfmpegRuntimePath() {
  return path.join(__dirname, '..', 'node_modules', '@screenpipe', 'cli-win32-x64', 'bin', 'ffmpeg.exe');
}

function latestScreenpipeCompactionMs() {
  const dayDir = path.join(screenpipeDataDir(), 'data', 'data', localDateKey(new Date()));
  if (!fs.existsSync(dayDir)) {
    return 0;
  }
  try {
    return fs.readdirSync(dayDir)
      .filter((name) => /^compact_monitor_.*\.mp4$/i.test(name))
      .map((name) => fs.statSync(path.join(dayDir, name)).mtimeMs)
      .filter(Number.isFinite)
      .reduce((latest, mtimeMs) => Math.max(latest, mtimeMs), 0);
  } catch {
    return 0;
  }
}

function setScreenpipeFfmpegIdlePriority() {
  if (process.platform !== 'win32' || ffmpegPriorityCheckInFlight) {
    return Promise.resolve({ changed: 0, sampled: 0 });
  }

  ffmpegPriorityCheckInFlight = true;
  const ffmpegPath = screenpipeFfmpegRuntimePath();
  const script = [
    `$ffmpegPath = ${singleQuotePowerShell(ffmpegPath)}`,
    `$targetPriority = ${singleQuotePowerShell(SCREENPIPE_FFMPEG_PRIORITY_CLASS)}`,
    "$currentSessionId = (Get-Process -Id $PID).SessionId",
    "$matches = @(Get-Process -Name ffmpeg -ErrorAction SilentlyContinue | Where-Object {",
    "  $exe = [string]$_.Path",
    "  ([int]$_.SessionId -eq [int]$currentSessionId) -and $exe.Equals($ffmpegPath, [StringComparison]::OrdinalIgnoreCase)",
    "})",
    "$changed = @()",
    "foreach ($p in $matches) {",
    "  try {",
    "    if ([string]$p.PriorityClass -ne $targetPriority) {",
    "      $p.PriorityClass = $targetPriority",
    "      $changed += [pscustomobject]@{ Id = $p.Id; PriorityClass = [string]$p.PriorityClass }",
    "    }",
    "  } catch {}",
    "}",
    "[pscustomobject]@{ Sampled = $matches.Count; Changed = $changed } | ConvertTo-Json -Compress"
  ].join('; ');

  return new Promise((resolve) => {
    let stdout = '';
    let settled = false;
    const child = spawn('powershell.exe', ['-NoProfile', '-Command', script], {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });
    const finish = (value) => {
      if (settled) {
        return;
      }
      settled = true;
      ffmpegPriorityCheckInFlight = false;
      resolve(value);
    };
    const timeout = setTimeout(() => {
      try {
        child.kill();
      } catch {
        // Best effort timeout cleanup.
      }
      finish({ changed: 0, sampled: 0, timedOut: true });
    }, SCREENPIPE_FFMPEG_PRIORITY_TIMEOUT_MS);

    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      stdout += chunk;
    });
    child.on('error', (error) => {
      clearTimeout(timeout);
      traceStartup('screenpipe_ffmpeg_priority_failed', { error: error?.message || String(error) });
      finish({ changed: 0, sampled: 0, error: true });
    });
    child.on('close', () => {
      clearTimeout(timeout);
      try {
        const text = String(stdout || '').trim();
        const parsed = text ? JSON.parse(text) : {};
        const changed = Array.isArray(parsed.Changed)
          ? parsed.Changed
          : (parsed.Changed ? [parsed.Changed] : []);
        if (changed.length) {
          traceStartup('screenpipe_ffmpeg_priority_set', {
            priority: SCREENPIPE_FFMPEG_PRIORITY_CLASS,
            processes: changed
          });
        }
        finish({ changed: changed.length, sampled: Number(parsed.Sampled || 0) });
      } catch (error) {
        traceStartup('screenpipe_ffmpeg_priority_parse_failed', { error: error?.message || String(error) });
        finish({ changed: 0, sampled: 0, error: true });
      }
    });
  });
}

function startScreenpipeFfmpegPriorityGovernor() {
  if (process.platform !== 'win32' || ffmpegPriorityTimer) {
    return;
  }

  const schedule = (delayMs) => {
    if (isQuitting) {
      return;
    }
    if (ffmpegPriorityTimer) {
      clearTimeout(ffmpegPriorityTimer);
    }
    ffmpegPriorityTimer = setTimeout(() => {
      runPriorityBurst(Date.now() + SCREENPIPE_FFMPEG_PRIORITY_BURST_MS);
    }, Math.max(0, delayMs));
  };

  const scheduleNextCompactionWindow = () => {
    const latestCompactionMs = latestScreenpipeCompactionMs();
    if (screenpipeLastSpawnAtMs && latestCompactionMs < screenpipeLastSpawnAtMs) {
      schedule(screenpipeLastSpawnAtMs + SCREENPIPE_FFMPEG_INITIAL_COMPACTION_DELAY_MS - SCREENPIPE_FFMPEG_PRIORITY_LOOKAHEAD_MS - Date.now());
      return;
    }
    if (!latestCompactionMs) {
      schedule(SCREENPIPE_FFMPEG_PRIORITY_FALLBACK_MS);
      return;
    }
    let dueAtMs = latestCompactionMs + SCREENPIPE_COMPACTION_INTERVAL_MS - SCREENPIPE_FFMPEG_PRIORITY_LOOKAHEAD_MS;
    while (dueAtMs < Date.now() - SCREENPIPE_FFMPEG_PRIORITY_BURST_MS) {
      dueAtMs += SCREENPIPE_COMPACTION_INTERVAL_MS;
    }
    schedule(dueAtMs - Date.now());
  };

  const runPriorityBurst = (untilMs) => {
    if (isQuitting) {
      return;
    }
    setScreenpipeFfmpegIdlePriority()
      .catch((error) => traceStartup('screenpipe_ffmpeg_priority_failed', { error: error?.message || String(error) }))
      .finally(() => {
        if (isQuitting) {
          return;
        }
        if (Date.now() < untilMs) {
          schedule(SCREENPIPE_FFMPEG_PRIORITY_CHECK_MS);
          return;
        }
        scheduleNextCompactionWindow();
      });
  };

  traceStartup('screenpipe_ffmpeg_priority_governor_started', {
    burst_ms: SCREENPIPE_FFMPEG_PRIORITY_BURST_MS,
    burst_poll_ms: SCREENPIPE_FFMPEG_PRIORITY_CHECK_MS,
    fallback_ms: SCREENPIPE_FFMPEG_PRIORITY_FALLBACK_MS,
    priority: SCREENPIPE_FFMPEG_PRIORITY_CLASS
  });
  schedule(0);
}

function rescheduleScreenpipeFfmpegPriorityGovernor(source = 'screenpipe') {
  if (process.platform !== 'win32') {
    return;
  }
  if (ffmpegPriorityTimer) {
    clearTimeout(ffmpegPriorityTimer);
    ffmpegPriorityTimer = null;
  }
  traceStartup('screenpipe_ffmpeg_priority_governor_rescheduled', { source });
  startScreenpipeFfmpegPriorityGovernor();
}

function captureAudioMode(settings = services?.settings?.getSettings?.() || {}) {
  const capture = settings.capture || {};
  if (['off', 'meeting', 'always'].includes(capture.audioMode)) {
    return capture.audioMode;
  }
  return capture.listeningEnabled ? 'always' : 'off';
}

function isAudioActiveForSettings(settings = services?.settings?.getSettings?.() || {}) {
  const mode = captureAudioMode(settings);
  return mode === 'always' || (mode === 'meeting' && meetingAudioActive);
}

function effectiveScreenpipeVisionMode(settings = services?.settings?.getSettings?.() || {}) {
  if (SCREENPIPE_VISION_FORCE_DISABLED) {
    return 'off';
  }
  return settings.capture?.visionMode === 'off' ? 'off' : 'normal';
}

function disableAudioAtStartupIfNeeded() {
  if (!AUDIO_DISABLED_AT_STARTUP || !services) {
    return;
  }
  const settings = services.settings.getSettings();
  if (captureAudioMode(settings) === 'off') {
    return;
  }
  meetingAudioActive = false;
  services.settings.updateCapture({ audioMode: 'off', listeningEnabled: false });
  diagnosticsCache = null;
  traceStartup('audio_disabled_at_startup_pending_review', {
    pending: 'Revisit Screenpipe audio optimization before re-enabling default startup listening.'
  });
}

function inferAudioDeviceNames(capture = {}) {
  const names = Array.isArray(capture.audioDeviceNames)
    ? capture.audioDeviceNames.map((name) => String(name || '').trim()).filter(Boolean)
    : [];
  if (capture.audioDeviceMode === 'custom') {
    return names;
  }

  const wantsInput = capture.audioDeviceMode === 'input' || capture.audioDeviceMode === 'input-output';
  const wantsOutput = capture.audioDeviceMode === 'output' || capture.audioDeviceMode === 'input-output';
  return names.filter((name) => (
    (wantsInput && /\(input\)$/i.test(name)) ||
    (wantsOutput && /\(output\)$/i.test(name))
  ));
}

async function hydrateDefaultAudioDevices(settings = services?.settings?.getSettings?.() || {}) {
  const capture = settings.capture || {};
  if (
    !isAudioActiveForSettings(settings) ||
    capture.audioDeviceMode === 'default' ||
    (capture.audioDeviceNames || []).length
  ) {
    return settings;
  }

  const devices = await services.screenpipe.listAudioDevices().catch(() => []);
  if (!devices.length) {
    return settings;
  }

  const wantsInput = capture.audioDeviceMode === 'input' || capture.audioDeviceMode === 'input-output';
  const wantsOutput = capture.audioDeviceMode === 'output' || capture.audioDeviceMode === 'input-output';
  const selected = [];
  const defaultInput = devices.find((device) => device.is_default && /\(input\)$/i.test(device.name || ''));
  const defaultOutput = devices.find((device) => device.is_default && /\(output\)$/i.test(device.name || ''));
  if (wantsInput && defaultInput?.name) {
    selected.push(defaultInput.name);
  }
  if (wantsOutput && defaultOutput?.name) {
    selected.push(defaultOutput.name);
  }
  if (!selected.length) {
    return settings;
  }

  return services.settings.updateCapture({ audioDeviceNames: selected });
}

function buildScreenpipeArgs(settings = services?.settings?.getSettings?.() || {}) {
  const capture = settings.capture || {};
  const audioActive = isAudioActiveForSettings(settings);
  const visionMode = SCREENPIPE_VISION_FORCE_DISABLED ? 'off' : (capture.visionMode || 'normal');
  const args = ['record'];
  const retention = effectiveScreenpipeRetention(settings);
  const commonArgs = [
    '--video-quality',
    SCREENPIPE_VIDEO_QUALITY,
    ...screenpipeLanguageArgs(),
    '--disable-telemetry',
    '--retention-days',
    String(retention.screenpipeCliRetentionDays),
    '--retention-mode',
    'media',
    '--disable-clipboard-capture',
    '--pause-on-drm-content',
    '--api-auth',
    '--port',
    String(screenpipePortFromSettings(settings)),
    '--data-dir',
    screenpipeDataDir()
  ];
  if (visionMode === 'off') {
    commonArgs.push('--disable-vision');
  }
  if (!audioActive) {
    return [...args, '--disable-audio', ...commonArgs];
  }

  args.push(
    '--audio-transcription-engine',
    capture.audioTranscriptionEngine || 'whisper-tiny-quantized',
    '--transcription-mode',
    'batch',
    '--filter-music'
  );

  const deviceNames = inferAudioDeviceNames(capture);
  if (deviceNames.length) {
    deviceNames.forEach((deviceName) => {
      args.push('--audio-device', deviceName);
    });
  } else {
    args.push('--use-system-default-audio');
  }

  args.push(...commonArgs);
  return args;
}

function isMeetingLikeRecord(record = {}) {
  const text = [
    record.app_name,
    record.window_title,
    record.url_if_available,
    record.ocr_text,
    record.transcript_text,
    record.classification
  ].filter(Boolean).join(' ').toLowerCase();
  return /\b(zoom|google meet|meet\.google|teams|microsoft teams|webex|jitsi|videomeet|video call|meeting|call)\b/.test(text);
}

function queryActivityRangeLite(startTime, endTime) {
  if (!services?.activityStore) {
    return [];
  }
  if (typeof services.activityStore.queryRangeLite === 'function') {
    return services.activityStore.queryRangeLite(startTime, endTime);
  }
  return services.activityStore.queryRange(startTime, endTime);
}

function invalidateScreenpipeProcessCache() {
  screenpipeProcessCache = null;
}

function resolveFfmpegStatus() {
  const screenpipeRuntimePath = path.join(__dirname, '..', 'node_modules', '@screenpipe', 'cli-win32-x64', 'bin', 'ffmpeg.exe');
  const candidates = [
    screenpipeRuntimePath,
    process.env.FFMPEG_BIN,
    process.env.FFMPEG_PATH,
    path.join(__dirname, '..', '..', 'ffmpeg', 'ffmpeg.exe'),
    path.join(__dirname, '..', 'ffmpeg', 'ffmpeg.exe')
  ];
  try {
    const ffmpegStaticPath = require('ffmpeg-static');
    if (ffmpegStaticPath) {
      candidates.push(ffmpegStaticPath);
    }
  } catch {
    // Optional dependency resolution can fail in portable builds.
  }

  candidates.push(path.join(__dirname, '..', 'node_modules', 'ffmpeg-static', 'ffmpeg.exe'));

  const found = candidates.find((candidate) => candidate && fs.existsSync(candidate));
  const runtimeOk = process.platform !== 'win32' || fs.existsSync(screenpipeRuntimePath);
  const ok = Boolean(found && runtimeOk);
  return {
    ok,
    label: 'FFmpeg',
    path: found || null,
    runtime_path: screenpipeRuntimePath,
    runtime_ok: runtimeOk,
    detail: ok
      ? `Screenpipe runtime found: ${screenpipeRuntimePath}`
      : (found
        ? `FFmpeg source found at ${found}, but Screenpipe runtime is missing: ${screenpipeRuntimePath}`
        : `Missing Screenpipe FFmpeg runtime: ${screenpipeRuntimePath}`)
  };
}

function screenpipeLogPaths() {
  const base = app.getPath('userData');
  return {
    stdout: path.join(base, 'screenpipe-stdout.log'),
    stderr: path.join(base, 'screenpipe-stderr.log')
  };
}

function screenpipeRuntimeVersionPath() {
  return path.join(app.getPath('userData'), 'screenpipe-runtime-version.json');
}

function shouldForceScreenpipeRestartForAppVersion() {
  const currentVersion = app.getVersion();
  try {
    const parsed = JSON.parse(fs.readFileSync(screenpipeRuntimeVersionPath(), 'utf8'));
    return parsed?.app_version !== currentVersion;
  } catch {
    return true;
  }
}

function markScreenpipeRuntimeVersion(source = 'unknown') {
  try {
    fs.writeFileSync(screenpipeRuntimeVersionPath(), JSON.stringify({
      app_version: app.getVersion(),
      updated_at: new Date().toISOString(),
      source
    }, null, 2));
  } catch (error) {
    traceStartup('screenpipe_runtime_version_mark_failed', { source, error: error?.message || String(error) });
  }
}

function screenpipeDataDir() {
  const explicitDataDir = String(process.env.COGNIFY_SCREENPIPE_DATA_DIR || '').trim();
  if (explicitDataDir) {
    return path.resolve(explicitDataDir);
  }

  if (process.env.COGNIFY_USE_LEGACY_SCREENPIPE_DIR !== '1') {
    return path.join(app.getPath('userData'), 'screenpipe-data');
  }

  const existingUserScreenpipeDir = path.join(app.getPath('home'), '.screenpipe');
  if (
    fs.existsSync(path.join(existingUserScreenpipeDir, 'db.sqlite')) ||
    fs.existsSync(path.join(existingUserScreenpipeDir, 'data'))
  ) {
    return existingUserScreenpipeDir;
  }

  return path.join(app.getPath('userData'), 'screenpipe-data');
}

function screenpipePortFromSettings(settings = {}) {
  try {
    const parsed = new URL(settings.screenpipeBaseUrl || '');
    const port = Number(parsed.port || 3030);
    if (Number.isInteger(port) && port >= 1024 && port <= 65535) {
      return port;
    }
  } catch {
    // Fall through to the legacy Screenpipe default.
  }
  return 3030;
}

function screenpipeLanguageArgs() {
  const language = String(process.env.COGNIFY_SCREENPIPE_LANGUAGE || SCREENPIPE_DEFAULT_LANGUAGE).trim().toLowerCase();
  if (!language || language === 'all' || language === 'auto') {
    return [];
  }
  return ['--language', language];
}

function screenpipeBaseUrlForPort(port) {
  return `http://127.0.0.1:${port}`;
}

function listeningTcpPorts() {
  if (process.platform !== 'win32') {
    return new Set();
  }

  try {
    const script = [
      'Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue',
      'Select-Object -ExpandProperty LocalPort -Unique'
    ].join(' | ');
    const output = execFileSync('powershell.exe', ['-NoProfile', '-Command', script], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 1500
    });
    return new Set(output.split(/\r?\n/).map((line) => Number(line.trim())).filter((port) => Number.isInteger(port)));
  } catch {
    return new Set();
  }
}

function chooseAvailableScreenpipePort(settings = {}, options = {}) {
  const usedPorts = listeningTcpPorts();
  const preferred = screenpipePortFromSettings(settings);
  if (options.avoidPreferred) {
    usedPorts.add(preferred);
  }
  const rangeSize = SCREENPIPE_PORT_MAX - SCREENPIPE_PORT_MIN + 1;
  const start = preferred >= SCREENPIPE_PORT_MIN && preferred <= SCREENPIPE_PORT_MAX
    ? preferred
    : SCREENPIPE_PORT_MIN;

  for (let offset = 0; offset < rangeSize; offset += 1) {
    const port = SCREENPIPE_PORT_MIN + ((start - SCREENPIPE_PORT_MIN + offset) % rangeSize);
    if (!usedPorts.has(port)) {
      return port;
    }
  }

  throw new Error('No available local Screenpipe port was found.');
}

function isScreenpipePortOccupied(settings = {}) {
  return listeningTcpPorts().has(screenpipePortFromSettings(settings));
}

function updaterStatePath() {
  return path.join(app.getPath('userData'), 'updater-state.json');
}

function updateDownloadDir() {
  return path.join(app.getPath('userData'), 'updates');
}

function readUpdaterState() {
  try {
    return JSON.parse(fs.readFileSync(updaterStatePath(), 'utf8'));
  } catch {
    return {
      checked_at: null,
      status: 'idle',
      detail: 'No update check has run yet.'
    };
  }
}

function writeUpdaterState(next) {
  const state = {
    ...readUpdaterState(),
    ...next,
    updated_at: new Date().toISOString()
  };
  const status = String(next.status || '');
  if (['checking', 'current', 'available', 'available-runtime', 'failed', 'failed-silent'].includes(status)) {
    delete state.downloaded_bytes;
    delete state.size_bytes;
    delete state.progress_percent;
    if (!Object.prototype.hasOwnProperty.call(next, 'manifest')) {
      delete state.manifest;
    }
  }
  if (status === 'checking' && !Object.prototype.hasOwnProperty.call(next, 'remote_version')) {
    delete state.remote_version;
  }
  fs.mkdirSync(path.dirname(updaterStatePath()), { recursive: true });
  fs.writeFileSync(updaterStatePath(), JSON.stringify(state, null, 2), 'utf8');
  return state;
}

function parseVersion(value) {
  return String(value || '')
    .split('.')
    .map((part) => Number.parseInt(part, 10))
    .map((part) => (Number.isFinite(part) ? part : 0));
}

function compareVersions(left, right) {
  const a = parseVersion(left);
  const b = parseVersion(right);
  const max = Math.max(a.length, b.length);
  for (let index = 0; index < max; index += 1) {
    const delta = (a[index] || 0) - (b[index] || 0);
    if (delta !== 0) {
      return delta > 0 ? 1 : -1;
    }
  }
  return 0;
}

function isAllowedUpdateUrl(value) {
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'https:' && (
      parsed.hostname === 'raw.githubusercontent.com' ||
      parsed.hostname === 'github.com' ||
      parsed.hostname === 'media.githubusercontent.com' ||
      parsed.hostname === 'api.github.com'
    );
  } catch {
    return false;
  }
}

function resolveUpdateManifestUrl() {
  return process.env.COGNIFY_UPDATE_MANIFEST_URL || DEFAULT_UPDATE_MANIFEST_URL;
}

function resolveUpdateManifestUrls() {
  const override = process.env.COGNIFY_UPDATE_MANIFEST_URL;
  if (override) {
    return [override];
  }
  return DEFAULT_UPDATE_MANIFEST_FALLBACK_URLS;
}

function cacheBustedUpdateUrl(url) {
  const parsed = new URL(url);
  parsed.searchParams.set('cognify_update_ts', String(Date.now()));
  return parsed.toString();
}

function manifestBaseUrl(manifestUrl) {
  try {
    const parsed = new URL(manifestUrl);
    if (parsed.hostname === 'api.github.com') {
      return DEFAULT_UPDATE_MANIFEST_URL;
    }
  } catch {
    return DEFAULT_UPDATE_MANIFEST_URL;
  }
  return manifestUrl || resolveUpdateManifestUrl();
}

function resolveBundleUrl(manifest, manifestUrl = resolveUpdateManifestUrl()) {
  const bundleFile = String(manifest.bundle_file || '').replace(/\\/g, '/');
  if (!bundleFile || bundleFile.includes('..')) {
    throw new Error('Update manifest does not contain a safe bundle_file.');
  }

  if (/^https:\/\//i.test(bundleFile)) {
    if (!isAllowedUpdateUrl(bundleFile)) {
      throw new Error('Update bundle URL host is not allowed.');
    }
    return bundleFile;
  }

  return new URL(bundleFile, manifestBaseUrl(manifestUrl)).toString();
}

function parseUpdateManifestBuffer(url, buffer) {
  const text = buffer.toString('utf8');
  let parsedUrl;
  try {
    parsedUrl = new URL(url);
  } catch {
    parsedUrl = null;
  }

  if (parsedUrl?.hostname === 'api.github.com') {
    const apiPayload = JSON.parse(text);
    const encoded = String(apiPayload.content || '').replace(/\s/g, '');
    if (!encoded) {
      throw new Error('GitHub API update manifest response did not include file content.');
    }
    return JSON.parse(Buffer.from(encoded, 'base64').toString('utf8'));
  }

  return JSON.parse(text);
}

async function fetchBestUpdateManifest() {
  const attempts = await Promise.all(resolveUpdateManifestUrls().map(async (manifestUrl) => {
    try {
      const manifestFetchUrl = cacheBustedUpdateUrl(manifestUrl);
      const manifestBuffer = await httpsGetBuffer(manifestFetchUrl, { maxBytes: 256 * 1024, timeoutMs: 20000 });
      const manifest = parseUpdateManifestBuffer(manifestUrl, manifestBuffer);
      const version = String(manifest.version || '');
      if (!version) {
        throw new Error('Update manifest is missing version.');
      }
      return { url: manifestUrl, manifestUrl, manifest, version };
    } catch (error) {
      return { url: manifestUrl, error: error?.message || String(error) };
    }
  }));

  const best = attempts
    .filter((attempt) => attempt.manifest && attempt.version)
    .sort((left, right) => compareVersions(right.version, left.version))[0] || null;

  if (!best) {
    const detail = attempts.map((attempt) => `${attempt.url}: ${attempt.error || attempt.version}`).join('; ');
    throw new Error(`Update manifest could not be read from trusted endpoints. ${detail}`);
  }

  return { manifest: best.manifest, manifestUrl: best.manifestUrl, version: best.version, attempts };
}

function httpsGetBuffer(url, options = {}, redirects = 0) {
  if (!isAllowedUpdateUrl(url)) {
    return Promise.reject(new Error(`Update URL is not allowed: ${url}`));
  }

  return new Promise((resolve, reject) => {
    const request = https.get(url, {
      headers: {
        'User-Agent': 'Cognify-Updater/1.1',
        'Cache-Control': 'no-cache',
        Pragma: 'no-cache'
      }
    }, (response) => {
      if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location) {
        response.resume();
        if (redirects >= 5) {
          reject(new Error('Too many update download redirects.'));
          return;
        }
        const nextUrl = new URL(response.headers.location, url).toString();
        httpsGetBuffer(nextUrl, options, redirects + 1).then(resolve, reject);
        return;
      }

      if (response.statusCode !== 200) {
        response.resume();
        reject(new Error(`Update download failed with HTTP ${response.statusCode}`));
        return;
      }

      const chunks = [];
      let total = 0;
      const expectedBytes = Number(response.headers['content-length'] || options.expectedBytes || 0);
      response.on('data', (chunk) => {
        total += chunk.length;
        if (options.maxBytes && total > options.maxBytes) {
          request.destroy(new Error(`Update download exceeded ${options.maxBytes} bytes.`));
          return;
        }
        chunks.push(chunk);
        if (typeof options.onProgress === 'function') {
          options.onProgress({
            downloadedBytes: total,
            totalBytes: expectedBytes || 0,
            percent: expectedBytes ? Math.min(99, Math.round((total / expectedBytes) * 100)) : null
          });
        }
      });
      response.on('end', () => resolve(Buffer.concat(chunks)));
    });

    request.on('error', reject);
    request.setTimeout(options.timeoutMs || 30000, () => {
      request.destroy(new Error('Update download timed out.'));
    });
  });
}

function sha256Hex(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function appInstallRoot() {
  return path.resolve(__dirname, '..', '..');
}

function appPayloadRoot() {
  return path.resolve(__dirname, '..');
}

function assertInside(parent, child) {
  const relative = path.relative(parent, child);
  if (relative.startsWith('..') || path.isAbsolute(relative)) {
    throw new Error(`Unsafe update path: ${child}`);
  }
}

function expandZip(zipPath, destination) {
  fs.rmSync(destination, { recursive: true, force: true });
  fs.mkdirSync(destination, { recursive: true });
  execFileSync('powershell', [
    '-NoProfile',
    '-ExecutionPolicy',
    'Bypass',
    '-Command',
    `Expand-Archive -LiteralPath ${singleQuotePowerShell(zipPath)} -DestinationPath ${singleQuotePowerShell(destination)} -Force`
  ], {
    windowsHide: true,
    stdio: 'pipe'
  });
}

function removeDirectoryContents(target) {
  if (!fs.existsSync(target)) {
    return;
  }

  fs.readdirSync(target, { withFileTypes: true }).forEach((entry) => {
    const entryPath = path.join(target, entry.name);
    assertInside(appInstallRoot(), entryPath);
    fs.rmSync(entryPath, { recursive: true, force: true });
  });
}

function stageCurrentAppBackup(version, payloadApp) {
  const backupRoot = path.join(updateDownloadDir(), 'backup', String(version || 'unknown'));
  fs.rmSync(backupRoot, { recursive: true, force: true });
  fs.mkdirSync(backupRoot, { recursive: true });

  copyExistingPayloadPaths(payloadApp, appPayloadRoot(), backupRoot);
  return backupRoot;
}

function restoreAppBackup(backupRoot) {
  if (!backupRoot || !fs.existsSync(backupRoot)) {
    return;
  }

  copyDirectoryContents(backupRoot, appPayloadRoot());
}

function copyExistingPayloadPaths(payloadSource, currentRoot, backupRoot) {
  if (!fs.existsSync(payloadSource)) {
    return;
  }

  fs.readdirSync(payloadSource, { withFileTypes: true }).forEach((entry) => {
    const sourcePath = path.join(payloadSource, entry.name);
    const currentPath = path.join(currentRoot, entry.name);
    const backupPath = path.join(backupRoot, entry.name);
    if (!fs.existsSync(currentPath)) {
      return;
    }

    if (entry.isDirectory()) {
      copyExistingPayloadPaths(sourcePath, currentPath, backupPath);
      return;
    }

    if (entry.isFile()) {
      fs.mkdirSync(path.dirname(backupPath), { recursive: true });
      fs.copyFileSync(currentPath, backupPath);
    }
  });
}

function relaunchCognifySoon() {
  isRelaunching = true;
  setTimeout(() => {
    app.relaunch();
    app.exit(0);
  }, 1200);
}

function copyDirectoryContents(source, destination, options = {}) {
  const restrictDestination = options.restrictDestination !== false;
  if (restrictDestination) {
    assertInside(appInstallRoot(), destination);
  }
  fs.mkdirSync(destination, { recursive: true });
  fs.readdirSync(source, { withFileTypes: true }).forEach((entry) => {
    const sourcePath = path.join(source, entry.name);
    const destinationPath = path.join(destination, entry.name);
    if (restrictDestination) {
      assertInside(appInstallRoot(), destinationPath);
    }
    if (entry.isDirectory()) {
      copyDirectoryContents(sourcePath, destinationPath, options);
      return;
    }
    if (entry.isFile()) {
      if (filesAreIdentical(sourcePath, destinationPath)) {
        return;
      }
      fs.copyFileSync(sourcePath, destinationPath);
    }
  });
}

function filesAreIdentical(leftPath, rightPath) {
  if (!fs.existsSync(leftPath) || !fs.existsSync(rightPath)) {
    return false;
  }

  const left = fs.statSync(leftPath);
  const right = fs.statSync(rightPath);
  if (left.size !== right.size) {
    return false;
  }

  const leftHash = crypto.createHash('sha256').update(fs.readFileSync(leftPath)).digest('hex');
  const rightHash = crypto.createHash('sha256').update(fs.readFileSync(rightPath)).digest('hex');
  return leftHash === rightHash;
}

function applyAppUpdate(extractDir) {
  const manifestPath = path.join(extractDir, 'manifest.json');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (manifest.update_type !== 'app' || manifest.requires_existing_install !== true) {
    throw new Error('Only app-only updates for existing installs can be applied automatically.');
  }
  if (manifest.components?.electron || manifest.components?.dotnet) {
    throw new Error('Electron and .NET runtime updates are not supported by GetUpdate yet.');
  }

  const payloadApp = path.join(extractDir, 'app');
  if (!fs.existsSync(path.join(payloadApp, 'src', 'main.js'))) {
    throw new Error('Update payload is missing app/src/main.js.');
  }

  const targetRoot = appInstallRoot();
  const targetApp = appPayloadRoot();
  if (manifest.components?.screenpipe) {
    stopScreenpipeProcesses(services?.settings?.getSettings?.() || {}, { reason: 'update-apply' });
  }
  copyDirectoryContents(payloadApp, targetApp);

  const rootVersion = path.join(extractDir, 'VERSION');
  if (fs.existsSync(rootVersion)) {
    fs.copyFileSync(rootVersion, path.join(targetRoot, 'VERSION'));
  }

  return manifest;
}

async function getUpdate({ apply = true, silent = false } = {}) {
  if (apply && services && !isOnboardingComplete()) {
    const checkedAt = new Date().toISOString();
    traceStartup('update_deferred_until_onboarding_complete', { silent });
    return writeUpdaterState({
      checked_at: checkedAt,
      status: 'deferred-onboarding',
      local_version: app.getVersion(),
      detail: 'Update apply deferred until Cognify setup is complete.'
    });
  }

  if (updateCheckInFlight) {
    return updateCheckInFlight;
  }

  updateCheckInFlight = (async () => {
    const checkedAt = new Date().toISOString();
    const localVersion = app.getVersion();
    writeUpdaterState({ checked_at: checkedAt, status: 'checking', detail: 'Checking GitHub update manifest.' });

    try {
      const manifestResult = await fetchBestUpdateManifest();
      const manifest = manifestResult.manifest;
      const remoteVersion = manifestResult.version;

      if (!remoteVersion) {
        throw new Error('Update manifest is missing version.');
      }

      if (compareVersions(remoteVersion, localVersion) <= 0) {
        return writeUpdaterState({
          checked_at: checkedAt,
          status: 'current',
          local_version: localVersion,
          remote_version: remoteVersion,
          detail: `Cognify is current at v${localVersion}.`
        });
      }

      if (manifest.update_type && manifest.update_type !== 'app') {
        return writeUpdaterState({
          checked_at: checkedAt,
          status: 'available-runtime',
          local_version: localVersion,
          remote_version: remoteVersion,
          detail: `v${remoteVersion} is available, but it includes runtime components and must use the full updater.`
        });
      }

      const declaredSize = Number(manifest.size_bytes || 0);
      if (declaredSize > MAX_APP_UPDATE_BYTES) {
        throw new Error(`App update is too large for automatic apply: ${declaredSize} bytes.`);
      }

      if (!apply) {
        return writeUpdaterState({
          checked_at: checkedAt,
          status: 'available',
          local_version: localVersion,
          remote_version: remoteVersion,
          detail: `v${remoteVersion} app update is available.`
        });
      }

      const bundleUrl = resolveBundleUrl(manifest, manifestResult.manifestUrl);
      const maxBytes = Math.max(MAX_APP_UPDATE_BYTES, declaredSize || 0);
      writeUpdaterState({
        checked_at: checkedAt,
        status: 'downloading',
        local_version: localVersion,
        remote_version: remoteVersion,
        detail: `Downloading Cognify v${remoteVersion} update...`,
        downloaded_bytes: 0,
        size_bytes: declaredSize || 0,
        progress_percent: 0
      });
      let lastProgressWrite = 0;
      const bundleBuffer = await httpsGetBuffer(bundleUrl, {
        maxBytes,
        timeoutMs: 60000,
        expectedBytes: declaredSize,
        onProgress: ({ downloadedBytes, totalBytes, percent }) => {
          const now = Date.now();
          if (now - lastProgressWrite < 700 && downloadedBytes < declaredSize) {
            return;
          }
          lastProgressWrite = now;
          const label = percent === null ? `${Math.round(downloadedBytes / 1024 / 1024)} MB` : `${percent}%`;
          writeUpdaterState({
            checked_at: checkedAt,
            status: 'downloading',
            local_version: localVersion,
            remote_version: remoteVersion,
            detail: `Downloading Cognify v${remoteVersion} update: ${label}`,
            downloaded_bytes: downloadedBytes,
            size_bytes: totalBytes || declaredSize || 0,
            progress_percent: percent
          });
        }
      });
      if (declaredSize && bundleBuffer.length !== declaredSize) {
        if (bundleBuffer.toString('utf8', 0, Math.min(bundleBuffer.length, 256)).startsWith('version https://git-lfs.github.com/spec/')) {
          throw new Error('Downloaded update is a Git LFS pointer, not the update zip. Publish the bundle as a normal Git blob or use a release asset URL.');
        }
        throw new Error(`Downloaded update size mismatch: expected ${declaredSize}, got ${bundleBuffer.length}.`);
      }

      writeUpdaterState({
        checked_at: checkedAt,
        status: 'verifying',
        local_version: localVersion,
        remote_version: remoteVersion,
        detail: `Verifying Cognify v${remoteVersion} update...`,
        downloaded_bytes: bundleBuffer.length,
        size_bytes: declaredSize || bundleBuffer.length,
        progress_percent: 100
      });
      const actualHash = sha256Hex(bundleBuffer);
      if (String(manifest.sha256 || '').toLowerCase() !== actualHash) {
        throw new Error('Downloaded update SHA-256 did not match update.txt.');
      }

      const downloadDir = updateDownloadDir();
      fs.mkdirSync(downloadDir, { recursive: true });
      const zipPath = path.join(downloadDir, `cognify-update-${remoteVersion}.zip`);
      const extractDir = path.join(downloadDir, `extract-${remoteVersion}`);
      fs.writeFileSync(zipPath, bundleBuffer);
      writeUpdaterState({
        checked_at: checkedAt,
        status: 'extracting',
        local_version: localVersion,
        remote_version: remoteVersion,
        detail: `Extracting Cognify v${remoteVersion} update...`,
        progress_percent: 100
      });
      expandZip(zipPath, extractDir);
      writeUpdaterState({
        checked_at: checkedAt,
        status: 'backing-up',
        local_version: localVersion,
        remote_version: remoteVersion,
        detail: 'Backing up current Cognify app files...',
        progress_percent: 100
      });
      const backupRoot = stageCurrentAppBackup(localVersion, path.join(extractDir, 'app'));
      let payloadManifest;
      try {
        writeUpdaterState({
          checked_at: checkedAt,
          status: 'applying',
          local_version: localVersion,
          remote_version: remoteVersion,
          detail: `Applying Cognify v${remoteVersion} update...`,
          progress_percent: 100
        });
        payloadManifest = applyAppUpdate(extractDir);
      } catch (error) {
        restoreAppBackup(backupRoot);
        throw error;
      }
      relaunchCognifySoon();

      return writeUpdaterState({
        checked_at: checkedAt,
        status: 'applied',
        local_version: localVersion,
        remote_version: remoteVersion,
        detail: `v${remoteVersion} app update applied. Restart Cognify to use it.`,
        manifest: payloadManifest
      });
    } catch (error) {
      const next = writeUpdaterState({
        checked_at: checkedAt,
        status: silent ? 'failed-silent' : 'failed',
        local_version: localVersion,
        detail: error.message || 'Update check failed.'
      });
      if (!silent) {
        throw Object.assign(error, { state: next });
      }
      return next;
    }
  })();

  try {
    return await updateCheckInFlight;
  } finally {
    updateCheckInFlight = null;
  }
}

function startupShortcutPath() {
  return path.join(
    app.getPath('appData'),
    'Microsoft',
    'Windows',
    'Start Menu',
    'Programs',
    'Startup',
    'Cognify.lnk'
  );
}

function legacyStartupCommandPath() {
  return path.join(
    app.getPath('appData'),
    'Microsoft',
    'Windows',
    'Start Menu',
    'Programs',
    'Startup',
    'Cognify Startup.cmd'
  );
}

function singleQuotePowerShell(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function resolveStartupLauncher() {
  const candidates = [
    path.join(path.dirname(process.execPath), 'Cognify.bat'),
    path.join(process.cwd(), 'Cognify.bat'),
    path.resolve(process.cwd(), '..', 'Cognify.bat'),
    path.resolve(process.cwd(), '..', 'Start-Cognify.bat'),
    path.resolve(__dirname, '..', '..', 'Start-Cognify.bat'),
    path.join(path.dirname(process.execPath), 'Launch-Cognify.ps1'),
    path.resolve(process.cwd(), 'Launch-Cognify.ps1'),
    path.resolve(process.cwd(), '..', 'Launch-Cognify.ps1')
  ];
  const found = candidates.find((candidate) => fs.existsSync(candidate));
  if (found) {
    return { path: found, type: path.extname(found).toLowerCase() };
  }

  const repoRoot = path.resolve(__dirname, '..');
  if (fs.existsSync(path.join(repoRoot, 'package.json'))) {
    return { path: repoRoot, type: 'dev' };
  }

  return null;
}

function startupStatus() {
  const shortcutPath = startupShortcutPath();
  const legacyPath = legacyStartupCommandPath();
  const launcher = resolveStartupLauncher();
  return {
    enabled: fs.existsSync(shortcutPath) || fs.existsSync(legacyPath),
    path: shortcutPath,
    legacy_path: legacyPath,
    launcher_path: launcher?.path || null,
    launcher_type: launcher?.type || null,
    supported: Boolean(launcher)
  };
}

function startupShortcutForLauncher(launcher) {
  if (!launcher) {
    throw new Error('Cognify launcher was not found.');
  }

  if (launcher.type === '.bat' || launcher.type === '.cmd') {
    return {
      targetPath: launcher.path,
      arguments: '',
      workingDirectory: path.dirname(launcher.path)
    };
  }

  if (launcher.type === '.ps1') {
    return {
      targetPath: 'powershell.exe',
      arguments: `-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "${launcher.path}"`,
      workingDirectory: path.dirname(launcher.path)
    };
  }

  if (launcher.type === 'dev') {
    const npmCmd = process.env.npm_execpath && fs.existsSync(process.env.npm_execpath)
      ? process.env.npm_execpath
      : 'npm.cmd';
    const command = [
      `Set-Location -LiteralPath ${singleQuotePowerShell(launcher.path)}`,
      `$env:COGNIFY_ACTIVITY_STORE='sqlite'`,
      `Start-Process -FilePath ${singleQuotePowerShell(npmCmd)} -ArgumentList @('start') -WorkingDirectory ${singleQuotePowerShell(launcher.path)} -WindowStyle Hidden`
    ].join('; ');
    return {
      targetPath: 'powershell.exe',
      arguments: `-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "${command}"`,
      workingDirectory: launcher.path
    };
  }

  throw new Error('Unsupported Cognify startup launcher.');
}

function writeStartupShortcut(shortcutPath, launcher) {
  const shortcut = startupShortcutForLauncher(launcher);
  const iconPath = getCognifyIconPath()
    || (fs.existsSync(process.execPath)
    ? process.execPath
    : shortcut.targetPath);
  const script = [
    '$shell = New-Object -ComObject WScript.Shell',
    `$shortcut = $shell.CreateShortcut(${singleQuotePowerShell(shortcutPath)})`,
    `$shortcut.TargetPath = ${singleQuotePowerShell(shortcut.targetPath)}`,
    `$shortcut.Arguments = ${singleQuotePowerShell(shortcut.arguments || '')}`,
    `$shortcut.WorkingDirectory = ${singleQuotePowerShell(shortcut.workingDirectory || path.dirname(shortcut.targetPath))}`,
    '$shortcut.Description = "Start Cognify"',
    `$shortcut.IconLocation = ${singleQuotePowerShell(iconPath)}`,
    '$shortcut.Save()'
  ].join('; ');
  execFileSync('powershell.exe', ['-NoProfile', '-Command', script], {
    windowsHide: true,
    stdio: 'pipe'
  });
}

function setStartupEnabled(enabled) {
  const shortcutPath = startupShortcutPath();
  const legacyPath = legacyStartupCommandPath();
  if (!enabled) {
    if (fs.existsSync(shortcutPath)) {
      fs.unlinkSync(shortcutPath);
    }
    if (fs.existsSync(legacyPath)) {
      fs.unlinkSync(legacyPath);
    }
    return startupStatus();
  }

  const launcher = resolveStartupLauncher();
  if (!launcher) {
    throw new Error('Cognify launcher was not found.');
  }

  fs.mkdirSync(path.dirname(shortcutPath), { recursive: true });
  writeStartupShortcut(shortcutPath, launcher);
  if (fs.existsSync(legacyPath)) {
    fs.unlinkSync(legacyPath);
  }
  return startupStatus();
}

function notesPath() {
  return path.join(app.getPath('userData'), 'notes.json');
}

function readNotes() {
  const filePath = notesPath();
  if (!fs.existsSync(filePath)) {
    return [];
  }

  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeNotes(notes = []) {
  fs.writeFileSync(notesPath(), JSON.stringify(notes, null, 2), 'utf8');
}

function cleanNote(note = {}) {
  return {
    id: String(note.id || `${Date.now()}-${Math.random().toString(16).slice(2)}`),
    text: String(note.text || '').trim().slice(0, 4000),
    color: ['blue', 'green', 'amber', 'pink', 'slate'].includes(note.color) ? note.color : 'blue',
    created_at: note.created_at || new Date().toISOString(),
    updated_at: new Date().toISOString(),
    locked: false
  };
}

function sortedNotes(notes = readNotes()) {
  return [...notes].sort((left, right) => new Date(right.updated_at).getTime() - new Date(left.updated_at).getTime());
}

function saveNote(payload = {}) {
  const next = cleanNote(payload);
  if (!next.text) {
    throw new Error('Note text is required.');
  }

  const notes = readNotes();
  const index = notes.findIndex((note) => note.id === next.id);
  if (index >= 0) {
    next.created_at = notes[index].created_at || next.created_at;
    notes[index] = next;
  } else {
    notes.push(next);
  }
  writeNotes(notes);
  return { note: next, notes: sortedNotes(notes) };
}

function deleteNote(id) {
  const notes = readNotes().filter((note) => note.id !== String(id || ''));
  writeNotes(notes);
  return { notes: sortedNotes(notes) };
}

function resolveScreenpipeExe() {
  const candidates = [
    path.join(__dirname, '..', 'node_modules', '@screenpipe', 'cli-win32-x64', 'bin', 'screenpipe.exe')
  ];

  const found = candidates.find((candidate) => fs.existsSync(candidate));
  if (found) {
    return found;
  }

  return null;
}

function getBundledScreenpipeVersion() {
  try {
    const packagePath = path.join(__dirname, '..', 'node_modules', 'screenpipe', 'package.json');
    const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
    return String(packageJson.version || 'unknown').replace(/[^0-9A-Za-z_.-]/g, '_');
  } catch {
    return 'unknown';
  }
}

function ensureScreenpipeOnnxRuntime() {
  if (process.platform !== 'win32') {
    return { ok: true, detail: 'No ONNX runtime patch needed.' };
  }

  const screenpipeOrt = path.join(__dirname, '..', 'node_modules', '@screenpipe', 'cli-win32-x64', 'bin', 'onnxruntime.dll');
  const compatibleOrt = path.join(__dirname, '..', 'node_modules', 'onnxruntime-node', 'bin', 'napi-v6', 'win32', 'x64', 'onnxruntime.dll');
  if (!fs.existsSync(screenpipeOrt) || !fs.existsSync(compatibleOrt)) {
    return { ok: false, detail: 'Compatible ONNX runtime DLL not found.' };
  }

  try {
    const current = fs.statSync(screenpipeOrt);
    const compatible = fs.statSync(compatibleOrt);
    if (current.size === compatible.size) {
      return { ok: true, detail: 'Compatible ONNX runtime already installed.' };
    }

    const backup = `${screenpipeOrt}.screenpipe-${getBundledScreenpipeVersion()}.bak`;
    if (!fs.existsSync(backup)) {
      fs.copyFileSync(screenpipeOrt, backup);
    }
    fs.copyFileSync(compatibleOrt, screenpipeOrt);
    return { ok: true, detail: 'Compatible ONNX runtime installed for Screenpipe audio.' };
  } catch (error) {
    return { ok: false, detail: error?.message || String(error) };
  }
}

function ensureScreenpipeFfmpegRuntime(ffmpegPath) {
  if (process.platform !== 'win32') {
    return { ok: true, detail: 'No FFmpeg runtime patch needed.' };
  }

  const screenpipeFfmpeg = path.join(__dirname, '..', 'node_modules', '@screenpipe', 'cli-win32-x64', 'bin', 'ffmpeg.exe');
  if (!ffmpegPath || !fs.existsSync(ffmpegPath)) {
    return { ok: false, detail: 'Source FFmpeg executable not found.' };
  }

  try {
    const current = fs.existsSync(screenpipeFfmpeg) ? fs.statSync(screenpipeFfmpeg) : null;
    const source = fs.statSync(ffmpegPath);
    if (current && current.size === source.size) {
      return { ok: true, detail: 'Screenpipe FFmpeg runtime already installed.' };
    }

    fs.copyFileSync(ffmpegPath, screenpipeFfmpeg);
    return { ok: true, detail: 'Screenpipe FFmpeg runtime installed.' };
  } catch (error) {
    return { ok: false, detail: error?.message || String(error) };
  }
}

function stopScreenpipeProcesses(settings = {}, options = {}) {
  if (process.platform !== 'win32') {
    const result = {
      ok: true,
      skipped: true,
      reason: options.reason || 'not-win32',
      requested_at: new Date().toISOString()
    };
    screenpipeLastStopState = result;
    return result;
  }

  const requestedAt = new Date().toISOString();
  try {
    invalidateScreenpipeProcessCache();
    const dataDir = screenpipeDataDir();
    const port = String(screenpipePortFromSettings(settings));
    const bundledExe = resolveScreenpipeExe() || '';
    const includeLegacyDefault = options.includeLegacyDefault ? '$true' : '$false';
    const script = [
      `$dataDir = ${singleQuotePowerShell(dataDir)}`,
      `$port = ${singleQuotePowerShell(port)}`,
      `$bundledExe = ${singleQuotePowerShell(bundledExe)}`,
      `$includeLegacyDefault = ${includeLegacyDefault}`,
      "$currentSessionId = (Get-Process -Id $PID).SessionId",
      "$portPattern = '(^|\\s)--port\\s+' + [regex]::Escape($port) + '(\\s|$)'",
      "$legacyPattern = '(^|\\s)--port\\s+3030(\\s|$)'",
      "$targetIds = @()",
      "$screenpipePackagePattern = '@screenpipe\\cli-win32-x64\\bin\\screenpipe.exe'",
      "Get-Process -Name screenpipe -ErrorAction SilentlyContinue | Where-Object {",
      "  $exe = [string]$_.Path",
      "  ([int]$_.SessionId -eq [int]$currentSessionId) -and ($exe.IndexOf($screenpipePackagePattern, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and (($exe.IndexOf('\\companion-agent\\', [StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($exe.IndexOf('\\Cognify\\', [StringComparison]::OrdinalIgnoreCase) -ge 0))",
      "} | ForEach-Object { $targetIds += [int]$_.Id }",
      "$cimProcesses = @()",
      "try { $cimProcesses = Get-CimInstance Win32_Process -Filter \"Name = 'screenpipe.exe'\" -ErrorAction Stop } catch {}",
      "$cimProcesses | Where-Object {",
      "  $cmd = [string]$_.CommandLine",
      "  $sameSession = [int]$_.SessionId -eq [int]$currentSessionId",
      "  $matchesCurrent = ($cmd.IndexOf($dataDir, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and ($cmd -match $portPattern)",
      "  $matchesLegacy = $includeLegacyDefault -and $bundledExe -and ($cmd.IndexOf($bundledExe, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and ($cmd -match $legacyPattern)",
      "  $sameSession -and ($matchesCurrent -or $matchesLegacy)",
      "} | ForEach-Object { $targetIds += [int]$_.ProcessId }",
      "$targetIds = $targetIds | Sort-Object -Unique",
      "foreach ($targetProcessId in $targetIds) { & \"$env:WINDIR\\System32\\taskkill.exe\" /PID $targetProcessId /T *> $null }",
      "Start-Sleep -Milliseconds 1200",
      "foreach ($targetProcessId in $targetIds) { if (Get-Process -Id $targetProcessId -ErrorAction SilentlyContinue) { Stop-Process -Id $targetProcessId -Force -ErrorAction SilentlyContinue } }",
      "$remainingIds = @()",
      "foreach ($targetProcessId in $targetIds) { if (Get-Process -Id $targetProcessId -ErrorAction SilentlyContinue) { $remainingIds += [int]$targetProcessId } }",
      "[pscustomobject]@{ TargetIds = @($targetIds); RemainingIds = @($remainingIds) } | ConvertTo-Json -Compress"
    ].join('; ');
    const output = execFileSync('powershell.exe', ['-NoProfile', '-Command', script], {
      encoding: 'utf8',
      windowsHide: true,
      stdio: 'pipe',
      timeout: SCREENPIPE_PROCESS_STOP_TIMEOUT_MS
    }).trim();
    const parsed = output ? JSON.parse(output) : {};
    const targetIds = Array.isArray(parsed.TargetIds)
      ? parsed.TargetIds
      : (parsed.TargetIds ? [parsed.TargetIds] : []);
    const remainingIds = Array.isArray(parsed.RemainingIds)
      ? parsed.RemainingIds
      : (parsed.RemainingIds ? [parsed.RemainingIds] : []);
    const result = {
      ok: remainingIds.length === 0,
      reason: options.reason || 'stop-screenpipe',
      requested_at: requestedAt,
      checked_at: new Date().toISOString(),
      stopped_count: targetIds.length - remainingIds.length,
      target_pids: targetIds,
      remaining_pids: remainingIds,
      include_legacy_default: Boolean(options.includeLegacyDefault)
    };
    screenpipeLastStopState = result;
    invalidateScreenpipeProcessCache();
    return result;
  } catch (error) {
    const result = {
      ok: false,
      reason: options.reason || 'stop-screenpipe',
      requested_at: requestedAt,
      checked_at: new Date().toISOString(),
      error: error?.message || String(error),
      include_legacy_default: Boolean(options.includeLegacyDefault)
    };
    screenpipeLastStopState = result;
    invalidateScreenpipeProcessCache();
    traceStartup('screenpipe_owned_processes_stop_failed', { error: result.error });
    return result;
  }
}

function stopStaleCognifyScreenpipeProcesses(settings = {}) {
  if (process.platform !== 'win32') {
    return;
  }

  try {
    invalidateScreenpipeProcessCache();
    const dataDir = screenpipeDataDir();
    const port = String(screenpipePortFromSettings(settings));
    const bundledExe = resolveScreenpipeExe() || '';
    const script = [
      `$dataDir = ${singleQuotePowerShell(dataDir)}`,
      `$port = ${singleQuotePowerShell(port)}`,
      `$bundledExe = ${singleQuotePowerShell(bundledExe)}`,
      "$currentSessionId = (Get-Process -Id $PID).SessionId",
      "$portPattern = '(^|\\s)--port\\s+' + [regex]::Escape($port) + '(\\s|$)'",
      "$screenpipePackagePattern = '@screenpipe\\cli-win32-x64\\bin\\screenpipe.exe'",
      "$cimProcesses = @()",
      "try { $cimProcesses = Get-CimInstance Win32_Process -Filter \"Name = 'screenpipe.exe'\" -ErrorAction Stop } catch {}",
      "$cimProcesses | Where-Object {",
      "  $cmd = [string]$_.CommandLine",
      "  $exe = [string]$_.ExecutablePath",
      "  $sameSession = [int]$_.SessionId -eq [int]$currentSessionId",
      "  $isCurrent = ($cmd.IndexOf($dataDir, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and ($cmd -match $portPattern)",
      "  $isCognifyPackaged = ($cmd.IndexOf($screenpipePackagePattern, [StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($exe.IndexOf($screenpipePackagePattern, [StringComparison]::OrdinalIgnoreCase) -ge 0)",
      "  $isKnownCognifyPath = ($cmd.IndexOf('\\companion-agent\\', [StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($cmd.IndexOf('\\Cognify\\', [StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($exe.IndexOf('\\companion-agent\\', [StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($exe.IndexOf('\\Cognify\\', [StringComparison]::OrdinalIgnoreCase) -ge 0)",
      "  $sameSession -and -not $isCurrent -and $isCognifyPackaged -and $isKnownCognifyPath",
      "} | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }",
      "$known = Get-Process -Name screenpipe -ErrorAction SilentlyContinue | Where-Object {",
      "  $exe = [string]$_.Path",
      "  ([int]$_.SessionId -eq [int]$currentSessionId) -and ($exe.IndexOf($screenpipePackagePattern, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and (($exe.IndexOf('\\companion-agent\\', [StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($exe.IndexOf('\\Cognify\\', [StringComparison]::OrdinalIgnoreCase) -ge 0))",
      "} | Sort-Object StartTime -Descending",
      "$keep = $known | Select-Object -First 1",
      "$known | Where-Object { -not $keep -or $_.Id -ne $keep.Id } | ForEach-Object { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }"
    ].join('; ');
    execFileSync('powershell.exe', ['-NoProfile', '-Command', script], {
      windowsHide: true,
      stdio: 'pipe',
      timeout: SCREENPIPE_PROCESS_QUERY_TIMEOUT_MS
    });
  } catch {
    // Keep startup resilient if process enumeration is denied.
  }
}

function currentUserScreenpipeProcess(settings = {}) {
  if (process.platform !== 'win32') {
    return { running: false, pid: null };
  }

  const settingsKey = JSON.stringify({
    dataDir: screenpipeDataDir(),
    port: screenpipePortFromSettings(settings)
  });
  if (
    screenpipeProcessCache &&
    screenpipeProcessCache.settingsKey === settingsKey &&
    (Date.now() - screenpipeProcessCache.createdAtMs) < SCREENPIPE_PROCESS_CACHE_MS
  ) {
    return screenpipeProcessCache.value;
  }

  try {
    const dataDir = screenpipeDataDir();
    const port = String(screenpipePortFromSettings(settings));
    const script = [
      `$dataDir = ${singleQuotePowerShell(dataDir)}`,
      `$port = ${singleQuotePowerShell(port)}`,
      "$currentSessionId = (Get-Process -Id $PID).SessionId",
      "$portPattern = '(^|\\s)--port\\s+' + [regex]::Escape($port) + '(\\s|$)'",
      "$cimProcesses = @()",
      "try { $cimProcesses = Get-CimInstance Win32_Process -Filter \"Name = 'screenpipe.exe'\" -ErrorAction Stop } catch {}",
      "$p = $cimProcesses | Where-Object {",
      "  $cmd = [string]$_.CommandLine",
      "  $sameSession = [int]$_.SessionId -eq [int]$currentSessionId",
      "  $sameSession -and ($cmd.IndexOf($dataDir, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and ($cmd -match $portPattern)",
      "} | Select-Object -First 1 ProcessId,CommandLine,@{Name='Match';Expression={'current-data-dir-port'}}",
      "if (-not $p) {",
      "  $screenpipePackagePattern = '@screenpipe\\cli-win32-x64\\bin\\screenpipe.exe'",
      "  $fallback = Get-Process -Name screenpipe -ErrorAction SilentlyContinue | Where-Object {",
      "    $exe = [string]$_.Path",
      "    ([int]$_.SessionId -eq [int]$currentSessionId) -and ($exe.IndexOf($screenpipePackagePattern, [StringComparison]::OrdinalIgnoreCase) -ge 0) -and (($exe.IndexOf('\\companion-agent\\', [StringComparison]::OrdinalIgnoreCase) -ge 0) -or ($exe.IndexOf('\\Cognify\\', [StringComparison]::OrdinalIgnoreCase) -ge 0))",
      "  } | Sort-Object StartTime -Descending | Select-Object -First 1",
      "  if ($fallback) { $p = [pscustomobject]@{ ProcessId = $fallback.Id; CommandLine = $fallback.Path; Match = 'bundled-fallback' } }",
      "}",
      "if ($p) { $p | ConvertTo-Json -Compress }"
    ].join('; ');
    const output = execFileSync('powershell.exe', ['-NoProfile', '-Command', script], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: SCREENPIPE_PROCESS_QUERY_TIMEOUT_MS
    }).trim();
    if (!output) {
      const value = { running: false, pid: null };
      screenpipeProcessCache = {
        settingsKey,
        createdAtMs: Date.now(),
        value
      };
      return value;
    }
    const parsed = JSON.parse(output);
    const value = {
      running: true,
      pid: parsed.ProcessId || null,
      commandLine: parsed.CommandLine || '',
      owned: parsed.Match === 'current-data-dir-port',
      match: parsed.Match || ''
    };
    screenpipeProcessCache = {
      settingsKey,
      createdAtMs: Date.now(),
      value
    };
    return value;
  } catch {
    return { running: false, pid: null };
  }
}

function moveScreenpipeToAvailablePort(settings = {}) {
  const nextPort = chooseAvailableScreenpipePort(settings, { avoidPreferred: true });
  const currentPort = screenpipePortFromSettings(settings);
  if (nextPort === currentPort) {
    return settings;
  }

  const nextSettings = services.settings.updateConnection({
    screenpipeBaseUrl: screenpipeBaseUrlForPort(nextPort)
  });
  services.screenpipe.updateSettings?.(nextSettings);
  traceStartup('screenpipe_port_changed', {
    previous_port: currentPort,
    next_port: nextPort
  });
  return nextSettings;
}

async function ensureScreenpipeRunning({ force = false, source = 'health' } = {}) {
  if (screenpipeStartInFlight) {
    traceStartup('screenpipe_ensure_joined_inflight', { source, force });
    return screenpipeStartInFlight;
  }

  screenpipeStartInFlight = (async () => {
    const ensureStartedAt = Date.now();
    traceStartup('screenpipe_ensure_started', { source, force });
    let settings = services.settings.getSettings();
    const staleStartedAt = Date.now();
    stopStaleCognifyScreenpipeProcesses(settings);
    traceStartup('screenpipe_stale_cleanup_checked', {
      source,
      duration_ms: Date.now() - staleStartedAt
    });
    const statusStartedAt = Date.now();
    let status = await services.screenpipe.getStatus({ force });
    traceStartup('screenpipe_status_checked', {
      source,
      duration_ms: Date.now() - statusStartedAt,
      apiAvailable: Boolean(status.apiAvailable),
      running: Boolean(status.running)
    });
    const searchFailed = Boolean(status.searchVerified && !status.apiAuthenticated);
    const processStartedAt = Date.now();
    const ownedProcess = currentUserScreenpipeProcess(settings);
    traceStartup('screenpipe_owned_process_checked', {
      source,
      duration_ms: Date.now() - processStartedAt,
      running: Boolean(ownedProcess.running),
      pid: ownedProcess.pid || null,
      owned: Boolean(ownedProcess.owned),
      match: ownedProcess.match || null
    });
    const ownedApiReachable = status.apiAvailable && !searchFailed && ownedProcess.running && ownedProcess.owned;
    if (!force && ownedApiReachable) {
      traceStartup('screenpipe_ensure_completed', {
        source,
        result: 'owned-api-reachable',
        duration_ms: Date.now() - ensureStartedAt
      });
      return { ok: true, alreadyRunning: true, detail: 'Screenpipe API is already reachable.' };
    }

    if ((!ownedProcess.running || !ownedProcess.owned) && status.apiAvailable) {
      const stopStartedAt = Date.now();
      traceStartup('screenpipe_non_owned_api_detected', {
        source,
        port: screenpipePortFromSettings(settings),
        process_running: Boolean(ownedProcess.running),
        process_match: ownedProcess.match || null
      });
      stopScreenpipeProcesses(settings, { includeLegacyDefault: true, reason: `${source}-non-owned-api` });
      traceStartup('screenpipe_non_owned_api_stop_attempted', {
        source,
        duration_ms: Date.now() - stopStartedAt
      });
      await new Promise((resolve) => setTimeout(resolve, 1200));
      services.screenpipe.invalidateStatusCache?.();
      const recheckStartedAt = Date.now();
      status = await services.screenpipe.getStatus({ force: true });
      traceStartup('screenpipe_status_rechecked_after_stop', {
        source,
        duration_ms: Date.now() - recheckStartedAt,
        apiAvailable: Boolean(status.apiAvailable),
        running: Boolean(status.running)
      });
    }

    if ((!ownedProcess.running || !ownedProcess.owned) && (status.apiAvailable || isScreenpipePortOccupied(settings))) {
      traceStartup('screenpipe_port_move_needed', { source });
      settings = moveScreenpipeToAvailablePort(settings);
    }

    const exePath = resolveScreenpipeExe();
    if (!exePath) {
      traceStartup('screenpipe_ensure_completed', {
        source,
        result: 'missing-exe',
        duration_ms: Date.now() - ensureStartedAt
      });
      return { ok: false, detail: 'Bundled Screenpipe executable was not found.' };
    }

    const ortPatch = ensureScreenpipeOnnxRuntime();
    if (!ortPatch.ok) {
      traceStartup('screenpipe_onnx_runtime_patch_failed', { source, detail: ortPatch.detail });
    }

    const hydrateStartedAt = Date.now();
    settings = await hydrateDefaultAudioDevices(settings);
    traceStartup('screenpipe_audio_devices_checked', {
      source,
      duration_ms: Date.now() - hydrateStartedAt
    });
    const apiKey = settings.screenpipeApiKey || process.env.SCREENPIPE_API_KEY || 'cognify-local-screenpipe-token';
    const audioMode = captureAudioMode(settings);
    const audioActive = isAudioActiveForSettings(settings);
    const retention = effectiveScreenpipeRetention(settings);
    const screenpipeArgs = buildScreenpipeArgs(settings);
    traceStartup('screenpipe_args_built', {
      source,
      audio_mode: audioMode,
      audio_active: audioActive,
      raw_target_days: retention.effectiveRawTargetDays,
      raw_hard_cap_days: retention.screenpipeCliRetentionDays,
      evidence_days: retention.retentionDays
    });
    const logs = screenpipeLogPaths();
    const ffmpegStartedAt = Date.now();
    const ffmpeg = resolveFfmpegStatus();
    traceStartup('screenpipe_ffmpeg_resolved', {
      source,
      duration_ms: Date.now() - ffmpegStartedAt,
      ok: Boolean(ffmpeg.ok),
      path: ffmpeg.path || null
    });
    const ffmpegPatchStartedAt = Date.now();
    const ffmpegPatch = ensureScreenpipeFfmpegRuntime(ffmpeg.path);
    traceStartup('screenpipe_ffmpeg_patch_checked', {
      source,
      duration_ms: Date.now() - ffmpegPatchStartedAt,
      ok: Boolean(ffmpegPatch.ok),
      detail: ffmpegPatch.detail
    });
    if (!ffmpegPatch.ok) {
      traceStartup('screenpipe_ffmpeg_runtime_patch_failed', { source, detail: ffmpegPatch.detail });
    }
    const patchedFfmpeg = resolveFfmpegStatus();
    const logOpenStartedAt = Date.now();
    const stdout = fs.openSync(logs.stdout, 'a');
    const stderr = fs.openSync(logs.stderr, 'a');
    traceStartup('screenpipe_logs_opened', {
      source,
      duration_ms: Date.now() - logOpenStartedAt
    });
    const screenpipeBinDir = path.dirname(exePath);
    const ffmpegForEnv = patchedFfmpeg.runtime_ok ? patchedFfmpeg.runtime_path : ffmpeg.path;
    const ffmpegBinDir = ffmpegForEnv ? path.dirname(ffmpegForEnv) : '';
    const pathEntries = [screenpipeBinDir, ffmpegBinDir, process.env.PATH || ''].filter(Boolean);

    try {
      if (force || searchFailed || !status.apiAvailable) {
        const stopStartedAt = Date.now();
        stopScreenpipeProcesses(settings, { includeLegacyDefault: !status.apiAvailable, reason: `${source}-restart` });
        traceStartup('screenpipe_existing_processes_stopped', {
          source,
          duration_ms: Date.now() - stopStartedAt,
          force,
          searchFailed,
          apiAvailable: Boolean(status.apiAvailable)
        });
        await new Promise((resolve) => setTimeout(resolve, 1200));
      }

      const spawnStartedAt = Date.now();
      const child = spawn(exePath, screenpipeArgs, {
        cwd: path.join(__dirname, '..'),
        detached: true,
        windowsHide: true,
        env: {
          ...process.env,
          SCREENPIPE_API_KEY: apiKey,
          PATH: pathEntries.join(path.delimiter),
          ...(ffmpegForEnv ? {
            FFMPEG_BIN: ffmpegForEnv,
            FFMPEG_PATH: ffmpegForEnv
          } : {})
        },
        stdio: ['ignore', stdout, stderr]
      });
      traceStartup('screenpipe_spawn_returned', {
        source,
        duration_ms: Date.now() - spawnStartedAt,
        pid: child.pid
      });
      screenpipeLastSpawnAtMs = Date.now();
      rescheduleScreenpipeFfmpegPriorityGovernor(`screenpipe-spawn-${source}`);
      setProcessBelowNormalPriority(child.pid, 'screenpipe');
      child.unref();
      invalidateScreenpipeProcessCache();
      services.screenpipe.invalidateStatusCache?.();
      traceStartup('screenpipe_start_requested', {
        source,
        pid: child.pid,
        exePath,
        audio_mode: audioMode,
        audio_active: audioActive,
        args: screenpipeArgs,
        duration_ms: Date.now() - ensureStartedAt
      });
      return { ok: true, pid: child.pid, detail: 'Screenpipe start requested.' };
    } catch (error) {
      traceStartup('screenpipe_start_failed', { source, error: error.message });
      return { ok: false, detail: error.message };
    } finally {
      fs.closeSync(stdout);
      fs.closeSync(stderr);
    }
  })();

  try {
    return await screenpipeStartInFlight;
  } finally {
    screenpipeStartInFlight = null;
  }
}

async function disableListeningAfterAudioStartFailure(source = 'audio-start-failed') {
  const settings = services.settings.getSettings();
  if (captureAudioMode(settings) === 'off') {
    return null;
  }

  await new Promise((resolve) => setTimeout(resolve, 2500));
  const status = await services.screenpipe.getStatus({ force: true });
  if (status.running && status.apiAvailable) {
    const updatedSettings = await hydrateDefaultAudioDevices(settings);
    if (
      isAudioActiveForSettings(updatedSettings) &&
      !(settings.capture?.audioDeviceNames || []).length &&
      (updatedSettings.capture?.audioDeviceNames || []).length
    ) {
      traceStartup('screenpipe_audio_devices_hydrated', {
        audio_devices: updatedSettings.capture.audioDeviceNames
      });
      return ensureScreenpipeRunning({ force: true, source: 'audio-device-hydrated' });
    }
    return null;
  }

  meetingAudioActive = false;
  services.settings.updateCapture({ audioMode: 'off', listeningEnabled: false });
  diagnosticsCache = null;
  traceStartup('screenpipe_audio_start_failed_fallback', { source });
  return ensureScreenpipeRunning({ force: true, source });
}

function createPanelWindow() {
  cancelHiddenWindowDestroy('panel');
  panelWindow = new BrowserWindow({
    width: 1120,
    height: 760,
    minWidth: 620,
    minHeight: 620,
    show: false,
    skipTaskbar: true,
    frame: false,
    transparent: true,
    autoHideMenuBar: true,
    title: 'Cognify',
    alwaysOnTop: false,
    resizable: true,
    hasShadow: true,
    backgroundColor: '#00000000',
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  panelWindow.loadFile(path.join(__dirname, 'renderer', 'panel.html'));
  panelWindow.setMenuBarVisibility(false);
  panelWindow.removeMenu();
  panelWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      quitApp();
    }
  });
  panelWindow.on('closed', () => {
    panelWindow = null;
    cancelHiddenWindowDestroy('panel');
  });
}

function createReportWindow() {
  cancelHiddenWindowDestroy('report');
  reportWindow = new BrowserWindow({
    width: REPORT_WINDOW_WIDTH,
    height: REPORT_WINDOW_HEIGHT,
    minWidth: 720,
    minHeight: 560,
    show: false,
    skipTaskbar: false,
    frame: false,
    transparent: true,
    autoHideMenuBar: true,
    title: 'Cognify Report',
    alwaysOnTop: false,
    resizable: true,
    hasShadow: true,
    backgroundColor: '#00000000',
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  reportWindow.loadFile(path.join(__dirname, 'renderer', 'report.html'));
  reportWindow.setMenuBarVisibility(false);
  reportWindow.removeMenu();
  reportWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      hideReportWindow({ restoreContext: true });
    }
  });
  reportWindow.on('closed', () => {
    reportWindow = null;
    cancelHiddenWindowDestroy('report');
  });
}

function createSnapshotWindow() {
  cancelHiddenWindowDestroy('snapshot');
  const popupOptions = popupWindowTransparencyOptions();
  snapshotWindow = new BrowserWindow({
    width: SNAPSHOT_WINDOW_WIDTH,
    height: SNAPSHOT_WINDOW_HEIGHT,
    minWidth: 300,
    minHeight: 620,
    show: false,
    skipTaskbar: true,
    frame: false,
    transparent: popupOptions.transparent,
    alwaysOnTop: true,
    resizable: false,
    hasShadow: true,
    backgroundColor: popupOptions.backgroundColor,
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  snapshotWindow.loadFile(path.join(__dirname, 'renderer', 'snapshot.html'));
  traceStartup('snapshot_window_created', { opaqueFallback: popupOptions.opaqueFallback });
  snapshotWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      hideSnapshotWindow();
    }
  });
  snapshotWindow.on('blur', () => {
    if (keepSnapshotVisible) {
      return;
    }

    if (snapshotWindow && !snapshotWindow.isDestroyed() && snapshotWindow.isVisible()) {
      hideSnapshotWindow();
    }
  });
  snapshotWindow.on('closed', () => {
    snapshotWindow = null;
    cancelHiddenWindowDestroy('snapshot');
  });
}

function createHealthWindow() {
  cancelHiddenWindowDestroy('health');
  const popupOptions = popupWindowTransparencyOptions();
  healthWindow = new BrowserWindow({
    width: SNAPSHOT_WINDOW_WIDTH,
    height: SNAPSHOT_WINDOW_HEIGHT,
    minWidth: SNAPSHOT_WINDOW_WIDTH,
    minHeight: SNAPSHOT_WINDOW_HEIGHT,
    show: false,
    skipTaskbar: true,
    frame: false,
    transparent: popupOptions.transparent,
    alwaysOnTop: true,
    resizable: false,
    hasShadow: true,
    backgroundColor: popupOptions.backgroundColor,
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  healthWindow.loadFile(path.join(__dirname, 'renderer', 'health.html'));
  traceStartup('health_window_created', { opaqueFallback: popupOptions.opaqueFallback });
  healthWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      hideWindowForIdleDestroy('health', healthWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
    }
  });
  healthWindow.on('closed', () => {
    healthWindow = null;
    cancelHiddenWindowDestroy('health');
  });
}

function createWorkHoursWindow() {
  cancelHiddenWindowDestroy('work-hours');
  const popupOptions = popupWindowTransparencyOptions();
  workHoursWindow = new BrowserWindow({
    width: WORK_HOURS_WINDOW_WIDTH,
    height: WORK_HOURS_WINDOW_HEIGHT,
    minWidth: WORK_HOURS_WINDOW_WIDTH,
    minHeight: WORK_HOURS_WINDOW_HEIGHT,
    show: false,
    skipTaskbar: true,
    frame: false,
    transparent: popupOptions.transparent,
    alwaysOnTop: true,
    resizable: false,
    hasShadow: true,
    backgroundColor: popupOptions.backgroundColor,
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  workHoursWindow.loadFile(path.join(__dirname, 'renderer', 'work-hours.html'));
  traceStartup('work_hours_window_created', { opaqueFallback: popupOptions.opaqueFallback });
  workHoursWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      hideWindowForIdleDestroy('work-hours', workHoursWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
    }
  });
  workHoursWindow.on('closed', () => {
    workHoursWindow = null;
    cancelHiddenWindowDestroy('work-hours');
  });
}

function createNotesWindow() {
  cancelHiddenWindowDestroy('notes');
  const popupOptions = popupWindowTransparencyOptions();
  notesWindow = new BrowserWindow({
    width: SNAPSHOT_WINDOW_WIDTH,
    height: SNAPSHOT_WINDOW_HEIGHT,
    minWidth: SNAPSHOT_WINDOW_WIDTH,
    minHeight: SNAPSHOT_WINDOW_HEIGHT,
    show: false,
    skipTaskbar: true,
    frame: false,
    transparent: popupOptions.transparent,
    alwaysOnTop: true,
    resizable: false,
    hasShadow: true,
    backgroundColor: popupOptions.backgroundColor,
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  notesWindow.loadFile(path.join(__dirname, 'renderer', 'notes.html'));
  traceStartup('notes_window_created', { opaqueFallback: popupOptions.opaqueFallback });
  notesWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      hideWindowForIdleDestroy('notes', notesWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
    }
  });
  notesWindow.on('closed', () => {
    notesWindow = null;
    cancelHiddenWindowDestroy('notes');
  });
}

function createNudgeWindow() {
  cancelHiddenWindowDestroy('nudge');
  nudgeWindow = new BrowserWindow({
    width: NUDGE_WINDOW_WIDTH,
    height: NUDGE_WINDOW_HEIGHT,
    minWidth: NUDGE_WINDOW_WIDTH,
    minHeight: NUDGE_WINDOW_HEIGHT,
    show: false,
    skipTaskbar: true,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    resizable: false,
    focusable: false,
    hasShadow: true,
    backgroundColor: '#00000000',
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  nudgeWindow.loadFile(path.join(__dirname, 'renderer', 'nudge.html'));
  nudgeWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      hideWindowForIdleDestroy('nudge', nudgeWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
    }
  });
  nudgeWindow.on('closed', () => {
    nudgeWindow = null;
    cancelHiddenWindowDestroy('nudge');
  });
}

function createNudgeDetailWindow() {
  cancelHiddenWindowDestroy('nudge-detail');
  nudgeDetailWindow = new BrowserWindow({
    width: NUDGE_DETAIL_WINDOW_WIDTH,
    height: NUDGE_DETAIL_WINDOW_HEIGHT,
    minWidth: NUDGE_DETAIL_WINDOW_WIDTH,
    minHeight: NUDGE_DETAIL_WINDOW_HEIGHT,
    show: false,
    skipTaskbar: true,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    resizable: false,
    focusable: true,
    hasShadow: true,
    backgroundColor: '#00000000',
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  nudgeDetailWindow.loadFile(path.join(__dirname, 'renderer', 'nudge-detail.html'));
  nudgeDetailWindow.on('close', (event) => {
    if (!isQuitting) {
      event.preventDefault();
      hideWindowForIdleDestroy('nudge-detail', nudgeDetailWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
    }
  });
  nudgeDetailWindow.on('closed', () => {
    nudgeDetailWindow = null;
    cancelHiddenWindowDestroy('nudge-detail');
  });
}

function createSetupWindow() {
  setupWindow = new BrowserWindow({
    width: 760,
    height: 680,
    minWidth: 640,
    minHeight: 600,
    show: false,
    skipTaskbar: false,
    frame: false,
    transparent: false,
    autoHideMenuBar: true,
    title: 'Cognify Setup',
    alwaysOnTop: false,
    resizable: true,
    hasShadow: true,
    backgroundColor: '#0b0f17',
    icon: getCognifyIcon(),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });

  setupWindow.loadFile(path.join(__dirname, 'renderer', 'setup.html'));
  setupWindow.setMenuBarVisibility(false);
  setupWindow.removeMenu();
  setupWindow.on('close', (event) => {
    if (!isQuitting && !allowSetupWindowClose) {
      event.preventDefault();
      quitApp();
    }
  });
  setupWindow.on('closed', () => {
    setupWindow = null;
    allowSetupWindowClose = false;
  });
  traceStartup('setup_window_created');
}

function cancelHiddenWindowDestroy(key) {
  const timer = hiddenWindowDestroyTimers.get(key);
  if (!timer) {
    return;
  }
  clearTimeout(timer);
  hiddenWindowDestroyTimers.delete(key);
}

function scheduleHiddenWindowDestroy(key, targetWindow, delayMs) {
  cancelHiddenWindowDestroy(key);
  if (!targetWindow || targetWindow.isDestroyed() || targetWindow.isVisible()) {
    return;
  }

  const effectiveDelayMs = effectiveHiddenWindowDestroyMs(key, delayMs);
  const timer = setTimeout(() => {
    hiddenWindowDestroyTimers.delete(key);
    if (!targetWindow || targetWindow.isDestroyed() || targetWindow.isVisible() || isQuitting) {
      return;
    }
    traceStartup('hidden_window_destroyed', { key, delay_ms: effectiveDelayMs, requested_delay_ms: delayMs, low_ram: isLowRamMode() });
    targetWindow.destroy();
  }, effectiveDelayMs);
  hiddenWindowDestroyTimers.set(key, timer);
}

function hideWindowForIdleDestroy(key, targetWindow, delayMs) {
  if (!targetWindow || targetWindow.isDestroyed()) {
    return;
  }
  targetWindow.hide();
  scheduleHiddenWindowDestroy(key, targetWindow, delayMs);
}

function positionWindowNearWidget(targetWindow, width, height) {
  if (!targetWindow || targetWindow.isDestroyed() || !widgetWindow || widgetWindow.isDestroyed()) {
    return;
  }

  const widgetBounds = widgetWindow.getBounds();
  const display = screen.getDisplayNearestPoint({
    x: widgetBounds.x + Math.round(widgetBounds.width / 2),
    y: widgetBounds.y + Math.round(widgetBounds.height / 2)
  });
  const area = display.workArea;
  const gap = 12;
  let nextX = widgetBounds.x - width - gap;
  if (nextX < area.x + gap) {
    nextX = widgetBounds.x + widgetBounds.width + gap;
  }
  nextX = Math.min(Math.max(area.x + gap, nextX), area.x + area.width - width - gap);
  const centeredY = area.y + Math.round((area.height - height) / 2);
  const nextY = Math.min(
    Math.max(area.y + gap, centeredY),
    area.y + area.height - height - gap
  );

  targetWindow.setBounds({
    x: Math.round(nextX),
    y: Math.round(nextY),
    width,
    height
  });
}

function isInlineManualNudge(nudge = {}) {
  return nudge.type === 'idle-return'
    && nudge.manual_block?.startTime
    && nudge.manual_block?.endTime;
}

function nudgeWindowHeight(nudge = {}) {
  return isInlineManualNudge(nudge) ? NUDGE_MANUAL_WINDOW_HEIGHT : NUDGE_WINDOW_HEIGHT;
}

function resolveNudgeBounds(height = NUDGE_WINDOW_HEIGHT) {
  if (!widgetWindow || widgetWindow.isDestroyed()) {
    return null;
  }

  const widgetBounds = widgetWindow.getBounds();
  const display = screen.getDisplayNearestPoint({
    x: widgetBounds.x + Math.round(widgetBounds.width / 2),
    y: widgetBounds.y + Math.round(widgetBounds.height / 2)
  });
  const area = display.workArea;
  const gap = 6;
  const rightX = widgetBounds.x + widgetBounds.width - 10;
  const leftX = widgetBounds.x - NUDGE_WINDOW_WIDTH + 10;
  const opensRight = rightX + NUDGE_WINDOW_WIDTH <= area.x + area.width - gap;
  const x = opensRight ? rightX : Math.max(area.x + gap, leftX);
  const y = Math.min(
    Math.max(area.y + gap, widgetBounds.y + Math.round((widgetBounds.height - height) / 2)),
    area.y + area.height - height - gap
  );

  return {
    x: Math.round(x),
    y: Math.round(y),
    width: NUDGE_WINDOW_WIDTH,
    height,
    side: opensRight ? 'left' : 'right'
  };
}

function resolveNudgeDetailBounds() {
  const anchor = nudgeWindow && !nudgeWindow.isDestroyed() && nudgeWindow.isVisible()
    ? nudgeWindow.getBounds()
    : widgetWindow?.getBounds();
  if (!anchor) {
    return null;
  }

  const display = screen.getDisplayNearestPoint({
    x: anchor.x + Math.round(anchor.width / 2),
    y: anchor.y + Math.round(anchor.height / 2)
  });
  const area = display.workArea;
  const gap = 10;
  let x = anchor.x + anchor.width + gap;
  if (x + NUDGE_DETAIL_WINDOW_WIDTH > area.x + area.width - gap) {
    x = anchor.x - NUDGE_DETAIL_WINDOW_WIDTH - gap;
  }
  x = Math.min(Math.max(area.x + gap, x), area.x + area.width - NUDGE_DETAIL_WINDOW_WIDTH - gap);
  const y = Math.min(
    Math.max(area.y + gap, anchor.y),
    area.y + area.height - NUDGE_DETAIL_WINDOW_HEIGHT - gap
  );

  return {
    x: Math.round(x),
    y: Math.round(y),
    width: NUDGE_DETAIL_WINDOW_WIDTH,
    height: NUDGE_DETAIL_WINDOW_HEIGHT
  };
}

function showSnapshotWindow() {
  if (!isOnboardingComplete()) {
    traceStartup('snapshot_show_blocked_until_onboarding_complete');
    showSetupWindow('snapshot-request');
    return { visible: false, blocked: 'onboarding' };
  }
  if (!snapshotWindow || snapshotWindow.isDestroyed()) {
    createSnapshotWindow();
  }
  cancelHiddenWindowDestroy('snapshot');

  ensureWidgetVisible({ focus: false });
  positionWindowNearWidget(snapshotWindow, SNAPSHOT_WINDOW_WIDTH, SNAPSHOT_WINDOW_HEIGHT);
  snapshotWindow.show();
  snapshotWindow.moveTop();
  snapshotWindow.focus();
  notifySnapshotVisible();
  refreshLiveTruthCurrent('snapshot-visible').catch((error) => {
    traceStartup('live_truth_snapshot_refresh_failed', { error: error?.message || String(error) });
  });
  const snapshotBounds = snapshotWindow.getBounds();
  const snapshotDisplay = screen.getDisplayMatching(snapshotBounds);
  traceStartup('snapshot_shown', {
    bounds: snapshotBounds,
    display: snapshotDisplay
      ? {
        id: snapshotDisplay.id,
        bounds: snapshotDisplay.bounds,
        workArea: snapshotDisplay.workArea,
        scaleFactor: snapshotDisplay.scaleFactor
      }
      : null,
    focused: snapshotWindow.isFocused(),
    visible: snapshotWindow.isVisible()
  });
  return { visible: true };
}

function notifySnapshotVisible() {
  if (!snapshotWindow || snapshotWindow.isDestroyed()) {
    return;
  }
  if (snapshotWindow.webContents.isLoading()) {
    snapshotWindow.webContents.once('did-finish-load', () => {
      if (snapshotWindow && !snapshotWindow.isDestroyed() && snapshotWindow.isVisible()) {
        snapshotWindow.webContents.send('snapshot:visible');
      }
    });
    return;
  }
  snapshotWindow.webContents.send('snapshot:visible');
}

function notifySnapshotHidden() {
  if (!snapshotWindow || snapshotWindow.isDestroyed()) {
    return;
  }
  snapshotWindow.webContents.send('snapshot:hidden');
}

function hideSnapshotWindow() {
  if (snapshotWindow && !snapshotWindow.isDestroyed()) {
    notifySnapshotHidden();
    traceStartup('snapshot_hidden', {
      bounds: snapshotWindow.getBounds(),
      focused: snapshotWindow.isFocused(),
      visible: snapshotWindow.isVisible()
    });
    hideWindowForIdleDestroy('snapshot', snapshotWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  if (healthWindow && !healthWindow.isDestroyed()) {
    hideWindowForIdleDestroy('health', healthWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  if (workHoursWindow && !workHoursWindow.isDestroyed()) {
    hideWindowForIdleDestroy('work-hours', workHoursWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  if (notesWindow && !notesWindow.isDestroyed()) {
    hideWindowForIdleDestroy('notes', notesWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
}

function showPanelWindow() {
  if (shouldShowSetupMode()) {
    return showSetupWindow('panel-request');
  }
  if (!panelWindow || panelWindow.isDestroyed()) {
    createPanelWindow();
  }
  cancelHiddenWindowDestroy('panel');

  ensureWidgetVisible({ focus: false });

  const display = widgetWindow && !widgetWindow.isDestroyed()
    ? screen.getDisplayNearestPoint({
      x: widgetWindow.getBounds().x + Math.round(widgetWindow.getBounds().width / 2),
      y: widgetWindow.getBounds().y + Math.round(widgetWindow.getBounds().height / 2)
    })
    : screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  const bounds = panelWindow.getBounds();
  const area = display.workArea;
  const nextX = area.x + Math.round((area.width - bounds.width) / 2);
  const nextY = area.y + Math.round((area.height - bounds.height) / 2);

  if (panelWindow.isMinimized()) {
    panelWindow.restore();
  }

  panelWindow.setPosition(nextX, nextY);
  panelWindow.setSkipTaskbar(false);
  panelWindow.show();
  panelWindow.moveTop();
  panelWindow.focus();
  panelWindow.setAlwaysOnTop(true);
  panelWindow.show();
  panelWindow.moveTop();
  panelWindow.focus();
  panelWindow.setAlwaysOnTop(false);

  // Fallback: if a daily progress nudge never fired via idle-return, surface it on panel open
  if (pendingDailyProgressNudge) {
    setTimeout(showPendingDailyProgressNudge, 2000);
  }
}

function showSetupWindow(reason = 'setup-request') {
  if (!services) {
    return { visible: false, blocked: 'services-not-ready' };
  }
  if (isOnboardingComplete()) {
    enterRuntimeMode('setup-request-after-complete');
    return { visible: false, completed: true };
  }
  if (!setupWindow || setupWindow.isDestroyed()) {
    createSetupWindow();
  }

  const display = screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  const area = display?.workArea || { x: 0, y: 0, width: 1280, height: 720 };
  const bounds = setupWindow.getBounds();
  const nextX = area.x + Math.round((area.width - bounds.width) / 2);
  const nextY = area.y + Math.round((area.height - bounds.height) / 2);

  if (setupWindow.isMinimized()) {
    setupWindow.restore();
  }
  setupWindow.setPosition(nextX, nextY);
  setupWindow.setSkipTaskbar(false);
  setupWindow.show();
  setupWindow.moveTop();
  setupWindow.focus();
  traceStartup('setup_window_shown', { reason });
  return { visible: true, mode: 'setup' };
}

function resolveReportPanelBounds() {
  const fallbackDisplay = screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  const snapshotBounds = snapshotWindow && !snapshotWindow.isDestroyed() && snapshotWindow.isVisible()
    ? snapshotWindow.getBounds()
    : null;
  const anchorBounds = snapshotBounds || (widgetWindow && !widgetWindow.isDestroyed() ? widgetWindow.getBounds() : null);
  const display = anchorBounds
    ? screen.getDisplayNearestPoint({
      x: anchorBounds.x + Math.round(anchorBounds.width / 2),
      y: anchorBounds.y + Math.round(anchorBounds.height / 2)
    })
    : fallbackDisplay;
  const area = display.workArea;
  const gap = 16;
  const anchor = snapshotBounds || {
    x: area.x + area.width - SNAPSHOT_WINDOW_WIDTH - gap,
    y: area.y + Math.round((area.height - SNAPSHOT_WINDOW_HEIGHT) / 2),
    width: SNAPSHOT_WINDOW_WIDTH,
    height: SNAPSHOT_WINDOW_HEIGHT
  };
  const height = snapshotBounds
    ? Math.min(anchor.height, 560)
    : Math.min(560, Math.max(520, area.height - (gap * 2)));
  const rightSpace = (area.x + area.width) - (anchor.x + anchor.width) - (gap * 2);
  const leftSpace = anchor.x - area.x - (gap * 2);
  const opensRight = rightSpace >= leftSpace && rightSpace >= 620;
  const availableWidth = Math.max(620, Math.floor(opensRight ? rightSpace : leftSpace));
  const width = Math.min(REPORT_WINDOW_WIDTH, availableWidth);
  const finalX = opensRight
    ? anchor.x + anchor.width + gap
    : Math.max(area.x + gap, anchor.x - width - gap);
  const alignedY = snapshotBounds
    ? anchor.y
    : area.y + Math.round((area.height - height) / 2);
  const finalY = Math.min(
    Math.max(area.y + gap, alignedY),
    area.y + area.height - height - gap
  );
  const startX = opensRight
    ? Math.max(area.x + gap, anchor.x + anchor.width - 24)
    : Math.min(area.x + area.width - width - gap, anchor.x - width + 24);

  return {
    start: {
      x: Math.round(startX),
      y: Math.round(finalY),
      width,
      height
    },
    final: {
      x: Math.round(finalX),
      y: Math.round(finalY),
      width,
      height
    }
  };
}

function animateWindowBounds(targetWindow, fromBounds, toBounds, durationMs = 220) {
  if (!targetWindow || targetWindow.isDestroyed()) {
    return;
  }

  const startedAt = Date.now();
  const tick = () => {
    if (!targetWindow || targetWindow.isDestroyed()) {
      return;
    }

    const progress = Math.min(1, (Date.now() - startedAt) / durationMs);
    const eased = 1 - Math.pow(1 - progress, 3);
    targetWindow.setBounds({
      x: Math.round(fromBounds.x + ((toBounds.x - fromBounds.x) * eased)),
      y: Math.round(fromBounds.y + ((toBounds.y - fromBounds.y) * eased)),
      width: Math.round(fromBounds.width + ((toBounds.width - fromBounds.width) * eased)),
      height: Math.round(fromBounds.height + ((toBounds.height - fromBounds.height) * eased))
    });

    if (progress < 1) {
      setTimeout(tick, 16);
    }
  };

  tick();
}

function resolveAttachedSnapshotBounds(width = SNAPSHOT_WINDOW_WIDTH, height = SNAPSHOT_WINDOW_HEIGHT) {
  const snapshotBounds = snapshotWindow && !snapshotWindow.isDestroyed() && snapshotWindow.isVisible()
    ? snapshotWindow.getBounds()
    : null;
  if (!snapshotBounds) {
    return null;
  }

  const display = screen.getDisplayNearestPoint({
    x: snapshotBounds.x + Math.round(snapshotBounds.width / 2),
    y: snapshotBounds.y + Math.round(snapshotBounds.height / 2)
  });
  const area = display.workArea;
  const insetOverlap = 24;
  const leftX = snapshotBounds.x - width + insetOverlap;
  const rightX = snapshotBounds.x + snapshotBounds.width - insetOverlap;
  const opensLeft = leftX >= area.x;
  const finalX = opensLeft
    ? leftX
    : Math.min(rightX, area.x + area.width - width);
  const startX = opensLeft
    ? Math.min(snapshotBounds.x - 48, finalX + 42)
    : Math.max(snapshotBounds.x + 48, finalX - 42);
  const finalY = Math.min(
    Math.max(area.y, snapshotBounds.y),
    area.y + area.height - height
  );

  return {
    start: {
      x: Math.round(startX),
      y: Math.round(finalY),
      width,
      height
    },
    final: {
      x: Math.round(finalX),
      y: Math.round(finalY),
      width,
      height
    }
  };
}

function showHealthWindowFromSnapshot() {
  extendReadinessQuietWindow(10 * 1000);
  if (!isOnboardingComplete()) {
    showPanelWindow();
    return { visible: false, blocked: 'onboarding' };
  }
  if (!healthWindow || healthWindow.isDestroyed()) {
    createHealthWindow();
  }
  cancelHiddenWindowDestroy('health');
  if (!snapshotWindow || snapshotWindow.isDestroyed() || !snapshotWindow.isVisible()) {
    showSnapshotWindow();
  }

  keepSnapshotVisible = true;
  if (panelWindow && !panelWindow.isDestroyed()) {
    hideWindowForIdleDestroy('panel', panelWindow, WORK_WINDOW_IDLE_DESTROY_MS);
  }
  if (notesWindow && !notesWindow.isDestroyed()) {
    hideWindowForIdleDestroy('notes', notesWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  if (workHoursWindow && !workHoursWindow.isDestroyed()) {
    hideWindowForIdleDestroy('work-hours', workHoursWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }

  const bounds = resolveAttachedSnapshotBounds();
  if (!bounds) {
    return;
  }

  healthWindow.setBounds(bounds.start);
  healthWindow.show();
  snapshotWindow.moveTop();
  healthWindow.moveTop();
  healthWindow.focus();
  animateWindowBounds(healthWindow, bounds.start, bounds.final);
  return { visible: true };
}

function showWorkHoursWindowFromSnapshot() {
  extendReadinessQuietWindow(10 * 1000);
  if (!isOnboardingComplete()) {
    showPanelWindow();
    return { visible: false, blocked: 'onboarding' };
  }
  if (!workHoursWindow || workHoursWindow.isDestroyed()) {
    createWorkHoursWindow();
  }
  cancelHiddenWindowDestroy('work-hours');
  if (!snapshotWindow || snapshotWindow.isDestroyed() || !snapshotWindow.isVisible()) {
    showSnapshotWindow();
  }

  keepSnapshotVisible = true;
  if (panelWindow && !panelWindow.isDestroyed()) {
    hideWindowForIdleDestroy('panel', panelWindow, WORK_WINDOW_IDLE_DESTROY_MS);
  }
  if (healthWindow && !healthWindow.isDestroyed()) {
    hideWindowForIdleDestroy('health', healthWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  if (notesWindow && !notesWindow.isDestroyed()) {
    hideWindowForIdleDestroy('notes', notesWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }

  const bounds = resolveAttachedSnapshotBounds(WORK_HOURS_WINDOW_WIDTH, WORK_HOURS_WINDOW_HEIGHT);
  if (!bounds) {
    return { visible: false, blocked: 'snapshot' };
  }

  workHoursWindow.setBounds(bounds.start);
  workHoursWindow.show();
  snapshotWindow.moveTop();
  workHoursWindow.moveTop();
  workHoursWindow.focus();
  animateWindowBounds(workHoursWindow, bounds.start, bounds.final);
  return { visible: true };
}

function setWorkHoursSummaryExpanded(expanded = false) {
  if (!workHoursWindow || workHoursWindow.isDestroyed()) {
    return { visible: false };
  }

  if (expanded) {
    const current = workHoursWindow.getBounds();
    const display = screen.getDisplayNearestPoint({
      x: current.x + Math.round(current.width / 2),
      y: current.y + Math.round(current.height / 2)
    });
    const area = display.workArea;
    const width = Math.min(WORK_SUMMARY_WINDOW_WIDTH, Math.max(WORK_HOURS_WINDOW_WIDTH, area.width - 48));
    const height = Math.min(WORK_SUMMARY_WINDOW_HEIGHT, Math.max(WORK_HOURS_WINDOW_HEIGHT, area.height - 48));
    const final = {
      x: Math.round(area.x + (area.width - width) / 2),
      y: Math.round(area.y + (area.height - height) / 2),
      width,
      height
    };
    workHoursWindow.setBounds(final, true);
    workHoursWindow.show();
    workHoursWindow.focus();
    return { visible: true, expanded: true, bounds: final };
  }

  const attached = snapshotWindow && !snapshotWindow.isDestroyed() && snapshotWindow.isVisible()
    ? resolveAttachedSnapshotBounds(WORK_HOURS_WINDOW_WIDTH, WORK_HOURS_WINDOW_HEIGHT)
    : null;
  const final = attached?.final || {
    ...workHoursWindow.getBounds(),
    width: WORK_HOURS_WINDOW_WIDTH,
    height: WORK_HOURS_WINDOW_HEIGHT
  };
  workHoursWindow.setBounds(final, true);
  return { visible: true, expanded: false, bounds: final };
}

function showNotesWindowFromSnapshot() {
  if (!isOnboardingComplete()) {
    showPanelWindow();
    return { visible: false, blocked: 'onboarding' };
  }
  if (!notesWindow || notesWindow.isDestroyed()) {
    createNotesWindow();
  }
  cancelHiddenWindowDestroy('notes');
  if (!snapshotWindow || snapshotWindow.isDestroyed() || !snapshotWindow.isVisible()) {
    showSnapshotWindow();
  }

  keepSnapshotVisible = true;
  if (panelWindow && !panelWindow.isDestroyed()) {
    hideWindowForIdleDestroy('panel', panelWindow, WORK_WINDOW_IDLE_DESTROY_MS);
  }
  if (healthWindow && !healthWindow.isDestroyed()) {
    hideWindowForIdleDestroy('health', healthWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  if (workHoursWindow && !workHoursWindow.isDestroyed()) {
    hideWindowForIdleDestroy('work-hours', workHoursWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }

  const bounds = resolveAttachedSnapshotBounds();
  if (!bounds) {
    return;
  }

  notesWindow.setBounds(bounds.start);
  notesWindow.show();
  snapshotWindow.moveTop();
  notesWindow.moveTop();
  notesWindow.focus();
  animateWindowBounds(notesWindow, bounds.start, bounds.final);
  return { visible: true };
}

function showReportPanelFromSnapshot(mode = 'reports') {
  extendReadinessQuietWindow(10 * 1000);
  if (!isOnboardingComplete()) {
    showPanelWindow();
    return { visible: false, blocked: 'onboarding' };
  }
  if (!panelWindow || panelWindow.isDestroyed()) {
    createPanelWindow();
  }
  cancelHiddenWindowDestroy('panel');
  if (!snapshotWindow || snapshotWindow.isDestroyed() || !snapshotWindow.isVisible()) {
    showSnapshotWindow();
  }

  keepSnapshotVisible = true;
  pendingPanelMode = mode;
  if (healthWindow && !healthWindow.isDestroyed()) {
    hideWindowForIdleDestroy('health', healthWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  if (notesWindow && !notesWindow.isDestroyed()) {
    hideWindowForIdleDestroy('notes', notesWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  if (workHoursWindow && !workHoursWindow.isDestroyed()) {
    hideWindowForIdleDestroy('work-hours', workHoursWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  const bounds = resolveReportPanelBounds();

  if (panelWindow.isMinimized()) {
    panelWindow.restore();
  }

  panelWindow.setSkipTaskbar(false);
  panelWindow.setBounds(bounds.start);
  panelWindow.show();
  panelWindow.moveTop();
  snapshotWindow.moveTop();
  panelWindow.focus();
  panelWindow.webContents.send('panel:mode', pendingPanelMode);
  animateWindowBounds(panelWindow, bounds.start, bounds.final);
  return { visible: true };
}

function resolveExpandedPanelBounds() {
  const display = panelWindow && !panelWindow.isDestroyed()
    ? screen.getDisplayMatching(panelWindow.getBounds())
    : screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  const area = display.workArea;
  const width = Math.max(760, Math.round(area.width * 0.8));
  const height = Math.max(620, Math.round(area.height * 0.8));
  return {
    x: area.x + Math.round((area.width - width) / 2),
    y: area.y + Math.round((area.height - height) / 2),
    width,
    height
  };
}

function expandPanelWindow() {
  if (!panelWindow || panelWindow.isDestroyed()) {
    createPanelWindow();
  }
  cancelHiddenWindowDestroy('panel');

  panelNormalBounds = panelWindow.getBounds();
  const expandedBounds = resolveExpandedPanelBounds();
  panelWindow.setSkipTaskbar(false);
  panelWindow.show();
  panelWindow.focus();
  animateWindowBounds(panelWindow, panelWindow.getBounds(), expandedBounds, 180);
  return { expanded: true, bounds: expandedBounds };
}

function restorePanelWindow() {
  if (!panelWindow || panelWindow.isDestroyed()) {
    return { expanded: false };
  }

  const current = panelWindow.getBounds();
  const fallback = resolveReportPanelBounds().final;
  const target = panelNormalBounds || fallback;
  panelNormalBounds = null;
  animateWindowBounds(panelWindow, current, target, 180);
  return { expanded: false, bounds: target };
}

function showReportWindow(payload = {}) {
  if (!isOnboardingComplete()) {
    showPanelWindow();
    return { shown: false, blocked: 'onboarding' };
  }
  if (!reportWindow || reportWindow.isDestroyed()) {
    createReportWindow();
  }
  cancelHiddenWindowDestroy('report');
  keepSnapshotVisible = false;
  hideSnapshotWindow();
  if (panelWindow && !panelWindow.isDestroyed()) {
    hideWindowForIdleDestroy('panel', panelWindow, WORK_WINDOW_IDLE_DESTROY_MS);
  }
  if (healthWindow && !healthWindow.isDestroyed()) {
    hideWindowForIdleDestroy('health', healthWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  if (notesWindow && !notesWindow.isDestroyed()) {
    hideWindowForIdleDestroy('notes', notesWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
  const display = panelWindow && !panelWindow.isDestroyed()
    ? screen.getDisplayMatching(panelWindow.getBounds())
    : screen.getDisplayNearestPoint(screen.getCursorScreenPoint());
  const area = display?.workArea || { x: 0, y: 0, width: 1280, height: 720 };
  const width = Math.max(900, area.width - 40);
  const height = Math.max(620, area.height - 40);
  reportWindow.setBounds({
    x: area.x + Math.round((area.width - width) / 2),
    y: area.y + Math.round((area.height - height) / 2),
    width,
    height
  });
  reportWindow.setSkipTaskbar(false);
  reportWindow.show();
  reportWindow.moveTop();
  reportWindow.focus();
  const sendPayload = () => {
    if (reportWindow && !reportWindow.isDestroyed()) {
      reportWindow.webContents.send('report:render', payload);
    }
  };
  if (reportWindow.webContents.isLoading()) {
    reportWindow.webContents.once('did-finish-load', sendPayload);
  } else {
    sendPayload();
  }
  return { shown: true };
}

function hideReportWindow({ restoreContext = false } = {}) {
  if (reportWindow && !reportWindow.isDestroyed()) {
    hideWindowForIdleDestroy('report', reportWindow, WORK_WINDOW_IDLE_DESTROY_MS);
  }
  reportNormalBounds = null;
  if (restoreContext) {
    return showReportPanelFromSnapshot('reports');
  }
  return { hidden: true };
}

function expandReportWindow() {
  if (!reportWindow || reportWindow.isDestroyed()) {
    createReportWindow();
  }
  cancelHiddenWindowDestroy('report');
  reportNormalBounds = reportWindow.getBounds();
  const display = screen.getDisplayMatching(reportNormalBounds);
  const area = display.workArea;
  const expandedBounds = {
    x: area.x + 20,
    y: area.y + 20,
    width: Math.max(720, area.width - 40),
    height: Math.max(560, area.height - 40)
  };
  reportWindow.setSkipTaskbar(false);
  reportWindow.show();
  reportWindow.focus();
  animateWindowBounds(reportWindow, reportWindow.getBounds(), expandedBounds, 180);
  return { expanded: true, bounds: expandedBounds };
}

function restoreReportWindow() {
  if (!reportWindow || reportWindow.isDestroyed()) {
    return { expanded: false };
  }
  const current = reportWindow.getBounds();
  const target = reportNormalBounds || {
    ...current,
    width: REPORT_WINDOW_WIDTH,
    height: REPORT_WINDOW_HEIGHT
  };
  reportNormalBounds = null;
  animateWindowBounds(reportWindow, current, target, 180);
  return { expanded: false, bounds: target };
}

async function saveReportDoc(payload = {}) {
  const result = await dialog.showSaveDialog(reportWindow || panelWindow, {
    title: 'Save report as Word document',
    defaultPath: `${safeFileName(payload.title || 'Cognify Report')}.doc`,
    filters: [{ name: 'Word Document', extensions: ['doc'] }]
  });
  if (result.canceled || !result.filePath) {
    return { canceled: true };
  }
  const html = [
    '<!doctype html><html><head><meta charset="utf-8">',
    `<title>${escapeHtmlForDocument(payload.title || 'Cognify Report')}</title>`,
    '<style>body{font-family:Segoe UI,Arial,sans-serif;line-height:1.45;color:#111827} h1{font-size:24px} h2{font-size:16px;margin-top:22px}.meta{color:#4b5563}.item{margin:8px 0;padding:8px;border:1px solid #e5e7eb;border-radius:6px}.source{color:#6b7280;font-size:11px;text-transform:uppercase}</style>',
    '</head><body>',
    `<h1>${escapeHtmlForDocument(payload.title || 'Cognify Report')}</h1>`,
    `<div class="meta">${escapeHtmlForDocument(payload.subtitle || '')}</div>`,
    String(payload.html || ''),
    '</body></html>'
  ].join('');
  fs.writeFileSync(result.filePath, html, 'utf8');
  return { canceled: false, filePath: result.filePath };
}

async function saveReportPdf() {
  if (!reportWindow || reportWindow.isDestroyed()) {
    throw new Error('Report window is not open.');
  }
  const result = await dialog.showSaveDialog(reportWindow, {
    title: 'Save report as PDF',
    defaultPath: 'Cognify Report.pdf',
    filters: [{ name: 'PDF', extensions: ['pdf'] }]
  });
  if (result.canceled || !result.filePath) {
    return { canceled: true };
  }
  const data = await reportWindow.webContents.printToPDF({
    printBackground: true,
    pageSize: 'A4',
    margins: { marginType: 'default' }
  });
  fs.writeFileSync(result.filePath, data);
  return { canceled: false, filePath: result.filePath };
}

function safeFileName(value = '') {
  return String(value || 'Cognify Report').replace(/[<>:"/\\|?*\x00-\x1F]/g, '').trim().slice(0, 80) || 'Cognify Report';
}

function escapeHtmlForDocument(value = '') {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function nudgeKey(nudge = {}) {
  if (nudge.dedupe_key) {
    return String(nudge.dedupe_key);
  }
  return `${nudge.type || 'nudge'}:${nudge.message || nudge.title || ''}`;
}

function isNudgeDismissed(nudge) {
  const dismissedUntil = dismissedNudges.get(nudgeKey(nudge));
  const shownUntil = shownNudges.get(nudgeKey(nudge));
  const now = Date.now();
  return (dismissedUntil && dismissedUntil > now) || (shownUntil && shownUntil > now);
}

function dismissCurrentNudge(minutes = 45) {
  if (currentNudge) {
    dismissedNudges.set(nudgeKey(currentNudge), Date.now() + (Math.max(1, minutes) * 60 * 1000));
  }
  currentNudge = null;
  hideNudgeDetailsWindow();
  hideNudgeWindow();
}

function hideNudgeWindow() {
  if (nudgeHideTimer) {
    clearTimeout(nudgeHideTimer);
    nudgeHideTimer = null;
  }
  if (nudgeWindow && !nudgeWindow.isDestroyed()) {
    hideWindowForIdleDestroy('nudge', nudgeWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
}

function markRoleNudgePrompted(nudge) {
  if (nudge?.type !== 'role-classification' && nudge?.type !== 'role-setup') {
    return;
  }
  const nowIso = new Date().toISOString();
  const settings = services.settings.getSettings();
  const detection = settings.profile?.roleDetection || {};
  if (nudge.type === 'role-setup') {
    services.settings.updateRoleDetection({
      firstSetupPromptedAt: detection.firstSetupPromptedAt || nowIso,
      lastPromptedAt: nowIso,
      promptCount: Number(detection.promptCount || 0) + 1
    });
    return;
  }
  const update = {
    lastPromptedAt: nowIso,
    lastDetectedRoleId: nudge.role_classification?.role_id || detection.lastDetectedRoleId || '',
    lastDetectedRole: nudge.role_classification?.role_label || detection.lastDetectedRole || '',
    lastConfidence: Number(nudge.role_classification?.confidence || detection.lastConfidence || 0),
    lastClassification: nudge.role_classification || detection.lastClassification || null,
    promptCount: Number(detection.promptCount || 0) + 1
  };
  if (!detection.firstPromptedAt) {
    update.firstPromptedAt = nowIso;
  }
  if (nudge.role_prompt_reason === 'reclassification') {
    update.lastReclassificationPromptedAt = nowIso;
  }
  services.settings.updateRoleDetection(update);
  roleClassificationCache = null;
}

function hideNudgeDetailsWindow() {
  if (nudgeDetailWindow && !nudgeDetailWindow.isDestroyed()) {
    hideWindowForIdleDestroy('nudge-detail', nudgeDetailWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
  }
}

function manualInlineNudgeIsAwaitingUserAction(nextNudge = {}) {
  if (!currentNudge || !isInlineManualNudge(currentNudge)) {
    return false;
  }
  if (isInlineManualNudge(nextNudge) && nudgeKey(nextNudge) === nudgeKey(currentNudge)) {
    return false;
  }
  return Boolean(nudgeWindow && !nudgeWindow.isDestroyed() && nudgeWindow.isVisible());
}

function showNudgeWindow(nudge) {
  if (!nudge || isQuitting || services?.activity?.isPaused()) {
    return;
  }
  if (!isOnboardingComplete()) {
    traceStartup('nudge_show_blocked_until_onboarding_complete', {
      type: nudge.type || null
    });
    return;
  }
  if (manualInlineNudgeIsAwaitingUserAction(nudge)) {
    traceStartup('nudge_show_blocked_by_manual_inline', {
      blocked_type: nudge.type || null,
      active_type: currentNudge?.type || null,
      active_key: currentNudge ? nudgeKey(currentNudge) : null
    });
    return;
  }
  if (!nudgeWindow || nudgeWindow.isDestroyed()) {
    createNudgeWindow();
  }
  cancelHiddenWindowDestroy('nudge');

  const inlineManual = isInlineManualNudge(nudge);
  const bounds = resolveNudgeBounds(nudgeWindowHeight(nudge));
  if (!bounds) {
    return;
  }

  currentNudge = nudge;
  markRoleNudgePrompted(nudge);
  shownNudges.set(nudgeKey(nudge), Date.now() + (30 * 60 * 1000));
  if (typeof nudgeWindow.setFocusable === 'function') {
    nudgeWindow.setFocusable(inlineManual);
  }
  nudgeWindow.setBounds({
    x: bounds.x,
    y: bounds.y,
    width: bounds.width,
    height: bounds.height
  });
  nudgeWindow.webContents.send('nudge:update', { nudge, side: bounds.side });
  nudgeWindow.showInactive();
  nudgeWindow.moveTop();

  if (nudgeHideTimer) {
    clearTimeout(nudgeHideTimer);
  }
  if (inlineManual) {
    nudgeHideTimer = null;
    return;
  }
  nudgeHideTimer = setTimeout(() => {
    hideNudgeWindow();
  }, 11000);
}

async function showNudgeDetailsWindow() {
  if (!currentNudge || isQuitting) {
    return { visible: false };
  }
  if (!isOnboardingComplete()) {
    return { visible: false, blocked: 'onboarding' };
  }
  if (!nudgeDetailWindow || nudgeDetailWindow.isDestroyed()) {
    createNudgeDetailWindow();
  }
  cancelHiddenWindowDestroy('nudge-detail');

  const bounds = resolveNudgeDetailBounds();
  if (bounds) {
    nudgeDetailWindow.setBounds(bounds);
  }
  const details = await buildCurrentNudgeDetails(currentNudge);
  nudgeDetailWindow.webContents.send('nudge:detailsUpdate', details);
  nudgeDetailWindow.show();
  nudgeDetailWindow.moveTop();
  return { visible: true, details };
}

async function buildCurrentNudgeDetails(nudge = currentNudge) {
  return nudgeDetails().buildNudgeDetails(nudge, {
    nowMs: Date.now(),
    appStartedAtMs: new Date(appStartedAt).getTime(),
    queryActivityRange: (startIso, endIso) => services.activityStore.queryRange(startIso, endIso),
    getIdleSummary: () => idleSummaryWithManualConsumedSlots(),
    getTodayStats: () => buildTodayStats({ force: false, passive: true })
  });
}

function testNudgeForType(type) {
  const now = Date.now();
  if (type === 'context-switching') {
    const labels = ['github.com', 'Code', 'slack.com', 'jira.example.com', 'Teams', 'docs.example.com'];
    const segments = labels.map((label, index) => ({
      key: label.includes('.') ? `web:${label}` : `app:${label.toLowerCase()}`,
      label,
      startMs: now - ((labels.length - index) * 90 * 1000),
      endMs: now - (((labels.length - index) * 90) - 75) * 1000,
      durationMs: 75 * 1000
    }));
    return {
      type: 'context-switching',
      severity: 'attention',
      title: 'Context switching',
      message: 'Too much context switching detected.',
      footer: '11 meaningful switches in 15 minutes',
      metric: '11',
      target: 'reports',
      dedupe_key: `test-context-switching:${now}`,
      analysis: {
        window_minutes: 15,
        min_surface_seconds: 60,
        record_count: 18,
        raw_segment_count: 12,
        meaningful_segment_count: 12,
        unique_surface_count: 6,
        switches: 11,
        segments
      }
    };
  }

  if (type === 'idle') {
    return {
      type: 'idle',
      severity: 'attention',
      title: 'Idle Nudge',
      message: 'You have been idle for 24 minutes.',
      footer: 'Resume when ready',
      metric: '24m',
      target: 'snapshot',
      dedupe_key: `test-idle:${now}`
    };
  }

  if (type === 'health-tip') {
    return {
      type: 'work-hours-break',
      severity: 'insight',
      title: 'Work Hours Break',
      message: 'You have logged 1h 36m of Work Hours today. Consider stretching or a one minute walk.',
      footer: 'Based on Work Hours, not PC Available',
      metric: '1h 36m',
      target: 'work-hours',
      work_minutes: 96,
      dedupe_key: `test-health-tip:${now}`
    };
  }

  if (type === 'focus-drop') {
    return {
      type: 'focus-drop',
      severity: 'warning',
      title: 'Focus Check',
      message: '32 minutes of social or distraction time in the last hour.',
      footer: 'Open reports for the distraction summary',
      metric: '32m',
      target: 'reports',
      dedupe_key: `test-focus-drop:${now}`
    };
  }

  return {
    type: 'idle-return',
    severity: 'insight',
    title: 'Back From Idle',
    message: 'Were you working away from the PC during this idle slot?',
    footer: 'Add Manual Timing Block',
    metric: '42m',
    target: 'manual-block',
    manual_block: {
      startTime: new Date(now - (42 * 60 * 1000)).toISOString(),
      endTime: new Date(now).toISOString(),
      kind: 'work',
      locked: true,
      source: 'idle-return'
    },
    dedupe_key: `test-idle-return:${now}`
  };
}

function showTestNudge(type) {
  const nudge = testNudgeForType(type);
  showNudgeWindow(nudge);
  return nudge;
}

function showSetupCompleteNudge() {
  keepSnapshotVisible = false;
  hideSnapshotWindow();
  if (reportWindow && !reportWindow.isDestroyed()) {
    hideWindowForIdleDestroy('report', reportWindow, WORK_WINDOW_IDLE_DESTROY_MS);
  }
  if (panelWindow && !panelWindow.isDestroyed()) {
    hideWindowForIdleDestroy('panel', panelWindow, WORK_WINDOW_IDLE_DESTROY_MS);
  }
  ensureWidgetVisible({ focus: false });
  showNudgeWindow({
    type: 'setup-complete',
    severity: 'insight',
    title: 'Cognify Orb Ready',
    message: 'Setup is complete. Use the orb when you need reports or context.',
    footer: 'Click the orb anytime',
    metric: '',
    target: 'snapshot',
    dedupe_key: `setup-complete:${Date.now()}`
  });
}

function showPendingDailyProgressNudge() {
  if (pendingDailyProgressTimer) {
    clearTimeout(pendingDailyProgressTimer);
    pendingDailyProgressTimer = null;
  }
  if (!pendingDailyProgressNudge) {
    return;
  }
  const { nudge, sentAt } = pendingDailyProgressNudge;
  pendingDailyProgressNudge = null;
  const STALE_AFTER_MS = 8 * 60 * 60 * 1000;
  if (Date.now() - sentAt < STALE_AFTER_MS) {
    showNudgeWindow(nudge);
  }
}

function buildIdleReturnNudge(interval = {}) {
  const durationSeconds = Math.max(0, Number(interval.duration_seconds || 0));
  if (durationSeconds < (30 * 60)) {
    return null;
  }
  const minutes = Math.floor(durationSeconds / 60);
  if (minutes < 30) {
    return null;
  }

  return {
    type: 'idle-return',
    severity: 'insight',
    title: 'Back From Idle',
    message: `Were you working away from the PC during this ${nudgeDetails().formatNudgeMinutes(minutes)} idle slot?`,
    footer: 'Add Manual Timing Block',
    metric: nudgeDetails().formatNudgeMinutes(minutes),
    target: 'manual-block',
    manual_block: {
      startTime: interval.start,
      endTime: interval.end,
      kind: 'work',
      locked: true,
      source: 'idle-return'
    },
    dedupe_key: `idle-return:${interval.start}:${interval.end}`
  };
}

function showIdleReturnNudge(interval = {}) {
  const nudge = buildIdleReturnNudge(interval);
  if (!nudge) {
    return { shown: false, skipped: 'short_idle' };
  }

  // Payroll-critical: this lets users restore legitimate work/meeting time
  // from deducted idle, so it is intentionally not Low RAM gated.
  showNudgeWindow(nudge);
  return { shown: true, nudge };
}

function refreshTruthForClosedIdleInterval(interval = {}) {
  const startTime = interval.start;
  const endTime = interval.end;
  if (!startTime || !endTime) {
    return;
  }

  try {
    services.reportCache?.invalidateRange?.(startTime, endTime);
  } catch (error) {
    perfLog('idle_interval_report_cache_invalidate_failed', {
      error: error?.message || String(error)
    });
  }

  if (!services.liveTruth?.refreshStoredRange) {
    return;
  }

  services.liveTruth.refreshStoredRange(startTime, endTime, { source: 'system-idle-closed' })
    .catch((error) => {
      perfLog('idle_interval_live_truth_refresh_failed', {
        error: error?.message || String(error)
      });
    });
}

function handleIdleIntervalClosed(interval = {}) {
  if (!interval.suppress_nudge) {
    showIdleReturnNudge(interval);
  }
  refreshTruthForClosedIdleInterval(interval);

  // After the user settles back in from idle, surface the daily progress nudge
  // if one is pending (e.g. the 6am auto-send fired while they were away)
  if (pendingDailyProgressNudge) {
    if (pendingDailyProgressTimer) {
      clearTimeout(pendingDailyProgressTimer);
    }
    pendingDailyProgressTimer = setTimeout(showPendingDailyProgressNudge, 3 * 60 * 1000);
  }
}

async function getProductivityNudges({ includeExpensive = false } = {}) {
  const nudges = [];
  const idleSummary = services.systemIdle.getTodaySummary();
  if (idleSummary.active && idleSummary.active_since) {
    const idleMinutes = Math.floor((Date.now() - new Date(idleSummary.active_since).getTime()) / 60000);
    if (idleMinutes >= 20) {
      nudges.push({
        type: 'idle',
        severity: 'attention',
        title: 'Idle Nudge',
        message: `You have been idle for ${idleMinutes} minutes.`,
        footer: 'Resume when ready',
        metric: `${idleMinutes}m`,
        target: 'snapshot'
      });
    }
  }

  const workHoursTip = workHoursHealthTipNudge();
  if (workHoursTip) {
    nudges.push(workHoursTip);
  }

  const switchNudge = contextSwitchNudge();
  if (switchNudge) {
    nudges.push(switchNudge);
  }

  const roleNudge = roleClassificationNudge();
  if (roleNudge) {
    nudges.push(roleNudge);
  }

  if (includeExpensive) {
    const focusDrop = await focusDropNudge();
    if (focusDrop) {
      nudges.push(focusDrop);
    }

    const peak = await peakProductivityWindow();
    if (peak) {
      nudges.push({
        type: 'peak-productivity',
        severity: 'insight',
        title: 'Productivity',
        message: `Peak productivity: ${peak.label}.`,
        footer: 'Best deep-work window',
        metric: peak.label,
        target: 'reports',
        peak_window: peak
      });
    }
  }

  return {
    checked_at: new Date().toISOString(),
    nudges
  };
}

function firstFiniteNumber(...values) {
  for (const value of values) {
    if (value === null || value === undefined || value === '') {
      continue;
    }
    const number = Number(value);
    if (Number.isFinite(number)) {
      return number;
    }
  }
  return null;
}

function hasWorkHoursPcAvailableEvidence(summary = {}) {
  return Number.isFinite(Number(summary.gross_pc_available_minutes)) ||
    Number.isFinite(Number(summary.work_minutes_breakdown?.gross_pc_available_minutes)) ||
    Number(summary.runtime_available_minutes || 0) > 0;
}

function manualWorkMinutesForNudge(summary = {}) {
  const manual = summary.manual_timing_blocks || {};
  const value = firstFiniteNumber(
    summary.manual_net_added_work_minutes,
    Number(manual.net_added_minutes || manual.net_added_work_minutes || 0) +
      Number(manual.net_added_meeting_minutes || 0)
  );
  return Math.max(0, Math.round(value || 0));
}

function workMinutesForNudge(summary = {}) {
  if (!summary || typeof summary !== 'object') {
    return null;
  }

  if (hasWorkHoursPcAvailableEvidence(summary)) {
    const ledger = buildWorkHoursLedger({
      pcAvailableMinutes: safePcAvailableMinutesFromSummary(summary),
      idleMinutes: firstFiniteNumber(summary.idle_minutes, summary.input_idle_minutes) || 0,
      manualAddedMinutes: manualWorkMinutesForNudge(summary),
      rangeMinutes: firstFiniteNumber(summary.range_minutes)
    });
    return ledger.work_minutes;
  }

  const explicit = firstFiniteNumber(
    summary.work_minutes,
    summary.work_minutes_breakdown?.total_work_minutes
  );
  return explicit === null ? null : Math.max(0, Math.round(explicit));
}

function todayWorkMinutesForNudge() {
  const snapshot = currentCategorySnapshotFromLiveTruth('nudge-work-hours');
  return workMinutesForNudge(snapshot?.summary || {});
}

function workHoursHealthTipNudge() {
  const workMinutes = todayWorkMinutesForNudge();
  if (workMinutes === null) {
    return null;
  }
  if (workMinutes < 90) {
    return null;
  }

  const bucket = Math.floor(workMinutes / 60) * 60;
  const formattedWork = nudgeDetails().formatNudgeMinutes(workMinutes);
  return {
    type: 'work-hours-break',
    severity: 'insight',
    title: 'Work Hours Break',
    message: `You have logged ${formattedWork} of Work Hours today. Consider stretching or a one minute walk.`,
    footer: 'Based on Work Hours, not PC Available',
    metric: formattedWork,
    target: 'work-hours',
    work_minutes: workMinutes,
    dedupe_key: `work-hours-break:${new Date().toISOString().slice(0, 10)}:${bucket}`
  };
}

async function focusDropNudge() {
  const end = new Date();
  const start = new Date(end.getTime() - (60 * 60 * 1000));
  const todayStats = await buildTodayStats({ force: false, passive: true });
  const socialMinutes = Math.round(nudgeDetails().classifiedMinutesFromSummaryItems(
    todayStats?.summary?.app_timeline || [],
    start.getTime(),
    end.getTime()
  ).social || 0);
  if (socialMinutes < 20) {
    return null;
  }

  return {
    type: 'focus-drop',
    severity: socialMinutes >= 35 ? 'warning' : 'attention',
    title: 'Focus Check',
    message: `${socialMinutes} minutes of social or distraction time in the last hour.`,
    footer: 'Open reports for the distraction summary',
    metric: nudgeDetails().formatNudgeMinutes(socialMinutes),
    target: 'reports',
    dedupe_key: `focus-drop:${new Date().toISOString().slice(0, 13)}`
  };
}

function contextSwitchNudge() {
  const end = new Date();
  const start = new Date(end.getTime() - (15 * 60 * 1000));
  const records = queryActivityRangeLite(start.toISOString(), end.toISOString());
  return nudgeAnalysis().contextSwitchNudgeFromRecords(records, {
    startMs: start.getTime(),
    endMs: end.getTime()
  });
}

function currentCategorySnapshotFromLiveTruth(source = 'live-truth') {
  const state = services?.liveTruth?.getTodayState?.();
  if (!state) {
    return null;
  }
  return {
    summary: state.summary || {},
    cache: state.cache || { pending: true, complete: false },
    sync: null,
    context_count: Number(state.summary?.activity_events || 0),
    source
  };
}

function cacheRoleClassificationNudge(value) {
  roleClassificationCache = { createdAtMs: Date.now(), value };
  return value;
}

function shouldRunRoleClassificationNow() {
  if (!services?.systemIdle?.getTodaySummary) {
    return false;
  }
  try {
    return Boolean(services.systemIdle.getTodaySummary().active);
  } catch {
    return false;
  }
}

function roleClassificationNudge() {
  const settings = services.settings.getSettings();
  const profile = settings.profile || {};
  const detection = profile.roleDetection || {};
  const nowMs = Date.now();
  if (roleClassificationCache && (nowMs - roleClassificationCache.createdAtMs) < ROLE_CLASSIFICATION_CACHE_MS) {
    return roleClassificationCache.value;
  }
  if (!shouldRunRoleClassificationNow()) {
    return null;
  }

  const firstObservedAt = detection.firstObservedAt || new Date(nowMs).toISOString();
  if (!detection.firstObservedAt) {
    services.settings.updateRoleDetection({ firstObservedAt });
  }

  const setupNudge = firstStartRoleSetupNudge(profile, detection, firstObservedAt, nowMs);
  if (setupNudge) {
    return cacheRoleClassificationNudge(setupNudge);
  }

  const start = new Date(nowMs - ROLE_DETECTION_WINDOW_MS);
  const end = new Date(nowMs);
  const records = services.activityStore.queryRange(start.toISOString(), end.toISOString());
  const classification = roleClassification().classifyRoleFromRecords(records, { nowMs });
  const lastClassifiedMs = Date.parse(detection.lastClassifiedAt || '');
  const shouldPersistDetection = (
    !Number.isFinite(lastClassifiedMs) ||
    (nowMs - lastClassifiedMs) >= ROLE_CLASSIFICATION_CACHE_MS ||
    detection.lastDetectedRoleId !== classification.role_id ||
    Number(detection.lastConfidence || 0) !== Number(classification.confidence || 0)
  );
  if (shouldPersistDetection) {
    services.settings.updateRoleDetection({
      lastDetectedRoleId: classification.role_id,
      lastDetectedRole: classification.role_label,
      lastConfidence: classification.confidence,
      lastClassification: classification,
      lastClassifiedAt: new Date(nowMs).toISOString()
    });
  }

  if (!classification.enough_data) {
    return cacheRoleClassificationNudge(null);
  }

  const firstObservedMs = new Date(firstObservedAt).getTime();
  const inFirstWeek = Number.isFinite(firstObservedMs) && (nowMs - firstObservedMs) <= ROLE_ONBOARDING_WINDOW_MS;
  const confirmedRoleId = profile.roleId || '';
  if (!confirmedRoleId) {
    if (
      inFirstWeek &&
      !detection.firstPromptedAt &&
      classification.confidence >= ROLE_FIRST_PROMPT_CONFIDENCE
    ) {
      return cacheRoleClassificationNudge(rolePromptNudge(classification, 'first-week'));
    }
    return cacheRoleClassificationNudge(null);
  }

  const confidenceForConfirmedRole = roleClassification().confirmedRoleConfidence(classification, confirmedRoleId);
  const lastRePromptMs = new Date(detection.lastReclassificationPromptedAt || 0).getTime();
  const cooldownElapsed = !Number.isFinite(lastRePromptMs) || (nowMs - lastRePromptMs) >= ROLE_RECLASSIFY_COOLDOWN_MS;
  if (
    confidenceForConfirmedRole < ROLE_RECLASSIFY_CONFIDENCE &&
    classification.confidence >= ROLE_RECLASSIFY_CONFIDENCE &&
    classification.role_id !== confirmedRoleId &&
    cooldownElapsed
  ) {
    return cacheRoleClassificationNudge(rolePromptNudge(classification, 'reclassification', confidenceForConfirmedRole));
  }

  return cacheRoleClassificationNudge(null);
}

function firstStartRoleSetupNudge(profile = {}, detection = {}, firstObservedAt = '', nowMs = Date.now()) {
  const firstObservedMs = new Date(firstObservedAt || 0).getTime();
  const inFirstWeek = Number.isFinite(firstObservedMs) && (nowMs - firstObservedMs) <= ROLE_ONBOARDING_WINDOW_MS;
  const hasRole = Boolean(String(profile.roleId || profile.role || '').trim());
  const hasContext = Boolean(String(profile.roleNotes || '').trim());
  if (!inFirstWeek || detection.firstSetupPromptedAt || (hasRole && hasContext)) {
    return null;
  }
  return {
    type: 'role-setup',
    severity: 'insight',
    title: 'Add role context',
    message: 'Add your role and weekly context so Cognify can make HOD drafts more accurate.',
    footer: 'One-time setup prompt',
    metric: 'Setup',
    target: 'profile',
    role_prompt_reason: 'first-start-setup',
    dedupe_key: `role-setup:${new Date().toISOString().slice(0, 10)}`
  };
}

function rolePromptNudge(classification, reason, confirmedConfidence = null) {
  const evidence = (classification.evidence || [])
    .slice(0, 2)
    .map((item) => item.label)
    .filter(Boolean)
    .join(', ');
  const message = reason === 'reclassification'
    ? `Your activity now looks more like ${classification.role_label}. Review your role profile?`
    : `Your activity looks like ${classification.role_label}. Confirm your role profile?`;
  const footerParts = [
    `${classification.confidence}% confidence`,
    evidence ? `based on ${evidence}` : ''
  ].filter(Boolean);
  return {
    type: 'role-classification',
    severity: 'insight',
    title: 'Role Profile',
    message,
    footer: footerParts.join(' • '),
    metric: `${classification.confidence}%`,
    target: 'profile',
    role_prompt_reason: reason,
    role_confirmed_confidence: confirmedConfidence,
    role_classification: classification,
    dedupe_key: `role-classification:${reason}:${classification.role_id}:${new Date().toISOString().slice(0, 10)}`
  };
}

async function peakProductivityWindow() {
  if (peakProductivityCache && (Date.now() - peakProductivityCache.createdAtMs) < (30 * 60 * 1000)) {
    return peakProductivityCache.value;
  }

  const trend = await hourlyFocusTrend(7);
  if (!trend.length) {
    peakProductivityCache = { createdAtMs: Date.now(), value: null };
    return null;
  }

  let best = null;
  for (let startHour = 0; startHour <= 21; startHour += 1) {
    const windowRows = trend.filter((row) => row.hour >= startHour && row.hour < startHour + 3);
    const deepWorkMinutes = windowRows.reduce((sum, row) => sum + row.deep_work_minutes, 0);
    const activeMinutes = windowRows.reduce((sum, row) => sum + row.total_active_minutes, 0);
    if (activeMinutes < 45 || deepWorkMinutes < 20) {
      continue;
    }
    const score = deepWorkMinutes / activeMinutes;
    if (!best || score > best.score || (score === best.score && deepWorkMinutes > best.deep_work_minutes)) {
      best = {
        start_hour: startHour,
        end_hour: startHour + 3,
        score,
        deep_work_minutes: Math.round(deepWorkMinutes),
        total_active_minutes: Math.round(activeMinutes)
      };
    }
  }

  if (!best) {
    peakProductivityCache = { createdAtMs: Date.now(), value: null };
    return null;
  }

  const value = {
    ...best,
    label: `${hourLabel(best.start_hour)} - ${hourLabel(best.end_hour)}`
  };
  peakProductivityCache = { createdAtMs: Date.now(), value };
  return value;
}

async function hourlyFocusTrend(days = 7) {
  const safeDays = Math.min(Math.max(1, Math.round(Number(days) || 7)), 7);
  const buckets = new Map();

  for (let offset = -(safeDays - 1); offset <= 0; offset += 1) {
    const summary = await measurePerf(`hourlyFocusTrend.day.${offset}`, async () => {
      const bounds = dayBoundsForOffset(offset);
      const report = await measurePerf(`hourlyFocusTrend.day.${offset}.cache`, () => (
        services.reportCache.dailyReport({
          startTime: bounds.startTime,
          endTime: bounds.endTime,
          sync: false,
          includeTasks: false,
          staleOk: true
        })
      ), { slowMs: 500 });
      return report.summary || {};
    }, { slowMs: 1000 });

    (summary.app_timeline || []).forEach((group) => {
      (group.items || []).forEach((item) => {
        const timestamp = new Date(item.timestamp);
        if (Number.isNaN(timestamp.getTime())) {
          return;
        }
        const hour = timestamp.getHours();
        if (!buckets.has(hour)) {
          buckets.set(hour, { hour, deep_work_minutes: 0, total_active_minutes: 0 });
        }
        const bucket = buckets.get(hour);
        bucket.deep_work_minutes += Math.round(Number(item.classified_ms?.work || 0) / 60000);
        bucket.total_active_minutes += Math.round(Number(item.duration_ms_estimate || 0) / 60000);
      });
    });
  }

  return Array.from(buckets.values());
}

function hourLabel(hour) {
  const normalized = ((hour % 24) + 24) % 24;
  const suffix = normalized >= 12 ? 'PM' : 'AM';
  const hour12 = normalized % 12 || 12;
  return `${hour12} ${suffix}`;
}

function manualDeductedIdleIntervals(startTime, endTime) {
  const startMs = new Date(startTime).getTime();
  const endMs = new Date(endTime).getTime();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
    return [];
  }
  const rawIdle = normalizeIntervalsForManualImpact(
    services.systemIdle?.getIntervalsInRange?.(startTime, endTime) || [],
    startMs,
    endMs
  );
  const passiveWork = normalizeIntervalsForManualImpact(
    services.focusEvents?.getPassiveWorkIntervals?.(startTime, endTime, { classifier: services.classifier }) || [],
    startMs,
    endMs
  );
  return subtractManualImpactIntervals(rawIdle, passiveWork);
}

function manualRecordsInRange(startTime, endTime) {
  try {
    return (services.activityStore?.queryRange?.(startTime, endTime) || [])
      .filter((record) => isManualTimingRecord(record));
  } catch (error) {
    perfLog('manual_records_query_failed', { error: error?.message || String(error) });
    return [];
  }
}

function idleSummaryWithManualConsumedSlots() {
  const summary = services.systemIdle.getTodaySummary();
  const bounds = dayBoundsForOffset(0);
  const manualRecords = manualRecordsInRange(bounds.startTime, bounds.endTime);
  return {
    ...summary,
    manual_consumed_slots: manualConsumedSlots(manualRecords)
  };
}

function normalizeIntervalsForManualImpact(intervals = [], startMs, endMs) {
  return intervals
    .map((interval) => {
      const intervalStartMs = Number.isFinite(Number(interval.startMs))
        ? Number(interval.startMs)
        : new Date(interval.start || interval.start_time || 0).getTime();
      const intervalEndMs = Number.isFinite(Number(interval.endMs))
        ? Number(interval.endMs)
        : new Date(interval.end || interval.end_time || 0).getTime();
      return {
        startMs: Math.max(startMs, intervalStartMs),
        endMs: Math.min(endMs, intervalEndMs)
      };
    })
    .filter((interval) => Number.isFinite(interval.startMs) && Number.isFinite(interval.endMs) && interval.endMs > interval.startMs)
    .sort((left, right) => left.startMs - right.startMs);
}

function subtractManualImpactIntervals(baseIntervals = [], subtractIntervals = []) {
  if (!subtractIntervals.length) {
    return baseIntervals;
  }
  const result = [];
  baseIntervals.forEach((base) => {
    let segments = [{ startMs: base.startMs, endMs: base.endMs }];
    subtractIntervals.forEach((subtract) => {
      segments = segments.flatMap((segment) => {
        if (subtract.endMs <= segment.startMs || subtract.startMs >= segment.endMs) {
          return [segment];
        }
        const pieces = [];
        if (subtract.startMs > segment.startMs) {
          pieces.push({ startMs: segment.startMs, endMs: subtract.startMs });
        }
        if (subtract.endMs < segment.endMs) {
          pieces.push({ startMs: subtract.endMs, endMs: segment.endMs });
        }
        return pieces;
      });
    });
    result.push(...segments.filter((segment) => segment.endMs > segment.startMs));
  });
  return result;
}

async function addManualActivityBlock(payload = {}) {
  const idleIntervals = payload.startTime && payload.endTime
    ? manualDeductedIdleIntervals(payload.startTime, payload.endTime)
    : [];
  const prepared = prepareManualActivityBlock(payload, {
    now: new Date(),
    idleIntervals
  });
  const existingManualRecords = manualRecordsInRange(prepared.block.start_time, prepared.block.end_time);
  if (manualSlotAlreadyConsumed(existingManualRecords, prepared.block.start_time, prepared.block.end_time)) {
    throw new Error('This idle block already has a manual entry. Choose another idle block.');
  }
  const preparedRecords = Array.isArray(prepared.records) && prepared.records.length
    ? prepared.records
    : [prepared.record].filter(Boolean);
  const result = services.activityStore.ingest(preparedRecords);
  const response = manualActivitySaveResponse({
    result,
    block: prepared.block,
    impact: prepared.impact
  });

  services.reportCache?.invalidateRange(prepared.block.start_time, prepared.block.end_time);
  todayStatsCache = null;
  todayCategorySnapshotCache = null;
  activitySummaryCache = null;
  focusTrendCache = null;
  peakProductivityCache = null;
  roleClassificationCache = null;
  let liveTruthRefresh = null;
  if (services.liveTruth?.refreshStoredRange) {
    try {
      liveTruthRefresh = await services.liveTruth.refreshStoredRange(
        prepared.block.start_time,
        prepared.block.end_time,
        { source: 'manual-activity' }
      );
    } catch (error) {
      liveTruthRefresh = { ok: false, error: error?.message || String(error) };
      perfLog('manual_activity_live_truth_refresh_failed', liveTruthRefresh);
    }
  }
  scheduleReadinessWarm('manual-activity');
  return {
    ...response,
    live_truth_refresh: liveTruthRefresh
  };
}

async function maybeShowProductivityNudge({ force = false } = {}) {
  try {
    const result = await getProductivityNudges({ includeExpensive: force });
    const candidate = (result.nudges || [])
      .filter((nudge) => force || !isNudgeDismissed(nudge))
      .sort((left, right) => nudgePriority(right) - nudgePriority(left))[0];
    if (candidate) {
      showNudgeWindow(candidate);
    }
    return result;
  } catch (error) {
    traceStartup('nudge_check_failed', { error: error.message });
    return { checked_at: new Date().toISOString(), nudges: [], error: error.message };
  }
}

function nudgePriority(nudge = {}) {
  const severityScore = {
    warning: 3,
    attention: 2,
    insight: 1
  };
  const typeScore = {
    idle: 4,
    'idle-return': 5,
    'focus-drop': 4,
    'health-tip': 2,
    'work-hours-break': 2,
    'context-switching': 3,
    'role-classification': 1,
    'peak-productivity': 1,
    'daily-progress-updated': 1
  };
  return (severityScore[nudge.severity] || 0) * 10 + (typeScore[nudge.type] || 0);
}

function startNudgeMonitor() {
  if (nudgeTimer) {
    return;
  }
  if (isLowRamMode()) {
    traceStartup('nudge_monitor_skipped_low_ram', { low_ram: lowRamModeInfo() });
    return;
  }

  const runNudgeMonitor = () => {
    measurePerf('timer.nudgeMonitor', () => maybeShowProductivityNudge(), { slowMs: 1000 }).catch((error) => {
      traceStartup('nudge_monitor_failed', { error: error.message });
    });
  };

  nudgeTimer = setTimeout(() => {
    measurePerf('timer.nudgeInitial', () => maybeShowProductivityNudge(), { slowMs: 1000, always: true }).catch((error) => {
      traceStartup('nudge_initial_failed', { error: error.message });
    });
    nudgeTimer = setInterval(() => {
      runNudgeMonitor();
    }, NUDGE_MONITOR_INTERVAL_MS);
  }, NUDGE_START_DELAY_MS);
  traceStartup('nudge_monitor_delayed', { delay_ms: NUDGE_START_DELAY_MS });
}

function startMeetingAudioMonitor() {
  if (meetingAudioTimer) {
    return;
  }

  const check = async () => {
    if (meetingAudioCheckInFlight) {
      return;
    }
    meetingAudioCheckInFlight = true;
    try {
      if (!services) {
        return;
      }
      const settings = services.settings.getSettings();
      if (captureAudioMode(settings) !== 'meeting') {
        if (meetingAudioActive) {
          meetingAudioActive = false;
          await ensureScreenpipeRunning({ force: true, source: 'meeting-audio-off' });
        }
        return;
      }

      const end = new Date();
      const start = new Date(end.getTime() - (10 * 60 * 1000));
      const records = queryActivityRangeLite(start.toISOString(), end.toISOString());
      const meetingDetected = records.some(isMeetingLikeRecord);
      if (meetingDetected) {
        meetingAudioLastSeenAt = Date.now();
      }

      if (meetingDetected && !meetingAudioActive) {
        meetingAudioActive = true;
        traceStartup('meeting_audio_enabled', { source: 'meeting-monitor' });
        await ensureScreenpipeRunning({ force: true, source: 'meeting-audio-on' });
        return;
      }

      if (meetingAudioActive && (Date.now() - meetingAudioLastSeenAt) > MEETING_AUDIO_IDLE_MS) {
        meetingAudioActive = false;
        traceStartup('meeting_audio_disabled', { source: 'meeting-monitor' });
        await ensureScreenpipeRunning({ force: true, source: 'meeting-audio-idle' });
      }
    } finally {
      meetingAudioCheckInFlight = false;
    }
  };

  meetingAudioTimer = setInterval(() => {
    check().catch((error) => traceStartup('meeting_audio_monitor_failed', { error: error?.message || String(error) }));
  }, MEETING_AUDIO_CHECK_MS);
  check().catch((error) => traceStartup('meeting_audio_monitor_failed', { error: error?.message || String(error) }));
}

function startScreenpipeMemoryGuard() {
  if (screenpipeMemoryTimer) {
    return;
  }

  const scheduleNext = (delayMs = SCREENPIPE_MEMORY_CHECK_MS) => {
    if (isQuitting) {
      return;
    }
    if (screenpipeMemoryTimer) {
      clearTimeout(screenpipeMemoryTimer);
    }
    screenpipeMemoryTimer = setTimeout(() => {
      check().catch((error) => traceStartup('screenpipe_memory_guard_failed', { error: error?.message || String(error) }));
    }, Math.max(60 * 1000, delayMs));
  };

  const check = async () => {
    if (screenpipeMemoryCheckInFlight) {
      scheduleNext(SCREENPIPE_MEMORY_PRESSURE_CHECK_MS);
      return;
    }
    screenpipeMemoryCheckInFlight = true;
    let nextDelayMs = SCREENPIPE_MEMORY_HEALTHY_CHECK_MS;
    try {
      if (!services) {
        return;
      }
      const memory = await sampleScreenpipeProcessMemory();
      const checkedAtMs = Date.now();
      const cpuPercent = screenpipeCpuPercent(screenpipeMemoryState, memory, checkedAtMs);
      const highCpuSamples = Number.isFinite(cpuPercent) && cpuPercent >= SCREENPIPE_CPU_WARN_PERCENT
        ? Number(screenpipeMemoryState.highCpuSamples || 0) + 1
        : 0;
      screenpipeMemoryState = {
        ...screenpipeMemoryState,
        ...memory,
        checkedAt: new Date(checkedAtMs).toISOString(),
        cpuPercent,
        highCpuSamples
      };
      const pressureBytes = screenpipeMemoryPressureBytes(memory);
      const cpuPressure = Number.isFinite(cpuPercent) && cpuPercent >= SCREENPIPE_CPU_WARN_PERCENT;
      if (!Number.isFinite(cpuPercent) && Number.isFinite(Number(memory.cpuSeconds)) && memory.pid) {
        nextDelayMs = SCREENPIPE_CPU_BASELINE_CHECK_MS;
      }
      if (cpuPressure) {
        nextDelayMs = SCREENPIPE_MEMORY_PRESSURE_CHECK_MS;
        traceStartup('screenpipe_cpu_high', {
          cpu_percent: cpuPercent,
          high_cpu_samples: highCpuSamples,
          pid: memory.pid
        });
      }
      if (highCpuSamples >= 2 && Number.isFinite(cpuPercent) && cpuPercent >= SCREENPIPE_CPU_AUDIO_DISABLE_PERCENT) {
        const settings = services.settings.getSettings();
        if (isAudioActiveForSettings(settings)) {
          meetingAudioActive = false;
          services.settings.updateCapture({ audioMode: 'off', listeningEnabled: false });
          diagnosticsCache = null;
          traceStartup('screenpipe_cpu_disabled_audio', {
            cpu_percent: cpuPercent,
            high_cpu_samples: highCpuSamples
          });
          await ensureScreenpipeRunning({ force: true, source: 'cpu-guard-disable-audio' });
          return;
        }
      }
      if (highCpuSamples >= 2 && Number.isFinite(cpuPercent) && cpuPercent >= SCREENPIPE_CPU_RESTART_PERCENT && canRestartScreenpipeForCpu(checkedAtMs)) {
        screenpipeMemoryState.cpuRestarts.push(checkedAtMs);
        diagnosticsCache = null;
        traceStartup('screenpipe_cpu_restart', {
          cpu_percent: cpuPercent,
          high_cpu_samples: highCpuSamples,
          pid: memory.pid
        });
        await ensureScreenpipeRunning({ force: true, source: 'cpu-guard-restart' });
        return;
      }
      const staleFrames = screenpipeStaleFrameDiagnostics();
      screenpipeMemoryState.staleFrames = staleFrames;
      if (staleFrames.stale && canRestartScreenpipeForStaleFrames(checkedAtMs)) {
        screenpipeMemoryState.staleFrameRestarts.push(checkedAtMs);
        diagnosticsCache = null;
        traceStartup('screenpipe_stale_frame_restart', staleFrames);
        await ensureScreenpipeRunning({ force: true, source: 'stale-frame-guard-restart' });
        return;
      }
      if ((!pressureBytes || pressureBytes < SCREENPIPE_MEMORY_WARN_BYTES) && !cpuPressure) {
        return;
      }
      if (!pressureBytes || pressureBytes < SCREENPIPE_MEMORY_WARN_BYTES) {
        return;
      }
      nextDelayMs = SCREENPIPE_MEMORY_PRESSURE_CHECK_MS;

      traceStartup('screenpipe_memory_high', {
        private_bytes: memory.privateBytes,
        working_set_bytes: memory.workingSetBytes,
        pressure_bytes: pressureBytes,
        pid: memory.pid
      });
      if (pressureBytes < SCREENPIPE_MEMORY_RESTART_BYTES) {
        const settings = services.settings.getSettings();
        if (isAudioActiveForSettings(settings) && !(settings.capture?.audioDeviceNames || []).length) {
          const updatedSettings = await hydrateDefaultAudioDevices(settings);
          if ((updatedSettings.capture?.audioDeviceNames || []).length) {
            traceStartup('screenpipe_memory_hydrated_audio_devices', {
              pressure_bytes: pressureBytes,
              audio_devices: updatedSettings.capture.audioDeviceNames
            });
            await ensureScreenpipeRunning({ force: true, source: 'memory-guard-audio-devices' });
          }
        }
        return;
      }

      const now = Date.now();
      screenpipeMemoryState.restarts = (screenpipeMemoryState.restarts || [])
        .filter((timestamp) => now - timestamp < (30 * 60 * 1000));
      screenpipeMemoryState.restarts.push(now);
      const settings = services.settings.getSettings();
      if (isAudioActiveForSettings(settings) && screenpipeMemoryState.restarts.length >= 2) {
        meetingAudioActive = false;
        services.settings.updateCapture({ audioMode: 'off', listeningEnabled: false });
        diagnosticsCache = null;
        traceStartup('screenpipe_memory_disabled_audio', { pressure_bytes: pressureBytes });
        await ensureScreenpipeRunning({ force: true, source: 'memory-guard-disable-audio' });
        return;
      }

      await ensureScreenpipeRunning({ force: true, source: 'memory-guard-restart' });
    } finally {
      screenpipeMemoryCheckInFlight = false;
      scheduleNext(nextDelayMs);
    }
  };

  scheduleNext(2 * 60 * 1000);
}

function scheduleReadinessWarm(source = 'requested') {
  if (isLowRamMode() && !/\b(manual|force|user)\b/i.test(String(source || ''))) {
    traceStartup('readiness_warm_skipped_low_ram', { source, low_ram: lowRamModeInfo() });
    return;
  }
  const dueAtMs = Math.max(Date.now() + 1000, readinessWarmAllowedAtMs);
  readinessWarmSource = source;
  if (readinessWarmTimer) {
    if (dueAtMs <= readinessWarmDueAtMs) {
      return;
    }
    clearTimeout(readinessWarmTimer);
  }
  readinessWarmRequested = true;
  readinessWarmDueAtMs = dueAtMs;
  readinessWarmTimer = setTimeout(() => {
    const warmSource = readinessWarmSource || source;
    readinessWarmRequested = false;
    readinessWarmTimer = null;
    readinessWarmDueAtMs = 0;
    readinessWarmSource = null;
    if (reportCacheWarmInFlight) {
      scheduleReadinessWarm(`${warmSource}-deferred`);
      return;
    }
    warmReadiness({ source: warmSource }).catch((error) => {
      perfLog('readiness_warm_failed', { source: warmSource, error: error?.message || String(error) });
    });
  }, Math.max(0, dueAtMs - Date.now()));
}

function extendReadinessQuietWindow(delayMs) {
  readinessWarmAllowedAtMs = Math.max(readinessWarmAllowedAtMs, Date.now() + delayMs);
  if (readinessWarmTimer && readinessWarmDueAtMs < readinessWarmAllowedAtMs) {
    scheduleReadinessWarm(readinessWarmSource || 'interaction-deferred');
  }
}

function isUserFacingWindowVisible() {
  return [snapshotWindow, panelWindow, healthWindow, notesWindow, workHoursWindow, nudgeWindow, nudgeDetailWindow]
    .some((windowRef) => windowRef && !windowRef.isDestroyed() && windowRef.isVisible());
}

function isLiveTruthRepairBlockedByWindow() {
  return [setupWindow, panelWindow, reportWindow]
    .some((windowRef) => windowRef && !windowRef.isDestroyed() && windowRef.isVisible());
}

async function warmReadiness({ source = 'timer' } = {}) {
  if (isLowRamMode() && !/\b(manual|force|user)\b/i.test(String(source || ''))) {
    return { skipped: true, reason: 'low_ram_mode' };
  }
  if (reportCacheWarmInFlight) {
    return { skipped: true, reason: 'in_flight' };
  }
  if (isUserFacingWindowVisible() && !String(source || '').includes('manual')) {
    readinessWarmAllowedAtMs = Math.max(readinessWarmAllowedAtMs, Date.now() + (2 * 60 * 1000));
    scheduleReadinessWarm(`${source}-visible-deferred`);
    return { skipped: true, reason: 'user_window_visible' };
  }
  reportCacheWarmInFlight = true;
  const startedAt = Date.now();
  try {
    if (!services?.liveTruth) {
      return { skipped: true, reason: 'services_unavailable' };
    }
    const bounds = dayBoundsForOffset(0);
    const current = currentCategorySnapshotFromLiveTruth('readiness-live-truth');
    const currentSnapshot = {
      summary: current?.summary || {},
      cache: current?.cache || {},
      sync: current?.sync || null,
      context_count: current?.context_count || 0,
      source: current?.source || 'readiness-live-truth'
    };
    if (isCompleteCategorySnapshot(currentSnapshot)) {
      todayCategorySnapshotCache = {
        cacheKey: bounds.date,
        createdAtMs: Date.now(),
        value: currentSnapshot
      };
    }
    traceStartup('readiness_warmed', {
      source,
      date: bounds.date,
      duration_ms: Date.now() - startedAt,
      current_built_hours: 0,
      category_hours: currentSnapshot.cache?.hour_count || 0,
      category_complete: Boolean(currentSnapshot.cache?.complete)
    });
    return { ok: true };
  } finally {
    reportCacheWarmInFlight = false;
  }
}

function startReportCacheWarmer() {
  if (reportCacheWarmTimer) {
    return;
  }

  reportCacheWarmTimer = setInterval(() => {
    warmReadiness({ source: 'timer' }).catch((error) => perfLog('report_cache_warm_failed', { error: error?.message || String(error) }));
  }, REPORT_CACHE_WARM_INTERVAL_MS);
  const cacheWarmJitter = Math.floor(Math.random() * 60000) - 30000; // ±30s
  setTimeout(() => {
    scheduleReadinessWarm('startup-delay');
  }, Math.max(0, REPORT_CACHE_WARM_DELAY_MS + cacheWarmJitter));
}

function startReportCacheWarmerOnce(source = 'requested') {
  if (reportCacheWarmStartRequested) {
    return;
  }
  if (isLowRamMode() && !/\b(manual|force|user)\b/i.test(String(source || ''))) {
    reportCacheWarmStartRequested = true;
    traceStartup('report_cache_warmer_skipped_low_ram', { source, low_ram: lowRamModeInfo() });
    return;
  }
  reportCacheWarmStartRequested = true;
  traceStartup('report_cache_warmer_starting', { source });
  startReportCacheWarmer();
}

function showDailyProgressUpdatedNudge(result = {}) {
  if (!result?.sent || !result.logdate) {
    return;
  }
  const nudge = {
    type: 'daily-progress-updated',
    severity: 'insight',
    title: 'Daily Progress Updated',
    message: `Your Daily Progress updated of ${result.logdate}`,
    footer: 'Yesterday summary sent',
    metric: result.logdate,
    target: 'reports',
    dedupe_key: `daily-progress-updated:${result.dateKey || result.logdate}`
  };
  showNudgeWindow(nudge);
  // Keep pending so the panel-open path can resurface it if the user missed
  // the immediate 11-second popup (e.g. send fired at 6am while they were away)
  pendingDailyProgressNudge = { nudge, sentAt: Date.now() };
}

function scheduleDailyLogSendAfterPrepare(source = 'prepare') {
  if (dailyLogPreparedSendTimer || isQuitting) {
    return;
  }
  dailyLogPreparedSendTimer = setTimeout(() => {
    dailyLogPreparedSendTimer = null;
    runDailyLogSend(`${source}-ready-send`);
  }, DAILY_LOG_SEND_AFTER_PREPARE_DELAY_MS);
  dailyLogPreparedSendTimer.unref?.();
  traceStartup('daily_log_send_after_prepare_scheduled', {
    source,
    delay_ms: DAILY_LOG_SEND_AFTER_PREPARE_DELAY_MS
  });
}

async function runDailyLogSend(source = 'timer') {
  if (isQuitting || dailyLogInFlight || !services?.dailyLog) {
    return { sent: false, skipped: 'not_ready' };
  }
  dailyLogInFlight = true;
  try {
    const prepareResult = typeof services.dailyLog.preparePendingReports === 'function'
      ? await services.dailyLog.preparePendingReports({ source: `${source}-prepare` })
      : null;
    if (prepareResult?.prepared || prepareResult?.failedCount) {
      traceStartup('daily_log_prepare_completed', {
        source,
        prepared_count: prepareResult.preparedCount || 0,
        failed_count: prepareResult.failedCount || 0,
        skipped_count: prepareResult.skippedCount || 0
      });
    }
    if (Number(prepareResult?.preparedCount || 0) > 0) {
      scheduleDailyLogSendAfterPrepare(source);
      return {
        sent: false,
        skipped: 'prepared_waiting_for_send',
        preparedCount: prepareResult.preparedCount || 0,
        failedCount: prepareResult.failedCount || 0,
        results: prepareResult.results || []
      };
    }
    const sender = typeof services.dailyLog.sendPendingIfDue === 'function'
      ? services.dailyLog.sendPendingIfDue.bind(services.dailyLog)
      : services.dailyLog.sendYesterdayIfDue.bind(services.dailyLog);
    const result = await sender({ source });
    if (result?.sent) {
      traceStartup('daily_log_sent', {
        source,
        dateKey: result.dateKey || null,
        logdate: result.logdate || null,
        sent_count: result.sentCount || 1,
        failed_count: result.failedCount || 0
      });
      showDailyProgressUpdatedNudge(result);
    } else if (result?.failed) {
      traceStartup('daily_log_failed', {
        source,
        dateKey: result.dateKey || null,
        logdate: result.logdate || null,
        error: result.error || null,
        nextAttemptAfter: result.nextAttemptAfter || null
      });
    } else {
      traceStartup('daily_log_skipped', {
        source,
        skipped: result?.skipped || 'unknown',
        dateKey: result?.dateKey || null,
        logdate: result?.logdate || null
      });
    }
    return result;
  } catch (error) {
    traceStartup('daily_log_unhandled_failed', { source, error: error?.message || String(error) });
    return { sent: false, failed: true, error: error?.message || String(error) };
  } finally {
    dailyLogInFlight = false;
  }
}

function startDailyLogSender() {
  if (dailyLogTimer || dailyLogStartupTimer) {
    return;
  }
  dailyLogStartupTimer = setTimeout(() => {
    dailyLogStartupTimer = null;
    runDailyLogSend('startup-morning');
  }, DAILY_LOG_STARTUP_DELAY_MS);
  dailyLogTimer = setInterval(() => {
    runDailyLogSend('morning-timer');
  }, DAILY_LOG_CHECK_INTERVAL_MS);
  traceStartup('daily_log_sender_scheduled', {
    startup_delay_ms: DAILY_LOG_STARTUP_DELAY_MS,
    interval_ms: DAILY_LOG_CHECK_INTERVAL_MS
  });
}

function runSilentUpdateCheck(source = 'timer') {
  if (isQuitting || !isOnboardingComplete()) {
    traceStartup('silent_update_check_skipped', { source, reason: isQuitting ? 'quitting' : 'onboarding' });
    return;
  }
  getUpdate({ apply: true, silent: true })
    .then((state) => {
      traceStartup('silent_update_check_completed', {
        source,
        status: state?.status || null,
        local_version: state?.local_version || null,
        remote_version: state?.remote_version || null
      });
    })
    .catch((error) => {
      traceStartup('silent_update_check_failed', { source, error: error.message });
    });
}

function startUpdateChecker() {
  if (updateCheckTimer) {
    return;
  }
  setTimeout(() => runSilentUpdateCheck('startup'), 15000);
  updateCheckTimer = setInterval(() => runSilentUpdateCheck('interval'), UPDATE_CHECK_INTERVAL_MS);
  updateCheckTimer.unref?.();
  traceStartup('silent_update_checker_scheduled', {
    startup_delay_ms: 15000,
    interval_ms: UPDATE_CHECK_INTERVAL_MS
  });
}

function freeSystemMemoryBytes() {
  try {
    const info = process.getSystemMemoryInfo?.();
    if (info && Number.isFinite(Number(info.free))) {
      return Number(info.free) * 1024;
    }
  } catch {
    // Memory info is advisory only.
  }
  try {
    const freeBytes = os.freemem();
    return Number.isFinite(freeBytes) ? freeBytes : null;
  } catch {
    return null;
  }
}

function liveTruthWorkGate({ repair = false, source = 'timer' } = {}) {
  if (isQuitting) {
    return { ok: false, reason: 'quitting' };
  }
  if (!services?.liveTruth) {
    return { ok: false, reason: 'service-unavailable' };
  }
  if (!isOnboardingComplete()) {
    return { ok: false, reason: 'onboarding' };
  }
  if (heavyReportInFlight || reportCacheBackfillInFlight) {
    return { ok: false, reason: 'busy-report-work' };
  }
  if (repair && isLiveTruthRepairBlockedByWindow()) {
    return { ok: false, reason: 'heavy-window-visible' };
  }
  if (isLowRamMode()) {
    if (repair && !/\b(manual|force|user|snapshot)\b/i.test(String(source || ''))) {
      return { ok: false, reason: 'low-ram-repair-deferred' };
    }
    if (!/\b(manual|force|user|snapshot)\b/i.test(String(source || ''))) {
      const lowRamGate = lowRamBackgroundGate({ source });
      if (!lowRamGate.ok) {
        return { ok: false, reason: lowRamGate.reason || 'low_ram_mode', freeBytes: lowRamGate.freeBytes };
      }
    }
  }
  const freeBytes = freeSystemMemoryBytes();
  if (freeBytes !== null && freeBytes < LIVE_TRUTH_MIN_FREE_MEMORY_BYTES) {
    return { ok: false, reason: 'low-memory', freeBytes };
  }
  return { ok: true };
}

async function refreshLiveTruthCurrent(source = 'timer', options = {}) {
  const gate = liveTruthWorkGate({ repair: false, source });
  if (!gate.ok) {
    traceStartup('live_truth_current_skipped', { source, reason: gate.reason, freeBytes: gate.freeBytes || null });
    return { skipped: true, reason: gate.reason };
  }
  const startedAt = Date.now();
  try {
    const result = await services.liveTruth.refreshCurrent({
      source,
      force: Boolean(options.force)
    });
    if (result?.ok) {
      todayCategorySnapshotCache = null;
    }
    traceStartup('live_truth_current_refreshed', {
      source,
      duration_ms: Date.now() - startedAt,
      skipped: Boolean(result?.skipped),
      reason: result?.reason || null,
      hour: result?.hour || null,
      current_status: result?.state?.cache?.current_status || null,
      pending_hours: result?.state?.cache?.pending_hours?.length || 0,
      gap_hours: result?.state?.cache?.gap_hours?.length || 0
    });
    return result;
  } catch (error) {
    traceStartup('live_truth_current_failed', { source, error: error?.message || String(error) });
    return { failed: true, error: error?.message || String(error) };
  }
}

async function repairLiveTruthClosedHour(source = 'timer') {
  const gate = liveTruthWorkGate({ repair: true, source });
  if (!gate.ok) {
    traceStartup('live_truth_repair_skipped', { source, reason: gate.reason, freeBytes: gate.freeBytes || null });
    return { skipped: true, reason: gate.reason };
  }
  const startedAt = Date.now();
  try {
    const result = await services.liveTruth.verifyNextClosedHour({ source });
    if (result?.ok) {
      todayCategorySnapshotCache = null;
    }
    traceStartup('live_truth_repair_completed', {
      source,
      duration_ms: Date.now() - startedAt,
      skipped: Boolean(result?.skipped),
      reason: result?.reason || null,
      hour: result?.hour || null,
      status: result?.status || null,
      pending_hours: result?.state?.cache?.pending_hours?.length || 0,
      gap_hours: result?.state?.cache?.gap_hours?.length || 0
    });
    return result;
  } catch (error) {
    traceStartup('live_truth_repair_failed', { source, error: error?.message || String(error) });
    return { failed: true, error: error?.message || String(error) };
  }
}

function startLiveTruthMonitor() {
  if (liveTruthCurrentTimer || liveTruthRepairTimer) {
    return;
  }
  const lowRam = isLowRamMode();
  const currentStartupDelayMs = lowRam ? LOW_RAM_LIVE_TRUTH_CURRENT_STARTUP_DELAY_MS : LIVE_TRUTH_CURRENT_STARTUP_DELAY_MS;
  const currentIntervalMs = lowRam ? LOW_RAM_LIVE_TRUTH_CURRENT_INTERVAL_MS : LIVE_TRUTH_CURRENT_INTERVAL_MS;
  const jitter = () => Math.floor(Math.random() * 60000) - 30000; // ±30s
  liveTruthCurrentStartupTimer = setTimeout(() => {
    liveTruthCurrentStartupTimer = null;
    refreshLiveTruthCurrent('startup-current');
  }, Math.max(0, currentStartupDelayMs + jitter()));
  if (!lowRam) {
    liveTruthRepairStartupTimer = setTimeout(() => {
      liveTruthRepairStartupTimer = null;
      repairLiveTruthClosedHour('startup-repair');
    }, Math.max(0, LIVE_TRUTH_REPAIR_STARTUP_DELAY_MS + jitter()));
  }
  liveTruthCurrentTimer = setInterval(() => {
    refreshLiveTruthCurrent('interval-current');
  }, currentIntervalMs);
  if (!lowRam) {
    liveTruthRepairTimer = setInterval(() => {
      repairLiveTruthClosedHour('interval-repair');
    }, LIVE_TRUTH_REPAIR_INTERVAL_MS);
  }
  liveTruthCurrentTimer.unref?.();
  liveTruthRepairTimer?.unref?.();
  liveTruthCurrentStartupTimer.unref?.();
  liveTruthRepairStartupTimer?.unref?.();
  traceStartup('live_truth_monitor_started', {
    low_ram: lowRam,
    current_interval_ms: currentIntervalMs,
    repair_interval_ms: lowRam ? 0 : LIVE_TRUTH_REPAIR_INTERVAL_MS,
    current_startup_delay_ms: currentStartupDelayMs,
    repair_startup_delay_ms: lowRam ? 0 : LIVE_TRUTH_REPAIR_STARTUP_DELAY_MS
  });
}

function precreateSnapshotWindow() {
  if (!isOnboardingComplete()) {
    return;
  }
  if (!snapshotWindow || snapshotWindow.isDestroyed()) {
    createSnapshotWindow();
    traceStartup('snapshot_precreated');
  }
}

function startRuntimeServices(reason = 'runtime') {
  if (!services || !isOnboardingComplete()) {
    traceStartup('runtime_services_blocked_until_onboarding_complete', { reason });
    return;
  }

  if (!runtimeAvailabilityStarted) {
    try {
      const result = services.runtimeAvailability?.start?.();
      runtimeAvailabilityStarted = Boolean(result?.started || result?.already_running);
      traceStartup('runtime_availability_started', { reason, ...(result || { started: false }) });
    } catch (error) {
      traceStartup('runtime_availability_start_failed', { reason, error: error?.message || String(error) });
    }
  }

  if (!systemIdleStarted) {
    try {
      services.systemIdle.start();
      systemIdleStarted = true;
      traceStartup('system_idle_started', { reason });
    } catch (error) {
      traceStartup('system_idle_start_failed', { reason, error: error?.message || String(error) });
    }
  }

  if (!windowsFocusStarted && !windowsFocusStartTimer) {
    try {
      windowsFocusStartTimer = setTimeout(() => {
        windowsFocusStartTimer = null;
        if (windowsFocusStarted || !services?.windowsFocus || !isOnboardingComplete()) {
          return;
        }
        try {
          const focusStart = services.windowsFocus.start();
          windowsFocusStarted = Boolean(focusStart?.started || services.windowsFocus?.process);
          traceStartup('windows_focus_started', { reason, delayed: true, ...(focusStart || { started: false }) });
        } catch (error) {
          traceStartup('windows_focus_start_failed', { reason, delayed: true, error: error?.message || String(error) });
        }
      }, WINDOWS_FOCUS_START_DELAY_MS);
      windowsFocusStartTimer.unref?.();
      traceStartup('windows_focus_start_delayed', { reason, delay_ms: WINDOWS_FOCUS_START_DELAY_MS });
    } catch (error) {
      traceStartup('windows_focus_start_failed', { reason, error: error?.message || String(error) });
    }
  }

  startWindowsFocusWatchdog(reason);
}

function startWindowsFocusWatchdog(reason = 'runtime') {
  if (windowsFocusWatchdogTimer || !services?.windowsFocus || !isOnboardingComplete()) {
    return;
  }
  windowsFocusWatchdogTimer = setInterval(() => {
    if (!services?.windowsFocus || !isOnboardingComplete()) {
      return;
    }
    try {
      const result = services.windowsFocus.ensureFresh({
        staleAfterMs: WINDOWS_FOCUS_STALE_AFTER_MS,
        startupGraceMs: WINDOWS_FOCUS_STARTUP_GRACE_MS
      });
      if (result?.action && result.action !== 'none') {
        windowsFocusStarted = Boolean(result.ok || services.windowsFocus?.process);
        diagnosticsCache = null;
        traceStartup('windows_focus_watchdog_action', { reason, ...result });
      }
    } catch (error) {
      traceStartup('windows_focus_watchdog_failed', { reason, error: error?.message || String(error) });
    }
    try {
      const result = services.systemIdle?.ensureFresh?.();
      if (result?.action && result.action !== 'none') {
        diagnosticsCache = null;
        traceStartup('system_idle_watchdog_action', { reason, ...result });
      }
    } catch (error) {
      traceStartup('system_idle_watchdog_failed', { reason, error: error?.message || String(error) });
    }
  }, WINDOWS_FOCUS_WATCHDOG_INTERVAL_MS);
  windowsFocusWatchdogTimer.unref?.();
  traceStartup('windows_focus_watchdog_started', {
    reason,
    interval_ms: WINDOWS_FOCUS_WATCHDOG_INTERVAL_MS,
    stale_after_ms: WINDOWS_FOCUS_STALE_AFTER_MS
  });
}

function closeSetupWindowAfterComplete() {
  if (!setupWindow || setupWindow.isDestroyed()) {
    return;
  }
  allowSetupWindowClose = true;
  setupWindow.destroy();
}

function enterRuntimeMode(reason = 'runtime') {
  if (!services) {
    return { started: false, reason: 'services-not-ready' };
  }
  if (!isOnboardingComplete()) {
    enterSetupMode(`${reason}-blocked`);
    return { started: false, blocked: 'onboarding' };
  }

  const firstStart = !runtimeModeStarted;
  runtimeModeStarted = true;
  traceStartup(firstStart ? 'runtime_mode_entered' : 'runtime_mode_refreshed', { reason });
  closeSetupWindowAfterComplete();
  startRuntimeServices(reason);

  if (!widgetWindow || widgetWindow.isDestroyed()) {
    createWidgetWindow();
    traceStartup('widget_created', { reason });
  } else {
    ensureWidgetVisible({ focus: false });
  }

  if (!tray) {
    createTray();
    traceStartup('tray_created', { reason });
  }
  rebuildTrayMenu();
  startStartupBackgroundWork();
  return { started: true };
}

function enterSetupMode(reason = 'setup') {
  if (!services) {
    return { started: false, reason: 'services-not-ready' };
  }
  traceStartup('onboarding_mode_entered', { reason });
  if (!tray) {
    createTray();
    traceStartup('tray_created', { reason: 'setup' });
  }
  rebuildTrayMenu();
  return showSetupWindow(reason);
}

function startStartupBackgroundWork() {
  if (startupBackgroundStarted) {
    return;
  }
  if (!isOnboardingComplete()) {
    traceStartup('startup_background_blocked_until_onboarding_complete');
    return;
  }
  startupBackgroundStarted = true;
  traceStartup('startup_background_started');
  readinessWarmAllowedAtMs = Date.now() + (5 * 60 * 1000);

  setTimeout(() => {
    try {
      services.retention.enforce();
      traceStartup('retention_enforced');
    } catch (error) {
      traceStartup('retention_failed', { error: error?.message || String(error) });
    }
  }, 60 * 1000);

  setTimeout(() => {
    maybeImportSqliteActivityStore();
  }, 90 * 1000);

  setTimeout(() => {
    const forceForVersionChange = shouldForceScreenpipeRestartForAppVersion();
    const source = forceForVersionChange ? 'startup-version-change' : 'startup';
    ensureScreenpipeRunning({ source, force: forceForVersionChange })
      .then((result) => {
        if (result?.ok) {
          markScreenpipeRuntimeVersion(source);
        }
        return result;
      })
      .then(() => disableListeningAfterAudioStartFailure('startup-audio-fallback'))
      .finally(() => {
        readinessWarmAllowedAtMs = Math.min(readinessWarmAllowedAtMs || Infinity, Date.now() + (2 * 60 * 1000));
        setTimeout(() => startReportCacheWarmerOnce('screenpipe-supervision-settled'), 2 * 60 * 1000);
      })
      .catch((error) => {
        traceStartup('screenpipe_startup_supervision_failed', { error: error.message });
      });
  }, 2 * 60 * 1000);

  setTimeout(() => {
    startReportCacheWarmerOnce('startup-fallback');
  }, 10 * 60 * 1000);

  startLiveTruthMonitor();
  startDailyLogSender();

  setTimeout(() => {
    startNudgeMonitor();
    startMeetingAudioMonitor();
    startScreenpipeMemoryGuard();
    startScreenpipeFfmpegPriorityGovernor();
  }, 2 * 60 * 1000);

  startUpdateChecker();
}

function scheduleScreenpipeRestartAfterUserReturn(reason, inactiveMs) {
  if (!services || isQuitting || inactiveMs < SCREENPIPE_UNLOCK_RESTART_MIN_LOCK_MS) {
    return;
  }
  const now = Date.now();
  if (now - screenpipeLastUnlockRestartAtMs < SCREENPIPE_UNLOCK_RESTART_COOLDOWN_MS) {
    traceStartup('screenpipe_unlock_restart_skipped_cooldown', {
      reason,
      inactive_ms: inactiveMs,
      cooldown_ms: SCREENPIPE_UNLOCK_RESTART_COOLDOWN_MS
    });
    return;
  }
  screenpipeLastUnlockRestartAtMs = now;
  if (screenpipeUnlockRestartTimer) {
    clearTimeout(screenpipeUnlockRestartTimer);
  }
  traceStartup('screenpipe_unlock_restart_scheduled', {
    reason,
    inactive_ms: inactiveMs,
    delay_ms: SCREENPIPE_UNLOCK_RESTART_DELAY_MS
  });
  screenpipeUnlockRestartTimer = setTimeout(() => {
    screenpipeUnlockRestartTimer = null;
    ensureScreenpipeRunning({ force: true, source: `user-return-${reason}` })
      .then((result) => {
        if (result?.ok) {
          markScreenpipeRuntimeVersion(`user-return-${reason}`);
        }
      })
      .catch((error) => {
        traceStartup('screenpipe_unlock_restart_failed', { reason, error: error?.message || String(error) });
      });
  }, SCREENPIPE_UNLOCK_RESTART_DELAY_MS);
  screenpipeUnlockRestartTimer.unref?.();
}

function registerPowerIdleEvents() {
  if (!powerMonitor || registerPowerIdleEvents.registered) {
    return;
  }
  registerPowerIdleEvents.registered = true;
  powerMonitor.on('lock-screen', () => {
    screenLockStartedAtMs = Date.now();
    const result = services?.systemIdle?.markTelemetryUnavailable?.('screen_locked', new Date());
    traceStartup('power_idle_start', { reason: 'screen_locked', telemetry_unavailable: Boolean(result?.marked) });
  });
  powerMonitor.on('unlock-screen', () => {
    const inactiveMs = screenLockStartedAtMs ? Date.now() - screenLockStartedAtMs : 0;
    screenLockStartedAtMs = null;
    const result = services?.systemIdle?.markTelemetryAvailable?.('screen_unlocked', new Date());
    services?.systemIdle?.ensureFresh?.();
    traceStartup('power_idle_end', { reason: 'screen_locked', telemetry_available: Boolean(result?.marked), inactive_ms: inactiveMs });
    scheduleScreenpipeRestartAfterUserReturn('screen-unlock', inactiveMs);
  });
  powerMonitor.on('suspend', () => {
    screenSuspendStartedAtMs = Date.now();
    const result = services?.systemIdle?.markTelemetryUnavailable?.('system_suspend', new Date());
    traceStartup('power_idle_start', { reason: 'system_suspend', telemetry_unavailable: Boolean(result?.marked) });
  });
  powerMonitor.on('resume', () => {
    const inactiveMs = screenSuspendStartedAtMs ? Date.now() - screenSuspendStartedAtMs : 0;
    screenSuspendStartedAtMs = null;
    const result = services?.systemIdle?.markTelemetryAvailable?.('system_resume', new Date());
    services?.systemIdle?.ensureFresh?.();
    traceStartup('power_idle_end', { reason: 'system_suspend', telemetry_available: Boolean(result?.marked), inactive_ms: inactiveMs });
    scheduleScreenpipeRestartAfterUserReturn('resume', inactiveMs);
  });
}

function createTray() {
  if (tray) {
    return;
  }
  tray = new Tray(getCognifyIcon());
  tray.setToolTip('Cognify');
  tray.on('click', () => {
    if (!isOnboardingComplete()) {
      showSetupWindow('tray-click');
      return;
    }
    showReportPanelFromSnapshot('reports');
  });
}

async function rebuildTrayMenu() {
  if (!tray || !services) {
    return;
  }

  if (!isOnboardingComplete()) {
    const setupMenu = Menu.buildFromTemplate([
      {
        label: 'Complete Setup',
        click: () => showSetupWindow('tray-menu')
      },
      {
        label: 'Open Data Folder',
        click: () => shell.openPath(app.getPath('userData'))
      },
      { type: 'separator' },
      {
        label: 'Exit',
        click: () => quitApp()
      }
    ]);
    tray.setContextMenu(setupMenu);
    return;
  }

  const status = await services.screenpipe.getStatus();
  const paused = services.activity.isPaused();
  const recordingLabel = !status.running ? 'Capture Offline' : (paused ? 'Resume Capture' : 'Pause Capture');

  const menu = Menu.buildFromTemplate([
    {
      label: 'Open Cognify',
      click: () => {
        ensureWidgetVisible({ focus: false });
        showReportPanelFromSnapshot('reports');
      }
    },
    {
      label: 'Add/Edit Role',
      click: () => {
        ensureWidgetVisible({ focus: false });
        showReportPanelFromSnapshot('role');
      }
    },
    {
      label: recordingLabel,
      click: async () => {
        if (!status.running) {
          return;
        }

        if (paused) {
          await services.activity.resumeCapture();
        } else {
          await services.activity.pauseCapture();
        }

        await rebuildTrayMenu();
      }
    },
    {
      label: 'Reset Orb Position',
      click: () => {
        resetWidgetPosition();
      }
    },
    {
      label: 'Restart Cognify',
      click: () => {
        relaunchApp();
      }
    },
    { type: 'separator' },
    {
      label: 'Connection Settings File',
      click: () => shell.openPath(path.join(app.getPath('userData'), 'settings.json'))
    },
    {
      label: 'Copy Diagnostics',
      click: async () => {
        const capabilities = await services.screenpipe.getCapabilities();
        clipboard.writeText(JSON.stringify({ status, paused, capabilities }, null, 2));
      }
    },
    {
      label: 'Open Debug Log',
      click: () => shell.openPath(debugLogPath)
    },
    {
      label: 'Open Data Folder',
      click: () => shell.openPath(app.getPath('userData'))
    },
    { type: 'separator' },
    {
      label: 'Exit',
      click: () => quitApp()
    }
  ]);

  tray.setContextMenu(menu);
}

function quitApp() {
  if (isQuitting) {
    return;
  }

  isQuitting = true;
  if (exitRequestTimer) {
    clearInterval(exitRequestTimer);
    exitRequestTimer = null;
  }
  traceStartup('screenpipe_owned_processes_stop_requested', { reason: 'quit', includeLegacyDefault: true });
  stopScreenpipeProcesses(services?.settings?.getSettings?.() || {}, { includeLegacyDefault: true, reason: 'quit' });
  stopInstanceHeartbeat();
  removeExitRequest();
  if (typeof app.releaseSingleInstanceLock === 'function') {
    app.releaseSingleInstanceLock();
  }
  cleanupKnownProfileLocks();
  if (tray) {
    tray.destroy();
    tray = null;
  }

  if (setupWindow && !setupWindow.isDestroyed()) {
    setupWindow.destroy();
  }

  if (panelWindow && !panelWindow.isDestroyed()) {
    panelWindow.destroy();
  }

  if (healthWindow && !healthWindow.isDestroyed()) {
    healthWindow.destroy();
  }

  if (notesWindow && !notesWindow.isDestroyed()) {
    notesWindow.destroy();
  }

  if (workHoursWindow && !workHoursWindow.isDestroyed()) {
    workHoursWindow.destroy();
  }

  if (nudgeWindow && !nudgeWindow.isDestroyed()) {
    nudgeWindow.destroy();
  }
  if (nudgeDetailWindow && !nudgeDetailWindow.isDestroyed()) {
    nudgeDetailWindow.destroy();
  }

  if (snapshotWindow && !snapshotWindow.isDestroyed()) {
    snapshotWindow.destroy();
  }

  if (widgetWindow && !widgetWindow.isDestroyed()) {
    widgetWindow.destroy();
  }

  if (services?.systemIdle) {
    services.systemIdle.stop();
  }
  if (services?.runtimeAvailability) {
    services.runtimeAvailability.stop();
    runtimeAvailabilityStarted = false;
  }
  if (windowsFocusStartTimer) {
    clearTimeout(windowsFocusStartTimer);
    windowsFocusStartTimer = null;
  }
  if (windowsFocusWatchdogTimer) {
    clearInterval(windowsFocusWatchdogTimer);
    windowsFocusWatchdogTimer = null;
  }
  if (screenpipeUnlockRestartTimer) {
    clearTimeout(screenpipeUnlockRestartTimer);
    screenpipeUnlockRestartTimer = null;
  }
  if (ffmpegPriorityTimer) {
    clearTimeout(ffmpegPriorityTimer);
    ffmpegPriorityTimer = null;
  }
  if (sqliteImportRetryTimer) {
    clearTimeout(sqliteImportRetryTimer);
    sqliteImportRetryTimer = null;
  }
  if (services?.windowsFocus) {
    services.windowsFocus.stop();
  }
  if (services?.focusEvents) {
    services.focusEvents.close();
  }
  if (services?.sqliteActivityStore) {
    services.sqliteActivityStore.close();
  }
  if (nudgeTimer) {
    clearInterval(nudgeTimer);
    nudgeTimer = null;
  }
  if (pendingDailyProgressTimer) {
    clearTimeout(pendingDailyProgressTimer);
    pendingDailyProgressTimer = null;
  }
  if (nudgeHideTimer) {
    clearTimeout(nudgeHideTimer);
    nudgeHideTimer = null;
  }
  if (meetingAudioTimer) {
    clearInterval(meetingAudioTimer);
    meetingAudioTimer = null;
  }
  if (screenpipeMemoryTimer) {
    clearTimeout(screenpipeMemoryTimer);
    screenpipeMemoryTimer = null;
  }
  if (reportCacheWarmTimer) {
    clearInterval(reportCacheWarmTimer);
    reportCacheWarmTimer = null;
  }
  if (reportCacheBackfillTimer) {
    clearTimeout(reportCacheBackfillTimer);
    reportCacheBackfillTimer = null;
  }
  if (dailyLogStartupTimer) {
    clearTimeout(dailyLogStartupTimer);
    dailyLogStartupTimer = null;
  }
  if (dailyLogPreparedSendTimer) {
    clearTimeout(dailyLogPreparedSendTimer);
    dailyLogPreparedSendTimer = null;
  }
  if (dailyLogTimer) {
    clearInterval(dailyLogTimer);
    dailyLogTimer = null;
  }
  if (updateCheckTimer) {
    clearInterval(updateCheckTimer);
    updateCheckTimer = null;
  }
  if (liveTruthCurrentStartupTimer) {
    clearTimeout(liveTruthCurrentStartupTimer);
    liveTruthCurrentStartupTimer = null;
  }
  if (liveTruthRepairStartupTimer) {
    clearTimeout(liveTruthRepairStartupTimer);
    liveTruthRepairStartupTimer = null;
  }
  if (liveTruthCurrentTimer) {
    clearInterval(liveTruthCurrentTimer);
    liveTruthCurrentTimer = null;
  }
  if (liveTruthRepairTimer) {
    clearInterval(liveTruthRepairTimer);
    liveTruthRepairTimer = null;
  }

  setTimeout(() => app.exit(0), 1500);
  app.quit();
}

function relaunchApp() {
  if (isQuitting) {
    return;
  }

  isRelaunching = true;
  traceStartup('relaunch_requested');
  app.relaunch();
  quitApp();
}

function resetWidgetPosition() {
  if (!widgetWindow || widgetWindow.isDestroyed()) {
    return;
  }

  const nextBounds = defaultWidgetBounds();
  widgetWindow.setBounds(nextBounds);
  persistWidgetBounds();
  ensureWidgetVisible({ focus: false });
  traceStartup('widget_reset', { bounds: nextBounds });
}

function cleanupKnownProfileLocks() {
  const lockCandidates = [
    path.join(app.getPath('userData'), 'Local Storage', 'leveldb', 'LOCK'),
    path.join(app.getPath('userData'), 'Session Storage', 'LOCK')
  ];

  lockCandidates.forEach((lockPath) => {
    try {
      if (fs.existsSync(lockPath)) {
        fs.unlinkSync(lockPath);
        traceStartup('profile_lock_removed', { lockPath });
      }
    } catch (error) {
      traceStartup('profile_lock_remove_failed', { lockPath, error: error.message });
    }
  });
}

function migrateLegacyUserData() {
  const currentRoot = app.getPath('userData');
  const legacyRoot = path.join(app.getPath('appData'), 'screenpipe-companion-mvp');
  if (!fs.existsSync(legacyRoot) || path.resolve(legacyRoot) === path.resolve(currentRoot)) {
    return;
  }

  try {
    const currentSettingsPath = path.join(currentRoot, 'settings.json');
    const legacySettingsPath = path.join(legacyRoot, 'settings.json');
    if (fs.existsSync(currentSettingsPath) && fs.existsSync(legacySettingsPath)) {
      const currentSettings = JSON.parse(fs.readFileSync(currentSettingsPath, 'utf8'));
      const legacySettings = JSON.parse(fs.readFileSync(legacySettingsPath, 'utf8'));
      const currentProfile = currentSettings.profile || {};
      const legacyProfile = legacySettings.profile || {};
      if ((!currentProfile.name && legacyProfile.name) || (!currentProfile.email && legacyProfile.email)) {
        currentSettings.profile = {
          name: currentProfile.name || legacyProfile.name || '',
          email: currentProfile.email || legacyProfile.email || ''
        };
        fs.writeFileSync(currentSettingsPath, JSON.stringify(currentSettings, null, 2), 'utf8');
        traceStartup('legacy_profile_migrated', { legacyRoot });
      }
    }
  } catch (error) {
    traceStartup('legacy_profile_migration_failed', { error: error?.message || String(error) });
  }

  try {
    const currentNotesPath = path.join(currentRoot, 'notes.json');
    const legacyNotesPath = path.join(legacyRoot, 'notes.json');
    if (fs.existsSync(legacyNotesPath) && !fs.existsSync(currentNotesPath)) {
      fs.copyFileSync(legacyNotesPath, currentNotesPath);
      traceStartup('legacy_notes_migrated', { legacyRoot });
    }
  } catch (error) {
    traceStartup('legacy_notes_migration_failed', { error: error?.message || String(error) });
  }
}

function dayBoundsForOffset(offsetDays = 0) {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() + offsetDays);
  const end = new Date(start);
  end.setDate(end.getDate() + 1);
  const now = new Date();
  return {
    date: localDateKey(start),
    startTime: start.toISOString(),
    endTime: (end > now ? now : end).toISOString()
  };
}

function workSummaryBoundsForPreset(preset = 'today') {
  const normalized = preset === 'yesterday' ? 'yesterday' : 'today';
  const bounds = dayBoundsForOffset(normalized === 'yesterday' ? -1 : 0);
  return {
    ...bounds,
    preset: normalized,
    label: normalized === 'today' ? `Today: ${bounds.date}` : `Yesterday: ${bounds.date}`
  };
}

async function buildWorkSummaryReport(payload = {}) {
  const bounds = workSummaryBoundsForPreset(payload.preset || payload.datePreset || 'today');
  const [query, canonicalResult] = await Promise.all([
    services.activity.getRangeData(bounds.startTime, bounds.endTime, {
      sync: false
    }),
    canonicalDailySummariesForRangeWithCoverage(bounds.startTime, bounds.endTime, {
      source: 'work-summary',
      staleOk: false,
      maxDays: 2
    })
  ]);
  const idleIntervals = services.systemIdle.getIntervalsInRange(bounds.startTime, bounds.endTime);
  const focusIntervals = getFocusIntervalsInRange(bounds.startTime, bounds.endTime);
  const canonicalSummary = mergeCanonicalSummaries(
    canonicalResult.summaries,
    bounds.startTime,
    bounds.endTime,
    canonicalResult.coverage
  );
  const targetActivityMinutes = firstFiniteNumber(
    canonicalSummary?.estimated_active_minutes,
    canonicalSummary?.active_minutes,
    canonicalSummary?.total_active_minutes
  );
  const detail = services.activityReport.generateWorkSummary(query.records || [], {
    startTime: bounds.startTime,
    endTime: bounds.endTime,
    idleIntervals,
    focusIntervals,
    targetActivityMinutes,
    canonicalSummary
  });

  return {
    ...bounds,
    generated_at: new Date().toISOString(),
    summary: canonicalSummary || {},
    canonical_summary: canonicalSummary,
    canonical_coverage: canonicalResult.coverage,
    sync: query.sync || services.activityStore.getSyncSummary(bounds.startTime, bounds.endTime),
    source: detail.source,
    activity_minutes: detail.activity_minutes,
    captured_record_count: detail.captured_record_count,
    focus_interval_count: detail.focus_interval_count,
    captured_minutes: detail.captured_minutes,
    focus_minutes: detail.focus_minutes,
    app_totals: detail.app_totals,
    manual_timing_blocks: detail.manual_timing_blocks || canonicalSummary?.manual_timing_blocks || null,
    rows: detail.rows
  };
}

function getFocusIntervalsInRange(startTime, endTime) {
  try {
    return services.focusEvents?.getActiveIntervals?.(startTime, endTime, {
      idleThresholdSeconds: services.systemIdle?.thresholdSeconds || 5 * 60
    }) || [];
  } catch (error) {
    traceStartup('focus_intervals_failed', { error: error?.message || String(error) });
    return [];
  }
}

function localDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function localDaySegmentsForRange(startTime, endTime, maxSegments = 8) {
  const start = new Date(startTime);
  const end = new Date(endTime);
  if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
    return [];
  }

  const segments = [];
  const cursor = new Date(start);
  cursor.setHours(0, 0, 0, 0);
  const nowMs = Date.now();
  while (cursor < end && segments.length < maxSegments) {
    const dayStart = new Date(cursor);
    const next = new Date(cursor);
    next.setDate(next.getDate() + 1);
    const segmentStartMs = Math.max(start.getTime(), dayStart.getTime());
    const segmentEndMs = Math.min(end.getTime(), next.getTime(), nowMs);
    if (segmentEndMs > segmentStartMs) {
      segments.push({
        date: localDateKey(dayStart),
        startTime: new Date(segmentStartMs).toISOString(),
        endTime: new Date(segmentEndMs).toISOString()
      });
    }
    cursor.setDate(cursor.getDate() + 1);
  }
  return segments;
}

function manualWorkMinutesFromSummary(summary = {}) {
  const manual = summary.manual_timing_blocks || {};
  const value = firstFiniteNumber(
    summary.manual_net_added_work_minutes,
    Number(manual.net_added_minutes || manual.net_added_work_minutes || 0) +
      Number(manual.net_added_meeting_minutes || 0)
  );
  return Math.max(0, Math.round(value || 0));
}

function canonicalWorkMinutesFromSummary(summary = {}) {
  const pcAvailable = safePcAvailableMinutesFromSummary(summary);
  const idle = firstFiniteNumber(summary.idle_minutes, summary.input_idle_minutes) || 0;
  const manual = manualWorkMinutesFromSummary(summary);
  return buildWorkHoursLedger({
    pcAvailableMinutes: pcAvailable,
    idleMinutes: idle,
    manualAddedMinutes: manual,
    rangeMinutes: firstFiniteNumber(summary.range_minutes)
  }).work_minutes;
}

function mergeMinuteMap(target = {}, source = {}) {
  Object.keys(source || {}).forEach((key) => {
    target[key] = Math.max(0, Math.round(Number(target[key] || 0) + Number(source[key] || 0)));
  });
  return target;
}

function mergeCanonicalSummaries(dailySummaries = [], startTime, endTime, canonicalCoverage = null) {
  const summaries = dailySummaries.filter((summary) => summary && typeof summary === 'object');
  if (!summaries.length) {
    return null;
  }
  if (summaries.length === 1) {
    return canonicalCoverage ? {
      ...summaries[0],
      canonical_coverage: canonicalCoverage
    } : summaries[0];
  }

  const classified = {};
  const appNames = new Set();
  const appsUsed = new Set();
  const browserNames = new Set();
  const siteDomains = new Set();
  const rangeMinutes = Math.max(0, Math.round((new Date(endTime).getTime() - new Date(startTime).getTime()) / 60000));
  const totals = summaries.reduce((acc, summary) => {
    const pcAvailable = safePcAvailableMinutesFromSummary(summary);
    const idle = firstFiniteNumber(summary.idle_minutes, summary.input_idle_minutes) || 0;
    const manual = manualWorkMinutesFromSummary(summary);
    const work = canonicalWorkMinutesFromSummary(summary);
    const focusScore = summary.focus_score || {};
    mergeMinuteMap(classified, summary.classified_minutes || {});
    (summary.app_display_names || []).forEach((name) => appNames.add(name));
    (summary.apps_used || []).forEach((name) => appsUsed.add(name));
    (summary.browser_activity?.browser_names || []).forEach((name) => browserNames.add(name));
    (summary.browser_activity?.sites || []).forEach((site) => {
      if (site?.domain) {
        siteDomains.add(site.domain);
      }
    });
    acc.pcAvailable += pcAvailable;
    acc.idle += Math.min(pcAvailable, Math.max(0, Math.round(Number(idle) || 0)));
    acc.manual += Math.max(0, Math.round(Number(manual) || 0));
    acc.work += work;
    acc.runtime += Math.max(0, Math.round(Number(summary.runtime_available_minutes || 0)));
    acc.active += Math.max(0, Math.round(Number(summary.estimated_active_minutes || summary.active_minutes || 0)));
    acc.focus += Math.max(0, Math.round(Number(summary.focus_minutes || 0)));
    acc.pcWork += Math.max(0, Math.round(Number(summary.pc_work_minutes || focusScore.deep_work_minutes || 0)));
    acc.messaging += Math.max(0, Math.round(Number(summary.messaging_minutes || summary.pc_messaging_minutes || 0)));
    acc.social += Math.max(0, Math.round(Number(summary.social_minutes || 0)));
    acc.missing += Math.max(0, Math.round(Number(summary.missing_minutes || 0)));
    acc.events += Math.max(0, Math.round(Number(summary.activity_events || summary.event_count || 0)));
    return acc;
  }, {
    pcAvailable: 0,
    idle: 0,
    manual: 0,
    work: 0,
    runtime: 0,
    active: 0,
    focus: 0,
    pcWork: 0,
    messaging: 0,
    social: 0,
    missing: 0,
    events: 0
  });

  return {
    source: 'report-cache-canonical-range',
    official_time_source: 'report-cache-live-truth',
    pc_available_source: 'report-cache-live-truth',
    canonical_coverage: canonicalCoverage,
    range_start: startTime,
    range_end: endTime,
    range_minutes: rangeMinutes,
    runtime_available_minutes: totals.runtime,
    gross_pc_available_minutes: totals.pcAvailable,
    active_minutes: totals.active,
    estimated_active_minutes: totals.active,
    focus_minutes: totals.focus,
    pc_work_minutes: totals.pcWork,
    messaging_minutes: totals.messaging,
    pc_messaging_minutes: totals.messaging,
    social_minutes: totals.social,
    idle_minutes: totals.idle,
    input_idle_minutes: totals.idle,
    manual_net_added_work_minutes: totals.manual,
    missing_minutes: totals.missing,
    activity_events: totals.events,
    event_count: totals.events,
    classified_minutes: classified,
    app_display_names: Array.from(appNames),
    apps_used: Array.from(appsUsed),
    browser_activity: {
      browser_names: Array.from(browserNames),
      sites: Array.from(siteDomains).map((domain) => ({ domain }))
    },
    focus_score: {
      deep_work_minutes: totals.pcWork,
      total_active_minutes: totals.active,
      score_percent: totals.active > 0 ? Math.round((totals.pcWork / totals.active) * 100) : 0
    },
    work_minutes: totals.work,
    work_minutes_breakdown: {
      pc_work_minutes: totals.pcWork,
      pc_messaging_minutes: totals.messaging,
      pc_active_work_minutes: Math.max(0, totals.pcAvailable - totals.idle),
      gross_pc_available_minutes: totals.pcAvailable,
      idle_minutes: totals.idle,
      manual_net_added_minutes: totals.manual,
      total_work_minutes: totals.work
    }
  };
}

async function canonicalDailySummariesForRangeWithCoverage(startTime, endTime, options = {}) {
  const segments = localDaySegmentsForRange(startTime, endTime, options.maxDays || 8);
  const missingDates = [];
  const incompleteDates = [];
  const summaries = await Promise.all(segments.map(async (segment) => {
    try {
      const report = await services.reportCache.dailyReport({
        startTime: segment.startTime,
        endTime: segment.endTime,
        force: false,
        sync: false,
        includeTasks: false,
        staleOk: Boolean(options.staleOk)
      });
      if (!report?.summary) {
        missingDates.push(segment.date);
        return null;
      }
      if (report.cache?.complete === false) {
        incompleteDates.push(segment.date);
      }
      return {
        ...report.summary,
        canonical_date: segment.date,
        canonical_range_start: segment.startTime,
        canonical_range_end: segment.endTime,
        canonical_cache: report.cache || null
      };
    } catch (error) {
      traceStartup('canonical_report_summary_failed', {
        source: options.source || 'report',
        date: segment.date,
        error: error?.message || String(error)
      });
      missingDates.push(segment.date);
      return null;
    }
  }));
  const coveredSummaries = summaries.filter(Boolean);
  return {
    summaries: coveredSummaries,
    coverage: {
      source: options.source || 'report',
      complete: missingDates.length === 0 && incompleteDates.length === 0 && coveredSummaries.length === segments.length,
      expected_days: segments.length,
      covered_days: coveredSummaries.length,
      missing_dates: Array.from(new Set(missingDates)).sort(),
      incomplete_dates: Array.from(new Set(incompleteDates)).sort(),
      range_start: startTime,
      range_end: endTime
    }
  };
}

async function canonicalDailySummariesForRange(startTime, endTime, options = {}) {
  const result = await canonicalDailySummariesForRangeWithCoverage(startTime, endTime, options);
  return result.summaries;
}

function activitySummaryCacheKey(payload = {}) {
  const start = payload.startTime ? new Date(payload.startTime) : new Date();
  if (!Number.isFinite(start.getTime())) {
    return 'invalid';
  }
  return `${localDateKey(start)}:${Boolean(payload.appName) ? String(payload.appName) : 'all'}`;
}

function buildLocalActivitySummary(payload = {}) {
  const end = payload.endTime ? new Date(payload.endTime) : new Date();
  const start = payload.startTime ? new Date(payload.startTime) : new Date(end.getTime() - (2 * 60 * 60 * 1000));
  const endTime = Number.isFinite(end.getTime()) ? end.toISOString() : new Date().toISOString();
  const startTime = Number.isFinite(start.getTime()) ? start.toISOString() : new Date(Date.now() - (2 * 60 * 60 * 1000)).toISOString();
  const appFilter = String(payload.appName || '').trim().toLowerCase();
  const passive = Boolean(payload.passive);
  const queryRange = passive && services.activityStore?.queryRangeLite
    ? services.activityStore.queryRangeLite.bind(services.activityStore)
    : services.activityStore?.queryRange?.bind(services.activityStore);
  const records = (queryRange?.(startTime, endTime) || [])
    .filter((record) => !appFilter || String(record.app_name || '').trim().toLowerCase() === appFilter)
    .filter((record) => String(record?.app_name || '').trim().toLowerCase() !== 'system process');

  const apps = new Map();
  const windows = [];
  const recentTexts = [];
  records.forEach((record) => {
    const appName = record.app_name || 'Unknown';
    const timestamp = record.timestamp_start || record.timestamp || record.timestamp_end || endTime;
    if (!apps.has(appName)) {
      apps.set(appName, {
        name: appName,
        count: 0,
        minutes: 0,
        first_seen: timestamp,
        last_seen: timestamp
      });
    }
    const appEntry = apps.get(appName);
    appEntry.count += 1;
    appEntry.last_seen = timestamp;

    windows.push({
      app_name: appName,
      window_name: record.window_title || record.window_name || appName,
      browser_url: record.url_if_available || '',
      first_seen: timestamp,
      last_seen: timestamp
    });
    const text = passive
      ? ''
      : String(record.ocr_text || record.transcript_text || record.window_title || '').trim();
    if (text) {
      recentTexts.push({
        timestamp,
        app_name: appName,
        window_name: record.window_title || record.window_name || appName,
        browser_url: record.url_if_available || '',
        text: text.slice(0, 300)
      });
    }
  });

  return {
    source: 'local-activity-store',
    pending: true,
    time_range: { start: startTime, end: endTime },
    apps: Array.from(apps.values()).sort((left, right) => right.count - left.count).slice(0, 20),
    windows: windows
      .sort((left, right) => new Date(right.last_seen).getTime() - new Date(left.last_seen).getTime())
      .slice(0, 30),
    recent_texts: recentTexts
      .sort((left, right) => new Date(right.timestamp).getTime() - new Date(left.timestamp).getTime())
      .slice(0, 20)
  };
}

async function buildCachedActivitySummary(payload = {}) {
  const key = activitySummaryCacheKey(payload);
  const nowMs = Date.now();
  const force = Boolean(payload.force);
  const passive = Boolean(payload.passive);
  if (
    !force &&
    activitySummaryCache &&
    activitySummaryCache.key === key &&
    (passive || (nowMs - activitySummaryCache.createdAtMs) < ACTIVITY_SUMMARY_CACHE_MS)
  ) {
    return activitySummaryCache.value;
  }

  if (!force && activitySummaryInFlight?.key === key) {
    if (passive) {
      scheduleReadinessWarm('activity-summary-passive');
      return activitySummaryCache?.value || buildLocalActivitySummary(payload);
    }
    return activitySummaryInFlight.promise;
  }

  if (!force && passive) {
    scheduleReadinessWarm('activity-summary-passive');
    return activitySummaryCache?.value || buildLocalActivitySummary(payload);
  }

  const promise = (async () => {
    const value = await services.screenpipe.getActivitySummary(payload);
    const normalized = value || buildLocalActivitySummary(payload);
    activitySummaryCache = {
      key,
      createdAtMs: Date.now(),
      value: normalized
    };
    return normalized;
  })();

  activitySummaryInFlight = { key, promise };
  try {
    return await promise;
  } finally {
    if (activitySummaryInFlight?.promise === promise) {
      activitySummaryInFlight = null;
    }
  }
}

async function buildFocusTrend(days = 7, { force = false, fast = false, passive = false } = {}) {
  const safeDays = Math.min(Math.max(1, Math.round(Number(days) || 7)), 7);
  const nowMs = Date.now();
  if (
    !force &&
    focusTrendCache &&
    focusTrendCache.daysRequested === safeDays &&
    (nowMs - focusTrendCache.createdAtMs) < FOCUS_TREND_CACHE_MS
  ) {
    return focusTrendCache.value;
  }

  if (!force && focusTrendInFlight?.daysRequested === safeDays) {
    if (fast) {
      return { pending: true, days: [], average_score_percent: 0 };
    }
    return focusTrendInFlight.promise;
  }

  if (!force && passive) {
    return focusTrendCache?.value || { pending: true, days: [], average_score_percent: 0 };
  }

  const promise = (async () => {
    const rows = [];

    for (let offset = -(safeDays - 1); offset <= 0; offset += 1) {
      const summaryResult = await measurePerf(`focusTrend.day.${offset}`, async () => {
        const bounds = dayBoundsForOffset(offset);
        if (!force) {
          const report = await measurePerf(`focusTrend.day.${offset}.cache`, () => (
            services.reportCache.dailyReport({
              startTime: bounds.startTime,
              endTime: bounds.endTime,
              sync: false,
              includeTasks: false,
              staleOk: true
            })
          ), { slowMs: 500 });
          return {
            bounds,
            summary: report.summary || {},
            pending: report.cache?.complete === false
          };
        }

        const syncDay = force && offset === 0;
        const query = await measurePerf(`focusTrend.day.${offset}.rangeData`, () => (
          services.activity.getRangeData(bounds.startTime, bounds.endTime, {
            sync: syncDay,
            maxDurationMs: syncDay ? 15000 : undefined,
            maxWindows: syncDay ? 48 : undefined
          })
        ), { slowMs: 500 });
        const context = services.aiContextBuilder.build(query.records || []);
        const idleIntervals = services.systemIdle.getIntervalsInRange(bounds.startTime, bounds.endTime);
        const focusIntervals = getFocusIntervalsInRange(bounds.startTime, bounds.endTime);
        const summary = await measurePerf(`focusTrend.day.${offset}.summary`, () => (
          services.dailySummary.generate(context, {
            startTime: bounds.startTime,
            endTime: bounds.endTime,
            idleIntervals,
            focusIntervals,
            includeTasks: false
          })
        ), { slowMs: 500 });
        return { bounds, summary };
      }, { slowMs: 1000 });
      const { bounds, summary } = summaryResult;
      const focusScore = summary.focus_score || {};
      rows.push({
        date: bounds.date,
        score_percent: Number(focusScore.score_percent || 0),
        deep_work_minutes: Number(focusScore.deep_work_minutes || 0),
        total_active_minutes: Number(focusScore.total_active_minutes || summary.estimated_active_minutes || 0),
        label: focusScore.label || '0%',
        pending: Boolean(summaryResult.pending)
      });
    }

    const value = {
      days: rows,
      average_score_percent: rows.length
        ? Math.round(rows.reduce((sum, row) => sum + Number(row.score_percent || 0), 0) / rows.length)
        : 0,
      pending: rows.some((row) => row.pending)
    };
    focusTrendCache = {
      daysRequested: safeDays,
      createdAtMs: Date.now(),
      value
    };
    return value;
  })();

  focusTrendInFlight = { daysRequested: safeDays, promise };
  if (fast) {
    promise
      .catch((error) => {
        perfLog('focus_trend_background_failed', { error: error?.message || String(error) });
      })
      .finally(() => {
        if (focusTrendInFlight?.promise === promise) {
          focusTrendInFlight = null;
        }
      });
    return focusTrendCache?.value || { pending: true, days: [], average_score_percent: 0 };
  }
  try {
    return await promise;
  } finally {
    if (focusTrendInFlight?.promise === promise) {
      focusTrendInFlight = null;
    }
  }
}

function configureWindowsUserTasks() {
  if (process.platform !== 'win32') {
    return;
  }

  app.setAppUserModelId('Cognify');
  const appPathArg = `"${String(app.getAppPath()).replace(/"/g, '\\"')}"`;
  const taskArguments = `${appPathArg} ${EXIT_TASK_ARG}`;
  app.setUserTasks([
    {
      program: process.execPath,
      arguments: taskArguments,
      iconPath: getCognifyIconPath() || process.execPath,
      iconIndex: 0,
      title: 'Exit Cognify',
      description: 'Close Cognify completely'
    }
  ]);
  traceStartup('windows_user_tasks_configured', { program: process.execPath, arguments: taskArguments });
}

async function maybeImportSqliteActivityStore() {
  const importFlag = String(process.env.COGNIFY_SQLITE_IMPORT_ON_START || '').trim().toLowerCase();
  if (['0', 'false', 'off', 'no'].includes(importFlag)) {
    traceStartup('sqlite_import_disabled', { reason: 'env' });
    return;
  }

  if (!services?.sqliteImportJsonl) {
    traceStartup('sqlite_import_unavailable');
    return;
  }

  try {
    const lowRamGate = lowRamBackgroundGate({ source: 'sqlite-import' });
    if (!lowRamGate.ok) {
      traceStartup('sqlite_import_skipped_low_ram', { reason: lowRamGate.reason, freeBytes: lowRamGate.freeBytes || null });
      scheduleSqliteImportRetry(lowRamGate.reason || 'low_ram_mode');
      return;
    }
    if (sqliteImportRetryTimer) {
      clearTimeout(sqliteImportRetryTimer);
      sqliteImportRetryTimer = null;
    }
    const fullImport = importFlag === '1' || importFlag === 'true' || importFlag === 'full';
    const result = services.sqliteImportJsonl(undefined, fullImport ? {} : {
      maxDays: SQLITE_RECENT_IMPORT_DAYS
    });
    invalidateReportCacheForSqliteImport(result);
    traceStartup('sqlite_import_completed', result);
  } catch (error) {
    traceStartup('sqlite_import_failed', { error: error?.message || String(error) });
  }
}

function scheduleSqliteImportRetry(reason = 'deferred') {
  if (sqliteImportRetryTimer || isQuitting) {
    return;
  }
  sqliteImportRetryTimer = setTimeout(() => {
    sqliteImportRetryTimer = null;
    maybeImportSqliteActivityStore();
  }, 30 * 60 * 1000);
  sqliteImportRetryTimer.unref?.();
  traceStartup('sqlite_import_retry_scheduled', { reason, delay_ms: 30 * 60 * 1000 });
}

function invalidateReportCacheForSqliteImport(result = {}) {
  const ranges = Array.isArray(result.changed_ranges) ? result.changed_ranges : [];
  let invalidated = 0;
  const invalidatedRanges = [];
  ranges.forEach((range) => {
    if (!range?.startTime || !range?.endTime) {
      return;
    }
    try {
      const value = services.reportCache?.invalidateRange(range.startTime, range.endTime);
      const count = Number(value?.invalidated || 0);
      invalidated += count;
      if (count > 0) {
        invalidatedRanges.push(range);
      }
    } catch (error) {
      traceStartup('sqlite_import_cache_invalidate_failed', {
        startTime: range.startTime,
        endTime: range.endTime,
        error: error?.message || String(error)
      });
    }
  });

  if (invalidated > 0) {
    todayStatsCache = null;
    todayCategorySnapshotCache = null;
    activitySummaryCache = null;
    focusTrendCache = null;
    peakProductivityCache = null;
    roleClassificationCache = null;
    traceStartup('sqlite_import_cache_invalidated', {
      ranges: ranges.length,
      invalidated
    });
    scheduleReportCacheRepairAfterSqliteImport(invalidatedRanges);
  }
}

function scheduleReportCacheRepairAfterSqliteImport(ranges = []) {
  if (isLowRamMode()) {
    traceStartup('sqlite_import_cache_rebuild_skipped_low_ram', { ranges: ranges.length, low_ram: lowRamModeInfo() });
    return;
  }
  const days = localDateKeysForRanges(ranges, 3);
  if (!days.length) {
    return;
  }

  setTimeout(() => {
    rebuildReportCacheDays(days, 'sqlite-import').catch((error) => {
      traceStartup('sqlite_import_cache_rebuild_failed', { error: error?.message || String(error) });
    });
  }, 1000);
}

async function rebuildReportCacheDays(days = [], source = 'requested') {
  const rebuilt = [];
  for (const dateKey of days) {
    const bounds = dayBoundsForDateKey(dateKey);
    if (!bounds) {
      continue;
    }
    const result = await services.reportCache.dailyReport({
      startTime: bounds.startTime,
      endTime: bounds.endTime,
      sync: false,
      includeTasks: false
    });
    rebuilt.push({
      date: dateKey,
      complete: Boolean(result.cache?.complete),
      hour_count: result.cache?.hour_count || 0,
      built_hours: result.cache?.built_hours || 0
    });
  }
  if (rebuilt.length) {
    traceStartup('report_cache_rebuilt_after_import', { source, days: rebuilt });
  }
}

function localDateKeysForRanges(ranges = [], maxDays = 3) {
  const keys = new Set();
  ranges.forEach((range) => {
    const start = new Date(range.startTime);
    const end = new Date(range.endTime);
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime())) {
      return;
    }
    start.setHours(0, 0, 0, 0);
    end.setHours(0, 0, 0, 0);
    for (let cursor = new Date(start); cursor <= end && keys.size < maxDays; cursor.setDate(cursor.getDate() + 1)) {
      keys.add(localDateKey(cursor));
    }
  });
  return Array.from(keys).sort();
}

function dayBoundsForDateKey(dateKey) {
  const match = String(dateKey || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) {
    return null;
  }
  const start = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 0, 0, 0, 0);
  if (!Number.isFinite(start.getTime())) {
    return null;
  }
  const end = new Date(start);
  end.setDate(end.getDate() + 1);
  const now = new Date();
  return {
    date: dateKey,
    startTime: start.toISOString(),
    endTime: (end > now ? now : end).toISOString()
  };
}

function buildCheapDiagnostics() {
  const nowMs = Date.now();
  if (
    diagnosticsCache &&
    (nowMs - diagnosticsCache.createdAtMs) < TELEMETRY_DIAGNOSTICS_CACHE_MS
  ) {
    return diagnosticsCache.value;
  }

  const settings = services.settings.getSettings();
  const audioMode = captureAudioMode(settings);
  const listeningEnabled = audioMode !== 'off';
  const hasProcessSample = Boolean(screenpipeMemoryState.checkedAt);
  const cachedStatus = services.screenpipe.getCachedStatus?.() || {};
  const cachedScreenpipeRunning = Boolean(cachedStatus.running || cachedStatus.apiAvailable);
  const sampledScreenpipeRunning = Boolean(screenpipeMemoryState.pid || screenpipeMemoryState.workingSetBytes);
  // Cheap diagnostics are intentionally never authoritative-negative; full diagnostics owns red health states.
  const screenpipeLikelyRunning = true;
  const memoryPressure = screenpipeMemoryPressureBytes(screenpipeMemoryState);
  const memorySampled = Boolean(memoryPressure);
  const ffmpeg = resolveFfmpegStatus();
  const focusEvents = services.focusEvents
    ? services.focusEvents.getHealth()
    : { ok: false, label: 'Focus Events', detail: 'Focus event store unavailable.' };
  const windowsFocus = services.windowsFocus
    ? services.windowsFocus.getHealth()
    : { ok: false, label: 'Windows Focus', detail: 'Windows focus helper unavailable.' };
  const systemIdle = services.systemIdle
    ? services.systemIdle.getHealth()
    : { ok: false, label: 'Idle Telemetry', detail: 'Idle telemetry unavailable.' };
  const runtimeAvailability = services.runtimeAvailability
    ? services.runtimeAvailability.getHealth()
    : { ok: false, label: 'Runtime Availability', detail: 'Runtime availability unavailable.' };
  const lowRam = lowRamModeInfo();
  const screenpipeDetail = cachedScreenpipeRunning
    ? `${cachedStatus.baseUrl || settings.screenpipeBaseUrl || 'Capture API'}/health recently reachable`
    : (sampledScreenpipeRunning
      ? `Process sampled${screenpipeMemoryState.pid ? `, pid ${screenpipeMemoryState.pid}` : ''}`
      : (hasProcessSample ? 'Capture health check is refreshing' : 'Background check is warming up'));
  const value = {
    checked_at: new Date().toISOString(),
    version: app.getVersion(),
    running_since: appStartedAt,
    overall: Boolean(screenpipeLikelyRunning && ffmpeg.ok && windowsFocus.ok && systemIdle.ok && runtimeAvailability.ok),
    app: {
      ok: true,
      label: 'App',
      detail: `Cognify running, store: ${services.activityStoreMode || 'jsonl'}`
    },
    low_ram_mode: {
      ok: true,
      label: 'Low RAM Mode',
      detail: lowRam.enabled
        ? `On (${lowRam.reason}); background reports and popups are demand-loaded.`
        : 'Off; standard background scheduling.',
      informational: true,
      ...lowRam,
      free_bytes: freeSystemMemoryBytes()
    },
    runtime_availability: runtimeAvailability,
    localhost: {
      ok: screenpipeLikelyRunning,
      label: 'Localhost API',
      detail: cachedScreenpipeRunning
        ? `${cachedStatus.baseUrl || settings.screenpipeBaseUrl || 'Capture API'}/health recently reachable`
        : (hasProcessSample ? 'Capture health check is refreshing' : 'Background check is warming up'),
      informational: true
    },
    screenpipe: {
      ok: screenpipeLikelyRunning,
      label: 'Screenpipe',
      detail: screenpipeDetail,
      informational: true
    },
    screenpipe_ownership: {
      ok: true,
      label: 'Screenpipe Ownership',
      detail: screenpipeLastStopState?.checked_at
        ? `Last stop ${screenpipeLastStopState.ok ? 'clean' : 'needs review'} at ${new Date(screenpipeLastStopState.checked_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`
        : 'Full ownership check deferred.',
      informational: true,
      last_stop: screenpipeLastStopState || null
    },
    screenpipe_retention: screenpipeRetentionDiagnostics(settings),
    search_api: {
      ok: true,
      label: 'Search API',
      detail: 'Deferred to keep the UI responsive.',
      informational: true,
      verified: false,
      readable: false,
      checked_at: null
    },
    ffmpeg,
    sqlite: { ok: true, label: 'SQLite', detail: 'Deferred in fast health check.', informational: true },
    focus_events: focusEvents,
    windows_focus: windowsFocus,
    system_idle: systemIdle,
    live_truth: liveTruthDiagnostics(),
    activity_store: {
      ok: true,
      label: 'Activity Store',
      detail: `Mode: ${services.activityStoreMode || 'jsonl'}`
    },
    recording: {
      ok: screenpipeLikelyRunning && !services.activity.isPaused(),
      label: 'Recording',
      detail: services.activity.isPaused() ? 'Paused' : (cachedScreenpipeRunning ? 'On' : 'Capture check is refreshing'),
      informational: !cachedScreenpipeRunning
    },
    listening: {
      ok: !listeningEnabled || screenpipeLikelyRunning || !hasProcessSample,
      label: 'Listening',
      detail: audioMode === 'off'
        ? 'Off by choice'
        : (audioMode === 'meeting'
          ? (meetingAudioActive ? 'Meeting Only: active now' : 'Meeting Only: waiting for meeting activity')
          : (screenpipeLikelyRunning ? 'Always On' : 'Audio requested, background check is reconnecting')),
      informational: !hasProcessSample,
      enabled: listeningEnabled,
      mode: audioMode,
      active: isAudioActiveForSettings(settings),
      device_mode: settings.capture?.audioDeviceMode || 'input-output',
      transcription_engine: settings.capture?.audioTranscriptionEngine || 'whisper-tiny-quantized'
    },
    vision: {
      ok: effectiveScreenpipeVisionMode(settings) !== 'off',
      label: 'Vision',
      detail: effectiveScreenpipeVisionMode(settings) === 'off'
        ? 'No Vision mode: Windows screen capture disabled for smooth mouse movement.'
        : `Normal vision, video quality ${SCREENPIPE_VIDEO_QUALITY}.`,
      informational: effectiveScreenpipeVisionMode(settings) === 'off',
      mode: effectiveScreenpipeVisionMode(settings),
      video_quality: SCREENPIPE_VIDEO_QUALITY
    },
    screenpipe_memory: {
      ok: !memorySampled || memoryPressure < SCREENPIPE_MEMORY_WARN_BYTES,
      label: 'Screenpipe RAM',
      detail: memorySampled
        ? `${formatMemoryMb(memoryPressure)} active memory, ${formatMemoryMb(screenpipeMemoryState.privateBytes)} private reserved`
        : 'Memory sampling in background',
      private_bytes: screenpipeMemoryState.privateBytes,
      working_set_bytes: screenpipeMemoryState.workingSetBytes,
      pressure_bytes: memoryPressure,
      cpu_percent: screenpipeMemoryState.cpuPercent,
      high_cpu_samples: screenpipeMemoryState.highCpuSamples,
      cpu_restart_count: (screenpipeMemoryState.cpuRestarts || []).length,
      stale_frames: screenpipeMemoryState.staleFrames || null,
      stale_frame_restart_count: (screenpipeMemoryState.staleFrameRestarts || []).length,
      pid: screenpipeMemoryState.pid,
      checked_at: screenpipeMemoryState.checkedAt,
      informational: !memorySampled
    },
    updater: readUpdaterState(),
    fast: true
  };
  return value;
}

function liveTruthDiagnostics() {
  try {
    const state = services.liveTruth?.getTodayState?.();
    const health = state?.health || {};
    const cache = state?.cache || {};
    return {
      ok: health.status !== 'attention',
      label: 'Live Truth',
      detail: health.detail || 'Live day verification is warming up.',
      informational: health.status === 'checking',
      status: health.status || 'checking',
      verified_until: state?.verified_until || null,
      pending_hours: cache.pending_hours || [],
      gap_hours: cache.gap_hours || []
    };
  } catch (error) {
    return {
      ok: false,
      label: 'Live Truth',
      detail: error?.message || 'Live day verification unavailable.',
      informational: true,
      status: 'unknown'
    };
  }
}

async function buildDiagnostics({ force = false, cheap = false } = {}) {
  if (cheap && !force) {
    return buildCheapDiagnostics();
  }

  const nowMs = Date.now();
  if (
    !force &&
    diagnosticsCache &&
    (nowMs - diagnosticsCache.createdAtMs) < DIAGNOSTICS_CACHE_MS
  ) {
    return diagnosticsCache.value;
  }

  if (!force && diagnosticsInFlight) {
    return diagnosticsInFlight;
  }

  const promise = (async () => {
    const status = await services.screenpipe.getStatus({ force });
    const ffmpeg = resolveFfmpegStatus();
    const sqlite = services.sqliteHealth
      ? services.sqliteHealth()
      : { ok: false, label: 'SQLite', detail: 'SQLite diagnostics unavailable.', informational: true };
    const activityStoreHealth = services.activityStoreHealth ? services.activityStoreHealth() : {};
    const focusEvents = services.focusEvents
      ? services.focusEvents.getHealth()
      : { ok: false, label: 'Focus Events', detail: 'Focus event store unavailable.', informational: true };
    const windowsFocus = services.windowsFocus
      ? services.windowsFocus.getHealth()
      : { ok: false, label: 'Windows Focus', detail: 'Windows focus helper unavailable.', informational: true };
    const systemIdle = services.systemIdle
      ? services.systemIdle.getHealth()
      : { ok: false, label: 'Idle Telemetry', detail: 'Idle telemetry unavailable.', informational: true };
    const runtimeAvailability = services.runtimeAvailability
      ? services.runtimeAvailability.getHealth()
      : { ok: false, label: 'Runtime Availability', detail: 'Runtime availability unavailable.', informational: true };
    const lowRam = lowRamModeInfo();
    const settings = services.settings.getSettings();
    const audioMode = captureAudioMode(settings);
    const listeningEnabled = audioMode !== 'off';
    const audioActive = isAudioActiveForSettings(settings);
    const screenpipeProcess = currentUserScreenpipeProcess(settings);
    const localhost = Boolean(status.apiAvailable);
    const searchVerified = Boolean(status.searchVerified);
    const searchReadable = Boolean(status.apiAuthenticated);
    const searchError = status.searchError || status.lastError || null;
    const searchDetail = searchVerified
      ? (searchReadable
        ? `Search API readable${status.searchLastCheckedAt ? `, checked ${new Date(status.searchLastCheckedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}` : ''}`
        : (searchError?.status ? `Search API error ${searchError.status}` : 'Search API did not respond quickly'))
      : 'Search API check deferred to avoid slowing the PC.';
    const value = {
      checked_at: new Date().toISOString(),
      version: app.getVersion(),
      running_since: appStartedAt,
      overall: Boolean(localhost && screenpipeProcess.running && ffmpeg.ok && windowsFocus.ok && systemIdle.ok && runtimeAvailability.ok),
      app: {
        ok: true,
        label: 'App',
        detail: `Cognify running, store: ${services.activityStoreMode || 'jsonl'}, data: ${app.getPath('userData')}`
      },
      low_ram_mode: {
        ok: true,
        label: 'Low RAM Mode',
        detail: lowRam.enabled
          ? `On (${lowRam.reason}); background reports and popups are demand-loaded.`
          : 'Off; standard background scheduling.',
        informational: true,
        ...lowRam,
        free_bytes: freeSystemMemoryBytes()
      },
      runtime_availability: runtimeAvailability,
      localhost: {
        ok: localhost,
        label: 'Localhost API',
        detail: localhost ? `${status.baseUrl}/health reachable` : `${status.baseUrl}/health unreachable`
      },
      screenpipe: {
        ok: screenpipeProcess.running && screenpipeProcess.owned && localhost,
        label: 'Screenpipe',
        detail: !screenpipeProcess.running
          ? 'Process not running'
          : (!screenpipeProcess.owned
            ? `Process running but not confirmed as Cognify-owned${screenpipeProcess.pid ? `, pid ${screenpipeProcess.pid}` : ''}`
            : (localhost ? `Running and capture API reachable${screenpipeProcess.pid ? `, pid ${screenpipeProcess.pid}` : ''}` : 'Capture API unreachable'))
      },
      screenpipe_ownership: screenpipeOwnershipDiagnostics(screenpipeProcess, status),
      screenpipe_retention: screenpipeRetentionDiagnostics(settings),
      search_api: {
        ok: searchReadable || !searchVerified,
        label: 'Search API',
        detail: searchDetail,
        informational: true,
        verified: searchVerified,
        readable: searchReadable,
        checked_at: status.searchLastCheckedAt || null
      },
      ffmpeg,
      sqlite,
      focus_events: focusEvents,
      windows_focus: windowsFocus,
      system_idle: systemIdle,
      live_truth: liveTruthDiagnostics(),
      activity_store: {
        ok: !activityStoreHealth.fallbackReason && (activityStoreHealth.dualWrite ? activityStoreHealth.dualWrite.ok : true),
        label: 'Activity Store',
        detail: activityStoreHealth.fallbackReason
          ? `Mode: ${activityStoreHealth.mode || 'jsonl'}, requested ${activityStoreHealth.requestedMode}. ${activityStoreHealth.fallbackReason}`
          : `Mode: ${activityStoreHealth.mode || 'jsonl'}${activityStoreHealth.dualWrite ? `, writes ${activityStoreHealth.dualWrite.primary} + ${activityStoreHealth.dualWrite.secondary}` : ''}`,
        mode: services.activityStoreMode || 'jsonl',
        requested_mode: services.requestedActivityStoreMode || 'jsonl',
        fallback_reason: activityStoreHealth.fallbackReason || null,
        dual_write: activityStoreHealth.dualWrite || null,
        recent_errors: activityStoreHealth.recentDualWriteErrors || []
      },
      recording: {
        ok: Boolean(status.running) && !services.activity.isPaused(),
        label: 'Recording',
        detail: !status.running ? 'Capture API offline' : (services.activity.isPaused() ? 'Paused' : 'On')
      },
      listening: {
        ok: !listeningEnabled || Boolean(status.running),
        label: 'Listening',
        detail: audioMode === 'off'
          ? 'Off by choice'
          : (audioMode === 'meeting'
            ? (audioActive ? 'Meeting Only: active now' : 'Meeting Only: waiting for meeting activity')
            : (status.running ? 'Always On' : 'Audio requested, but capture API is offline')),
        enabled: listeningEnabled,
        mode: audioMode,
        active: audioActive,
        device_mode: settings.capture?.audioDeviceMode || 'input-output',
        transcription_engine: settings.capture?.audioTranscriptionEngine || 'whisper-tiny-quantized'
      },
      vision: {
        ok: effectiveScreenpipeVisionMode(settings) !== 'off',
        label: 'Vision',
        detail: effectiveScreenpipeVisionMode(settings) === 'off'
          ? 'No Vision mode: Windows screen capture disabled for smooth mouse movement.'
          : `Normal vision, video quality ${SCREENPIPE_VIDEO_QUALITY}.`,
        informational: effectiveScreenpipeVisionMode(settings) === 'off',
        mode: effectiveScreenpipeVisionMode(settings),
        video_quality: SCREENPIPE_VIDEO_QUALITY
      },
      screenpipe_memory: {
        ok: !screenpipeMemoryPressureBytes(screenpipeMemoryState) || screenpipeMemoryPressureBytes(screenpipeMemoryState) < SCREENPIPE_MEMORY_WARN_BYTES,
        label: 'Screenpipe RAM',
        detail: screenpipeMemoryPressureBytes(screenpipeMemoryState)
          ? `${formatMemoryMb(screenpipeMemoryPressureBytes(screenpipeMemoryState))} active memory, ${formatMemoryMb(screenpipeMemoryState.privateBytes)} private reserved`
          : 'Memory not sampled yet',
        private_bytes: screenpipeMemoryState.privateBytes,
        working_set_bytes: screenpipeMemoryState.workingSetBytes,
        pressure_bytes: screenpipeMemoryPressureBytes(screenpipeMemoryState),
        cpu_percent: screenpipeMemoryState.cpuPercent,
        high_cpu_samples: screenpipeMemoryState.highCpuSamples,
        cpu_restart_count: (screenpipeMemoryState.cpuRestarts || []).length,
        stale_frames: screenpipeMemoryState.staleFrames || null,
        stale_frame_restart_count: (screenpipeMemoryState.staleFrameRestarts || []).length,
        pid: screenpipeMemoryState.pid,
        checked_at: screenpipeMemoryState.checkedAt
      },
      updater: readUpdaterState()
    };
    diagnosticsCache = {
      createdAtMs: Date.now(),
      value
    };
    return value;
  })();

  diagnosticsInFlight = promise;
  try {
    return await promise;
  } finally {
    if (diagnosticsInFlight === promise) {
      diagnosticsInFlight = null;
    }
  }
}

async function buildTodayStats({ force = false, sync = true, passive = false } = {}) {
  const end = new Date();
  const start = new Date(end);
  start.setHours(0, 0, 0, 0);
  const startTime = start.toISOString();
  const endTime = end.toISOString();
  const cacheKey = `${startTime}:${localDateKey(start)}`;
  const nowMs = Date.now();
  if (
    !force &&
    todayStatsCache &&
    todayStatsCache.cacheKey === cacheKey &&
    (passive || (nowMs - todayStatsCache.createdAtMs) < TODAY_STATS_CACHE_MS)
  ) {
    return todayStatsCache.value;
  }

  if (!force && todayStatsInFlight?.cacheKey === cacheKey) {
    return passive
      ? (todayStatsCache?.value || { records: [], summary: {}, pending: true })
      : todayStatsInFlight.promise;
  }

  if (!force && passive) {
    if (todayStatsCache?.value) {
      return todayStatsCache.value;
    }
    const lightweightStart = new Date(Math.max(start.getTime(), end.getTime() - (2 * 60 * 60 * 1000))).toISOString();
    const records = queryActivityRangeLite(lightweightStart, endTime);
    return {
      records,
      summary: {},
      sync: services.activityStore.getSyncSummary(lightweightStart, endTime),
      system_process_records: records.filter((record) => String(record?.app_name || '').trim().toLowerCase() === 'system process'),
      pending: true
    };
  }

  const promise = (async () => {
    const query = await measurePerf('getTodayStats.rangeData', () => (
      services.activity.getRangeData(startTime, endTime, { sync })
    ), { slowMs: 500 });
    const context = services.aiContextBuilder.build(query.records || []);
    const idleIntervals = services.systemIdle.getIntervalsInRange(startTime, endTime);
    const focusIntervals = getFocusIntervalsInRange(startTime, endTime);
    const summary = await measurePerf('getTodayStats.summary', () => (
      services.dailySummary.generate(context, {
        startTime,
        endTime,
        idleIntervals,
        focusIntervals,
        includeTasks: false
      })
    ), { slowMs: 500 });

    const value = {
      records: query.records || [],
      summary,
      sync: query.sync,
      system_process_records: query.system_process_records || []
    };
    todayStatsCache = {
      cacheKey,
      createdAtMs: Date.now(),
      value
    };
    return value;
  })();

  todayStatsInFlight = { cacheKey, promise };
  try {
    return await promise;
  } finally {
    if (todayStatsInFlight?.promise === promise) {
      todayStatsInFlight = null;
    }
  }
}

async function buildTodayCategorySnapshot({ force = false, sync = true, passive = false } = {}) {
  const bounds = dayBoundsForOffset(0);
  const cacheKey = bounds.date;
  const nowMs = Date.now();
  const cachedValue = todayCategorySnapshotCache?.cacheKey === cacheKey
    ? todayCategorySnapshotCache.value
    : null;
  if (
    !force &&
    cachedValue &&
    isCompleteCategorySnapshot(cachedValue) &&
    (passive || (nowMs - todayCategorySnapshotCache.createdAtMs) < TODAY_CATEGORY_CACHE_MS)
  ) {
    return cachedValue;
  }

  if (!force && todayCategorySnapshotInFlight?.cacheKey === cacheKey) {
    if (passive) {
      return isCompleteCategorySnapshot(cachedValue)
        ? cachedValue
        : { summary: {}, cache: { pending: true, complete: false }, pending: true };
    }
    return todayCategorySnapshotInFlight.promise;
  }

  const promise = (async () => {
    if (force) {
      await refreshLiveTruthCurrent('today-category-force', { force: true });
    }
    const liveTruthSnapshot = currentCategorySnapshotFromLiveTruth(passive ? 'live-truth-passive-day' : 'live-truth-current-day');
    if (liveTruthSnapshot?.summary) {
      if (isCompleteCategorySnapshot(liveTruthSnapshot)) {
        todayCategorySnapshotCache = {
          cacheKey,
          createdAtMs: Date.now(),
          value: liveTruthSnapshot
        };
      }
      return liveTruthSnapshot;
    }

    const passiveMode = Boolean(passive && !force);
    let result = await services.reportCache.dailyReport({
      startTime: bounds.startTime,
      endTime: bounds.endTime,
      force,
      sync: passiveMode ? false : sync,
      warmCurrentHourOnly: !passiveMode,
      includeTasks: false,
      staleOk: passiveMode
    });

    if (!passiveMode && shouldRecoverIncompleteCategorySnapshot(result)) {
      result = await services.reportCache.dailyReport({
        startTime: bounds.startTime,
        endTime: bounds.endTime,
        force: false,
        sync: false,
        includeTasks: false
      });
    }

    const value = {
      summary: result.summary || {},
      cache: result.cache || {},
      sync: result.sync || null,
      context_count: result.context_count || 0,
      source: passiveMode ? 'report-cache-stale-day' : 'report-cache-current-hour'
    };
    if (isCompleteCategorySnapshot(value)) {
      todayCategorySnapshotCache = {
        cacheKey,
        createdAtMs: Date.now(),
        value
      };
    } else if (todayCategorySnapshotCache?.cacheKey === cacheKey && !isCompleteCategorySnapshot(todayCategorySnapshotCache.value)) {
      todayCategorySnapshotCache = null;
    }
    return value;
  })();

  todayCategorySnapshotInFlight = { cacheKey, promise };
  try {
    return await promise;
  } finally {
    if (todayCategorySnapshotInFlight?.promise === promise) {
      todayCategorySnapshotInFlight = null;
    }
  }
}

async function buildWeeklyPerformanceEvidencePayload(payload = {}) {
  const end = payload.endTime ? new Date(payload.endTime) : new Date();
  const start = payload.startTime
    ? new Date(payload.startTime)
    : new Date(end.getTime() - (7 * 24 * 60 * 60 * 1000));
  if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
    throw new Error('Enter a valid weekly evidence date range.');
  }

  const startTime = start.toISOString();
  const endTime = end.toISOString();
  const [canonicalResult, records] = await Promise.all([
    canonicalDailySummariesForRangeWithCoverage(startTime, endTime, {
      source: 'weekly-performance',
      staleOk: false,
      maxDays: 8
    }),
    Promise.resolve(services.activityStore.queryRange(startTime, endTime))
  ]);
  const dailySummaries = canonicalResult.summaries;
  const idleIntervals = dailySummaries.length
    ? []
    : services.systemIdle.getIntervalsInRange(startTime, endTime);
  const selfInput = payload.selfInput || services.weeklySelfInput.getWeek(startTime);
  return weeklyPerformanceEvidence().buildWeeklyPerformanceEvidence({
    startTime,
    endTime,
    now: new Date().toISOString(),
    records,
    dailySummaries,
    canonicalCoverage: canonicalResult.coverage,
    roleProfile: services.settings.getSettings().profile || {},
    idleSummary: { intervals: idleIntervals },
    selfInput
  });
}

function getPerformanceRulesConfig() {
  const configPath = path.join(__dirname, '..', 'config', 'performance-rules.json');
  const stat = fs.statSync(configPath);
  if (performanceRulesCache?.mtimeMs === stat.mtimeMs) {
    return performanceRulesCache.config;
  }
  const config = performanceRuleEngine().loadPerformanceRulesConfig(configPath);
  performanceRulesCache = { mtimeMs: stat.mtimeMs, config };
  return config;
}

function getMyWeeklyReportConfig() {
  const configPath = path.join(__dirname, '..', 'config', 'my-weekly-report.json');
  const stat = fs.statSync(configPath);
  if (myWeeklyReportConfigCache?.mtimeMs === stat.mtimeMs) {
    return myWeeklyReportConfigCache.config;
  }
  const config = myWeeklyReport().loadMyWeeklyReportConfig(configPath);
  myWeeklyReportConfigCache = { mtimeMs: stat.mtimeMs, config };
  return config;
}

async function evaluateWeeklyPerformanceRulesPayload(payload = {}) {
  const evidence = payload.evidence || await buildWeeklyPerformanceEvidencePayload(payload);
  return performanceRuleEngine().evaluatePerformanceRules(evidence, getPerformanceRulesConfig());
}

async function buildMyWeeklyReportPayload(payload = {}) {
  const evidence = payload.evidence || await buildWeeklyPerformanceEvidencePayload(payload);
  return myWeeklyReport().buildMyWeeklyReport(evidence, getMyWeeklyReportConfig());
}

async function buildHodAppraisalDraftPayload(payload = {}) {
  const evidence = payload.evidence || await buildWeeklyPerformanceEvidencePayload(payload);
  const rulesConfig = getPerformanceRulesConfig();
  const evaluatedRules = payload.evaluatedRules || performanceRuleEngine().evaluatePerformanceRules(evidence, rulesConfig);
  return hodAppraisalDraft().buildHodAppraisalDraft(evidence, rulesConfig, {
    evaluatedRules,
    profileId: payload.profileId || 'hod_appraisal'
  });
}

function shouldRecoverIncompleteCategorySnapshot(result = {}) {
  const cache = result.cache || {};
  const summary = result.summary || {};
  if (cache.complete !== false) {
    return false;
  }

  if (Number(cache.covered_hours || cache.hour_count || 0) <= 1 && Number(cache.expected_hours || 0) > 1) {
    return true;
  }

  const activeMinutes = Number(summary.estimated_active_minutes || 0);
  const idleMinutes = Number(summary.input_idle_minutes || 0);
  const classified = summary.classified_minutes || {};
  const classifiedMinutes = Object.values(classified).reduce((sum, value) => sum + Number(value || 0), 0);

  return activeMinutes <= 0 && idleMinutes <= 0 && classifiedMinutes <= 0;
}

function isLunchIdleBackfillWindow(now = new Date()) {
  const minutes = now.getHours() * 60 + now.getMinutes();
  return minutes >= (12 * 60 + 30) && minutes <= (15 * 60);
}

function idleBackfillReadiness(now = new Date()) {
  const idleSummary = services?.systemIdle?.getTodaySummary?.();
  if (!idleSummary?.active || !idleSummary.active_since) {
    return { ready: false, reason: 'user_active' };
  }
  const activeSinceMs = new Date(idleSummary.active_since).getTime();
  if (!Number.isFinite(activeSinceMs)) {
    return { ready: false, reason: 'idle_start_unknown' };
  }
  const idleMs = Math.max(0, now.getTime() - activeSinceMs);
  const lunchWindow = isLunchIdleBackfillWindow(now);
  const requiredMs = REPORT_CACHE_BACKFILL_IDLE_MIN_MS;
  if (idleMs < requiredMs) {
    return {
      ready: false,
      reason: lunchWindow ? 'lunch_idle_window_pending' : 'idle_window_pending',
      idleMs,
      requiredMs
    };
  }
  const resource = screenpipeBackfillResourceReadiness(now);
  if (!resource.ready) {
    return {
      ready: false,
      reason: resource.reason,
      idleMs,
      requiredMs,
      resource
    };
  }
  return { ready: true, reason: lunchWindow ? 'lunch_idle_7m' : 'idle_7m', idleMs, requiredMs, resource };
}

function screenpipeBackfillResourceReadiness(now = new Date()) {
  if (!screenpipeMemoryState.checkedAt) {
    return { ready: false, reason: 'screenpipe_resource_sample_pending' };
  }
  const checkedAtMs = Date.parse(screenpipeMemoryState.checkedAt);
  if (!Number.isFinite(checkedAtMs) || (now.getTime() - checkedAtMs) > SCREENPIPE_RESOURCE_SAMPLE_STALE_MS) {
    return { ready: false, reason: 'screenpipe_resource_sample_stale' };
  }
  const pressureBytes = screenpipeMemoryPressureBytes(screenpipeMemoryState);
  if (pressureBytes >= SCREENPIPE_MEMORY_WARN_BYTES) {
    return {
      ready: false,
      reason: 'screenpipe_memory_pressure',
      pressureBytes
    };
  }
  const cpuPercent = Number(screenpipeMemoryState.cpuPercent);
  if (!Number.isFinite(cpuPercent)) {
    return {
      ready: false,
      reason: 'screenpipe_cpu_sample_pending'
    };
  }
  if (cpuPercent >= SCREENPIPE_CPU_WARN_PERCENT) {
    return {
      ready: false,
      reason: 'screenpipe_cpu_pressure',
      cpuPercent
    };
  }
  return {
    ready: true,
    reason: 'resources_quiet',
    pressureBytes,
    cpuPercent: Number.isFinite(cpuPercent) ? cpuPercent : null
  };
}

function scheduleTodayCategoryBackfill(missingHours = []) {
  if (!missingHours.length || reportCacheBackfillTimer || reportCacheBackfillInFlight) {
    return;
  }
  if (isLowRamMode()) {
    traceStartup('report_cache_backfill_skipped_low_ram', { missingHours: missingHours.length, low_ram: lowRamModeInfo() });
    return;
  }
  const readiness = idleBackfillReadiness();
  if (!readiness.ready) {
    traceStartup('report_cache_backfill_deferred_idle_window', {
      missingHours: missingHours.length,
      reason: readiness.reason,
      idle_ms: readiness.idleMs || 0,
      required_ms: readiness.requiredMs || 0
    });
    reportCacheBackfillTimer = setTimeout(() => {
      reportCacheBackfillTimer = null;
      scheduleTodayCategoryBackfill(missingHours);
    }, REPORT_CACHE_BACKFILL_DELAY_MS);
    return;
  }

  reportCacheBackfillTimer = setTimeout(async () => {
    reportCacheBackfillTimer = null;
    reportCacheBackfillInFlight = true;
    let remainingHours = missingHours.slice(1);
    try {
      if (isUserFacingWindowVisible()) {
        remainingHours = missingHours;
        traceStartup('report_cache_backfill_deferred_visible_window', { missingHours: missingHours.length });
        return;
      }
      const latestReadiness = idleBackfillReadiness();
      if (!latestReadiness.ready) {
        remainingHours = missingHours;
        traceStartup('report_cache_backfill_deferred_idle_window', {
          missingHours: missingHours.length,
          reason: latestReadiness.reason,
          idle_ms: latestReadiness.idleMs || 0,
          required_ms: latestReadiness.requiredMs || 0
        });
        return;
      }

      const bounds = dayBoundsForOffset(0);
      const hourKey = String(missingHours[0] || '').padStart(2, '0');
      const hour = Number(hourKey);
      if (!Number.isInteger(hour) || hour < 0 || hour > 23) {
        return;
      }
      const start = new Date(bounds.startTime);
      start.setHours(hour, 0, 0, 0);
      const end = new Date(start);
      end.setHours(end.getHours() + 1);
      const now = new Date();
      if (start >= now) {
        return;
      }
      await services.reportCache.dailyReport({
        startTime: start.toISOString(),
        endTime: (end > now ? now : end).toISOString(),
        sync: true,
        includeTasks: false,
        syncMaxDurationMs: REPORT_CACHE_BACKFILL_SYNC_BUDGET_MS,
        syncMaxWindows: REPORT_CACHE_BACKFILL_SYNC_WINDOWS
      });
      todayCategorySnapshotCache = null;
      traceStartup('report_cache_backfilled_hour', { hour: hourKey });
    } catch (error) {
      perfLog('report_cache_backfill_failed', { error: error?.message || String(error) });
    } finally {
      reportCacheBackfillInFlight = false;
      if (remainingHours.length) {
        scheduleTodayCategoryBackfill(remainingHours);
      }
    }
  }, REPORT_CACHE_BACKFILL_DELAY_MS);
}

const hasLock = hasExitTaskArg
  ? app.requestSingleInstanceLock({ exitTask: true })
  : app.requestSingleInstanceLock();
traceStartup('startup_flags', { argv: process.argv, hasExitTaskArg, hasLock });
if (!hasLock) {
  const exitRequestWritten = hasExitTaskArg ? writeExitRequest('no_lock_exit_arg') : false;
  traceStartup('exit_no_lock', { exitRequestWritten });
  if (hasExitTaskArg || hasFreshInstanceHeartbeat()) {
    app.exit(0);
  } else {
    traceStartup('stale_lock_continuing_without_electron_lock');
  }
}

app.on('second-instance', (_event, commandLine, _workingDirectory, additionalData = {}) => {
  traceStartup('second_instance', { commandLine, additionalData });
  if (additionalData?.exitTask || commandLine.includes(EXIT_TASK_ARG)) {
    traceStartup('second_instance_exit_task');
    quitApp();
    return;
  }

  if (shouldShowSetupMode()) {
    showSetupWindow('second-instance');
    return;
  }

  ensureWidgetVisible({ focus: false });
  if (panelWindow && !panelWindow.isDestroyed()) {
    if (panelWindow.isMinimized()) {
      panelWindow.restore();
    }
    showPanelWindow();
  }
});

function registerIpcHandlers() {
  ipcMain.handle('debug:log', (_, payload) => {
    try {
      const row = JSON.stringify({
        timestamp: new Date().toISOString(),
        ...payload
      });
      fs.appendFileSync(debugLogPath, `${row}\n`, 'utf8');
      return { ok: true };
    } catch (error) {
      return { ok: false, error: error.message };
    }
  });

  ipcMain.on('startup:trace', (_, payload = {}) => {
    const message = payload.message || 'event';
    const isInputTrace = message === 'widget_pointer_down' ||
      message === 'widget_pointer_up' ||
      message === 'widget_toggle_returned';
    if (isInputTrace && process.env.COGNIFY_TRACE_INPUT_EVENTS !== '1') {
      return;
    }
    traceStartup(`renderer_${message}`, {
      ...(payload.payload || {}),
      rendererTime: payload.rendererTime || null
    });
  });

  ipcMain.handle('widget:togglePanel', () => {
    const startedAt = Date.now();
    extendReadinessQuietWindow(15 * 1000);
    traceStartup('widget_toggle_received');
    if (snapshotWindow && !snapshotWindow.isDestroyed() && snapshotWindow.isVisible()) {
      keepSnapshotVisible = false;
      hideSnapshotWindow();
      traceStartup('widget_toggle_completed', { visible: false, duration_ms: Date.now() - startedAt });
      return { visible: false };
    }

    keepSnapshotVisible = true;
    const result = showSnapshotWindow();
    traceStartup('widget_toggle_completed', {
      visible: true,
      duration_ms: Date.now() - startedAt
    });
    return result;
  });

  ipcMain.handle('snapshot:openPanel', () => {
    return showReportPanelFromSnapshot('reports');
  });

  ipcMain.handle('snapshot:openHealthPanel', () => {
    return showHealthWindowFromSnapshot();
  });

  ipcMain.handle('snapshot:openWorkHoursPanel', () => {
    return showWorkHoursWindowFromSnapshot();
  });

  ipcMain.handle('snapshot:openNotesPanel', () => {
    return showNotesWindowFromSnapshot();
  });

  ipcMain.handle('snapshot:hide', () => {
    keepSnapshotVisible = false;
    hideSnapshotWindow();
    return { visible: false };
  });

  ipcMain.handle('panel:hide', () => {
    keepSnapshotVisible = false;
    panelNormalBounds = null;
    if (panelWindow && !panelWindow.isDestroyed()) {
      hideWindowForIdleDestroy('panel', panelWindow, WORK_WINDOW_IDLE_DESTROY_MS);
    }
    return { visible: false };
  });

  ipcMain.handle('app:quit', () => {
    quitApp();
    return { quitting: true };
  });

  ipcMain.handle('panel:expand', () => expandPanelWindow());

  ipcMain.handle('panel:restore', () => restorePanelWindow());

  ipcMain.handle('report:show', (_, payload) => showReportWindow(payload || {}));

  ipcMain.handle('report:hide', () => {
    return hideReportWindow({ restoreContext: true });
  });

  ipcMain.handle('report:expand', () => expandReportWindow());

  ipcMain.handle('report:restore', () => restoreReportWindow());

  ipcMain.handle('report:downloadDoc', (_, payload) => saveReportDoc(payload || {}));

  ipcMain.handle('report:downloadPdf', () => saveReportPdf());

  ipcMain.handle('health:hide', () => {
    keepSnapshotVisible = false;
    if (healthWindow && !healthWindow.isDestroyed()) {
      hideWindowForIdleDestroy('health', healthWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
    }
    return { visible: false };
  });

  ipcMain.handle('notes:hide', () => {
    keepSnapshotVisible = false;
    if (notesWindow && !notesWindow.isDestroyed()) {
      hideWindowForIdleDestroy('notes', notesWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
    }
    return { visible: false };
  });
  ipcMain.handle('workHours:hide', () => {
    keepSnapshotVisible = false;
    if (workHoursWindow && !workHoursWindow.isDestroyed()) {
      hideWindowForIdleDestroy('work-hours', workHoursWindow, POPUP_WINDOW_IDLE_DESTROY_MS);
    }
    return { visible: false };
  });
  ipcMain.handle('workHours:setSummaryExpanded', (_, expanded) => setWorkHoursSummaryExpanded(Boolean(expanded)));
  ipcMain.handle('nudge:getCurrent', () => currentNudge);
  ipcMain.handle('nudge:getDetails', () => buildCurrentNudgeDetails(currentNudge));
  ipcMain.handle('nudge:showDetails', () => showNudgeDetailsWindow());
  ipcMain.handle('nudge:hideDetails', () => {
    hideNudgeDetailsWindow();
    return { visible: false };
  });
  ipcMain.handle('nudge:dismiss', () => {
    dismissCurrentNudge();
    return { dismissed: true };
  });
  ipcMain.handle('nudge:openTarget', () => {
    const target = currentNudge?.target || 'snapshot';
    hideNudgeDetailsWindow();
    if (target === 'manual-block' && isInlineManualNudge(currentNudge)) {
      return { opened: 'manual-inline' };
    }
    hideNudgeWindow();
    if (target === 'reports') {
      showReportPanelFromSnapshot('reports');
      return { opened: 'reports' };
    }
    if (target === 'manual-block') {
      showReportPanelFromSnapshot('manual-block');
      return { opened: 'manual-block' };
    }
    if (target === 'work-hours') {
      showWorkHoursWindowFromSnapshot();
      return { opened: 'work-hours' };
    }
    if (target === 'profile') {
      if (!panelWindow || panelWindow.isDestroyed()) {
        createPanelWindow();
      }
      panelWindow.setSkipTaskbar(false);
      panelWindow.show();
      panelWindow.focus();
      return { opened: 'profile' };
    }
    showSnapshotWindow();
    return { opened: 'snapshot' };
  });
  handleTimed('assistant:getProductivityNudges', () => getProductivityNudges({ includeExpensive: false }), { slowMs: 1000 });
  handleTimed('assistant:getWorkSummaryReport', (_, payload = {}) => buildWorkSummaryReport(payload || {}), { slowMs: 1000 });
  handleTimed('assistant:showProductivityNudge', () => maybeShowProductivityNudge({ force: true }), { slowMs: 1000, always: true });
  handleTimed('assistant:getWeeklyPerformanceEvidence', (_, payload) => buildWeeklyPerformanceEvidencePayload(payload || {}), { slowMs: 1000 });
  handleTimed('assistant:evaluateWeeklyPerformanceRules', (_, payload) => evaluateWeeklyPerformanceRulesPayload(payload || {}), { slowMs: 1000 });
  handleTimed('assistant:getMyWeeklyReport', (_, payload) => buildMyWeeklyReportPayload(payload || {}), { slowMs: 1000 });
  handleTimed('assistant:getHodAppraisalDraft', (_, payload) => buildHodAppraisalDraftPayload(payload || {}), { slowMs: 1000 });
  ipcMain.handle('assistant:saveHodAppraisalDraft', (_, payload) => services.hodAppraisalReviews.saveDraft(payload || {}));
  ipcMain.handle('assistant:listHodAppraisalDrafts', (_, limit) => services.hodAppraisalReviews.list(limit));

  ipcMain.on('widget:startDrag', (_, payload) => {
    if (!widgetWindow || !payload) {
      return;
    }

    const [windowX, windowY] = widgetWindow.getPosition();
    dragState = {
      pointerX: payload.screenX,
      pointerY: payload.screenY,
      windowX,
      windowY
    };
  });

  ipcMain.on('widget:dragMove', (_, payload) => {
    if (!widgetWindow || !dragState || !payload) {
      return;
    }

    const nextX = Math.round(dragState.windowX + (payload.screenX - dragState.pointerX));
    const nextY = Math.round(dragState.windowY + (payload.screenY - dragState.pointerY));
    widgetWindow.setPosition(nextX, nextY);
  });

  ipcMain.on('widget:endDrag', () => {
    persistWidgetBounds();
    dragState = null;
  });

  handleTimed('assistant:getStatus', async () => {
    const status = services.screenpipe.getCachedStatus?.() || await services.screenpipe.getStatus();
    if (status.pending) {
      services.screenpipe.getStatus().catch((error) => {
        perfLog('status_background_refresh_failed', { error: error?.message || String(error) });
      });
    }
    const paused = services.activity.isPaused();
    const settings = services.settings.getSettings();
    const audioMode = captureAudioMode(settings);
    return {
      ...status,
      paused,
      recording: Boolean(status.running) && !paused,
      listeningEnabled: audioMode !== 'off',
      audioMode,
      audioActive: isAudioActiveForSettings(settings),
      audioDeviceMode: settings.capture?.audioDeviceMode || 'input-output',
      audioTranscriptionEngine: settings.capture?.audioTranscriptionEngine || 'whisper-tiny-quantized'
    };
  }, { slowMs: 500 });
  handleTimed('assistant:getDiagnostics', (_, options = {}) => (
    buildDiagnostics({
      force: Boolean(options.force),
      cheap: Boolean(options.cheap || options.passive)
    })
  ), { slowMs: 500 });
  ipcMain.handle('assistant:getUpdateState', () => readUpdaterState());
  ipcMain.handle('assistant:getUpdate', () => getUpdate({ apply: true, silent: false }));
  ipcMain.handle('assistant:getCapabilities', () => services.screenpipe.getCapabilities());
  ipcMain.handle('assistant:getAudioDevices', () => services.screenpipe.listAudioDevices());
  handleTimed('assistant:getActivitySummary', (_, payload = {}) => (
    buildCachedActivitySummary(payload)
  ), { slowMs: 750 });
  ipcMain.handle('health:repair', async (_, action) => {
    if (action === 'start-screenpipe' || action === 'start-localhost') {
      return ensureScreenpipeRunning({ force: true, source: action });
    }

    if (action === 'resume-recording') {
      const result = await services.activity.resumeCapture();
      await rebuildTrayMenu();
      return { ok: true, detail: 'Recording resume requested.', result };
    }

    return { ok: false, detail: `Unknown health repair action: ${action}` };
  });
  ipcMain.handle('health:openLogs', async () => {
    const logs = screenpipeLogPaths();
    if (fs.existsSync(logs.stderr)) {
      await shell.openPath(logs.stderr);
      return { ok: true, path: logs.stderr };
    }
    if (fs.existsSync(logs.stdout)) {
      await shell.openPath(logs.stdout);
      return { ok: true, path: logs.stdout };
    }
    await shell.openPath(app.getPath('userData'));
    return { ok: false, path: app.getPath('userData') };
  });
  ipcMain.handle('startup:getStatus', () => startupStatus());
  ipcMain.handle('startup:toggle', (_, enabled) => setStartupEnabled(Boolean(enabled)));
  ipcMain.handle('notes:list', () => ({ notes: sortedNotes() }));
  ipcMain.handle('notes:save', (_, payload) => saveNote(payload));
  ipcMain.handle('notes:delete', (_, id) => deleteNote(id));
  ipcMain.handle('assistant:getSetupInstructions', () => services.screenpipe.getSetupInstructions());
  handleTimed('assistant:getRecentActivity', (_, hours, options = {}) => (
    services.activity.recent(Math.min(Math.max(Number(hours) || 2, 0.25), 6), {
      sync: options.sync === true,
      maxDurationMs: options.sync === true ? 5000 : 0,
      maxWindows: options.sync === true ? 16 : 0
    })
  ), { slowMs: 750 });
  handleTimed('assistant:getFocusTrend', (_, days, options = {}) => (
    buildFocusTrend(days || 7, {
      force: Boolean(options.force),
      fast: Boolean(options.fast),
      passive: Boolean(options.passive)
    })
  ), { slowMs: 1000 });
  handleTimed('assistant:getTodayStats', (_, options = {}) => (
    buildTodayStats({
      force: Boolean(options.force),
      sync: options.sync !== false,
      passive: Boolean(options.passive)
    })
  ), { slowMs: 1000 });
  handleTimed('assistant:getTodayCategorySnapshot', (_, options = {}) => (
    buildTodayCategorySnapshot({
      force: Boolean(options.force),
      sync: options.sync !== false,
      passive: Boolean(options.passive)
    })
  ), { slowMs: 750 });
  handleTimed('assistant:getLiveDayTruth', () => (
    services.liveTruth.getTodayState()
  ), { slowMs: 250 });
  handleTimed('assistant:refreshLiveDayTruth', async (_, options = {}) => {
    await refreshLiveTruthCurrent('snapshot-request', { force: Boolean(options.force) });
    return services.liveTruth.getTodayState();
  }, { slowMs: 1000 });
  ipcMain.handle('assistant:pause', async () => {
    const result = await services.activity.pauseCapture();
    await rebuildTrayMenu();
    return result;
  });
  ipcMain.handle('assistant:resume', async () => {
    const result = await services.activity.resumeCapture();
    await rebuildTrayMenu();
    return result;
  });
  ipcMain.handle('assistant:updateCapture', async (_, payload = {}) => {
    let settings = services.settings.updateCapture(payload);
    diagnosticsCache = null;
    const restart = await ensureScreenpipeRunning({
      force: true,
      source: payload.visionMode !== undefined
        ? 'update-vision-capture'
        : (captureAudioMode(settings) !== 'off' ? 'enable-listening' : 'disable-listening')
    });
    let verified = null;
    let fallback = null;
    if (captureAudioMode(settings) !== 'off') {
      fallback = await disableListeningAfterAudioStartFailure('audio-start-failed-fallback');
      settings = services.settings.getSettings();
      verified = await services.screenpipe.getStatus({ force: true });
    }
    await rebuildTrayMenu();
    return {
      capture: settings.capture,
      restart,
      verified,
      fallback,
      ok: !fallback,
      detail: fallback
        ? 'Listening could not start, so Cognify switched Listening Off and restarted screen capture.'
        : 'Capture setting updated.'
    };
  });
  ipcMain.handle('assistant:deleteRange', async (_, payload) => {
    const result = await services.activity.deleteRange(payload);
    if (payload?.startTime && payload?.endTime) {
      services.reportCache?.invalidateRange(payload.startTime, payload.endTime);
    }
    todayStatsCache = null;
    todayCategorySnapshotCache = null;
    activitySummaryCache = null;
    focusTrendCache = null;
    peakProductivityCache = null;
    roleClassificationCache = null;
    scheduleReadinessWarm('delete-range');
    return result;
  });
  handleTimed('assistant:addManualActivityBlock', (_, payload) => addManualActivityBlock(payload), { slowMs: 250 });
  ipcMain.handle('assistant:compareActivityStores', (_, payload = {}) => {
    if (!payload.startTime || !payload.endTime) {
      throw new Error('startTime and endTime are required.');
    }
    return services.compareActivityStores(payload.startTime, payload.endTime);
  });
  handleTimed('assistant:ask', (_, payload) => services.chat.ask(payload), { slowMs: 1000, always: true });
  handleTimed('assistant:dailySummary', async (_, payload = {}) => {
    if (payload.startTime && payload.endTime && !Array.isArray(payload.records)) {
      validateDailyReportRange(payload.startTime, payload.endTime);
      const report = await services.reportCache.dailyReport({
        startTime: payload.startTime,
        endTime: payload.endTime,
        force: false,
        sync: false,
        includeTasks: false,
        staleOk: true
      });
      return report.summary || {};
    }
    const idleIntervals = payload.startTime && payload.endTime
      ? services.systemIdle.getIntervalsInRange(payload.startTime, payload.endTime)
      : [];
    const focusIntervals = payload.startTime && payload.endTime
      ? getFocusIntervalsInRange(payload.startTime, payload.endTime)
      : [];
    return services.dailySummary.generate(payload.records || [], {
      ...payload,
      idleIntervals,
      focusIntervals
    });
  }, { slowMs: 1000 });
  handleTimed('assistant:dailyReportCached', async (_, payload = {}) => {
    if (!payload.startTime || !payload.endTime) {
      throw new Error('startTime and endTime are required.');
    }
    validateDailyReportRange(payload.startTime, payload.endTime);
    const passive = Boolean(payload.passive || payload.preferCache);
    if (passive) {
      const result = await services.reportCache.dailyReport({
        startTime: payload.startTime,
        endTime: payload.endTime,
        force: false,
        sync: false,
        includeTasks: payload.includeTasks === true,
        staleOk: true
      });
      scheduleReadinessWarm('daily-report-passive');
      return {
        ...result,
        passive: true
      };
    }
    if (heavyReportInFlight) {
      throw new Error('Another report is already running. Wait for it to finish before starting Daily Report.');
    }
    const promise = services.reportCache.dailyReport({
      startTime: payload.startTime,
      endTime: payload.endTime,
      force: Boolean(payload.force),
      sync: payload.sync !== false,
      includeTasks: payload.includeTasks !== false,
      staleOk: Boolean(payload.staleOk)
    });
    heavyReportInFlight = promise;
    try {
      const result = await promise;
      if (result?.cache?.complete === false && Array.isArray(result.cache.missing_hours) && result.cache.missing_hours.length) {
        scheduleTodayCategoryBackfill(result.cache.missing_hours);
      }
      return result;
    } finally {
      if (heavyReportInFlight === promise) {
        heavyReportInFlight = null;
      }
    }
  }, { slowMs: 1000, always: true });
  handleTimed('assistant:activityReport', async (_, payload = {}) => {
    if (!payload.startTime || !payload.endTime) {
      throw new Error('startTime and endTime are required.');
    }
    validateReportRange(payload.startTime, payload.endTime);
    const reportKey = JSON.stringify({
      startTime: payload.startTime,
      endTime: payload.endTime,
      mode: payload.mode || 'timeline'
    });
    if (activityReportInFlight.has(reportKey)) {
      return activityReportInFlight.get(reportKey);
    }
    if (heavyReportInFlight) {
      throw new Error('Another report is already running. Wait for it to finish before starting a different report.');
    }
    const promise = (async () => {
    const [query, canonicalResult] = await Promise.all([
      services.activity.getRangeData(payload.startTime, payload.endTime),
      canonicalDailySummariesForRangeWithCoverage(payload.startTime, payload.endTime, {
        source: 'activity-report',
        staleOk: false,
        maxDays: 8
      })
    ]);
    const dailySummaries = canonicalResult.summaries;
    const visibleRecords = query.records || [];
    const systemProcessRecords = query.system_process_records || [];
    const idleIntervals = services.systemIdle.getIntervalsInRange(payload.startTime, payload.endTime);
    const focusIntervals = getFocusIntervalsInRange(payload.startTime, payload.endTime);
    const canonicalSummary = mergeCanonicalSummaries(dailySummaries, payload.startTime, payload.endTime, canonicalResult.coverage);
    return {
      ...services.activityReport.generate(visibleRecords || [], {
        startTime: payload.startTime,
        endTime: payload.endTime,
        mode: payload.mode || 'timeline',
        idleIntervals,
        focusIntervals,
        canonicalSummary,
        canonicalCoverage: canonicalResult.coverage
      }),
      canonical_summary: canonicalSummary,
      canonical_coverage: canonicalResult.coverage,
      sync: query.sync || services.activityStore.getSyncSummary(payload.startTime, payload.endTime),
      system_process_records: systemProcessRecords
    };
    })();
    activityReportInFlight.set(reportKey, promise);
    heavyReportInFlight = promise;
    try {
      return await promise;
    } finally {
      if (activityReportInFlight.get(reportKey) === promise) {
        activityReportInFlight.delete(reportKey);
      }
      if (heavyReportInFlight === promise) {
        heavyReportInFlight = null;
      }
    }
  }, { slowMs: 1000, always: true });
  ipcMain.handle('assistant:extractTasks', (_, payload) => services.tasks.extract(payload));
  ipcMain.handle('assistant:updateConnection', (_, payload) => services.settings.updateConnection(payload));
  ipcMain.handle('assistant:updateProfile', (_, payload) => {
    roleClassificationCache = null;
    return services.settings.updateProfile(payload);
  });
  ipcMain.handle('assistant:updateRoleProfile', (_, payload) => {
    roleClassificationCache = null;
    return services.settings.updateRoleProfile(payload);
  });
  ipcMain.handle('assistant:updateOnboarding', (_, payload) => services.settings.updateOnboarding(payload || {}));
  ipcMain.handle('assistant:completeOnboarding', async (_, payload) => {
    const nextPayload = payload && Object.keys(payload).length ? payload : { completedAt: true };
    const state = services.settings.updateOnboarding(nextPayload);
    setStartupEnabled(true);
    enterRuntimeMode('onboarding-complete');
    setTimeout(() => showSetupCompleteNudge(), 1000);
    return state;
  });
  ipcMain.handle('assistant:updatePrivacy', (_, payload) => services.settings.updatePrivacy(payload));
  ipcMain.handle('assistant:updateRetention', (_, policy) => services.settings.updateRetentionSettings(policy));
  ipcMain.handle('assistant:getSettings', () => services.settings.getSettings());
  ipcMain.handle('assistant:getWeeklySelfInput', (_, weekStart) => ({ self_input: services.weeklySelfInput.getWeek(weekStart || Date.now()) }));
  ipcMain.handle('assistant:saveWeeklySelfInput', (_, payload) => services.weeklySelfInput.saveWeek(payload || {}));
  ipcMain.handle('assistant:enforceRetention', () => services.retention.enforce());
  handleTimed('assistant:getIdleSummary', () => idleSummaryWithManualConsumedSlots(), { slowMs: 250 });
  ipcMain.handle('assistant:sendPayrollReport', (_, payload) => services.payroll.sendDailyReport(payload));
  ipcMain.handle('assistant:openGuide', () => shell.openExternal('https://docs.screenpi.pe/getting-started'));
  ipcMain.handle('assistant:openExternalUrl', (_, url) => shell.openExternal(url));
  ipcMain.handle('assistant:copyText', (_, text) => clipboard.writeText(String(text || '')));
}

app.whenReady().then(() => {
  traceStartup('when_ready');
  appStartedAt = new Date().toISOString();
  if (hasExitTaskArg) {
    traceStartup('exit_has_exit_arg');
    app.exit(0);
    return;
  }

  startExitRequestWatcher();
  startInstanceHeartbeat();
  cleanupKnownProfileLocks();
  migrateLegacyUserData();
  services = createServices(app.getPath('userData'), {
    sqlite: {
      lowMemory: isLowRamMode()
    },
    windowsFocus: {
      helperMode: process.env.COGNIFY_FOCUS_HELPER_MODE || 'native-first'
    },
    activity: {
      onIngest: (payload) => {
        const nowMs = Date.now();
        todayStatsCache = null;
        activitySummaryCache = null;
        if ((nowMs - lastActivityIngestWarmAtMs) >= READINESS_INGEST_WARM_MIN_MS) {
          lastActivityIngestWarmAtMs = nowMs;
          scheduleReadinessWarm('activity-ingest');
          traceStartup('readiness_warm_scheduled_from_ingest', payload);
        }
      }
    },
    systemIdle: {
      getIdleSeconds: () => powerMonitor.getSystemIdleTime(),
      onIntervalClosed: handleIdleIntervalClosed
    }
  });
  traceStartup('services_created', {
    userData: app.getPath('userData'),
    activityStoreMode: services.activityStoreMode,
    requestedActivityStoreMode: services.requestedActivityStoreMode,
    activityStoreFallbackReason: services.activityStoreFallbackReason,
    lowRamMode: lowRamModeInfo()
  });
  registerPowerIdleEvents();
  disableAudioAtStartupIfNeeded();
  debugLogPath = path.join(app.getPath('userData'), 'panel-debug.log');
  perfLogPath = path.join(app.getPath('userData'), 'perf-debug.log');
  configureWindowsUserTasks();
  traceStartup('tasks_configured');
  registerIpcHandlers();
  traceStartup('ipc_registered');
  traceStartup('snapshot_precreate_skipped_for_startup_memory');
  if (isOnboardingComplete()) {
    enterRuntimeMode('startup');
  } else {
    enterSetupMode('startup');
  }
});

app.on('activate', () => {
  if (shouldShowSetupMode()) {
    showSetupWindow('activate');
    return;
  }
  ensureWidgetVisible({ focus: false });
});

app.on('window-all-closed', (event) => {
  if (!isQuitting) {
    event.preventDefault();
  }
});

app.on('before-quit', () => {
  if (!isRelaunching) {
    cleanupKnownProfileLocks();
  }
});
