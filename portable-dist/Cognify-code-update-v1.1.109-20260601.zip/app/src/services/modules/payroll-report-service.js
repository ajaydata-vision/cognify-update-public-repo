class PayrollReportService {
  constructor(settingsService) {
    this.settingsService = settingsService;
  }

  async sendDailyReport(report = {}) {
    const settings = this.settingsService.getSettings();
    const payroll = settings.payroll || {};
    const endpoint = this._resolveEndpoint(payroll);
    const token = String(payroll.apiToken || '').trim();

    const payload = {
      ...report,
      name: report.name || settings.profile?.name || '',
      email_address: report.email_address || settings.profile?.email || ''
    };

    if (!payload.email_address) {
      throw new Error('Save your email address before sending the payroll report.');
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'X-Cognify-Api-Token': token } : {})
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });

      const bodyText = await response.text();
      let body = bodyText;
      try {
        body = bodyText ? JSON.parse(bodyText) : null;
      } catch {
        // Keep non-JSON server responses as text.
      }

      if (!response.ok) {
        throw new Error(`Payroll server returned ${response.status}: ${typeof body === 'string' ? body : JSON.stringify(body)}`);
      }
      this._assertSuccessfulResponse(body, 'Payroll server', response.status);

      return {
        ok: true,
        endpoint,
        status: response.status,
        response: body
      };
    } finally {
      clearTimeout(timeout);
    }
  }

  async sendCognifyDailyLog(log = {}) {
    const settings = this.settingsService.getSettings();
    const payroll = settings.payroll || {};
    const endpoint = this._resolveDailyLogEndpoint(payroll);
    const token = String(payroll.apiToken || '').trim();

    const payload = {
      emailAddress: log.emailAddress || settings.profile?.email || '',
      workHours: this._normalizeHourValue(log.workHours),
      activeHours: this._normalizeHourValue(log.activeHours),
      idleTime: this._normalizeHourValue(log.idleTime),
      socialTime: this._normalizeHourValue(log.socialTime),
      messageTime: this._normalizeHourValue(log.messageTime),
      logdate: String(log.logdate || '').trim()
    };

    if (!payload.emailAddress) {
      throw new Error('Save your email address before sending the Cognify daily log.');
    }
    if (!payload.logdate) {
      throw new Error('Daily log date is required.');
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'X-Cognify-Api-Token': token } : {})
        },
        body: JSON.stringify(payload),
        signal: controller.signal
      });

      const bodyText = await response.text();
      let body = bodyText;
      try {
        body = bodyText ? JSON.parse(bodyText) : null;
      } catch {
        // Keep non-JSON server responses as text.
      }

      if (!response.ok) {
        throw new Error(`Payroll daily log server returned ${response.status}: ${typeof body === 'string' ? body : JSON.stringify(body)}`);
      }
      this._assertSuccessfulResponse(body, 'Payroll daily log server', response.status);

      return {
        ok: true,
        endpoint,
        status: response.status,
        response: body
      };
    } finally {
      clearTimeout(timeout);
    }
  }

  _resolveEndpoint(payroll = {}) {
    const serverUrl = String(payroll.serverUrl || 'https://payroll.dil.in').trim().replace(/\/+$/, '');
    const apiPath = String(payroll.apiPath || '/api/dailyreport').trim();
    const path = apiPath.startsWith('/') ? apiPath : `/${apiPath}`;
    const endpoint = new URL(`${serverUrl}${path}`);

    if (endpoint.protocol !== 'https:') {
      throw new Error('Payroll server URL must use HTTPS.');
    }

    return endpoint.toString();
  }

  _resolveDailyLogEndpoint(payroll = {}) {
    const serverUrl = String(payroll.serverUrl || 'https://payrollapi.dil.in').trim().replace(/\/+$/, '');
    const apiPath = String(payroll.dailyLogApiPath || '/api/employee/congnifyDailyLog').trim();
    const path = apiPath.startsWith('/') ? apiPath : `/${apiPath}`;
    const endpoint = new URL(`${serverUrl}${path}`);

    if (endpoint.protocol !== 'https:') {
      throw new Error('Payroll daily log server URL must use HTTPS.');
    }

    return endpoint.toString();
  }

  _normalizeHourValue(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || numeric < 0) {
      return 0;
    }
    return Math.round(numeric * 100) / 100;
  }

  _assertSuccessfulResponse(body, label, statusCode) {
    const status = Number(statusCode || 0);
    const describe = () => `${label} returned ${status || 'OK'}: ${typeof body === 'string' ? body : JSON.stringify(body)}`;

    if (typeof body === 'string') {
      const text = body.trim();
      if (text && /(error|exception|fail|invalid)/i.test(text)) {
        throw new Error(describe());
      }
      return;
    }

    if (!body || typeof body !== 'object') {
      return;
    }

    const responseCode = Number(body.code || body.statusCode || body.status_code || 0);
    if (body.status === false || body.ok === false || body.success === false || responseCode >= 400) {
      throw new Error(describe());
    }

    const message = String(body.message || body.error || '').trim();
    if (message && /(error|exception|fail|invalid)/i.test(message) && body.status !== true && body.ok !== true && body.success !== true) {
      throw new Error(describe());
    }
  }
}

module.exports = { PayrollReportService };
