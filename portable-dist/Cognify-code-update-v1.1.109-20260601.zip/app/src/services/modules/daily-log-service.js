const fs = require('fs');
const path = require('path');
const {
  buildWorkHoursLedger,
  safePcAvailableMinutesFromSummary
} = require('./work-hours-ledger');

const DAILY_LOG_STATE_FILE = 'daily-log-state.json';
const DAILY_LOG_MORNING_START_HOUR = 6;
const DAILY_LOG_MORNING_END_HOUR = 13;
const DAILY_LOG_RETRY_DELAY_MS = 2 * 60 * 60 * 1000;
const DAILY_LOG_MAX_ATTEMPTS_PER_DAY = 5;
const DAILY_LOG_CATCHUP_LOOKBACK_DAYS = 7;

function pad2(value) {
  return String(value).padStart(2, '0');
}

function localDateKey(date = new Date()) {
  return [
    date.getFullYear(),
    pad2(date.getMonth() + 1),
    pad2(date.getDate())
  ].join('-');
}

function formatDailyLogDate(date = new Date()) {
  return [
    pad2(date.getDate()),
    pad2(date.getMonth() + 1),
    date.getFullYear()
  ].join('/');
}

function localDayBounds(date = new Date()) {
  const start = new Date(date);
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setDate(end.getDate() + 1);
  return {
    startTime: start.toISOString(),
    endTime: end.toISOString(),
    dateKey: localDateKey(start),
    date: start
  };
}

function yesterdayFor(now = new Date()) {
  const date = new Date(now);
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() - 1);
  return date;
}

function dayBeforeFor(now = new Date(), daysBack = 1) {
  const date = new Date(now);
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() - Math.max(1, Math.round(Number(daysBack) || 1)));
  return date;
}

function numberOrZero(value) {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : 0;
}

function minutesToHours(minutes) {
  return Math.round((numberOrZero(minutes) / 60) * 100) / 100;
}

function isMorning(now = new Date()) {
  const hour = now.getHours();
  return hour >= DAILY_LOG_MORNING_START_HOUR && hour < DAILY_LOG_MORNING_END_HOUR;
}

function buildDailyLogPayload({ report = {}, settings = {}, date = new Date() } = {}) {
  const summary = report.summary || {};
  const classified = summary.classified_minutes || {};
  const idle = numberOrZero(summary.idle_minutes || summary.input_idle_minutes);
  const available = safePcAvailableMinutesFromSummary(summary);
  const manualNetWork = Number.isFinite(Number(summary.manual_net_added_work_minutes))
    ? numberOrZero(summary.manual_net_added_work_minutes)
    : numberOrZero(summary.manual_timing_blocks?.net_added_minutes);
  const workLedger = buildWorkHoursLedger({
    pcAvailableMinutes: available,
    idleMinutes: idle,
    manualAddedMinutes: manualNetWork,
    rangeMinutes: summary.range_minutes
  });
  const profile = settings.profile || {};
  const hasGrossAvailable = Number.isFinite(Number(summary.gross_pc_available_minutes)) ||
    Number.isFinite(Number(summary.work_minutes_breakdown?.gross_pc_available_minutes)) ||
    Number.isFinite(Number(summary.runtime_available_minutes));
  const workMinutes = hasGrossAvailable
    ? workLedger.work_minutes
    : (Number.isFinite(Number(summary.work_minutes))
    ? Math.max(0, Math.round(Number(summary.work_minutes || 0)))
    : workLedger.work_minutes);
  const activeMinutes = Number.isFinite(Number(summary.active_minutes))
    ? summary.active_minutes
    : summary.estimated_active_minutes;
  const idleMinutes = Number.isFinite(Number(summary.idle_minutes))
    ? summary.idle_minutes
    : summary.input_idle_minutes;

  return {
    emailAddress: String(profile.email || '').trim(),
    workHours: minutesToHours(workMinutes),
    activeHours: minutesToHours(activeMinutes),
    idleTime: minutesToHours(idleMinutes),
    socialTime: minutesToHours(classified.social),
    messageTime: minutesToHours(classified.meeting),
    logdate: formatDailyLogDate(date)
  };
}

class DailyLogService {
  constructor(storagePath, services = {}, options = {}) {
    this.storagePath = storagePath;
    this.services = services;
    this.statePath = path.join(storagePath, options.stateFile || DAILY_LOG_STATE_FILE);
    this.now = options.now || (() => new Date());
    this.retryDelayMs = Number(options.retryDelayMs || DAILY_LOG_RETRY_DELAY_MS);
    this.maxAttemptsPerDay = Number(options.maxAttemptsPerDay || DAILY_LOG_MAX_ATTEMPTS_PER_DAY);
    this.catchupLookbackDays = Math.max(1, Math.round(Number(options.catchupLookbackDays || DAILY_LOG_CATCHUP_LOOKBACK_DAYS)));
  }

  async sendYesterdayIfDue({ now = this.now(), force = false, source = 'startup' } = {}) {
    return this.sendDayIfDue(yesterdayFor(now), { now, force, source });
  }

  async sendPendingIfDue({ now = this.now(), force = false, source = 'startup' } = {}) {
    const currentTime = now instanceof Date ? now : new Date(now);
    const settings = this.services.settings?.getSettings?.() || {};
    const payroll = settings.payroll || {};
    if (payroll.dailyLogAutoSendEnabled === false) {
      return { sent: false, skipped: 'disabled' };
    }
    if (!force && !isMorning(currentTime)) {
      return { sent: false, skipped: 'outside_morning_window' };
    }

    const state = this._loadState();
    const results = [];
    for (let daysBack = this.catchupLookbackDays; daysBack >= 1; daysBack -= 1) {
      const day = dayBeforeFor(currentTime, daysBack);
      const dateKey = localDateKey(day);
      if (!force && state.days?.[dateKey]?.status === 'sent') {
        continue;
      }
      const result = await this.sendDayIfDue(day, { now: currentTime, force, source });
      results.push(result);
    }

    const sentResults = results.filter((result) => result?.sent);
    if (sentResults.length > 0) {
      const lastSent = sentResults[sentResults.length - 1];
      return {
        ...lastSent,
        sent: true,
        sentCount: sentResults.length,
        failedCount: results.filter((result) => result?.failed).length,
        results
      };
    }

    const failed = results.find((result) => result?.failed);
    if (failed) {
      return {
        ...failed,
        sent: false,
        failed: true,
        sentCount: 0,
        failedCount: results.filter((result) => result?.failed).length,
        results
      };
    }

    return {
      sent: false,
      skipped: results.length ? 'nothing_sent' : 'already_sent',
      sentCount: 0,
      failedCount: 0,
      results
    };
  }

  async preparePendingReports({ now = this.now(), force = false, source = 'startup-prepare' } = {}) {
    const currentTime = now instanceof Date ? now : new Date(now);
    const settings = this.services.settings?.getSettings?.() || {};
    const payroll = settings.payroll || {};
    if (payroll.dailyLogAutoSendEnabled === false) {
      return { prepared: false, skipped: 'disabled', results: [] };
    }

    const state = this._loadState();
    const results = [];
    for (let daysBack = this.catchupLookbackDays; daysBack >= 1; daysBack -= 1) {
      const day = dayBeforeFor(currentTime, daysBack);
      const bounds = localDayBounds(day);
      const previous = state.days?.[bounds.dateKey] || null;
      if (!force && previous?.status === 'sent') {
        continue;
      }
      if (!force && previous?.prepareStatus === 'ready') {
        results.push({
          prepared: false,
          skipped: 'already_prepared',
          dateKey: bounds.dateKey,
          logdate: formatDailyLogDate(day)
        });
        continue;
      }
      results.push(await this.prepareDayReport(day, { now: currentTime, force, source, state }));
    }

    const preparedResults = results.filter((result) => result?.prepared);
    const failedResults = results.filter((result) => result?.failed);
    return {
      prepared: preparedResults.length > 0,
      preparedCount: preparedResults.length,
      failedCount: failedResults.length,
      skippedCount: results.filter((result) => result?.skipped).length,
      results
    };
  }

  async prepareDayReport(day, { now = this.now(), force = false, source = 'prepare', state = null } = {}) {
    const currentTime = now instanceof Date ? now : new Date(now);
    const settings = this.services.settings?.getSettings?.() || {};
    const payroll = settings.payroll || {};
    if (payroll.dailyLogAutoSendEnabled === false) {
      return { prepared: false, skipped: 'disabled' };
    }

    const bounds = localDayBounds(day);
    const logdate = formatDailyLogDate(day);
    const workingState = state || this._loadState();
    const previous = workingState.days?.[bounds.dateKey] || null;
    if (!force && previous?.status === 'sent') {
      return { prepared: false, skipped: 'already_sent', dateKey: bounds.dateKey, logdate };
    }
    if (!force && previous?.prepareStatus === 'ready') {
      return { prepared: false, skipped: 'already_prepared', dateKey: bounds.dateKey, logdate };
    }

    try {
      const report = await this.services.reportCache.dailyReport({
        startTime: bounds.startTime,
        endTime: bounds.endTime,
        sync: false,
        includeTasks: false,
        staleOk: false
      });
      this._recordPrepare(workingState, bounds.dateKey, {
        prepareStatus: 'ready',
        logdate,
        preparedAt: currentTime.toISOString(),
        source,
        cache: report.cache || null,
        summary: {
          work_minutes: Math.max(0, Math.round(Number(report.summary?.work_minutes || 0))),
          gross_pc_available_minutes: safePcAvailableMinutesFromSummary(report.summary || {}),
          idle_minutes: numberOrZero(report.summary?.idle_minutes || report.summary?.input_idle_minutes),
          runtime_available_minutes: numberOrZero(report.summary?.runtime_available_minutes),
          missing_minutes: numberOrZero(report.summary?.missing_minutes)
        }
      });
      return { prepared: true, dateKey: bounds.dateKey, logdate };
    } catch (error) {
      this._recordPrepare(workingState, bounds.dateKey, {
        prepareStatus: 'failed',
        logdate,
        preparedAt: currentTime.toISOString(),
        source,
        prepareError: error?.message || String(error)
      });
      return {
        prepared: false,
        failed: true,
        dateKey: bounds.dateKey,
        logdate,
        error: error?.message || String(error)
      };
    }
  }

  async sendDayIfDue(day, { now = this.now(), force = false, source = 'startup' } = {}) {
    const currentTime = now instanceof Date ? now : new Date(now);
    const settings = this.services.settings?.getSettings?.() || {};
    const payroll = settings.payroll || {};
    if (payroll.dailyLogAutoSendEnabled === false) {
      return { sent: false, skipped: 'disabled' };
    }
    if (!force && !isMorning(currentTime)) {
      return { sent: false, skipped: 'outside_morning_window' };
    }

    const bounds = localDayBounds(day);
    const logdate = formatDailyLogDate(day);
    const state = this._loadState();
    const previous = state.days?.[bounds.dateKey] || null;

    if (!force && previous?.status === 'sent') {
      return { sent: false, skipped: 'already_sent', dateKey: bounds.dateKey, logdate };
    }

    const attempts = Number(previous?.attemptCount || 0);
    const nextAttemptAfter = previous?.nextAttemptAfter ? new Date(previous.nextAttemptAfter) : null;
    if (!force && attempts >= this.maxAttemptsPerDay) {
      return { sent: false, skipped: 'attempt_limit', dateKey: bounds.dateKey, logdate };
    }
    if (!force && nextAttemptAfter && nextAttemptAfter.getTime() > currentTime.getTime()) {
      return { sent: false, skipped: 'backoff', dateKey: bounds.dateKey, logdate, nextAttemptAfter: nextAttemptAfter.toISOString() };
    }

    if (!String(settings.profile?.email || '').trim()) {
      this._recordAttempt(state, bounds.dateKey, {
        status: 'skipped',
        reason: 'missing_email',
        logdate,
        attemptCount: attempts,
        source,
        attemptedAt: currentTime.toISOString()
      });
      return { sent: false, skipped: 'missing_email', dateKey: bounds.dateKey, logdate };
    }

    try {
      const report = await this.services.reportCache.dailyReport({
        startTime: bounds.startTime,
        endTime: bounds.endTime,
        sync: false,
        includeTasks: false,
        staleOk: false
      });
      const payload = buildDailyLogPayload({ report, settings, date: day });
      const response = await this.services.payroll.sendCognifyDailyLog(payload);
      const sentAt = this.now().toISOString();

      this._recordAttempt(state, bounds.dateKey, {
        status: 'sent',
        logdate,
        sentAt,
        attemptedAt: sentAt,
        attemptCount: attempts + 1,
        source,
        payload,
        responseStatus: response.status || null,
        response: this._safeResponseSummary(response.response)
      });
      await this._audit('daily_log_sent', {
        dateKey: bounds.dateKey,
        logdate,
        source,
        status: response.status || null
      });
      return {
        sent: true,
        dateKey: bounds.dateKey,
        logdate,
        payload,
        response
      };
    } catch (error) {
      const attemptedAt = this.now();
      const nextAttempt = new Date(attemptedAt.getTime() + this.retryDelayMs);
      this._recordAttempt(state, bounds.dateKey, {
        status: 'failed',
        logdate,
        attemptedAt: attemptedAt.toISOString(),
        attemptCount: attempts + 1,
        source,
        error: error?.message || String(error),
        nextAttemptAfter: nextAttempt.toISOString()
      });
      await this._audit('daily_log_failed', {
        dateKey: bounds.dateKey,
        logdate,
        source,
        error: error?.message || String(error),
        nextAttemptAfter: nextAttempt.toISOString()
      });
      return {
        sent: false,
        failed: true,
        dateKey: bounds.dateKey,
        logdate,
        error: error?.message || String(error),
        nextAttemptAfter: nextAttempt.toISOString()
      };
    }
  }

  _recordAttempt(state, dateKey, entry) {
    state.days = state.days && typeof state.days === 'object' ? state.days : {};
    state.days[dateKey] = {
      ...(state.days[dateKey] || {}),
      ...entry
    };
    this._saveState(state);
  }

  _recordPrepare(state, dateKey, entry) {
    state.days = state.days && typeof state.days === 'object' ? state.days : {};
    state.days[dateKey] = {
      ...(state.days[dateKey] || {}),
      ...entry
    };
    this._saveState(state);
  }

  _loadState() {
    try {
      if (!fs.existsSync(this.statePath)) {
        return { days: {} };
      }
      const parsed = JSON.parse(fs.readFileSync(this.statePath, 'utf8'));
      return parsed && typeof parsed === 'object' ? { days: parsed.days || {} } : { days: {} };
    } catch {
      return { days: {} };
    }
  }

  _saveState(state) {
    fs.mkdirSync(this.storagePath, { recursive: true });
    fs.writeFileSync(this.statePath, `${JSON.stringify(state, null, 2)}\n`, 'utf8');
  }

  _safeResponseSummary(response) {
    if (response == null || typeof response === 'string') {
      return response;
    }
    try {
      return JSON.parse(JSON.stringify(response));
    } catch {
      return null;
    }
  }

  async _audit(event, payload) {
    if (!this.services.auditLog?.log) {
      return;
    }
    try {
      await this.services.auditLog.log(event, payload);
    } catch {
      // Daily log delivery should not fail because audit persistence failed.
    }
  }
}

module.exports = {
  DailyLogService,
  buildDailyLogPayload,
  formatDailyLogDate,
  localDateKey,
  localDayBounds,
  minutesToHours,
  isMorning
};
