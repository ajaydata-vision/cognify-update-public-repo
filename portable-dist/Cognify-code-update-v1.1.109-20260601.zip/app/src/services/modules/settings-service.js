const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULT_PAYROLL_API_TOKEN = '37c5a74ef3ed0ad0d8a9c38db2f14a2ab4e153f5a1ea0e228d886ac4c2f1826c';
const LEGACY_SCREENPIPE_API_KEY = 'cognify-local-screenpipe-token';
const LEGACY_SCREENPIPE_BASE_URL_STATIC = 'http://127.0.0.1:3030';
const LEGACY_SCREENPIPE_BASE_URL = 'http://localhost:3030';
const SCREENPIPE_BASE_PORT = 3030;
const SCREENPIPE_PORT_SPAN = 1000;
const DEFAULT_EVIDENCE_RETENTION_DAYS = 10;
const DEFAULT_SCREENPIPE_RAW_RETENTION_DAYS = 2;
const DEFAULT_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS = 7;
const DEFAULT_REPORT_CACHE_RETENTION_DAYS = 10;
const MIN_RETENTION_DAYS = 1;
const MAX_EVIDENCE_RETENTION_DAYS = 3650;
const MAX_SCREENPIPE_RAW_RETENTION_DAYS = 14;
const MIN_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS = 3;
const MAX_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS = 30;
const SCREENPIPE_AUDIO_RAW_RETENTION_MIN_DAYS = 3;
const SCREENPIPE_VISION_FORCE_DISABLED = process.env.COGNIFY_EXPERIMENTAL_SCREENPIPE_VISION !== '1';

function storageHash(storagePath) {
  return crypto
    .createHash('sha256')
    .update(path.resolve(storagePath || '').toLowerCase())
    .digest();
}

function defaultScreenpipePort(storagePath) {
  const envPort = Number(process.env.COGNIFY_SCREENPIPE_PORT);
  if (Number.isInteger(envPort) && envPort >= 1024 && envPort <= 65535) {
    return envPort;
  }

  return SCREENPIPE_BASE_PORT + (storageHash(storagePath).readUInt16BE(0) % SCREENPIPE_PORT_SPAN);
}

function defaultScreenpipeBaseUrl(storagePath) {
  return `http://127.0.0.1:${defaultScreenpipePort(storagePath)}`;
}

function defaultScreenpipeApiKey(storagePath) {
  return `cognify-${storageHash(storagePath).toString('hex').slice(0, 32)}`;
}

function isLoopbackScreenpipeBaseUrl(value) {
  try {
    const parsed = new URL(String(value || ''));
    const port = Number(parsed.port || 3030);
    return (
      parsed.protocol === 'http:' &&
      ['127.0.0.1', 'localhost', '::1', '[::1]'].includes(parsed.hostname) &&
      Number.isInteger(port) &&
      port >= 1024 &&
      port <= 65535
    );
  } catch {
    return false;
  }
}

function clampInteger(value, fallback, min, max) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return fallback;
  }
  return Math.min(max, Math.max(min, Math.round(parsed)));
}

function validateInteger(value, label, min, max) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
    throw new Error(`${label} must be between ${min} and ${max}`);
  }
  return Math.round(parsed);
}

function requestedAudioMode(settings = {}) {
  const mode = settings.capture?.audioMode;
  if (['off', 'meeting', 'always'].includes(mode)) {
    return mode;
  }
  return settings.capture?.listeningEnabled ? 'always' : 'off';
}

function normalizeRetentionSettings(settings = {}) {
  const retentionDays = clampInteger(
    settings.retentionDays,
    DEFAULT_EVIDENCE_RETENTION_DAYS,
    MIN_RETENTION_DAYS,
    MAX_EVIDENCE_RETENTION_DAYS
  );
  const screenpipeRawRetentionDays = clampInteger(
    settings.screenpipeRawRetentionDays,
    DEFAULT_SCREENPIPE_RAW_RETENTION_DAYS,
    MIN_RETENTION_DAYS,
    MAX_SCREENPIPE_RAW_RETENTION_DAYS
  );
  const reportCacheRetentionDays = clampInteger(
    settings.reportCacheRetentionDays,
    DEFAULT_REPORT_CACHE_RETENTION_DAYS,
    MIN_RETENTION_DAYS,
    MAX_EVIDENCE_RETENTION_DAYS
  );
  const audioRequested = requestedAudioMode(settings) !== 'off';
  const effectiveRawTargetDays = audioRequested
    ? Math.max(screenpipeRawRetentionDays, SCREENPIPE_AUDIO_RAW_RETENTION_MIN_DAYS)
    : screenpipeRawRetentionDays;
  const hardCapFloor = Math.min(
    MAX_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS,
    Math.max(MIN_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS, effectiveRawTargetDays + 1)
  );
  const configuredHardCap = clampInteger(
    settings.screenpipeRawRetentionHardCapDays,
    DEFAULT_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS,
    MIN_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS,
    MAX_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS
  );
  const screenpipeRawRetentionHardCapDays = Math.min(
    MAX_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS,
    Math.max(configuredHardCap, hardCapFloor)
  );

  return {
    retentionDays,
    screenpipeRawRetentionDays,
    screenpipeRawRetentionHardCapDays,
    reportCacheRetentionDays
  };
}

function effectiveScreenpipeRetention(settings = {}) {
  const normalized = normalizeRetentionSettings(settings);
  const audioRequested = requestedAudioMode(settings) !== 'off';
  const effectiveRawTargetDays = audioRequested
    ? Math.max(normalized.screenpipeRawRetentionDays, SCREENPIPE_AUDIO_RAW_RETENTION_MIN_DAYS)
    : normalized.screenpipeRawRetentionDays;
  const screenpipeCliRetentionDays = Math.max(
    normalized.screenpipeRawRetentionHardCapDays,
    Math.min(MAX_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS, effectiveRawTargetDays + 1)
  );

  return {
    ...normalized,
    audioRequested,
    effectiveRawTargetDays,
    screenpipeCliRetentionDays
  };
}

class SettingsService {
  constructor(storagePath) {
    this.filePath = path.join(storagePath, 'settings.json');
    this.defaultScreenpipeBaseUrl = defaultScreenpipeBaseUrl(storagePath);
    this.defaultScreenpipeApiKey = defaultScreenpipeApiKey(storagePath);
    this.settings = {
      screenpipeBaseUrl: this.defaultScreenpipeBaseUrl,
      screenpipeApiKey: this.defaultScreenpipeApiKey,
      retentionDays: DEFAULT_EVIDENCE_RETENTION_DAYS,
      screenpipeRawRetentionDays: DEFAULT_SCREENPIPE_RAW_RETENTION_DAYS,
      screenpipeRawRetentionHardCapDays: DEFAULT_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS,
      reportCacheRetentionDays: DEFAULT_REPORT_CACHE_RETENTION_DAYS,
      profile: {
        name: '',
        email: '',
        role: '',
        roleId: '',
        roleSource: '',
        roleNotes: '',
        roleConfirmedAt: '',
        roleDetection: {
          firstObservedAt: '',
          firstSetupPromptedAt: '',
          firstPromptedAt: '',
          lastPromptedAt: '',
          lastReclassificationPromptedAt: '',
          promptCount: 0,
          lastDetectedRoleId: '',
          lastDetectedRole: '',
          lastConfidence: 0,
          lastClassification: null
        }
      },
      payroll: {
        serverUrl: 'https://payrollapi.dil.in',
        apiPath: '/api/dailyreport',
        dailyLogApiPath: '/api/employee/congnifyDailyLog',
        dailyLogAutoSendEnabled: true,
        apiToken: DEFAULT_PAYROLL_API_TOKEN
      },
      classification: {
        workDomains: [
          'data.in',
          'dil.in',
          'xgenplus.com',
          'datagroup.in',
          'videomeet.in',
          'xgen.in',
          'bharatsync.com',
          'myxgen.com',
          'gov.in'
        ],
        workTlds: [
          'bank'
        ]
      },
      capture: {
        listeningEnabled: false,
        audioMode: 'off',
        audioDeviceMode: 'input-output',
        audioDeviceNames: [],
        audioTranscriptionEngine: 'whisper-tiny-quantized',
        visionMode: 'off'
      },
      privacy: {
        excludedApps: [],
        excludedDomains: [],
        excludePrivateWindows: true,
        blockSensitiveSurfaces: true
      },
      onboarding: {
        completedAt: '',
        dismissedHelpCards: []
      }
    };

    this._load();
  }

  _loadBootstrapProfile() {
    const bootstrapPath = process.env.COGNIFY_SETUP_PREFILL_PATH;
    if (!bootstrapPath || !fs.existsSync(bootstrapPath)) {
      return null;
    }
    try {
      const loaded = JSON.parse(fs.readFileSync(bootstrapPath, 'utf8'));
      return loaded?.profile && typeof loaded.profile === 'object' ? loaded.profile : null;
    } catch {
      return null;
    }
  }

  _load() {
    if (!fs.existsSync(this.filePath)) {
      const bootstrapProfile = this._loadBootstrapProfile();
      if (bootstrapProfile) {
        this.settings.profile = {
          ...this.settings.profile,
          ...bootstrapProfile,
          roleDetection: {
            ...this.settings.profile.roleDetection,
            ...(bootstrapProfile.roleDetection || {})
          }
        };
      }
      this._save();
      return;
    }

    let loaded;
    try {
      loaded = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
    } catch {
      try {
        fs.copyFileSync(this.filePath, `${this.filePath}.corrupt-${Date.now()}`);
      } catch {
        // Ignore backup failures and restore defaults.
      }
      this._normalizeRetentionSettings();
      this._save();
      return;
    }

    this.settings = {
      ...this.settings,
      ...loaded,
      classification: {
        ...this.settings.classification,
        ...(loaded.classification || {})
      },
      profile: {
        ...this.settings.profile,
        ...(loaded.profile || {}),
        roleDetection: {
          ...this.settings.profile.roleDetection,
          ...(loaded.profile?.roleDetection || {})
        }
      },
      payroll: {
        ...this.settings.payroll,
        ...(loaded.payroll || {})
      },
      capture: {
        ...this.settings.capture,
        ...(loaded.capture || {})
      },
      privacy: {
        ...this.settings.privacy,
        ...(loaded.privacy || {})
      },
      onboarding: {
        ...this.settings.onboarding,
        ...(loaded.onboarding || {}),
        dismissedHelpCards: Array.isArray(loaded.onboarding?.dismissedHelpCards)
          ? loaded.onboarding.dismissedHelpCards
          : []
      }
    };

    if (!String(this.settings.payroll.apiToken || '').trim()) {
      this.settings.payroll.apiToken = DEFAULT_PAYROLL_API_TOKEN;
    }

    let changed = false;
    if (
      !String(this.settings.screenpipeApiKey || '').trim() ||
      this.settings.screenpipeApiKey === LEGACY_SCREENPIPE_API_KEY
    ) {
      this.settings.screenpipeApiKey = this.defaultScreenpipeApiKey;
      changed = true;
    }

    if (
      !String(this.settings.screenpipeBaseUrl || '').trim() ||
      this.settings.screenpipeBaseUrl === LEGACY_SCREENPIPE_BASE_URL ||
      this.settings.screenpipeBaseUrl === LEGACY_SCREENPIPE_BASE_URL_STATIC ||
      !isLoopbackScreenpipeBaseUrl(this.settings.screenpipeBaseUrl)
    ) {
      this.settings.screenpipeBaseUrl = this.defaultScreenpipeBaseUrl;
      changed = true;
    }

    if (!loaded.capture?.audioMode && loaded.capture?.listeningEnabled) {
      this.settings.capture.audioMode = 'always';
      this.settings.capture.listeningEnabled = true;
      changed = true;
    }

    if (SCREENPIPE_VISION_FORCE_DISABLED && this.settings.capture.visionMode !== 'off') {
      this.settings.capture.visionMode = 'off';
      changed = true;
    }

    const legacyRetentionOnly =
      loaded.retentionDays === 30 &&
      loaded.screenpipeRawRetentionDays === undefined &&
      loaded.screenpipeRawRetentionHardCapDays === undefined &&
      loaded.reportCacheRetentionDays === undefined;
    if (legacyRetentionOnly) {
      this.settings.retentionDays = DEFAULT_EVIDENCE_RETENTION_DAYS;
      changed = true;
    }

    if (this._normalizeRetentionSettings()) {
      changed = true;
    }

    if (changed) {
      this._save();
    }
  }

  _save() {
    fs.writeFileSync(this.filePath, JSON.stringify(this.settings, null, 2));
  }

  _normalizeRetentionSettings() {
    const normalized = normalizeRetentionSettings(this.settings);
    const changed = Object.entries(normalized)
      .some(([key, value]) => this.settings[key] !== value);
    this.settings = {
      ...this.settings,
      ...normalized
    };
    return changed;
  }

  getSettings() {
    return this.settings;
  }

  updatePrivacy(next) {
    this.settings.privacy = { ...this.settings.privacy, ...next };
    this._save();
    return this.settings;
  }

  updateCapture(next) {
    const audioMode = ['off', 'meeting', 'always'].includes(next?.audioMode)
      ? next.audioMode
      : (next?.listeningEnabled === true ? 'always' : (next?.listeningEnabled === false ? 'off' : this.settings.capture.audioMode));
    const audioDeviceMode = ['default', 'input', 'output', 'input-output', 'custom'].includes(next?.audioDeviceMode)
      ? next.audioDeviceMode
      : this.settings.capture.audioDeviceMode;
    const audioTranscriptionEngine = [
      'disabled',
      'whisper-tiny',
      'whisper-tiny-quantized'
    ].includes(next?.audioTranscriptionEngine)
      ? next.audioTranscriptionEngine
      : this.settings.capture.audioTranscriptionEngine;
    const audioDeviceNames = Array.isArray(next?.audioDeviceNames)
      ? next.audioDeviceNames.map((name) => String(name || '').trim()).filter(Boolean).slice(0, 4)
      : this.settings.capture.audioDeviceNames;
    const requestedVisionMode = ['normal', 'off'].includes(next?.visionMode)
      ? next.visionMode
      : (this.settings.capture.visionMode || 'off');
    const visionMode = SCREENPIPE_VISION_FORCE_DISABLED ? 'off' : requestedVisionMode;

    this.settings.capture = {
      ...this.settings.capture,
      listeningEnabled: audioMode !== 'off',
      audioMode,
      audioDeviceMode,
      audioDeviceNames,
      audioTranscriptionEngine,
      visionMode
    };
    this._save();
    return this.settings;
  }

  updateConnection(next) {
    const baseUrl = next?.screenpipeBaseUrl;
    if (baseUrl !== undefined && !isLoopbackScreenpipeBaseUrl(baseUrl)) {
      throw new Error('Screenpipe base URL must be a local http://127.0.0.1 port.');
    }
    this.settings = {
      ...this.settings,
      ...next
    };
    this._save();
    return this.settings;
  }

  updateProfile(next) {
    const name = String(next?.name || '').trim().slice(0, 120);
    const email = String(next?.email || '').trim().slice(0, 160);
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      throw new Error('Enter a valid email address');
    }

    this.settings.profile = {
      ...this.settings.profile,
      name,
      email
    };
    this._save();
    return this.settings;
  }

  updateRoleProfile(next) {
    const role = String(next?.role || '').trim().slice(0, 120);
    const roleId = String(next?.roleId || '').trim().slice(0, 80);
    const roleSource = ['confirmed_detected', 'confirmed_selected', 'custom'].includes(next?.roleSource)
      ? next.roleSource
      : (roleId === 'custom' ? 'custom' : 'confirmed_selected');
    const roleNotes = String(next?.roleNotes || '').trim().slice(0, 1000);
    this.settings.profile = {
      ...this.settings.profile,
      role,
      roleId,
      roleSource,
      roleNotes,
      roleConfirmedAt: new Date().toISOString()
    };
    this._save();
    return this.settings;
  }

  updateRoleDetection(next) {
    this.settings.profile = {
      ...this.settings.profile,
      roleDetection: {
        ...this.settings.profile.roleDetection,
        ...next
      }
    };
    this._save();
    return this.settings;
  }

  updateOnboarding(next) {
    const dismissed = Array.isArray(next?.dismissedHelpCards)
      ? next.dismissedHelpCards.map((item) => String(item || '').trim()).filter(Boolean).slice(0, 50)
      : this.settings.onboarding.dismissedHelpCards;
    this.settings.onboarding = {
      ...this.settings.onboarding,
      ...next,
      completedAt: next?.completedAt === true
        ? new Date().toISOString()
        : (typeof next?.completedAt === 'string' ? next.completedAt : this.settings.onboarding.completedAt),
      dismissedHelpCards: dismissed
    };
    this._save();
    return this.settings;
  }

  updateRetentionDays(retentionDays) {
    return this.updateRetentionSettings({ retentionDays });
  }

  updateRetentionSettings(next) {
    if (!next || typeof next !== 'object') {
      return this.updateRetentionSettings({ retentionDays: next });
    }

    const candidate = {
      ...this.settings
    };
    if (next.retentionDays !== undefined) {
      candidate.retentionDays = validateInteger(
        next.retentionDays,
        'Retention days',
        MIN_RETENTION_DAYS,
        MAX_EVIDENCE_RETENTION_DAYS
      );
      if (next.reportCacheRetentionDays === undefined) {
        candidate.reportCacheRetentionDays = candidate.retentionDays;
      }
    }
    if (next.screenpipeRawRetentionDays !== undefined) {
      candidate.screenpipeRawRetentionDays = validateInteger(
        next.screenpipeRawRetentionDays,
        'Raw capture buffer days',
        MIN_RETENTION_DAYS,
        MAX_SCREENPIPE_RAW_RETENTION_DAYS
      );
    }
    if (next.screenpipeRawRetentionHardCapDays !== undefined) {
      candidate.screenpipeRawRetentionHardCapDays = validateInteger(
        next.screenpipeRawRetentionHardCapDays,
        'Raw capture hard cap days',
        MIN_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS,
        MAX_SCREENPIPE_RAW_RETENTION_HARD_CAP_DAYS
      );
    }
    if (next.reportCacheRetentionDays !== undefined) {
      candidate.reportCacheRetentionDays = validateInteger(
        next.reportCacheRetentionDays,
        'Report cache retention days',
        MIN_RETENTION_DAYS,
        MAX_EVIDENCE_RETENTION_DAYS
      );
    }

    this.settings = {
      ...this.settings,
      ...normalizeRetentionSettings(candidate)
    };
    this._save();
    return this.settings;
  }
}

module.exports = {
  SettingsService,
  defaultScreenpipeApiKey,
  defaultScreenpipeBaseUrl,
  defaultScreenpipePort,
  effectiveScreenpipeRetention,
  normalizeRetentionSettings,
  isLoopbackScreenpipeBaseUrl
};
