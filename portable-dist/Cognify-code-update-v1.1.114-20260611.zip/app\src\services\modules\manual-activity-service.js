const crypto = require('crypto');

const MINUTE_MS = 60 * 1000;
const ACTIVE_MINUTE_THRESHOLD_MS = 30 * 1000;
const MAX_MANUAL_BLOCK_MS = 12 * 60 * 60 * 1000;
const FUTURE_GRACE_MS = 60 * 1000;

function prepareManualActivityBlock(payload = {}, options = {}) {
  const nowMs = new Date(options.now || new Date()).getTime();
  const startMs = new Date(payload.startTime).getTime();
  const endMs = new Date(payload.endTime).getTime();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
    throw new Error('Manual block needs a valid start and end time.');
  }
  if ((endMs - startMs) < MINUTE_MS) {
    throw new Error('Manual block must be at least 1 minute.');
  }
  if ((endMs - startMs) > MAX_MANUAL_BLOCK_MS) {
    throw new Error('Manual block cannot be longer than 12 hours.');
  }
  if (Number.isFinite(nowMs) && endMs > nowMs + FUTURE_GRACE_MS) {
    throw new Error('Manual block cannot be saved for future time.');
  }

  const rawKind = String(payload.kind || 'work').trim().toLowerCase();
  if (!['work', 'meeting', 'break', 'other'].includes(rawKind)) {
    throw new Error('Choose a valid manual type.');
  }
  const kind = normalizeManualKind(rawKind);
  const note = String(payload.note || '').trim().slice(0, 240);
  if (!note) {
    throw new Error('Add a short note before saving manual time.');
  }

  const label = {
    work: 'Offline Work',
    meeting: 'Offline Meeting',
    break: 'Break',
    other: 'Manual Entry'
  }[kind];
  const id = crypto
    .createHash('sha1')
    .update(JSON.stringify(['manual', startMs, endMs, kind, note]))
    .digest('hex');
  const parentId = `manual-${id}`;
  const impact = manualBlockImpact({
    startMs,
    endMs,
    kind,
    idleIntervals: options.idleIntervals || []
  });
  const segments = splitLocalDaySegments(startMs, endMs);
  const records = segments.map((segment, index) => ({
    id: segments.length === 1 ? parentId : `${parentId}-${index + 1}`,
    type: 'manual',
    activity_type: 'manual',
    source: 'manual',
    manual_parent_id: parentId,
    manual_segment_index: index + 1,
    manual_segment_count: segments.length,
    manual_kind: kind,
    manual_start_time: new Date(startMs).toISOString(),
    manual_end_time: new Date(endMs).toISOString(),
    manual_local_date_key: segment.localDateKey,
    timestamp_start: new Date(segment.startMs).toISOString(),
    timestamp_end: new Date(segment.endMs).toISOString(),
    app_name: label,
    window_title: `${label}: ${note}`,
    ocr_text: note,
    duration_ms_estimate: segment.endMs - segment.startMs,
    confidence_score: 1
  }));
  const record = records[0];

  return {
    record,
    records,
    block: {
      start_time: new Date(startMs).toISOString(),
      end_time: new Date(endMs).toISOString(),
      minutes: impact.manual_minutes,
      kind,
      note,
      manual_local_date_key: segments.length === 1 ? segments[0].localDateKey : null,
      segments: records.map((entry) => ({
        start_time: entry.timestamp_start,
        end_time: entry.timestamp_end,
        minutes: Math.round(Number(entry.duration_ms_estimate || 0) / MINUTE_MS),
        manual_local_date_key: entry.manual_local_date_key
      }))
    },
    impact
  };
}

function manualActivitySaveResponse({ result = {}, block = {}, impact = {} } = {}) {
  const inserted = Math.max(0, Math.round(Number(result.inserted || 0)));
  const replaced = Math.max(0, Math.round(Number(result.replaced || 0)));
  const deduped = Math.max(0, Math.round(Number(result.deduped || 0)));
  const skippedDeleted = Math.max(0, Math.round(Number(result.skipped_deleted || 0)));
  const saved = inserted + replaced > 0;
  const alreadySaved = !saved && deduped > 0;
  const secondary = result.dual_write?.secondary || null;
  const backupOk = !secondary || secondary.ok !== false;

  if (!saved && !alreadySaved) {
    const reason = skippedDeleted > 0
      ? 'Manual block overlaps a deleted time range and was not saved.'
      : 'Manual block was not saved. Try again.';
    throw new Error(reason);
  }

  const status = alreadySaved
    ? 'already_saved'
    : (backupOk ? 'saved' : 'saved_with_warning');
  const message = manualSaveMessage(status, impact, backupOk);
  return {
    ok: true,
    status,
    saved,
    already_saved: alreadySaved,
    message,
    block,
    impact,
    store: {
      inserted,
      replaced,
      deduped,
      skipped_deleted: skippedDeleted,
      backup_ok: backupOk,
      backup_error: backupOk ? null : (secondary.error || 'Backup store did not accept the entry.')
    }
  };
}

function manualSaveMessage(status, impact = {}, backupOk = true) {
  const restored = Math.max(0, Math.round(Number(impact.work_restored_minutes || 0)));
  const manual = Math.max(0, Math.round(Number(impact.manual_minutes || 0)));
  const idle = Math.max(0, Math.round(Number(impact.idle_overlap_minutes || 0)));
  if (status === 'already_saved') {
    return 'Already saved. This manual block was not added again.';
  }
  if (!backupOk) {
    const restoredText = restored > 0 ? ` ${restored}m can still restore Work Hours from deducted idle.` : '';
    return `${manual}m saved locally, but backup storage needs attention.${restoredText}`;
  }
  if (restored > 0) {
    return `${manual}m saved. ${restored}m can restore Work Hours from deducted idle.`;
  }
  if (idle > 0 && !impact.affects_work_hours) {
    return `${manual}m saved as evidence. Break/other time does not add Work Hours.`;
  }
  return `${manual}m saved as evidence. It did not change Work Hours because it did not overlap deducted idle.`;
}

function manualBlockImpact({ startMs, endMs, kind = 'work', idleIntervals = [] } = {}) {
  const normalizedKind = normalizeManualKind(kind);
  const manualMinuteKeys = minuteKeysForInterval(startMs, endMs);
  const idleMinuteKeys = new Set();
  manualMinuteKeys.forEach((key) => {
    const minuteMs = new Date(key).getTime();
    if (minuteOverlapsIntervals(minuteMs, idleIntervals)) {
      idleMinuteKeys.add(key);
    }
  });
  const canRestoreWork = normalizedKind === 'work' || normalizedKind === 'meeting';
  const restored = canRestoreWork ? idleMinuteKeys.size : 0;
  return {
    manual_minutes: manualMinuteKeys.length,
    idle_overlap_minutes: idleMinuteKeys.size,
    work_restored_minutes: restored,
    non_impact_minutes: Math.max(0, manualMinuteKeys.length - restored),
    affects_work_hours: restored > 0,
    rule: 'Manual work/meeting only restores minutes that were already deducted as idle. It never overrides PC-active time.'
  };
}

function normalizeManualKind(kind = 'work') {
  const value = String(kind || 'work').trim().toLowerCase();
  return ['work', 'meeting', 'break', 'other'].includes(value) ? value : 'other';
}

function localDateKeyFromMs(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) {
    return '';
  }
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function nextLocalMidnightMs(value) {
  const date = new Date(value);
  date.setHours(24, 0, 0, 0);
  return date.getTime();
}

function splitLocalDaySegments(startMs, endMs) {
  const segments = [];
  let cursor = startMs;
  while (cursor < endMs) {
    const segmentEndMs = Math.min(nextLocalMidnightMs(cursor), endMs);
    segments.push({
      startMs: cursor,
      endMs: segmentEndMs,
      localDateKey: localDateKeyFromMs(cursor)
    });
    cursor = segmentEndMs;
  }
  return segments;
}

function manualSlotKeyFromRange(startTime, endTime) {
  const startMs = Number.isFinite(Number(startTime)) ? Number(startTime) : new Date(startTime || 0).getTime();
  const endMs = Number.isFinite(Number(endTime)) ? Number(endTime) : new Date(endTime || 0).getTime();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
    return null;
  }
  return `${new Date(startMs).toISOString()}|${new Date(endMs).toISOString()}`;
}

function isManualTimingRecord(record = {}) {
  const source = String(record.source || '').toLowerCase();
  const activityType = String(record.activity_type || record.type || '').toLowerCase();
  return source === 'manual' || activityType === 'manual';
}

function manualRecordSlotKey(record = {}) {
  if (!isManualTimingRecord(record)) {
    return null;
  }
  const parentStart = record.manual_parent_start_time || record.manual_start_time;
  const parentEnd = record.manual_parent_end_time || record.manual_end_time;
  return manualSlotKeyFromRange(
    parentStart || record.timestamp_start || record.start || record.start_time,
    parentEnd || record.timestamp_end || record.end || record.end_time
  );
}

function manualConsumedSlots(records = []) {
  const seen = new Set();
  return (Array.isArray(records) ? records : [])
    .map((record) => {
      const key = manualRecordSlotKey(record);
      if (!key || seen.has(key)) {
        return null;
      }
      seen.add(key);
      const [start, end] = key.split('|');
      return { key, start, end };
    })
    .filter(Boolean);
}

function manualSlotAlreadyConsumed(records = [], startTime, endTime) {
  const target = manualSlotKeyFromRange(startTime, endTime);
  if (!target) {
    return false;
  }
  return (Array.isArray(records) ? records : []).some((record) => manualRecordSlotKey(record) === target);
}

function minuteKeysForInterval(startMs, endMs) {
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
    return [];
  }
  const keys = [];
  const firstMinuteMs = Math.floor(startMs / MINUTE_MS) * MINUTE_MS;
  for (let cursor = firstMinuteMs; cursor < endMs; cursor += MINUTE_MS) {
    const overlap = Math.max(0, Math.min(cursor + MINUTE_MS, endMs) - Math.max(cursor, startMs));
    if (overlap >= ACTIVE_MINUTE_THRESHOLD_MS) {
      keys.push(new Date(cursor).toISOString());
    }
  }
  return keys;
}

function minuteOverlapsIntervals(minuteMs, intervals = []) {
  const startMs = minuteMs;
  const endMs = minuteMs + MINUTE_MS;
  return intervals.some((interval) => {
    const intervalStartMs = Number.isFinite(Number(interval.startMs))
      ? Number(interval.startMs)
      : new Date(interval.start || interval.start_time || 0).getTime();
    const intervalEndMs = Number.isFinite(Number(interval.endMs))
      ? Number(interval.endMs)
      : new Date(interval.end || interval.end_time || 0).getTime();
    if (!Number.isFinite(intervalStartMs) || !Number.isFinite(intervalEndMs)) {
      return false;
    }
    return Math.max(0, Math.min(endMs, intervalEndMs) - Math.max(startMs, intervalStartMs)) >= ACTIVE_MINUTE_THRESHOLD_MS;
  });
}

module.exports = {
  prepareManualActivityBlock,
  manualActivitySaveResponse,
  manualBlockImpact,
  normalizeManualKind,
  manualSlotKeyFromRange,
  manualRecordSlotKey,
  manualConsumedSlots,
  manualSlotAlreadyConsumed,
  isManualTimingRecord
};
