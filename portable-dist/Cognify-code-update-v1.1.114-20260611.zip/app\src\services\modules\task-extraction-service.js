const fs = require('fs');
const path = require('path');

const DEFAULT_CONFIG = {
  thresholds: {
    high_confidence: 0.78,
    needs_review: 0.58,
    max_title_length: 120,
    max_records: 800,
    max_lines: 2000,
    max_candidates: 60,
    max_related_scan_lines: 2000
  },
  intent_patterns: [
    '\\b(to\\s*do|todo|follow\\s*up|follow-up|followup|pending\\s+task|pending\\s+follow\\s*up|lets?\\s+do\\s+later|let\'?s\\s+do\\s+later|do\\s+it\\s+later|do\\s+later|will\\s+take\\s*up\\s+later|take\\s*up\\s+later|takeup\\s+later|do\\s+tomorrow|tomorrow\'?s?\\s+task|next\\s+step|action\\s+item)\\b'
  ],
  resolution_patterns: [
    '\\b(done|completed|complete|resolved|closed|fixed|sent|submitted|shared|updated|reviewed|replied|responded|scheduled|cancelled|canceled|no longer needed|not required|merged|approved)\\b'
  ],
  priority_patterns: {
    high: '\\b(urgent|asap|today|eod|end\\s+of\\s+day|blocked|critical)\\b',
    medium: '\\b(tomorrow|next\\s+step|follow\\s*up|pending)\\b'
  },
  weak_context_patterns: [
    '^google chrome$',
    '^microsoft edge$',
    '^chrome$',
    '^edge$',
    '^powershell$',
    '^windows powershell$',
    '^terminal$',
    '^file explorer$'
  ],
  confidence_weights: {
    explicit_intent: 0.42,
    deadline_or_priority: 0.12,
    work_context: 0.1,
    manual_or_transcript: 0.08,
    repeated_evidence: 0.12,
    specific_title: 0.08,
    weak_context_penalty: -0.08
  }
};

function compilePatterns(patterns = []) {
  return patterns
    .map((pattern) => {
      try {
        return new RegExp(pattern, 'i');
      } catch {
        return null;
      }
    })
    .filter(Boolean);
}

class TaskExtractionService {
  constructor(config = null) {
    this.config = config || loadTaskExtractionConfig();
    this.intentPatterns = compilePatterns(this.config.intent_patterns);
    this.resolutionPatterns = compilePatterns(this.config.resolution_patterns);
    this.weakContextPatterns = compilePatterns(this.config.weak_context_patterns);
    this.highPriorityPattern = new RegExp(this.config.priority_patterns?.high || DEFAULT_CONFIG.priority_patterns.high, 'i');
    this.mediumPriorityPattern = new RegExp(this.config.priority_patterns?.medium || DEFAULT_CONFIG.priority_patterns.medium, 'i');
  }

  async extract(records = [], options = {}) {
    const limits = this._limits(options);
    const candidates = [];
    const screenLines = this._screenLines(records, limits);

    for (const { line, record, timestampMs } of screenLines) {
      if (candidates.length >= limits.maxCandidates) {
        break;
      }
      if (!this._looksLikeTask(line)) {
        continue;
      }

      const keywords = this._keywords(line);
      const relatedEvidenceCount = this._relatedEvidenceCount(keywords, screenLines, limits);
      const confidence = this._confidenceForLine(line, record, relatedEvidenceCount);
      candidates.push({
        task_title: this._cleanTaskTitle(line),
        context: this._contextLabel(record),
        source_timestamp: record.timestamp_start || null,
        priority: this._priorityForLine(line),
        confidence_score: confidence,
        confidence_label: this._confidenceLabel(confidence),
        evidence_count: relatedEvidenceCount,
        suggested_due_date: /tomorrow/i.test(line)
          ? new Date(Date.now() + 86400000).toISOString().slice(0, 10)
          : null,
        evidence_line: line,
        evidence_sources: this._evidenceSources(line, record, screenLines, keywords),
        keywords,
        timestampMs
      });
    }

    return this._dedupeTasks(candidates.map((task) => {
      const resolution = this._resolvePendingStatus(task, screenLines);
      return {
        ...task,
        status: resolution.status,
        status_reason: resolution.reason,
        resolution_evidence: resolution.evidence
      };
    })).map(({ timestampMs, keywords, ...task }) => task);
  }

  _limits(options = {}) {
    const thresholds = this.config.thresholds || DEFAULT_CONFIG.thresholds;
    return {
      maxRecords: Math.max(1, Number(options.maxRecords || thresholds.max_records || DEFAULT_CONFIG.thresholds.max_records)),
      maxLines: Math.max(1, Number(options.maxLines || thresholds.max_lines || DEFAULT_CONFIG.thresholds.max_lines)),
      maxCandidates: Math.max(1, Number(options.maxCandidates || thresholds.max_candidates || DEFAULT_CONFIG.thresholds.max_candidates)),
      maxRelatedScanLines: Math.max(1, Number(options.maxRelatedScanLines || thresholds.max_related_scan_lines || DEFAULT_CONFIG.thresholds.max_related_scan_lines))
    };
  }

  _screenLines(records = [], limits = this._limits()) {
    const lines = [];
    const selectedRecords = records.length > limits.maxRecords
      ? records.slice(records.length - limits.maxRecords)
      : records;

    for (const record of selectedRecords) {
      const corpus = `${record.ocr_text || ''}\n${record.transcript_text || ''}`;
      const rawLines = corpus.split(/\n+/);
      for (const line of rawLines) {
        if (lines.length >= limits.maxLines) {
          break;
        }
        const normalized = line.trim();
        if (!normalized) {
          continue;
        }

        lines.push({
          line: normalized,
          normalized: this._normalizeText(normalized),
          keywords: this._keywords(normalized),
          timestampMs: new Date(record.timestamp_start || 0).getTime(),
          record
        });
      }
      if (lines.length >= limits.maxLines) {
        break;
      }
    }

    return lines.sort((left, right) => Number(left.timestampMs || 0) - Number(right.timestampMs || 0));
  }

  _looksLikeTask(line) {
    return this._hasExplicitFollowUpIntent(line);
  }

  _hasExplicitFollowUpIntent(line) {
    return this.intentPatterns.some((pattern) => pattern.test(line));
  }

  _isResolutionLine(line) {
    return this.resolutionPatterns.some((pattern) => pattern.test(line));
  }

  _resolvePendingStatus(task, screenLines) {
    if (this._isResolutionLine(task.evidence_line)) {
      return {
        status: 'resolved',
        reason: 'Task-like line already contains completion or resolution language.',
        evidence: task.evidence_line
      };
    }

    const tokens = task.keywords || this._keywords(task.evidence_line);
    const laterResolution = screenLines.find((entry) => {
      if (!Number.isFinite(entry.timestampMs) || !Number.isFinite(task.timestampMs) || entry.timestampMs < task.timestampMs) {
        return false;
      }
      if (!this._isResolutionLine(entry.line)) {
        return false;
      }

      return this._overlapCount(tokens, entry.keywords || this._keywords(entry.line)) >= Math.min(3, Math.max(1, tokens.length));
    });

    if (laterResolution) {
      return {
        status: 'resolved',
        reason: 'Later screen text appears to complete the same item.',
        evidence: laterResolution.line
      };
    }

    if (this._hasExplicitFollowUpIntent(task.evidence_line)) {
      return {
        status: 'pending',
        reason: 'Explicit follow-up wording found and no later completion evidence was detected.',
        evidence: task.evidence_line
      };
    }

    return {
      status: 'candidate',
      reason: 'Task-like wording found, but screen data does not prove it is still pending.',
      evidence: task.evidence_line
    };
  }

  _dedupeTasks(tasks = []) {
    const byKey = new Map();

    tasks.forEach((task) => {
      const key = this._keywords(task.task_title).slice(0, 8).join(' ');
      if (!key) {
        return;
      }

      const existing = byKey.get(key);
      if (!existing || this._taskRank(task) > this._taskRank(existing)) {
        byKey.set(key, task);
      }
    });

    return Array.from(byKey.values())
      .sort((left, right) => {
        const statusDelta = this._taskRank(right) - this._taskRank(left);
        if (statusDelta) return statusDelta;
        return Number(right.timestampMs || 0) - Number(left.timestampMs || 0);
      });
  }

  _taskRank(task) {
    const statusScore = { pending: 3, candidate: 2, resolved: 1 };
    return (statusScore[task.status] || 0) * 100 + Number(task.confidence_score || 0);
  }

  _priorityForLine(line) {
    if (this.highPriorityPattern.test(line)) {
      return 'high';
    }
    if (this.mediumPriorityPattern.test(line)) {
      return 'medium';
    }
    return 'normal';
  }

  _confidenceForLine(line, record, relatedEvidenceCount = 1) {
    const weights = this.config.confidence_weights || DEFAULT_CONFIG.confidence_weights;
    let score = 0.25;
    if (this._hasExplicitFollowUpIntent(line)) score += Number(weights.explicit_intent || 0);
    if (this.highPriorityPattern.test(line) || this.mediumPriorityPattern.test(line)) score += Number(weights.deadline_or_priority || 0);
    if (this._hasWorkContext(record)) score += Number(weights.work_context || 0);
    if (record.source === 'manual' || record.transcript_text) score += Number(weights.manual_or_transcript || 0);
    if (relatedEvidenceCount > 1) score += Number(weights.repeated_evidence || 0);
    if (this._contextIsSpecific(record)) score += Number(weights.specific_title || 0);
    if (this._isWeakContext(this._contextLabel(record))) score += Number(weights.weak_context_penalty || 0);
    return Math.max(0.1, Math.min(0.98, Number(score.toFixed(2))));
  }

  _confidenceLabel(score) {
    const thresholds = this.config.thresholds || DEFAULT_CONFIG.thresholds;
    if (score >= Number(thresholds.high_confidence || 0.78)) {
      return 'High';
    }
    if (score >= Number(thresholds.needs_review || 0.58)) {
      return 'Needs Review';
    }
    return 'Low';
  }

  _cleanTaskTitle(line) {
    const maxLength = Number(this.config.thresholds?.max_title_length || 120);
    const cleaned = String(line || '')
      .replace(/^\s*(todo|to do|action item|next step|pending task)\s*[:\-]?\s*/i, '')
      .replace(/\s+/g, ' ')
      .trim();
    return cleaned.slice(0, maxLength) || String(line || '').slice(0, maxLength);
  }

  _contextLabel(record = {}) {
    return record.window_title || record.app_name || record.url_if_available || 'Unknown';
  }

  _hasWorkContext(record = {}) {
    const text = [
      record.app_name,
      record.window_title,
      record.url_if_available,
      record.classification
    ].filter(Boolean).join(' ');
    return /\b(code|github|jira|portal|admin|sales|crm|support|legal|design|figma|excel|sheet|docs|mail|outlook|teams|slack|meet|zoom|work)\b/i.test(text);
  }

  _contextIsSpecific(record = {}) {
    const context = this._contextLabel(record);
    return context.length >= 12 && !this._isWeakContext(context);
  }

  _isWeakContext(context = '') {
    const normalized = String(context || '').replace(/\.exe$/i, '').trim();
    return this.weakContextPatterns.some((pattern) => pattern.test(normalized));
  }

  _relatedEvidenceCount(tokensOrLine, screenLines, limits = this._limits()) {
    const tokens = Array.isArray(tokensOrLine) ? tokensOrLine : this._keywords(tokensOrLine);
    if (!tokens.length) {
      return 1;
    }
    const scanLines = screenLines.length > limits.maxRelatedScanLines
      ? screenLines.slice(screenLines.length - limits.maxRelatedScanLines)
      : screenLines;
    let count = 0;
    for (const entry of scanLines) {
      if (this._overlapCount(tokens, entry.keywords || this._keywords(entry.line)) >= Math.min(3, tokens.length)) {
        count += 1;
      }
    }
    return count;
  }

  _evidenceSources(line, record, screenLines, lineKeywords = null) {
    const sources = [{
      type: record.transcript_text ? 'transcript_or_screen' : 'screen',
      label: this._contextLabel(record),
      text: line
    }];
    const tokens = lineKeywords || this._keywords(line);
    screenLines.forEach((entry) => {
      if (sources.length >= 4 || entry.line === line) {
        return;
      }
      if (this._overlapCount(tokens, entry.keywords || this._keywords(entry.line)) >= Math.min(3, Math.max(1, tokens.length))) {
        sources.push({
          type: entry.record?.transcript_text ? 'transcript_or_screen' : 'screen',
          label: this._contextLabel(entry.record || {}),
          text: entry.line
        });
      }
    });
    return sources;
  }

  _normalizeText(value) {
    return String(value || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  _keywords(value) {
    const stop = new Set(['todo', 'follow', 'up', 'followup', 'pending', 'task', 'later', 'tomorrow', 'takeup', 'take', 'action', 'item', 'next', 'step', 'please', 'need', 'needs', 'send', 'review', 'fix', 'prepare', 'the', 'and', 'for', 'with', 'this', 'that', 'from', 'to', 'in', 'on', 'at', 'a', 'an', 'is', 'are', 'was', 'were']);
    return this._normalizeText(value)
      .split(' ')
      .filter((token) => token.length >= 3 && !stop.has(token))
      .slice(0, 12);
  }

  _overlapCount(left = [], right = []) {
    const rightSet = new Set(right);
    return left.filter((token) => rightSet.has(token)).length;
  }
}

function loadTaskExtractionConfig() {
  const candidates = [
    path.resolve(__dirname, '..', '..', '..', 'config', 'task-extraction-rules.json'),
    path.resolve(process.cwd(), 'config', 'task-extraction-rules.json')
  ];
  const configPath = candidates.find((candidate) => fs.existsSync(candidate));
  if (!configPath) {
    return DEFAULT_CONFIG;
  }
  try {
    const loaded = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    return {
      ...DEFAULT_CONFIG,
      ...loaded,
      thresholds: {
        ...DEFAULT_CONFIG.thresholds,
        ...(loaded.thresholds || {})
      },
      priority_patterns: {
        ...DEFAULT_CONFIG.priority_patterns,
        ...(loaded.priority_patterns || {})
      },
      confidence_weights: {
        ...DEFAULT_CONFIG.confidence_weights,
        ...(loaded.confidence_weights || {})
      }
    };
  } catch {
    return DEFAULT_CONFIG;
  }
}

module.exports = { TaskExtractionService, loadTaskExtractionConfig };
