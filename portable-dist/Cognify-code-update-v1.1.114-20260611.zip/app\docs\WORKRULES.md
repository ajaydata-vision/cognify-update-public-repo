# Work Rules

This file is the source of truth for how Cognify should classify captured screen activity into:

- `work`
- `other`
- `unclear`

The intent is simple:

- change this file
- rerun classification logic
- get different `Work` vs `Other` results without changing core code

This is the policy layer. Storage, learning, personalization, and UI should follow this file rather than invent separate rule systems.

## Classification Contract

Every captured event or grouped session should eventually resolve to:

- `classification`: `work | other | unclear`
- `confidence`: `high | medium | low`
- `matched_rules`: list of rule ids that caused the decision

Rules should be applied at the most specific useful level:

1. URL/domain
2. app + window title
3. OCR text
4. app-only fallback
5. default to `unclear`

## Rule Precedence

Rules must be evaluated in this order:

1. Explicit user overrides
2. Hard excludes and privacy blocks
3. Strong work rules
4. Strong other rules
5. Weak work rules
6. Weak other rules
7. Fallback `unclear`

When multiple rules match:

- stronger confidence wins
- more specific signal wins over less specific signal
- URL/domain wins over app-only
- title + app wins over app-only
- if conflict remains, classify as `unclear`

## Guardrails

These rules matter before any work/other split:

- Do not classify `System Process` as work or other. Keep it out of user-facing totals.
- Do not treat Cognify's own local panel/orb as productive work.
- Do not treat Remote Desktop as self-capture just because OCR inside the remote session contains Cognify text.
- Private/incognito windows should remain privacy-filtered before classification.
- Sensitive surfaces such as banking, payments, OTP, and password entry should not be surfaced as detailed productivity content.

## Labels

### `work`

Use for activity directly related to job, business, professional output, study with clear task intent, or active execution of a project.

Examples:

- coding
- debugging
- terminals
- repo browsing
- documentation
- ticketing systems
- internal dashboards
- meetings
- work chat
- cloud consoles
- remote desktop into a work machine
- research clearly tied to an active task

### `other`

Use for non-work activity, passive entertainment, personal browsing, distraction, shopping, social use, or general drift not tied to a concrete task.

Examples:

- entertainment video
- social feeds
- memes
- random browsing
- shopping
- celebrity/news drift
- music browsing
- gaming

### `unclear`

Use when there is not enough evidence to classify safely.

Examples:

- generic browser tab with no URL
- ambiguous file explorer use
- unknown apps
- OCR too weak to infer intent

## Rule Format

Each rule should have:

- `id`
- `class`
- `confidence`
- `match_type`
- `patterns`
- `notes`

Target structure for future parser:

```text
id: work.github.repo
class: work
confidence: high
match_type: domain
patterns:
  - github.com
notes: Repository browsing, PR review, issues, code search
```

The current file is human-authored Markdown, but the rule blocks below are deliberately structured so they can be parsed later.

Important parser rule:

- only bullet entries wrapped in backticks are machine-readable patterns
- plain-language bullets are commentary, not executable patterns
- if a rule needs richer structure later, add explicit machine fields rather than relying on prose

## User Override Rules

These should eventually be editable from settings and applied before everything else.

Configured work domains and TLDs are also applied before generic browser ambiguity. They are stored in settings as `classification.workDomains` and `classification.workTlds`, matching exact domains, subdomains, URL hosts, domains extracted from titles/OCR, and email domains found in titles/OCR.

### `override.work.app`

- class: `work`
- confidence: `high`
- match_type: `app`
- patterns:
  - user-maintained

### `override.work.domain`

- class: `work`
- confidence: `high`
- match_type: `domain`
- patterns:
  - user-maintained

### `override.other.app`

- class: `other`
- confidence: `high`
- match_type: `app`
- patterns:
  - user-maintained

### `override.other.domain`

- class: `other`
- confidence: `high`
- match_type: `domain`
- patterns:
  - user-maintained

## Strong Work Rules

### `work.app.ide`

- class: `work`
- confidence: `high`
- match_type: `app`
- patterns:
  - `code.exe`
  - `cursor.exe`
  - `windsurf.exe`
  - `pycharm*.exe`
  - `webstorm*.exe`
  - `idea*.exe`
  - `notepad++.exe`
- notes: coding and editing environments are almost always work

### `work.app.terminal`

- class: `work`
- confidence: `high`
- match_type: `app`
- patterns:
  - `windowsterminal.exe`
  - `powershell.exe`
  - `cmd.exe`
  - `bash.exe`
  - `wsl.exe`
  - `warp.exe`
- notes: shells are treated as work by default

### `work.app.remote_desktop`

- class: `work`
- confidence: `high`
- match_type: `app_or_title`
- patterns:
  - `mstsc.exe`
  - `Remote Desktop Connection`
  - ` - Remote Desktop Connection`
- notes: remote desktop is work by default unless a future explicit override says otherwise

### `work.app.office_tools`

- class: `work`
- confidence: `high`
- match_type: `app`
- patterns:
  - `excel.exe`
  - `winword.exe`
  - `powerpnt.exe`
  - `onenote.exe`
  - `outlook.exe`
  - `msaccess.exe`
  - `mspub.exe`
  - `visio.exe`
  - `winproj.exe`
- notes: Office tools are work by default; explicit personal-title hints can override this

### `work.app.ai_tools`

- class: `work`
- confidence: `high`
- match_type: `app`
- patterns:
  - `chatgpt.exe`
  - `claude.exe`
  - `copilot.exe`
- notes: AI desktop tools are work by default when used as productivity, writing, research, or coding tools

### `work.domain.repo`

- class: `work`
- confidence: `high`
- match_type: `domain`
- patterns:
  - `github.com`
  - `gitlab.com`
    - `bitbucket.org`
- notes: repository, PR, issue, and code-host activity

### `work.domain.docs`

- class: `work`
- confidence: `high`
- match_type: `domain`
- patterns:
  - `docs.google.com`
  - `notion.so`
  - `confluence`
  - `readthedocs`
  - `developer.mozilla.org`
  - `learn.microsoft.com`
  - `platform.openai.com`
  - `chat.openai.com`
  - `chatgpt.com`
  - `claude.ai`
  - `console.anthropic.com`
  - `gemini.google.com`
  - `aistudio.google.com`
  - `perplexity.ai`
  - `poe.com`
  - `copilot.microsoft.com`
- notes: documentation and drafting; `chat.openai.com` counts as work only when used for task execution, drafting, coding, or research

### `work.domain.tasking`

- class: `work`
- confidence: `high`
- match_type: `domain`
- patterns:
  - `jira`
  - `atlassian.net`
  - `linear.app`
  - `trello.com`
  - `asana.com`
  - `clickup.com`
- notes: issue and task management

### `work.domain.comms`

- class: `work`
- confidence: `high`
- match_type: `domain_or_app`
- patterns:
  - `slack.com`
  - `teams.microsoft.com`
  - `meet.google.com`
  - `zoom`
  - `outlook.office.com`
  - `mail.google.com`
- notes: work communication and meetings
  Discord may later get an explicit work override, but it should not classify as work by default.

### `work.domain.cloud`

- class: `work`
- confidence: `high`
- match_type: `domain`
- patterns:
  - `console.aws.amazon.com`
  - `portal.azure.com`
  - `cloud.google.com`
  - `vercel.com`
  - `netlify.com`
  - `railway.app`
  - `render.com`
- notes: infra and deployment tools

### `work.title.task_keywords`

- class: `work`
- confidence: `medium`
- match_type: `title_or_text`
- patterns:
  - `pull request`
  - `merge request`
  - `issue`
  - `bug`
  - `sprint`
  - `deploy`
  - `release`
  - `invoice`
  - `proposal`
  - `client`
  - `ticket`
  - `roadmap`
  - `incident`
- notes: only use when stronger other rules do not match

## Strong Other Rules

### Office personal-title exception

- class: `other`
- confidence: `high`
- match_type: Office app plus title/text hint
- patterns:
  - `personal budget`
  - `household budget`
  - `family budget`
  - `wedding`
  - `vacation`
  - `holiday plan`
  - `recipe`
  - `personal expense`
  - `credit card statement`
  - `bank statement`
  - `resume`
  - `curriculum vitae`
- notes: implemented as a built-in compound rule; applies only when the active app is an Office tool, so personal documents do not inflate work time

### `other.domain.social`

- class: `other`
- confidence: `high`
- match_type: `domain`
- patterns:
  - `x.com`
  - `twitter.com`
  - `instagram.com`
  - `facebook.com`
  - `reddit.com`
  - `linkedin.com/feed`
- notes: feed browsing is other by default; specific future work exceptions can override

### `other.domain.entertainment_video`

- class: `other`
- confidence: `high`
- match_type: `domain`
- patterns:
  - `youtube.com`
  - `netflix.com`
  - `primevideo.com`
  - `hotstar.com`
  - `spotify.com`
- notes: treat as other unless a stronger work rule is present

### `other.domain.shopping`

- class: `other`
- confidence: `high`
- match_type: `domain`
- patterns:
  - `amazon.`
  - `flipkart.com`
  - `myntra.com`
  - `ebay.`
- notes: shopping and consumer browsing

### `other.domain.games`

- class: `other`
- confidence: `high`
- match_type: `domain`
- patterns:
  - `steampowered.com`
  - `steamcommunity.com`
  - `epicgames.com`
  - `roblox.com`
  - `minecraft.net`
  - `riotgames.com`
  - `leagueoflegends.com`
  - `battle.net`
  - `xbox.com`
- notes: gaming sites are confirmed non-work unless a user override says otherwise

### `other.app.games`

- class: `other`
- confidence: `high`
- match_type: `app`
- patterns:
  - `steam.exe`
  - `epicgameslauncher.exe`
  - `robloxplayerbeta.exe`
  - `minecraftlauncher.exe`
  - `riotclientservices.exe`
  - `leagueclient.exe`
  - `valorant.exe`
  - `battle.net.exe`
  - `xboxapp.exe`
- notes: game launchers and game clients are confirmed non-work unless a user override says otherwise

### `other.title.entertainment_keywords`

- class: `other`
- confidence: `medium`
- match_type: `title_or_text`
- patterns:
  - `watch later`
  - `home feed`
  - `shorts`
  - `reel`
  - `trending`
  - `playlist`
  - `episode`
  - `movie`
- notes: only use when no stronger work rule matches

## Weak Work Rules

### `work.browser.research`

- class: `work`
- confidence: `medium`
- match_type: `title_or_text`
- patterns:
  - `documentation`
  - `api reference`
  - `stack overflow`
  - `how to fix`
  - `error`
  - `exception`
    - `traceback`
- notes: browser research tied to execution

### `work.title.project_context`

- class: `work`
- confidence: `medium`
- match_type: `title_or_text`
- patterns:
  - `companion-agent`
  - `companion-agent-windows`
- notes: explicit local project names are active project context, including browser tabs, terminals, file explorer, and editor windows

### `work.file_explorer.project_context`

- class: `work`
- confidence: `low`
- match_type: `app_plus_text`
- patterns:
  - app: `explorer.exe`
  - text/title contains project folders, repos, docs, invoices, deliverables
- notes: weak until user overrides exist

## Weak Other Rules

### `other.browser.generic_drift`

- class: `other`
- confidence: `low`
- match_type: `title_or_text`
- patterns:
  - `news`
  - `celebrity`
  - `cricket`
  - `score`
  - `weather`
- notes: weak rule only

## Ambiguity Rules

When these match, prefer `unclear` unless a stronger rule already won:

### `unclear.generic_browser`

- class: `unclear`
- confidence: `low`
- match_type: `app_only`
- patterns:
  - `chrome.exe`
  - `msedge.exe`
  - `firefox.exe`
  - `brave.exe`
- notes: browser alone should never decide work vs other

### `unclear.unknown_app`

- class: `unclear`
- confidence: `low`
- match_type: `fallback`
- patterns:
  - missing app name
  - empty title
  - weak OCR

## Aggregation Rules

After event classification:

- adjacent events from the same app/title/url session should be merged
- session classification should normally follow the strongest rule that matched within that session
- if a session has both work and other evidence with similar strength, classify the session as `unclear`

Time totals should be reported as:

- `work_minutes`
- `other_minutes`
- `unclear_minutes`

And they should satisfy:

- `work + other + unclear <= selected range budget`

## Open Decisions

These need product decisions before we harden the engine:

- Is `YouTube` tutorial viewing work when the title/query is clearly task-related?
- Is `LinkedIn` always other, or can recruiter/client outreach count as work?
- Is `ChatGPT` work by default, or only when the surrounding title/text indicates active task execution?
- Should `Remote Desktop` always count as work, or should we inspect remote content too?
- Should meetings always count as work even if they are internal/non-productive?

## Next Implementation Step

When we wire this file into code, the classifier should:

1. parse this file into rule objects
2. classify events first
3. roll events into sessions
4. aggregate bounded time totals
5. expose both totals and matched-rule explanations
