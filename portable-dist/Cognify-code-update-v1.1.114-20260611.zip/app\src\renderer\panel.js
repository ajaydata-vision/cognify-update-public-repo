const output = document.getElementById('output');
const outputSection = document.getElementById('outputSection');
const expandOutput = document.getElementById('expandOutput');
const recording = document.getElementById('recording');
const listening = document.getElementById('listening');
const captureToggle = document.getElementById('captureToggle');
const focusEvents = document.getElementById('focusEvents');
const focusApps = document.getElementById('focusApps');
const focusTime = document.getElementById('focusTime');
const focusSites = document.getElementById('focusSites');
const idleTime = document.getElementById('idleTime');
const focusEventsCopy = document.getElementById('focusEventsCopy');
const focusAppsCopy = document.getElementById('focusAppsCopy');
const focusTimeCopy = document.getElementById('focusTimeCopy');
const focusSitesCopy = document.getElementById('focusSitesCopy');
const idleTimeCopy = document.getElementById('idleTimeCopy');
const classificationSummary = document.getElementById('classificationSummary');
const classificationBars = document.getElementById('classificationBars');
const runtimeHealth = document.getElementById('runtimeHealth');
const reportsView = document.getElementById('reportsView');
const healthView = document.getElementById('healthView');
const healthHeroTitle = document.getElementById('healthHeroTitle');
const healthHeroCopy = document.getElementById('healthHeroCopy');
const systemProcessInline = document.getElementById('systemProcessInline');
const systemProcessModal = document.getElementById('systemProcessModal');
const systemProcessModalContent = document.getElementById('systemProcessModalContent');
const manualBlockModal = document.getElementById('manualBlockModal');
const manualBlockStatus = document.getElementById('manualBlockStatus');
const profileModal = document.getElementById('profileModal');
const onboardingModal = document.getElementById('onboardingModal');
const setupName = document.getElementById('setupName');
const setupEmail = document.getElementById('setupEmail');
const setupRoleId = document.getElementById('setupRoleId');
const setupRole = document.getElementById('setupRole');
const setupRoleNotes = document.getElementById('setupRoleNotes');
const onboardingError = document.getElementById('onboardingError');
const onboardingProgress = document.getElementById('onboardingProgress');
const onboardingBackButton = document.getElementById('onboardingBack');
const onboardingNextButton = document.getElementById('onboardingNext');
const onboardingFinishButton = document.getElementById('finishOnboarding');
const profileName = document.getElementById('profileName');
const profileEmail = document.getElementById('profileEmail');
const profileRoleId = document.getElementById('profileRoleId');
const profileRole = document.getElementById('profileRole');
const profileRoleNotes = document.getElementById('profileRoleNotes');
const roleDetectionHint = document.getElementById('roleDetectionHint');
const saveProfileButton = document.getElementById('saveProfile');
const identityHeader = document.getElementById('identityHeader');
const profileView = document.getElementById('profileView');
const profileAvatar = document.getElementById('profileAvatar');
const profileDisplayName = document.getElementById('profileDisplayName');
const profileDisplayEmail = document.getElementById('profileDisplayEmail');
const toolsToggle = document.getElementById('toolsToggle');
const secondaryPanelRow = document.getElementById('secondaryPanelRow');
const audioDrawer = document.getElementById('audioDrawer');
const audioDeviceNames = document.getElementById('audioDeviceNames');
const reportWorkspace = document.getElementById('reportWorkspace');
const reportActionList = document.getElementById('reportActionList');
const reportActionButtons = [...document.querySelectorAll('[data-report-action]')];
const reportOptions = document.getElementById('reportOptions');
const reportCompactView = document.getElementById('reportCompactView');
const reportEditToggle = document.getElementById('reportEditToggle');
const reportSelectedRange = document.getElementById('reportSelectedRange');
const reportSelectedTitle = document.getElementById('reportSelectedTitle');
const reportSelectedDescription = document.getElementById('reportSelectedDescription');
const reportRunButton = document.getElementById('reportRunButton');
const reportQuestionRow = document.getElementById('reportQuestionRow');
const rangePresetButtons = [...document.querySelectorAll('[data-range-preset]')];
const rangeStatus = document.getElementById('rangeStatus');
const CLASSIFICATION_KEYS = ['work', 'meeting', 'social', 'other', 'unclear'];

let latestSystemProcessRecords = [];
let savedProfileSnapshot = { name: '', email: '' };
let latestDailyReportData = null;
let latestActivityReportData = null;
let latestActivityReportRangeKey = '';
let latestMyWeeklyReportData = null;
let latestHodDraftData = null;
let latestHodReviewedDrafts = [];
let latestManualIdleBlocks = [];
let profileEditMode = false;
let outputExpanded = false;
let reportOutputReady = false;
let listeningEnabled = false;
let currentAudioMode = 'off';
let onboardingStep = 0;
let selectedReportTab = 'daily';
let selectedReportAction = 'summary';
const runningActions = new Set();
const MAX_RANGE_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_DAILY_REPORT_MS = 24 * 60 * 60 * 1000;
const MAX_PAYROLL_ROWS_PER_SECTION = 80;
const MAX_TIMELINE_ROWS_RENDERED = 300;
const dailyReportRowsCache = new WeakMap();
const REPORT_ACTION_LABELS = new Set([
  'ask',
  'summary',
  'dailyReport',
  'timelineReport',
  'fullActivityReport',
  'myWeeklyReport',
  'hodDraft',
  'hodDraftHistory',
  'tasks'
]);
const REPORT_ACTION_CONFIG = {
  summary: {
    label: 'Daily Summary',
    description: 'PC Available, idle deducted, manual restored, and final work hours for one day.',
    tab: 'daily',
    run: () => summary()
  },
  dailyReport: {
    label: 'Daily Report',
    description: 'Payroll-ready day view with work-hour accounting and classified evidence.',
    tab: 'daily',
    run: () => dailyReport()
  },
  timelineReport: {
    label: 'Timeline',
    description: 'Time-ordered evidence across the selected range.',
    tab: 'activity',
    run: () => timelineReport()
  },
  fullActivityReport: {
    label: 'Full Activity',
    description: 'Detailed app, title, OCR, classification, and idle evidence for the selected range.',
    tab: 'activity',
    run: () => fullActivityReport()
  },
  myWeeklyReport: {
    label: 'Weekly Report',
    description: 'Personal weekly summary using the week that contains the selected From date.',
    tab: 'weekly',
    run: () => myWeeklyReport()
  },
  hodDraft: {
    label: 'HOD Draft',
    description: 'Manager-facing weekly draft using role context and the selected week.',
    tab: 'weekly',
    run: () => hodDraft()
  },
  hodDraftHistory: {
    label: 'Reviewed Drafts',
    description: 'Previously reviewed HOD drafts and approval notes.',
    tab: 'weekly',
    run: () => hodDraftHistory()
  },
  tasks: {
    label: 'Tasks',
    description: 'Extract completed tasks and evidence from the selected range.',
    tab: 'tasks',
    run: () => tasks()
  },
  ask: {
    label: 'Ask Evidence',
    description: 'Ask a question against the selected evidence range.',
    tab: 'ask',
    run: () => ask()
  }
};
const ROLE_LABELS = {
  developer: 'Developer / Engineering',
  'admin-operations': 'Admin / Operations',
  hr: 'HR',
  finance: 'Finance / Accounts',
  sales: 'Sales',
  marketing: 'Marketing',
  legal: 'Legal / Compliance',
  'customer-support': 'Customer Support / CS',
  'business-analyst': 'Business Analyst',
  designer: 'Designer / Creative',
  'social-media': 'Social Media',
  'manager-hod': 'Manager / HOD',
  'c-level-executive': 'C-Level / Executive',
  custom: 'Custom'
};

function localIsoDateInputValue(value = new Date()) {
  const date = new Date(value);
  const pad = (part) => String(part).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function mondayDateInputValue(date = new Date()) {
  const target = new Date(date);
  target.setHours(0, 0, 0, 0);
  const day = target.getDay();
  target.setDate(target.getDate() + (day === 0 ? -6 : 1 - day));
  return localIsoDateInputValue(target);
}

function pad2(value) {
  return String(value).padStart(2, '0');
}

function formatReportDateInput(value = new Date()) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return '';
  }
  return `${pad2(date.getDate())}-${pad2(date.getMonth() + 1)}-${date.getFullYear()}`;
}

function formatReportDateRangeLabel(startTime, endTime) {
  const start = new Date(startTime);
  const endInclusive = new Date(new Date(endTime).getTime() - 1);
  if (Number.isNaN(start.getTime()) || Number.isNaN(endInclusive.getTime())) {
    return 'Selected range';
  }
  const startLabel = formatReportDateInput(start);
  const endLabel = formatReportDateInput(endInclusive);
  return startLabel === endLabel ? startLabel : `${startLabel} to ${endLabel}`;
}

function reportRangeKey(range = {}) {
  return `${range.startTime || ''}|${range.endTime || ''}`;
}

async function debugLog(event, payload = {}) {
  try {
    await window.assistantApi.debugLog({ event, payload });
  } catch {
    // Ignore debug logging failures.
  }
}

function setOutput(value) {
  reportOutputReady = false;
  updateExpandedOutputButton();
  document.body.classList.add('status-visible');
  outputSection?.classList.remove('hidden');
  output.textContent = value;
  output.scrollTop = 0;
}

function clearOutputStatus(expectedText = '') {
  if (expectedText && output.textContent !== expectedText) {
    return;
  }
  output.textContent = '';
  outputSection?.classList.add('hidden');
  document.body.classList.remove('status-visible');
}

function setOutputHtml(value, options = {}) {
  reportOutputReady = Boolean(options.report) ? false : Boolean(options.report);
  updateExpandedOutputButton();
  if (options.report) {
    window.assistantApi.showReportWindow({
      title: options.title || 'Report',
      subtitle: options.subtitle || '',
      kind: options.kind || 'report',
      html: value,
      text: options.text || '',
      data: compactReportWindowData(options.kind || 'report', options.data || null)
    }).catch(() => {});
    output.textContent = '';
    outputSection?.classList.add('hidden');
    document.body.classList.remove('status-visible');
    return;
  }
  document.body.classList.add('status-visible');
  outputSection?.classList.remove('hidden');
  output.innerHTML = value;
  output.scrollTop = 0;
}

function compactReportWindowData(kind, data) {
  if (!data) {
    return null;
  }
  if (kind === 'daily-report') {
    return { payroll_payload: data.payroll_payload || null };
  }
  if (kind === 'hod-draft') {
    return data;
  }
  return null;
}

function updateExpandedOutputButton() {
  document.body.classList.toggle('report-expanded', outputExpanded);
  if (!expandOutput) {
    return;
  }

  expandOutput.classList.toggle('hidden', !reportOutputReady && !outputExpanded);
  expandOutput.textContent = outputExpanded ? 'Fit' : 'Max';
  expandOutput.title = outputExpanded ? 'Restore report view' : 'Expand report view';
}

async function toggleExpandedOutput() {
  await debugLog('panel_resize_started', { expanded: outputExpanded });
  try {
    if (outputExpanded) {
      await window.assistantApi.restorePanel();
      outputExpanded = false;
    } else {
      await window.assistantApi.expandPanel();
      outputExpanded = true;
    }
    updateExpandedOutputButton();
    await debugLog('panel_resize_completed', { expanded: outputExpanded });
  } catch (error) {
    await debugLog('panel_resize_failed', { message: error?.message || String(error) });
  }
}

function setRangeError(message = '') {
  const rangeError = document.getElementById('rangeError');
  if (!rangeError) {
    return;
  }

  rangeError.textContent = message;
  rangeError.classList.toggle('visible', Boolean(message));
  rangeStatus?.classList.toggle('error', Boolean(message));
  reportCompactView?.classList.toggle('error', Boolean(message));
  reportSelectedRange?.classList.toggle('error', Boolean(message));
  if (message && rangeStatus) {
    rangeStatus.textContent = 'Fix date range';
  }
  if (message && reportSelectedRange) {
    reportSelectedRange.textContent = message;
  }
}

function setRangeStatus(message = '', tone = '') {
  if (!rangeStatus) {
    return;
  }
  rangeStatus.textContent = message;
  rangeStatus.classList.toggle('error', tone === 'error');
  reportCompactView?.classList.toggle('error', tone === 'error');
  reportSelectedRange?.classList.toggle('error', tone === 'error');
  if (reportSelectedRange && message && message !== 'Editing range') {
    reportSelectedRange.textContent = message.replace(/^Range:\s*/, '').replace(/^Week:\s*/, 'Week: ');
  }
}

function safeObject(value) {
  return value && typeof value === 'object' ? value : {};
}

function safeSummary(summary) {
  return safeObject(summary);
}

function profileValues() {
  return {
    name: profileName.value.trim(),
    email: profileEmail.value.trim()
  };
}

function profileInitials(name, email) {
  const source = name || email || '';
  const parts = source
    .replace(/@.*/, '')
    .split(/[\s._-]+/)
    .filter(Boolean);
  const initials = parts.length > 1
    ? `${parts[0][0] || ''}${parts[1][0] || ''}`
    : source.slice(0, 2);
  return initials ? initials.toUpperCase() : '--';
}

function updateProfileDisplay() {
  const current = profileValues();
  const name = current.name || 'Add your name';
  const email = current.email || 'Add email address';
  profileDisplayName.textContent = name;
  profileDisplayEmail.textContent = email;
  profileAvatar.textContent = profileInitials(current.name, current.email);
}

function setProfileEditorVisible(visible) {
  profileEditMode = Boolean(visible);
  identityHeader?.classList.toggle('editing', profileEditMode);
  profileModal?.classList.toggle('open', profileEditMode);
  profileModal?.setAttribute('aria-hidden', profileEditMode ? 'false' : 'true');
  updateProfileDisplay();
}

function closeProfileModal() {
  setProfileEditorVisible(false);
}

function updateProfileEditorVisibility() {
  const current = profileValues();
  if (current.name !== savedProfileSnapshot.name || current.email !== savedProfileSnapshot.email) {
    setProfileEditorVisible(true);
    return;
  }

  updateProfileDisplay();
}

function selectedRoleLabel() {
  const selectedId = profileRoleId.value;
  if (selectedId && selectedId !== 'custom') {
    return ROLE_LABELS[selectedId] || selectedId;
  }
  return profileRole.value.trim();
}

function syncRoleCustomField() {
  const isCustom = !profileRoleId.value || profileRoleId.value === 'custom';
  profileRole.disabled = !isCustom;
  profileRole.placeholder = isCustom ? 'Custom role' : (ROLE_LABELS[profileRoleId.value] || 'Role');
  if (!isCustom) {
    profileRole.value = ROLE_LABELS[profileRoleId.value] || '';
  }
}

function selectedSetupRoleLabel() {
  const selectedId = setupRoleId?.value || '';
  if (selectedId && selectedId !== 'custom') {
    return ROLE_LABELS[selectedId] || selectedId;
  }
  return setupRole?.value.trim() || '';
}

function currentRoleProfile() {
  const roleId = profileRoleId?.value || '';
  return {
    roleId,
    role: selectedRoleLabel() || profileRole?.value.trim() || '',
    roleNotes: profileRoleNotes?.value.trim() || ''
  };
}

function roleContextNote(kind = 'daily') {
  const profile = currentRoleProfile();
  const role = profile.role || 'the confirmed role';
  const notes = profile.roleNotes ? ` Context: ${profile.roleNotes}` : '';
  if (kind === 'daily') {
    return `Use this as visible PC activity for ${role}; it does not prove offline decisions, calls, travel, outcomes, or quality.${notes}`;
  }
  if (kind === 'focus' && profile.roleId === 'c-level-executive') {
    return 'For an executive role, low focus score is not automatically bad; meeting load, approvals, context switching, and offline decisions must be interpreted separately.';
  }
  if (kind === 'focus' && ['manager-hod', 'admin-operations', 'customer-support'].includes(profile.roleId)) {
    return 'For this role, context switching can be expected; review the surfaces and outcomes before treating switching as distraction.';
  }
  return '';
}

function syncSetupRoleCustomField() {
  if (!setupRole || !setupRoleId) {
    return;
  }
  const isCustom = !setupRoleId.value || setupRoleId.value === 'custom';
  const rolePlaceholders = {
    developer: 'Example: Backend developer working on APIs, releases, and production fixes',
    'admin-operations': 'Example: Operations lead handling approvals, portals, vendors, and coordination',
    hr: 'Example: HR executive handling hiring, attendance, appraisals, and employee queries',
    finance: 'Example: Accounts manager handling billing, reconciliation, payroll, and approvals',
    sales: 'Example: Sales manager handling leads, proposals, follow-ups, and customer meetings',
    marketing: 'Example: Marketing lead handling campaigns, content, analytics, and launches',
    legal: 'Example: Legal officer handling contracts, compliance, notices, and policy review',
    'customer-support': 'Example: Support lead handling tickets, escalations, calls, and customer updates',
    'business-analyst': 'Example: Business analyst handling requirements, process maps, and stakeholder updates',
    designer: 'Example: Product designer handling UI screens, brand assets, and design reviews',
    'social-media': 'Example: Social media manager handling posts, campaigns, replies, and reporting',
    'manager-hod': 'Example: HOD managing team reviews, approvals, delivery tracking, and escalations',
    'c-level-executive': 'Example: CXO reviewing business metrics, leadership updates, approvals, and strategy',
    custom: 'Example: Senior Manager handling HOD approvals and payroll coordination'
  };
  setupRole.disabled = !isCustom;
  setupRole.placeholder = rolePlaceholders[setupRoleId.value] || 'Example: Designation plus the main work you handle';
  if (!isCustom) {
    setupRole.value = ROLE_LABELS[setupRoleId.value] || '';
  }
}

function renderRoleDetectionHint(profile = {}) {
  const detection = profile.roleDetection?.lastClassification;
  if (!detection?.role_label) {
    roleDetectionHint.style.display = 'none';
    roleDetectionHint.textContent = '';
    return;
  }
  const evidence = (detection.evidence || [])
    .slice(0, 3)
    .map((item) => item.label)
    .filter(Boolean)
    .join(', ');
  roleDetectionHint.style.display = 'block';
  roleDetectionHint.innerHTML = `<strong>Detected:</strong> ${escapeHtml(detection.role_label)} (${escapeHtml(String(detection.confidence || 0))}% confidence)${evidence ? `<br><strong>Signals:</strong> ${escapeHtml(evidence)}` : ''}`;
}

function editProfile() {
  setProfileEditorVisible(true);
  setTimeout(() => {
    (profileName.value.trim() ? profileEmail : profileName).focus();
  }, 0);
}

function toggleTools() {
  const open = document.body.classList.toggle('tools-visible');
  toolsToggle?.setAttribute('aria-expanded', open ? 'true' : 'false');
}

function wireSecondaryDrawers() {
  const drawers = [...document.querySelectorAll('.inline-panel-source')];
  const syncDrawerBackdrop = () => {
    document.body.classList.toggle('drawer-open', drawers.some((drawer) => drawer.open));
  };

  drawers.forEach((drawer) => {
    drawer.addEventListener('toggle', () => {
      if (!drawer.open) {
        syncDrawerBackdrop();
        return;
      }

      drawers
        .filter((candidate) => candidate !== drawer)
        .forEach((candidate) => {
          candidate.open = false;
        });
      syncDrawerBackdrop();
    });
  });

  document.addEventListener('click', (event) => {
    const openDrawer = drawers.find((drawer) => drawer.open);
    if (openDrawer && !openDrawer.contains(event.target)) {
      openDrawer.open = false;
      syncDrawerBackdrop();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      drawers.forEach((drawer) => {
        drawer.open = false;
      });
      syncDrawerBackdrop();
      closeManualBlockModal();
      if (onboardingModal?.classList.contains('open')) {
        setOnboardingError('Complete setup to continue.');
      }
    }
  });
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatCompactTime(value) {
  if (!value) {
    return 'Unknown time';
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return escapeHtml(String(value).replace('T', ' ').slice(0, 19));
  }

  return date.toLocaleString([], {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });
}

function formatTimeOnly(value) {
  if (!value) {
    return 'Unknown';
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return escapeHtml(String(value).replace('T', ' ').slice(11, 16));
  }

  return date.toLocaleTimeString([], {
    hour: 'numeric',
    minute: '2-digit'
  });
}

function formatMinutes(minutes) {
  const rounded = Math.max(0, Math.round(Number(minutes) || 0));
  if (rounded >= 60) {
    const hours = Math.floor(rounded / 60);
    const mins = rounded % 60;
    return mins ? `${hours}h ${mins}m` : `${hours}h`;
  }

  return `${rounded}m`;
}

function formatSecondsAsMinutes(seconds) {
  return formatMinutes(Math.round(Number(seconds || 0) / 60));
}

function isVisibleAppName(appName) {
  return String(appName || '').trim().toLowerCase() !== 'system process';
}

function formatList(items = [], empty = 'None') {
  return items.length ? items.join(', ') : empty;
}

function formatBulletList(items = [], empty = 'None') {
  return items.length ? items.map((item) => `- ${item}`).join('\n') : `- ${empty}`;
}

function limitList(items = [], count = 12) {
  if (items.length <= count) {
    return items;
  }

  return [...items.slice(0, count), `+ ${items.length - count} more`];
}

function renderChips(items = [], empty = 'None') {
  if (!items.length) {
    return `<div class="empty-state">${escapeHtml(empty)}</div>`;
  }

  return `<div class="chip-row">${items.map((item) => `<span class="chip">${escapeHtml(item)}</span>`).join('')}</div>`;
}

function classificationMinutesTotal(minutes = {}) {
  return CLASSIFICATION_KEYS.reduce((sum, key) => sum + Number(minutes[key] || 0), 0);
}

function classificationLabel(value) {
  const normalized = String(value || 'unclear').toLowerCase();
  if (normalized === 'work') {
    return 'Work';
  }
  if (normalized === 'meeting') {
    return 'Video Meeting';
  }
  if (normalized === 'social') {
    return 'Social';
  }
  if (normalized === 'other') {
    return 'Other';
  }
  if (normalized === 'break') {
    return 'Break';
  }
  return 'Unclear';
}

function titleCaseWords(value = '') {
  return String(value || '')
    .replace(/[-_]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .filter(Boolean)
    .map((word) => {
      if (/^[A-Z0-9]{2,}$/.test(word)) {
        return word;
      }
      return `${word.slice(0, 1).toUpperCase()}${word.slice(1).toLowerCase()}`;
    })
    .join(' ');
}

function displayAppName(value = '') {
  const cleaned = String(value || 'App')
    .replace(/\.exe$/i, '')
    .replace(/\s*-\s*(Google Chrome|Microsoft Edge|Mozilla Firefox)$/i, '')
    .trim();
  const aliases = {
    chrome: 'Chrome',
    msedge: 'Edge',
    code: 'VS Code',
    windowsterminal: 'Terminal',
    powershell: 'PowerShell',
    python: 'Python',
    electron: 'Cognify'
  };
  const key = cleaned.replace(/[\s._-]+/g, '').toLowerCase();
  return aliases[key] || titleCaseWords(cleaned);
}

function domainLabel(url = '') {
  try {
    const host = new URL(url).hostname.replace(/^www\./i, '');
    const known = {
      'claude.ai': 'Claude',
      'chatgpt.com': 'ChatGPT',
      'github.com': 'GitHub',
      'x.com': 'X',
      'twitter.com': 'X',
      'linkedin.com': 'LinkedIn',
      'youtube.com': 'YouTube',
      'meet.google.com': 'Google Meet',
      'teams.microsoft.com': 'Teams'
    };
    return known[host] || titleCaseWords(host.split('.')[0] || host);
  } catch {
    return '';
  }
}

function cleanReportTitle(value = '') {
  let title = String(value || 'Activity')
    .replace(/\s+-\s+(Google Chrome|Microsoft Edge|Mozilla Firefox|Visual Studio Code|File Explorer)$/i, '')
    .replace(/\s+\|\s+(Google Chrome|Microsoft Edge|Mozilla Firefox)$/i, '')
    .replace(/\b(await|const|function|return|print|delete from|select \*)\b.*$/i, '')
    .replace(/\b[OX]\s+[OX]\b.*$/i, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (!title || title.length < 3) {
    return 'Focused work';
  }

  const symbolCount = (title.match(/[{}()[\]=<>;`]/g) || []).length;
  if (title.length > 90 && symbolCount >= 2) {
    title = title.split(/[|:]/)[0] || 'Focused work';
  }

  title = title
    .replace(/^action required\s*\|?\s*/i, '')
    .replace(/^file explorer[,:\s-]*/i, '')
    .replace(/^windows powershell$/i, 'PowerShell')
    .trim();

  if (title.length > 76) {
    title = `${title.slice(0, 73).trim()}...`;
  }

  return title || 'Focused work';
}

function primarySourceLabel(row = {}) {
  const urlSource = (row.urls || []).map(domainLabel).find(Boolean);
  if (urlSource) {
    return urlSource;
  }
  const apps = (row.apps || []).map(displayAppName).filter(Boolean);
  if (!apps.length) {
    return 'Captured Activity';
  }
  if (apps.length === 1) {
    return apps[0];
  }
  return apps.find((app) => !/terminal|powershell|cmd/i.test(app)) || apps[0];
}

function reportRowSentence(row = {}) {
  const title = titleCaseWords(cleanReportTitle(row.title || 'Activity'));
  const source = primarySourceLabel(row);
  const classification = String(row.classification || '').toLowerCase();
  if (classification === 'meeting') {
    return `Meeting about ${title}`;
  }
  if (classification === 'social') {
    return `Browsed ${title} on ${source}`;
  }
  if (classification === 'other' || classification === 'unclear') {
    return `Reviewed ${title}`;
  }
  return `Worked on ${title} in ${source}`;
}

function cacheStatusLabel(cache = {}) {
  const hit = Number(cache.hit_hours || 0);
  const built = Number(cache.built_hours || 0);
  const total = Number(cache.hour_count || hit + built || 0);
  if (!total) {
    return 'Cache warming';
  }
  if (!built) {
    return `Loaded from cache (${hit}/${total} hours)`;
  }
  return `Cached report (${hit}/${total} hours reused)`;
}

function topActivityName(rows = []) {
  const first = rows.find((row) => Number(row.durationMinutes || 0) > 1);
  if (!first) {
    return 'No major work block found';
  }
  return `${formatMinutes(first.durationMinutes)} - ${reportRowSentence(first)}`;
}

function renderClassBadge(value, confidence) {
  const normalized = CLASSIFICATION_KEYS.includes(String(value || '').toLowerCase())
    ? String(value).toLowerCase()
    : 'unclear';
  const suffix = confidence ? ` ${confidence}` : '';
  return `<span class="class-badge ${normalized}" title="${escapeHtml(`${classificationLabel(normalized)}${suffix}`)}">${escapeHtml(classificationLabel(normalized))}</span>`;
}

function renderClassBuckets(minutes = {}) {
  return `<span class="class-buckets">${escapeHtml(`W ${formatMinutes(minutes.work || 0)} | M ${formatMinutes(minutes.meeting || 0)} | S ${formatMinutes(minutes.social || 0)} | O ${formatMinutes(minutes.other || 0)} | U ${formatMinutes(minutes.unclear || 0)}`)}</span>`;
}

function renderClassificationBars(minutes = {}) {
  const total = classificationMinutesTotal(minutes);
  if (!total) {
    return '<div class="empty-state">Run Ask or Daily Summary to classify captured activity.</div>';
  }

  return CLASSIFICATION_KEYS.map((key) => {
    const value = Number(minutes[key] || 0);
    const width = Math.round((value / total) * 100);
    return `
      <div class="classification-segment">
        <div class="classification-label">
          <span>${escapeHtml(classificationLabel(key))}</span>
          <span>${escapeHtml(formatMinutes(value))}</span>
        </div>
        <div class="classification-track">
          <div class="classification-fill ${key}" style="width:${escapeHtml(String(width))}%"></div>
        </div>
      </div>
    `;
  }).join('');
}

function setClassificationSnapshot(minutes = {}) {
  if (!classificationSummary || !classificationBars) {
    return;
  }

  const total = classificationMinutesTotal(minutes);
  classificationSummary.textContent = total ? `${formatMinutes(total)} estimated from rules` : 'No classified time yet';
  classificationBars.innerHTML = renderClassificationBars(minutes);
}

function setIdleSnapshot(summary = {}) {
  if (!idleTime || !idleTimeCopy) {
    return;
  }

  idleTime.textContent = formatSecondsAsMinutes(summary.total_idle_seconds || 0);
  const activeText = summary.active ? 'Currently idle. ' : '';
  const thresholdMinutes = Math.round(Number(summary.threshold_seconds || 300) / 60);
  idleTimeCopy.textContent = `${activeText}${summary.intervals?.length || 0} idle block(s), threshold ${thresholdMinutes}m.`;
  renderManualIdleBlocks(summary);
}

function renderRuntimeHealth(diagnostics = {}) {
  const items = [
    diagnostics.localhost,
    diagnostics.screenpipe,
    diagnostics.screenpipe_ownership,
    diagnostics.search_api,
    diagnostics.ffmpeg,
    diagnostics.listening,
    diagnostics.screenpipe_memory,
    diagnostics.recording,
    diagnostics.focus_events,
    diagnostics.windows_focus
  ].filter(Boolean);

  if (!items.length) {
    runtimeHealth.innerHTML = '<div class="empty-state">Runtime status unavailable.</div>';
    return;
  }

  runtimeHealth.innerHTML = items.map((item) => `
    <div class="health-detail-card ${item.informational ? 'info' : (item.ok ? 'ok' : 'bad')}" title="${escapeHtml(item.detail || '')}">
      <div class="health-detail-title"><span class="health-dot"></span>${escapeHtml(item.label || 'Status')}</div>
      <div class="health-detail-copy">${escapeHtml(item.detail || (item.ok ? 'OK' : 'Needs attention'))}</div>
    </div>
  `).join('');

  if (healthHeroTitle && healthHeroCopy) {
    const runtimeItems = items.filter((item) => !item.informational);
    const okCount = runtimeItems.filter((item) => item.ok).length;
    const total = runtimeItems.length;
    healthHeroTitle.textContent = okCount === total ? 'Everything is in place' : `${total - okCount} runtime check(s) need attention`;
    healthHeroCopy.textContent = `${okCount} of ${total} checks are healthy. Last checked ${new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}.`;
  }
}

function setRecordingStatus({ running = false, paused = false } = {}) {
  const offline = !running && !paused;
  recording.textContent = offline ? 'Cognify Offline' : (paused ? 'Capture Paused' : 'Recording On');
  recording.title = offline ? 'Capture is offline' : (paused ? 'Turn recording on' : 'Turn recording off');
  recording.classList.toggle('paused', paused && !offline);
  recording.classList.toggle('offline', offline);
  recording.disabled = offline;
  captureToggle.textContent = offline ? 'Capture Offline' : (paused ? 'Resume Capture' : 'Pause Capture');
  captureToggle.classList.toggle('paused', paused || offline);
  captureToggle.disabled = offline;
}

function setListeningStatus(enabled, options = {}) {
  listeningEnabled = Boolean(enabled);
  currentAudioMode = options.mode || currentAudioMode || (listeningEnabled ? 'always' : 'off');
  if (!listening) {
    return;
  }

  const busy = Boolean(options.busy);
  const label = currentAudioMode === 'meeting'
    ? 'Meeting Only'
    : (listeningEnabled ? 'Listening On' : 'Listening Off');
  listening.textContent = busy ? 'Listening...' : label;
  listening.title = listeningEnabled
    ? 'Click to cycle Listening: Off, Meeting Only, Always On.'
    : 'Listening is off. Click to enable Meeting Only.';
  listening.classList.toggle('on', listeningEnabled && !busy);
  listening.classList.toggle('busy', busy);
  listening.disabled = busy;
}

function syncRecordingStatusFromDiagnostics(diagnostics = {}) {
  if (!diagnostics.recording) {
    return;
  }

  const detail = String(diagnostics.recording.detail || '').toLowerCase();
  setRecordingStatus({
    running: Boolean(diagnostics.recording.ok) || detail === 'on' || detail === 'paused',
    paused: detail === 'paused'
  });
}

function syncListeningStatusFromDiagnostics(diagnostics = {}) {
  if (!diagnostics.listening) {
    return;
  }

  setListeningStatus(Boolean(diagnostics.listening.enabled), { mode: diagnostics.listening.mode || 'off' });
}

async function refreshRuntimeHealth() {
  if (document.hidden) {
    return;
  }

  try {
    const fullHealthView = document.body.classList.contains('health-mode');
    const diagnostics = await window.assistantApi.getDiagnostics(fullHealthView ? {} : { passive: true });
    renderRuntimeHealth(diagnostics);
    syncRecordingStatusFromDiagnostics(diagnostics);
    syncListeningStatusFromDiagnostics(diagnostics);
  } catch {
    renderRuntimeHealth({});
  }
}

async function setPanelMode(mode = 'reports') {
  const showHealth = mode === 'health';
  if (showHealth) {
    document.body.classList.remove('tools-visible');
    toolsToggle?.setAttribute('aria-expanded', 'false');
  }
  document.body.classList.toggle('health-visible', showHealth);
  document.body.classList.toggle('health-mode', showHealth);
  reportsView.classList.toggle('hidden', showHealth);
  healthView.classList.toggle('hidden', !showHealth);
  if (showHealth) {
    await refreshRuntimeHealth();
    return;
  }
  if (mode === 'role') {
    setProfileEditorVisible(true);
    setTimeout(() => {
      profileRoleId?.focus();
      profileRoleId?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      if (!profileRoleId?.value) {
        setOutput('Choose your role, add role context, then click Save Role.');
      }
    }, 0);
    return;
  }
  if (mode === 'manual-block') {
    setTimeout(() => openManualBlockModal({ kind: 'work' }), 0);
  }
}

function renderRuleEvidence(item = {}) {
  const rules = item.matched_rules || [];
  if (!rules.length) {
    return '<div class="session-rules">No rule evidence captured for this session.</div>';
  }

  return `<div class="session-rules">Rules: ${escapeHtml(rules.slice(0, 6).join(', '))}</div>`;
}

function renderSummaryRows(metrics = []) {
  return `
    <div class="summary-grid summary-rows">
      ${metrics.map((metric) => `
        <div class="summary-row">
          <div class="summary-label">${escapeHtml(metric.label)}</div>
          <div class="summary-value">${escapeHtml(metric.value)}</div>
        </div>
      `).join('')}
    </div>
  `;
}

const REPORT_STAT_HELP = {
  'Visible Time': 'Time Cognify saw something on your screen.',
  'Visible Hours': 'Time Cognify saw something on your screen.',
  'Active-Looking': 'Screen time that looked active, after removing idle time.',
  'PC Available': 'Time Cognify identified the PC as on/available before idle deduction.',
  'Active Hours': 'Idle-adjusted PC activity time.',
  'Active Time': 'Time you appeared to be using the PC.',
  'Passive / Review': 'Time that looked like reading, reviewing, or a window left open.',
  'Review / Reading': 'Time spent viewing pages, dashboards, references, or unclear work material. This is separate from meetings and chat.',
  'Input Idle': 'Time with no keyboard or mouse activity.',
  'Idle Time': 'Time with no keyboard or mouse activity.',
  Work: 'Time that looked like work.',
  'Deep Work': 'Focused work time. This is stricter than total PC time.',
  'Work Time': 'Time that looked like work.',
  'Work Hours': 'Official work total: PC Available minus idle deducted, plus manual work or meeting restored from idle.',
  'Canonical coverage': 'Whether official PC Available and Work Hours were available for the full selected range.',
  'Meeting / Chat': 'Time in meetings, chat, email, or messaging.',
  Social: 'Time on social or entertainment apps and sites.',
  'Private Excluded': 'Private or sensitive activity hidden from the report.',
  'Review Blocks': 'Items Cognify could not classify confidently.',
  'Focus Score': 'Deep Work divided by Active Time.',
  'Weekly Focus': 'Average focus score for the week.',
  Meetings: 'Time in meetings, chat, email, or messaging.',
  'Pending Follow-Ups': 'Possible follow-up items found on screen.',
  'Follow-Ups': 'Possible follow-up items found on screen.',
  'Activity Events': 'Screen captures used for this report.',
  Apps: 'Apps seen during this report.',
  Sites: 'Websites seen during this report.'
};

function reportStatHelp(label) {
  return REPORT_STAT_HELP[label] || `${label} shown in this report.`;
}

function renderReportStats(stats = []) {
  return `
    <div class="report-stat-grid">
      ${stats.map((stat) => `
        <div class="report-stat">
          <div class="report-stat-label">
            <span>${escapeHtml(stat.label)}</span>
            <span class="stat-help" title="${escapeHtml(reportStatHelp(stat.label))}" aria-label="${escapeHtml(reportStatHelp(stat.label))}">?</span>
          </div>
          <div class="report-stat-value">${escapeHtml(stat.value)}</div>
        </div>
      `).join('')}
    </div>
  `;
}

function focusScoreFromSummary(summary = {}) {
  const score = summary.focus_score || {};
  const activeMinutes = Number(score.total_active_minutes || summary.estimated_active_minutes || 0);
  const deepWorkMinutes = Number.isFinite(Number(score.deep_work_minutes))
    ? Number(score.deep_work_minutes)
    : Number(summary.pc_work_minutes || summary.classified_minutes?.work || 0);
  const scorePercent = activeMinutes > 0
    ? Math.round((deepWorkMinutes / activeMinutes) * 100)
    : Math.round(Number(score.score_percent || 0));

  return {
    score_percent: Math.max(0, Math.min(100, scorePercent)),
    deep_work_minutes: Math.max(0, Math.round(deepWorkMinutes)),
    total_active_minutes: Math.max(0, Math.round(activeMinutes)),
    label: activeMinutes > 0 ? `${Math.max(0, Math.min(100, scorePercent))}%` : '0%'
  };
}

function canonicalWorkMinutes(summary = {}) {
  const idle = Number(summary.idle_minutes || summary.input_idle_minutes || 0);
  const available = canonicalPcAvailableMinutes(summary);
  const manualNet = Number.isFinite(Number(summary.manual_net_added_work_minutes))
    ? Number(summary.manual_net_added_work_minutes)
    : Number(summary.manual_timing_blocks?.net_added_minutes || 0);
  if (hasPcAvailableEvidence(summary)) {
    const idleDeducted = Math.min(available, Math.max(0, Math.round(idle)));
    const manualRestored = Math.min(idleDeducted, Math.max(0, Math.round(manualNet)));
    return Math.min(available, Math.max(0, Math.round(available - idleDeducted + manualRestored)));
  }
  if (Number.isFinite(Number(summary.work_minutes))) {
    return Math.max(0, Math.round(Number(summary.work_minutes || 0)));
  }
  if (Number.isFinite(Number(summary.work_minutes_breakdown?.total_work_minutes))) {
    return Math.max(0, Math.round(Number(summary.work_minutes_breakdown.total_work_minutes || 0)));
  }
  const idleDeducted = Math.min(available, Math.max(0, Math.round(idle)));
  const manualRestored = Math.min(idleDeducted, Math.max(0, Math.round(manualNet)));
  return Math.min(available, Math.max(0, Math.round(available - idleDeducted + manualRestored)));
}

function canonicalPcAvailableMinutes(summary = {}) {
  const active = Number(summary.estimated_active_minutes || summary.active_minutes || 0);
  const idle = Number(summary.idle_minutes || summary.input_idle_minutes || 0);
  const captured = Math.max(0, Math.round(Number(summary.captured_minutes_estimate || 0)));
  const range = finiteNumber(summary.range_minutes);
  const localEvidence = clampMinutes(Math.max(active + idle, captured), range);
  const runtime = finiteNumber(summary.runtime_available_minutes);
  const explicit = finiteNumber(
    summary.gross_pc_available_minutes,
    summary.work_minutes_breakdown?.gross_pc_available_minutes
  );

  if (explicit !== null) {
    const trustedExplicit = Boolean(summary.pc_available_source) ||
      (runtime !== null && runtime > 0) ||
      summary.source === 'cognify-runtime-availability' ||
      summary.official_time_source === 'cognify-runtime-availability';
    return trustedExplicit
      ? clampMinutes(explicit, range)
      : clampMinutes(Math.min(explicit, localEvidence), range);
  }
  if (runtime !== null && runtime > 0) {
    return clampMinutes(runtime, range);
  }
  return localEvidence;
}

function hasPcAvailableEvidence(summary = {}) {
  return Number.isFinite(Number(summary.gross_pc_available_minutes)) ||
    Number.isFinite(Number(summary.work_minutes_breakdown?.gross_pc_available_minutes)) ||
    Number(summary.runtime_available_minutes || 0) > 0;
}

function hasOfficialWorkEvidence(summary = {}) {
  return hasPcAvailableEvidence(summary) ||
    Number.isFinite(Number(summary.work_minutes)) ||
    Number.isFinite(Number(summary.work_minutes_breakdown?.total_work_minutes));
}

function canonicalCoverageForReport(report = {}, summary = {}) {
  return report.canonical_coverage || summary.canonical_coverage || report.canonical_summary?.canonical_coverage || null;
}

function formatOfficialMinutes(minutes, hasEvidence, coverage = null) {
  if (!hasEvidence) {
    return coverage && coverage.complete === false ? 'Unavailable' : 'Not available';
  }
  const suffix = coverage && coverage.complete === false ? ' partial' : '';
  return `${formatMinutes(minutes)}${suffix}`;
}

function canonicalCoverageLabel(coverage = null) {
  if (!coverage) {
    return '';
  }
  if (coverage.complete !== false) {
    return 'Complete';
  }
  const missing = Number(coverage.missing_dates?.length || 0);
  const incomplete = Number(coverage.incomplete_dates?.length || 0);
  const affected = missing + incomplete;
  return affected > 0 ? `Incomplete (${affected} day${affected === 1 ? '' : 's'})` : 'Incomplete';
}

function finiteNumber(...values) {
  for (const value of values) {
    if (value === null || value === undefined || value === '') {
      continue;
    }
    const number = Number(value);
    if (Number.isFinite(number)) {
      return number;
    }
  }
  return null;
}

function clampMinutes(minutes, rangeMinutes = null) {
  const value = Math.max(0, Math.round(Number(minutes) || 0));
  const range = Number(rangeMinutes);
  if (!Number.isFinite(range) || range <= 0) {
    return value;
  }
  return Math.min(Math.max(0, Math.round(range)), value);
}

function weekdayShort(dateValue) {
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) {
    return '--';
  }
  return date.toLocaleDateString([], { weekday: 'short' });
}

function renderFocusScore(summary = {}, trend = {}) {
  const score = focusScoreFromSummary(summary);
  const days = (trend.days || []).slice(-7);
  const trendRows = days.length ? days : Array.from({ length: 7 }, () => ({ score_percent: 0 }));
  const weeklyAverage = Number.isFinite(Number(trend.average_score_percent))
    ? Math.max(0, Math.min(100, Math.round(Number(trend.average_score_percent))))
    : 0;

  return `
    <div class="focus-score-card">
      <div class="focus-score-head">
        <div>
          <div class="report-subtitle">Focus Score</div>
          <div class="focus-score-copy">Deep Work / Total Active Time</div>
          <div class="focus-score-copy">Weekly Focus: ${escapeHtml(`${weeklyAverage}% average`)}</div>
        </div>
        <div>
          <div class="focus-score-value">${escapeHtml(score.label)}</div>
          <div class="focus-score-copy">${escapeHtml(`${formatMinutes(score.deep_work_minutes)} deep work of ${formatMinutes(score.total_active_minutes)} active`)}</div>
        </div>
      </div>
      <div class="weekly-trend" title="Last 7 days">
        ${trendRows.map((day) => {
          const value = Math.max(0, Math.min(100, Math.round(Number(day.score_percent || 0))));
          return `
            <div class="weekly-trend-day">
              <div class="weekly-trend-track"><div class="weekly-trend-fill" style="height:${escapeHtml(String(value))}%"></div></div>
              <div class="weekly-trend-label">${escapeHtml(weekdayShort(day.date))}</div>
              <div class="weekly-trend-score">${escapeHtml(`${value}%`)}</div>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;
}

function renderTaskList(tasks = []) {
  const pending = tasks.filter((task) => task.status === 'pending');
  const candidates = tasks.filter((task) => task.status === 'candidate');
  const resolved = tasks.filter((task) => task.status === 'resolved');

  if (!pending.length && !candidates.length && !resolved.length) {
    return '<div class="empty-state">No pending follow-ups were detected from today\'s screen data.</div>';
  }

  const renderRows = (items) => `
    <div class="task-list">
      ${items.slice(0, 20).map((task) => `
        <div class="task-row">
          <div class="task-title">${escapeHtml(task.task_title || 'Untitled follow-up')}</div>
          <div class="task-meta">${escapeHtml([
            task.status || 'candidate',
            task.priority,
            task.context,
            formatCompactTime(task.source_timestamp),
            task.status_reason
          ].filter(Boolean).join(' | '))}</div>
          ${task.resolution_evidence && task.status === 'resolved' ? `<div class="task-meta">${escapeHtml(`Resolution evidence: ${task.resolution_evidence}`)}</div>` : ''}
        </div>
      `).join('')}
    </div>
  `;

  return [
    pending.length ? `<div class="report-note">Likely pending from screen data.</div>${renderRows(pending)}` : '<div class="empty-state">No likely pending follow-ups found.</div>',
    candidates.length ? `<div class="report-note">Possible follow-ups, not proven pending.</div>${renderRows(candidates)}` : '',
    resolved.length ? `<details><summary class="report-note">Resolved or completed candidates (${resolved.length})</summary>${renderRows(resolved)}</details>` : ''
  ].filter(Boolean).join('');
}

function titleReportKey(title) {
  return String(title || 'Untitled work')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function emptyClassifiedMs() {
  return CLASSIFICATION_KEYS.reduce((value, key) => {
    value[key] = 0;
    return value;
  }, {});
}

function mergeClassifiedMs(left = {}, right = {}) {
  return Object.keys(emptyClassifiedMs()).reduce((merged, key) => {
    merged[key] = Number(left[key] || 0) + Number(right[key] || 0);
    return merged;
  }, emptyClassifiedMs());
}

function dominantClassificationFromMs(classifiedMs = {}) {
  const entries = Object.entries(emptyClassifiedMs())
    .map(([key]) => ({
      key,
      value: Number(classifiedMs[key] || 0)
    }))
    .sort((left, right) => right.value - left.value);

  if (!entries[0]?.value || entries[0].value === entries[1]?.value) {
    return 'unclear';
  }

  return entries[0].key;
}

function buildTitleReportRows(appTimeline = []) {
  const grouped = new Map();

  appTimeline.forEach((appGroup) => {
    const appName = appGroup.app_name || appGroup.app_id || 'Unknown app';
    (appGroup.items || []).forEach((item) => {
      const title = item.title || 'Untitled work';
      const key = titleReportKey(title);
      if (!grouped.has(key)) {
        grouped.set(key, {
          title,
          durationMs: 0,
          durationMinutes: 0,
          eventCount: 0,
          sessionCount: 0,
          apps: new Set(),
          urls: new Map(),
          latestTimestamp: item.timestamp,
          classifiedMs: emptyClassifiedMs()
        });
      }

      const entry = grouped.get(key);
      entry.durationMs += Number(item.duration_ms_estimate || 0);
      entry.durationMinutes += Number(item.duration_minutes_estimate || 0);
      entry.eventCount += Number(item.event_count || 0);
      entry.sessionCount += Number(item.session_count || 1);
      entry.apps.add(appName);
      entry.classifiedMs = mergeClassifiedMs(entry.classifiedMs, item.classified_ms || {
        [item.classification || 'unclear']: Number(item.duration_ms_estimate || 0)
      });

      if (item.latest_url) {
        entry.urls.set(item.latest_url, item.timestamp || '');
      }
      (item.captured_urls || []).forEach((urlEntry) => {
        if (urlEntry?.url) {
          entry.urls.set(urlEntry.url, urlEntry.timestamp || item.timestamp || '');
        }
      });

      if (new Date(item.timestamp).getTime() > new Date(entry.latestTimestamp).getTime()) {
        entry.latestTimestamp = item.timestamp;
      }
    });
  });

  return Array.from(grouped.values())
    .map((entry) => ({
      ...entry,
      durationMinutes: entry.durationMs > 0 ? Math.max(1, Math.round(entry.durationMs / 60000)) : Math.round(entry.durationMinutes),
      apps: Array.from(entry.apps),
      urls: Array.from(entry.urls.keys()),
      classification: dominantClassificationFromMs(entry.classifiedMs),
      classified_minutes: {
        work: Math.round(Number(entry.classifiedMs.work || 0) / 60000),
        meeting: Math.round(Number(entry.classifiedMs.meeting || 0) / 60000),
        social: Math.round(Number(entry.classifiedMs.social || 0) / 60000),
        other: Math.round(Number(entry.classifiedMs.other || 0) / 60000),
        unclear: Math.round(Number(entry.classifiedMs.unclear || 0) / 60000)
      }
    }))
    .filter((entry) => Number(entry.durationMinutes || 0) > 1)
    .sort((left, right) => Number(right.durationMinutes || 0) - Number(left.durationMinutes || 0));
}

function reportRowForClass(row, classification, minutes) {
  return {
    ...row,
    durationMinutes: minutes,
    classification,
    classified_minutes: {
      ...emptyClassifiedMs(),
      [classification]: minutes
    }
  };
}

function splitDailyReportRows(appTimeline = []) {
  if (appTimeline && typeof appTimeline === 'object' && dailyReportRowsCache.has(appTimeline)) {
    return dailyReportRowsCache.get(appTimeline);
  }
  const rows = buildTitleReportRows(appTimeline);
  const rowsForClass = (classification) => rows
    .map((row) => reportRowForClass(row, classification, Number(row.classified_minutes?.[classification] || 0)))
    .filter((row) => Number(row.durationMinutes || 0) > 1);
  const referencedRows = rows
    .map((row) => reportRowForClass(
      row,
      row.classification === 'other' ? 'other' : 'unclear',
      Number(row.classified_minutes?.other || 0) + Number(row.classified_minutes?.unclear || 0)
    ))
    .filter((row) => Number(row.durationMinutes || 0) > 1);

  const result = {
    workRows: rowsForClass('work'),
    meetingRows: rowsForClass('meeting'),
    socialRows: rowsForClass('social'),
    referencedRows
  };
  if (appTimeline && typeof appTimeline === 'object') {
    dailyReportRowsCache.set(appTimeline, result);
  }
  return result;
}

function isoDateOnly(value = new Date()) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) {
    return isoDateOnly(new Date());
  }

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function formatReportRangeLabel(summary = {}) {
  const start = summary.range_start ? new Date(summary.range_start) : new Date();
  const end = summary.range_end ? new Date(summary.range_end) : null;
  if (Number.isNaN(start.getTime())) {
    return new Date().toLocaleDateString([], {
      weekday: 'long',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  const startLabel = start.toLocaleDateString([], {
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
  if (!end || Number.isNaN(end.getTime()) || isoDateOnly(start) === isoDateOnly(end)) {
    return startLabel;
  }

  const endLabel = end.toLocaleDateString([], {
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
  return `${startLabel} to ${endLabel}`;
}

function buildPayrollReportPayload(data = {}) {
  const summary = safeSummary(data.summary);
  const profile = profileValues();
  const reportDate = isoDateOnly(summary.range_start || new Date());
  const classified = summary.classified_minutes || {};
  const reportRows = splitDailyReportRows(summary.app_timeline || []);

  return {
    email_address: profile.email,
    name: profile.name,
    report_date: reportDate,
    generated_at: new Date().toISOString(),
    active_minutes: Number(summary.estimated_active_minutes || 0),
    captured_minutes: Number(summary.captured_minutes_estimate || summary.estimated_active_minutes || 0),
    passive_candidate_minutes: Number(summary.passive_candidate_minutes || 0),
    idle_minutes: Number(summary.input_idle_minutes || 0),
    missing_minutes: Number(summary.missing_minutes || 0),
    focus_score_percent: Number(summary.focus_score?.score_percent || 0),
    deep_work_minutes: Number(summary.focus_score?.deep_work_minutes || summary.pc_work_minutes || 0),
    work_minutes: canonicalWorkMinutes(summary),
    manual_timing_minutes: Number(summary.manual_timing_blocks?.total_minutes || summary.manual_timing_minutes || 0),
    manual_net_added_work_minutes: Number.isFinite(Number(summary.manual_net_added_work_minutes))
      ? Number(summary.manual_net_added_work_minutes)
      : Number(summary.manual_timing_blocks?.net_added_minutes || 0),
    meeting_minutes: Number(classified.meeting || 0),
    social_minutes: Number(classified.social || 0),
    other_minutes: Number(classified.other || 0),
    unclear_minutes: Number(classified.unclear || 0),
    title_wise_rows: payrollRows(reportRows.workRows),
    viewed_referenced_rows: payrollRows(reportRows.referencedRows),
    video_meeting_rows: payrollRows(reportRows.meetingRows),
    social_rows: payrollRows(reportRows.socialRows),
    tasks: (data.tasks || []).slice(0, 80),
    pending_follow_ups: (data.tasks || []).filter((task) => task.status === 'pending').slice(0, 40),
    focus_trend: compactFocusTrend(data.focus_trend),
    summary: compactPayrollSummary(summary)
  };
}

function payrollRows(rows = []) {
  return rows.slice(0, MAX_PAYROLL_ROWS_PER_SECTION).map((row) => ({
      title: row.title,
      minutes: Number(row.durationMinutes || 0),
      apps: (row.apps || []).slice(0, 4),
      urls: (row.urls || []).slice(0, 5),
      classification: row.classification,
      event_count: row.eventCount,
      session_count: row.sessionCount,
      latest_timestamp: row.latestTimestamp
    }));
}

function compactFocusTrend(focusTrend = null) {
  if (!focusTrend) {
    return null;
  }
  return {
    average_score_percent: focusTrend.average_score_percent,
    days: (focusTrend.days || []).slice(-7).map((day) => ({
      date: day.date,
      score_percent: day.score_percent,
      work_minutes: day.work_minutes,
      active_minutes: day.active_minutes
    }))
  };
}

function compactPayrollSummary(summary = {}) {
  return {
    range_start: summary.range_start,
    range_end: summary.range_end,
    range_minutes: summary.range_minutes,
    estimated_active_minutes: summary.estimated_active_minutes,
    captured_minutes_estimate: summary.captured_minutes_estimate,
    passive_candidate_minutes: summary.passive_candidate_minutes,
    input_idle_minutes: summary.input_idle_minutes,
    accounted_minutes: summary.accounted_minutes,
    missing_minutes: summary.missing_minutes,
    coverage_complete: summary.coverage_complete,
    coverage_percent: summary.coverage_percent,
    minute_partition: summary.minute_partition,
    work_minutes: canonicalWorkMinutes(summary),
    pc_work_minutes: Number(summary.pc_work_minutes || summary.focus_score?.deep_work_minutes || 0),
    manual_timing_blocks: summary.manual_timing_blocks || {},
    classified_minutes: summary.classified_minutes || {},
    focus_score: summary.focus_score || {},
    apps_used: (summary.app_display_names || summary.apps_used || []).slice(0, 20),
    websites_visited: (summary.websites_visited || []).slice(0, 30),
    meetings_or_calls: {
      event_count: summary.meetings_or_calls?.event_count || 0,
      total_minutes: summary.meetings_or_calls?.total_minutes || 0,
      items: (summary.meetings_or_calls?.items || []).slice(0, 20)
    }
  };
}

function renderTitleReportRows(rows = [], emptyText = 'No qualifying rows were found for this day.', limit = 8) {
  if (!rows.length) {
    return `<div class="empty-state">${escapeHtml(emptyText)}</div>`;
  }
  const visibleRows = rows.slice(0, limit);
  const hiddenCount = Math.max(0, rows.length - visibleRows.length);

  return `
    <div class="activity-card-list">
      ${visibleRows.map((row) => {
        const source = primarySourceLabel(row);
        return `
          <div class="activity-card">
            <div class="activity-card-main">
              <div class="activity-card-title">${escapeHtml(reportRowSentence(row))}</div>
              <div class="activity-card-meta">
                <span>${escapeHtml(classificationLabel(row.classification))}</span>
                <span>${escapeHtml(source)}</span>
              </div>
            </div>
            <div class="activity-card-time">${escapeHtml(formatMinutes(row.durationMinutes))}</div>
          </div>
        `;
      }).join('')}
      ${hiddenCount ? `<div class="report-note">Showing top ${escapeHtml(String(visibleRows.length))} of ${escapeHtml(String(rows.length))} rows. Use Timeline for the full list.</div>` : ''}
    </div>
  `;
}

function renderNonWorkObservations(observations = {}) {
  const items = Array.isArray(observations.items) ? observations.items : [];
  if (!items.length) {
    return '<div class="empty-state">No likely non-work signals were detected from app, title, or domain evidence.</div>';
  }
  const categoryCopy = (observations.category_minutes || [])
    .map((row) => `${row.label}: ${formatMinutes(row.minutes)}`)
    .join(' | ');
  return `
    ${categoryCopy ? `<div class="report-note">${escapeHtml(categoryCopy)}</div>` : ''}
    <div class="activity-card-list">
      ${items.slice(0, 8).map((item) => `
        <div class="activity-card">
          <div class="activity-card-main">
            <div class="activity-card-title">${escapeHtml(item.title || item.host || item.app_name || 'Observed activity')}</div>
            <div class="activity-card-meta">
              <span>${escapeHtml(item.category || 'Observation')}</span>
              <span>${escapeHtml(item.host || item.app_name || 'Existing evidence')}</span>
              <span>${escapeHtml(item.rule || 'rule')}</span>
            </div>
          </div>
          <div class="activity-card-time">${escapeHtml(formatMinutes(item.minutes || 0))}</div>
        </div>
      `).join('')}
    </div>
  `;
}

function renderManualTimingRows(blocks = {}) {
  const items = blocks.items || [];
  if (!items.length) {
    return '<div class="empty-state">No manual timing blocks were added for this day.</div>';
  }

  return `
    <div class="activity-card-list">
      ${items.slice(0, 8).map((item) => `
        <div class="activity-card">
          <div class="activity-card-main">
            <div class="activity-card-title">${escapeHtml(item.title || 'Manual Timing Block')}</div>
            <div class="activity-card-meta">
              <span>${escapeHtml(classificationLabel(item.kind || 'manual'))}</span>
              <span>${escapeHtml(`${formatCompactTime(item.start)} to ${formatCompactTime(item.end)}`)}</span>
            </div>
          </div>
          <div class="activity-card-time">${escapeHtml(formatMinutes(item.net_added_minutes || item.minutes || 0))}</div>
        </div>
      `).join('')}
    </div>
  `;
}

function renderFocusPatterns(summary = {}, reportRows = {}) {
  const socialRows = reportRows.socialRows || [];
  const topDistraction = socialRows[0];
  const appTimeline = summary.app_timeline || [];
  const totalSessions = appTimeline.reduce((sum, group) => sum + Number(group.session_count || 0), 0);
  const topFocusBlock = appTimeline
    .flatMap((group) => group.items || [])
    .filter((item) => item.classification === 'work')
    .sort((left, right) => Number(right.duration_minutes_estimate || 0) - Number(left.duration_minutes_estimate || 0))[0];
  const socialMinutes = Number(summary.classified_minutes?.social || 0);
  const activeMinutes = Number(summary.estimated_active_minutes || 0);
  const distractionShare = activeMinutes > 0 ? Math.round((socialMinutes / activeMinutes) * 100) : 0;

  return `
    <div class="report-block">
      <div class="report-subtitle">Focus Patterns</div>
      ${renderSummaryRows([
        {
          label: 'Distraction',
          value: topDistraction
            ? `${formatMinutes(topDistraction.durationMinutes)} | ${topDistraction.title}`
            : 'No major distraction found'
        },
        { label: 'Social Share', value: `${formatMinutes(socialMinutes)}${activeMinutes ? ` | ${distractionShare}% of active time` : ''}` },
        {
          label: 'Best Focus Block',
          value: topFocusBlock
            ? `${formatMinutes(topFocusBlock.duration_minutes_estimate || 0)} | ${topFocusBlock.title || topFocusBlock.app_name || 'Work'}`
            : 'No deep work block found'
        },
        { label: 'Switching', value: `${totalSessions} focused session block(s)` }
      ])}
    </div>
  `;
}

function renderSystemProcessNote(records = []) {
  if (!records.length) {
    return '';
  }

  const count = records.length;
  const label = count === 1 ? 'entry' : 'entries';
  return `
    <div class="system-process-note">
      <div class="system-process-text">
        <strong>System Process</strong> captured for debugging but not analyzed. ${escapeHtml(String(count))} ${label} available in the debug log.
      </div>
      <button class="debug-link" onclick="window.panelActions.openSystemProcessModal()">View Log</button>
    </div>
  `;
}

function renderSystemProcessLog(records = []) {
  if (!records.length) {
    return '<div class="empty-state">No System Process records are available for this range.</div>';
  }

  return records.slice(0, 50).map((record) => `
    <div class="log-item">
      <div class="log-meta">
        <span>${escapeHtml(formatCompactTime(record.timestamp_start))}</span>
        <span>${escapeHtml(record.activity_type || 'unknown')}</span>
        <span>${escapeHtml(record.source || 'screenpipe')}</span>
      </div>
      <div class="log-title">${escapeHtml(record.window_title || 'System Process')}</div>
      <div class="log-text">${escapeHtml(String(record.ocr_text || record.transcript_text || record.text || 'No OCR or transcript text captured.').slice(0, 1000))}</div>
    </div>
  `).join('') + (records.length > 50 ? `<div class="report-note">Showing 50 of ${escapeHtml(String(records.length))} debug records.</div>` : '');
}

function setSystemProcessRecords(records = []) {
  latestSystemProcessRecords = Array.isArray(records) ? records : [];
  systemProcessInline.style.display = latestSystemProcessRecords.length ? 'flex' : 'none';
  systemProcessModalContent.innerHTML = latestSystemProcessRecords.length
    ? '<div class="report-note">Open requested. Rendering debug records only when this modal is opened.</div>'
    : renderSystemProcessLog([]);
}

function openSystemProcessModal() {
  systemProcessModalContent.innerHTML = renderSystemProcessLog(latestSystemProcessRecords);
  systemProcessModal.classList.add('open');
  systemProcessModal.setAttribute('aria-hidden', 'false');
}

function closeSystemProcessModal() {
  systemProcessModal.classList.remove('open');
  systemProcessModal.setAttribute('aria-hidden', 'true');
}

function setManualBlockStatus(message = '', tone = '') {
  if (!manualBlockStatus) {
    return;
  }
  manualBlockStatus.textContent = message;
  manualBlockStatus.dataset.tone = tone;
}

function consumedManualSlotKeys(summary = {}) {
  return new Set((Array.isArray(summary?.manual_consumed_slots) ? summary.manual_consumed_slots : [])
    .map((slot) => slot?.key || `${slot?.start || ''}|${slot?.end || ''}`)
    .filter((key) => key && key !== '|'));
}

function normalizeManualIdleBlocks(summary = {}) {
  const intervals = Array.isArray(summary?.intervals) ? summary.intervals : [];
  const consumed = consumedManualSlotKeys(summary);
  return intervals
    .map((interval, index) => {
      const start = new Date(interval.start || interval.start_time || 0);
      const end = new Date(interval.end || interval.end_time || 0);
      if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
        return null;
      }
      const slotKey = `${start.toISOString()}|${end.toISOString()}`;
      if (consumed.has(slotKey)) {
        return null;
      }
      const minutes = Math.max(1, Math.round((end.getTime() - start.getTime()) / 60000));
      return {
        id: `${start.toISOString()}|${end.toISOString()}|${index}`,
        slotKey,
        startTime: start.toISOString(),
        endTime: end.toISOString(),
        minutes,
        label: `${formatCompactTime(start.toISOString())}-${formatCompactTime(end.toISOString())} (${formatMinutes(minutes)})`
      };
    })
    .filter(Boolean)
    .sort((left, right) => new Date(right.startTime).getTime() - new Date(left.startTime).getTime());
}

function renderManualIdleBlocks(summary = {}) {
  const select = document.getElementById('manualIdleBlock');
  if (!select) {
    return;
  }
  const previous = select.value;
  latestManualIdleBlocks = normalizeManualIdleBlocks(summary);
  if (!latestManualIdleBlocks.length) {
    const hasConsumedSlots = consumedManualSlotKeys(summary).size > 0;
    select.innerHTML = hasConsumedSlots
      ? '<option value="">No unused idle blocks available today</option>'
      : '<option value="">No idle blocks detected today</option>';
    select.disabled = true;
    const button = document.getElementById('addManualBlock');
    if (button) {
      button.disabled = true;
    }
    setManualBlockStatus(hasConsumedSlots
      ? 'All detected idle blocks already have manual entries.'
      : 'No idle blocks are available to restore.', 'warn');
    return;
  }

  select.innerHTML = latestManualIdleBlocks.map((block) => (
    `<option value="${escapeHtml(block.id)}">${escapeHtml(block.label)}</option>`
  )).join('');
  select.value = latestManualIdleBlocks.some((block) => block.id === previous)
    ? previous
    : latestManualIdleBlocks[0].id;
  select.disabled = false;
  const button = document.getElementById('addManualBlock');
  if (button && button.textContent !== 'Saving...') {
    button.disabled = false;
  }
}

function selectedManualIdleBlock() {
  const select = document.getElementById('manualIdleBlock');
  return latestManualIdleBlocks.find((block) => block.id === select?.value) || null;
}

function setManualBlockBusy(isBusy) {
  const button = document.getElementById('addManualBlock');
  if (button) {
    button.disabled = isBusy || latestManualIdleBlocks.length === 0;
    button.textContent = isBusy ? 'Saving...' : 'Add Block';
  }
  ['manualIdleBlock', 'manualNote'].forEach((id) => {
    const input = document.getElementById(id);
    if (input) {
      input.disabled = isBusy || (id === 'manualIdleBlock' && latestManualIdleBlocks.length === 0);
    }
  });
  document.querySelectorAll('input[name="manualKind"]').forEach((input) => {
    input.disabled = isBusy;
  });
}

function openManualBlockModal(options = {}) {
  if (options.kind) {
    setRadioValue('manualKind', options.kind);
  }
  setManualBlockStatus('Pick an idle block Cognify detected. Manual work/meeting restores deducted idle only.');
  setManualBlockBusy(false);
  manualBlockModal.classList.add('open');
  manualBlockModal.setAttribute('aria-hidden', 'false');
  refreshIdleSummary();
  setTimeout(() => {
    document.getElementById('manualIdleBlock')?.focus();
  }, 0);
}

function closeManualBlockModal() {
  setManualBlockBusy(false);
  manualBlockModal.classList.remove('open');
  manualBlockModal.setAttribute('aria-hidden', 'true');
}

function openOnboardingModal() {
  onboardingStep = 0;
  renderOnboardingStep();
  document.body.classList.add('onboarding-active');
  onboardingModal?.classList.add('open');
  onboardingModal?.setAttribute('aria-hidden', 'false');
  setTimeout(() => onboardingNextButton?.focus(), 0);
}

function closeOnboardingModal() {
  onboardingModal?.classList.remove('open');
  onboardingModal?.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('onboarding-active');
}

function setOnboardingError(message = '') {
  if (onboardingError) {
    onboardingError.textContent = message;
  }
}

function renderOnboardingStep() {
  const steps = [...document.querySelectorAll('[data-onboarding-step]')];
  const dots = [...document.querySelectorAll('[data-onboarding-dot]')];
  onboardingProgress?.classList.toggle('visible', onboardingStep > 0);
  onboardingModal?.classList.toggle('welcome-mode', onboardingStep === 0);
  steps.forEach((step) => {
    step.classList.toggle('active', Number(step.dataset.onboardingStep) === onboardingStep);
  });
  dots.forEach((dot) => {
    const index = Number(dot.dataset.onboardingDot);
    dot.classList.toggle('active', index === onboardingStep);
    dot.classList.toggle('done', index < onboardingStep);
  });
  if (onboardingBackButton) {
    onboardingBackButton.disabled = onboardingStep === 0;
    onboardingBackButton.style.visibility = onboardingStep === 0 ? 'hidden' : 'visible';
  }
  if (onboardingNextButton) {
    onboardingNextButton.style.display = onboardingStep >= 4 ? 'none' : '';
  }
  if (onboardingFinishButton) {
    onboardingFinishButton.style.display = onboardingStep >= 4 ? '' : 'none';
  }
  setOnboardingError('');
}

function validateOnboardingStep() {
  if (onboardingStep === 1) {
    const name = setupName?.value.trim() || '';
    const email = setupEmail?.value.trim() || '';
    if (!name) {
      return 'Enter your name to continue.';
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return 'Enter a valid email address to continue.';
    }
  }
  if (onboardingStep === 2 && !selectedSetupRoleLabel()) {
    return 'Select a role or enter a custom role to continue.';
  }
  if (onboardingStep === 3 && (setupRoleNotes?.value.trim() || '').length < 20) {
    return 'Add a short work context note so Cognify can understand your role better.';
  }
  return '';
}

function onboardingNext() {
  const error = validateOnboardingStep();
  if (error) {
    setOnboardingError(error);
    return;
  }
  onboardingStep = Math.min(4, onboardingStep + 1);
  renderOnboardingStep();
  const focusTargets = [onboardingNextButton, setupName, setupRoleId, setupRoleNotes, onboardingFinishButton];
  setTimeout(() => focusTargets[onboardingStep]?.focus(), 0);
}

function onboardingBack() {
  onboardingStep = Math.max(0, onboardingStep - 1);
  renderOnboardingStep();
}

async function finishOnboarding() {
  await runSafely('finishOnboarding', async () => {
    const error = validateOnboardingStep();
    if (error) {
      setOnboardingError(error);
      return;
    }
    const roleId = setupRoleId.value || 'custom';
    await window.assistantApi.updateProfile({
      name: setupName.value,
      email: setupEmail.value
    });
    const saved = await window.assistantApi.updateRoleProfile({
      role: selectedSetupRoleLabel(),
      roleId,
      roleSource: roleId === 'custom' ? 'custom' : 'confirmed_selected',
      roleNotes: setupRoleNotes.value
    });
    await window.assistantApi.completeOnboarding({ completedAt: true });
    profileName.value = setupName.value.trim();
    profileEmail.value = setupEmail.value.trim();
    profileRoleId.value = saved.profile?.roleId || roleId;
    profileRole.value = saved.profile?.role || selectedSetupRoleLabel();
    profileRoleNotes.value = saved.profile?.roleNotes || setupRoleNotes.value.trim();
    syncRoleCustomField();
    renderRoleDetectionHint(saved.profile || {});
    savedProfileSnapshot = profileValues();
    setProfileEditorVisible(false);
    closeOnboardingModal();
  }, 'Saving onboarding status failed');
}

async function exitOnboarding() {
  await window.assistantApi.quitApp();
}

function formatSyncStatusNote(sync) {
  if (!sync || sync.complete) {
    return '';
  }

  const incompleteCount = Number(sync.incomplete_window_count || 0);
  const label = incompleteCount === 1 ? 'window' : 'windows';
  return `
    <div class="sync-warning">
      Activity may be partial. ${escapeHtml(String(incompleteCount))} sync ${label} still need backfill for this range.
    </div>
  `;
}

function encodeActionValue(value) {
  return encodeURIComponent(String(value ?? ''));
}

function cssEscape(value) {
  if (window.CSS?.escape) {
    return window.CSS.escape(String(value ?? ''));
  }
  return String(value ?? '').replace(/["\\]/g, '\\$&');
}

function renderCapturedUrls(urls = []) {
  if (!urls.length) {
    return '';
  }

  return `
    <div class="session-drawer">
      <div class="report-note">Captured links for this session group.</div>
      <div class="session-url-list">
        ${urls.slice(0, 5).map((entry) => `
          <div class="session-url-item">
            <div class="session-url-copy">${escapeHtml(formatTimeOnly(entry.timestamp))}</div>
            <div class="session-url-text" title="${escapeHtml(entry.url)}">${escapeHtml(entry.url)}</div>
            <div class="session-url-actions">
              <button onclick="window.panelActions.openExternalUrl('${encodeActionValue(entry.url)}')">Open</button>
              <button onclick="window.panelActions.copyText('${encodeActionValue(entry.url)}')">Copy URL</button>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderSessionEvidence(item = {}) {
  const urls = renderCapturedUrls(item.captured_urls || []);
  const rules = renderRuleEvidence(item);
  return `
    <div class="session-drawer">
      ${rules}
    </div>
    ${urls}
  `;
}

function formatBrowserActivity(browserActivity = {}) {
  return `
    <div class="report-block">
      <div class="report-subtitle">Browser Activity</div>
      ${renderSummaryRows([
        { label: 'Browser events', value: String(browserActivity.event_count || 0) },
        { label: 'Browsers', value: formatList(browserActivity.browser_names || browserActivity.apps_used || []) },
        { label: 'Captured sites', value: String((browserActivity.sites || []).length) }
      ])}
      ${renderChips(limitList(browserActivity.sites || [], 10), 'No captured browser sites')}
    </div>
  `;
}

function formatAppTimeline(appTimeline = []) {
  if (!appTimeline.length) {
    return '<div class="empty-state">No app activity found in this time range.</div>';
  }

  return `
    <div class="app-list">
      ${appTimeline.slice(0, 12).map((group) => {
        const items = (group.items || []).slice(0, 24).map((item) => {
          const row = `
            <div class="timeline-row">
              <div class="timeline-time">${escapeHtml(formatCompactTime(item.timestamp))}</div>
              <div class="timeline-main">
                ${renderClassBadge(item.classification, item.classification_confidence)}
                <div class="timeline-title">${escapeHtml(item.title || 'Untitled window')}</div>
                <div class="session-meta">${escapeHtml(`${item.duration_label || '0m'} | ${item.event_count || 1} events${item.session_count > 1 ? ` | ${item.session_count} sessions` : ''}`)}</div>
              </div>
            </div>
          `;

          if (!item.captured_urls?.length && !item.matched_rules?.length) {
            return row;
          }

          return `
            <details class="session-item">
              <summary>${row}</summary>
              ${renderSessionEvidence(item)}
            </details>
          `;
        }).join('');

        return `
          <details class="app-item">
            <summary>
              <span class="app-name">${escapeHtml(group.app_name)}</span>
              ${renderClassBadge(group.classification, group.classification_confidence)}
              ${renderClassBuckets(group.classified_minutes || {})}
              <span class="app-meta">${escapeHtml(group.total_time_label || '0m')}</span>
              <span class="app-meta">${escapeHtml(`${group.event_count} events`)}</span>
              <span class="app-meta">${escapeHtml((group.dates || []).join(', ') || 'No date')}</span>
            </summary>
            <div class="timeline">${items || '<div class="empty-state">No captured titles</div>'}</div>
          </details>
        `;
      }).join('')}
    </div>
  `;
}

function formatAskResultHtml(data) {
  data = safeObject(data);
  const summary = safeSummary(data.summary);
  const browserActivity = summary.browser_activity || {};

  return `
    ${formatSyncStatusNote(data.sync)}
    ${renderSystemProcessNote(data.system_process_records || [])}
    <div class="report-block">
      <div class="report-title">Summary</div>
      <div class="report-copy">${escapeHtml(data.message || 'No answer available.')}</div>
      ${renderSummaryRows([
        { label: 'Activity events', value: String(summary.activity_events || summary.event_count || data.context_count || 0) },
        { label: 'Apps used', value: String((summary.app_display_names || summary.apps_used || []).length) },
        { label: 'Browsers', value: formatList(browserActivity.browser_names || [], 'None') }
      ])}
      ${formatBrowserActivity(browserActivity)}
    </div>
    <div class="report-block">
      <div class="report-subtitle">Apps</div>
      <div class="report-note">Expand an app to see captured time and titles.</div>
      ${formatAppTimeline(summary.app_timeline || [])}
    </div>
  `;
}

function formatSummaryHtml(summary = {}, sync) {
  summary = safeSummary(summary);
  const browserActivity = summary.browser_activity || {};
  const focusScore = focusScoreFromSummary(summary);
  const workMinutes = canonicalWorkMinutes(summary);
  const pcAvailableMinutes = canonicalPcAvailableMinutes(summary);
  const idleMinutes = Math.min(pcAvailableMinutes, Math.max(0, Math.round(Number(summary.idle_minutes || summary.input_idle_minutes || 0))));

  return `
    ${formatSyncStatusNote(sync)}
    ${renderSystemProcessNote(latestSystemProcessRecords)}
    <div class="report-block">
      <div class="report-title">Daily Summary</div>
      ${renderSummaryRows([
        { label: 'Work Hours', value: formatMinutes(workMinutes) },
        { label: 'PC Available', value: formatMinutes(pcAvailableMinutes) },
        { label: 'Idle deducted', value: formatMinutes(idleMinutes) },
        { label: 'Focus Score', value: focusScore.label },
        { label: 'Deep Work', value: formatMinutes(focusScore.deep_work_minutes) },
        { label: 'Apps used', value: formatList(summary.app_display_names || summary.apps_used || []) },
        { label: 'Browsers', value: formatList(browserActivity.browser_names || [], 'None') },
        { label: 'Captured sites', value: String((browserActivity.sites || []).length) }
      ])}
      ${formatBrowserActivity(browserActivity)}
    </div>
    <div class="report-block">
      <div class="report-subtitle">Apps</div>
      <div class="report-note">Expand an app to see captured time and titles.</div>
      ${formatAppTimeline(summary.app_timeline || [])}
    </div>
  `;
}

function formatDailyReportHtml(data = {}) {
  data = safeObject(data);
  const summary = safeSummary(data.summary);
  const browserActivity = summary.browser_activity || {};
  const tasks = data.tasks || [];
  const reportRows = splitDailyReportRows(summary.app_timeline || []);
  const reportDate = formatReportRangeLabel(summary);
  const activeMinutes = Number(summary.estimated_active_minutes || 0);
  const capturedMinutes = Number(summary.captured_minutes_estimate || activeMinutes);
  const passiveMinutes = Number(summary.passive_candidate_minutes || Math.max(0, capturedMinutes - activeMinutes));
  const idleMinutes = Number(summary.input_idle_minutes || 0);
  const missingMinutes = Number(summary.missing_minutes || 0);
  const classified = summary.classified_minutes || {};
  const manualBlocks = summary.manual_timing_blocks || {};
  const manualTotalMinutes = Number(manualBlocks.total_minutes || summary.manual_timing_minutes || 0);
  const rawManualNetMinutes = Number.isFinite(Number(summary.manual_net_added_work_minutes))
    ? Number(summary.manual_net_added_work_minutes)
    : Number(manualBlocks.net_added_minutes || 0);
  const manualNetMinutes = Math.min(Math.max(0, Math.round(idleMinutes)), Math.max(0, Math.round(rawManualNetMinutes)));
  const focusScore = focusScoreFromSummary(summary);
  const nonWorkObservations = summary.non_work_observations || {};
  const weeklyFocus = Number.isFinite(Number(data.focus_trend?.average_score_percent))
    ? `${Math.max(0, Math.min(100, Math.round(Number(data.focus_trend.average_score_percent))))}%`
    : '--';
  const workMinutes = canonicalWorkMinutes(summary);
  const meetingMinutes = Number(classified.meeting || 0);
  const socialMinutes = Number(classified.social || 0);
  const pendingTasks = tasks.filter((task) => task.status === 'pending');
  const referenceMinutes = Number(classified.other || 0) + Number(classified.unclear || 0);
  const pcWorkMinutes = Number(summary.pc_work_minutes || focusScore.deep_work_minutes || classified.work || 0);
  const cacheLabel = cacheStatusLabel(data.cache || {});
  const dailyUseNote = roleContextNote('daily');
  const focusUseNote = roleContextNote('focus');

  return `
    <div class="daily-report">
      ${formatSyncStatusNote(data.sync)}
      ${renderSystemProcessNote(data.system_process_records || [])}
      <div class="daily-hero">
        <div class="daily-hero-main">
          <div class="daily-kicker">${escapeHtml(cacheLabel)}</div>
          <div class="daily-title">Daily Report</div>
          <div class="daily-date">${escapeHtml(reportDate)}</div>
        </div>
        <div class="daily-hero-actions">
          <button onclick="window.panelActions.sendPayrollReport()">Send to Payroll Server</button>
          <span id="payrollSendStatus" class="report-note"></span>
        </div>
      </div>

      <div class="daily-scoreboard">
        <div class="daily-score primary">
          <div class="daily-score-label">Focus</div>
          <div class="daily-score-value">${escapeHtml(focusScore.label)}</div>
          <div class="daily-score-copy">${escapeHtml(`${formatMinutes(focusScore.deep_work_minutes)} PC work of ${formatMinutes(activeMinutes)} active`)}</div>
        </div>
        <div class="daily-score">
          <div class="daily-score-label">Input-Active</div>
          <div class="daily-score-value">${escapeHtml(formatMinutes(activeMinutes))}</div>
          <div class="daily-score-copy">${escapeHtml(`${formatMinutes(idleMinutes)} OS idle excluded`)}</div>
        </div>
        <div class="daily-score">
          <div class="daily-score-label">Observed Screen</div>
          <div class="daily-score-value">${escapeHtml(formatMinutes(capturedMinutes))}</div>
          <div class="daily-score-copy">${escapeHtml(`${formatMinutes(passiveMinutes)} passive/review candidate`)}</div>
        </div>
        <div class="daily-score">
          <div class="daily-score-label">No Evidence</div>
          <div class="daily-score-value">${escapeHtml(formatMinutes(missingMinutes))}</div>
          <div class="daily-score-copy">${missingMinutes > 0 ? 'Not counted as work' : 'All minutes accounted'}</div>
        </div>
        ${manualTotalMinutes > 0 ? `
          <div class="daily-score">
            <div class="daily-score-label">Manual Blocks</div>
            <div class="daily-score-value">${escapeHtml(formatMinutes(manualNetMinutes))}</div>
            <div class="daily-score-copy">${escapeHtml(`${formatMinutes(manualTotalMinutes)} declared, idle preserved`)}</div>
          </div>
        ` : ''}
      </div>

      <div class="daily-insights">
        ${dailyUseNote ? `<div class="report-note">${escapeHtml(dailyUseNote)}</div>` : ''}
        ${renderSummaryRows([
          { label: 'Main Work', value: topActivityName(reportRows.workRows) },
          { label: 'Weekly Focus', value: weeklyFocus === '--' ? 'Still warming' : `${weeklyFocus} average` },
          { label: 'Review / Reading', value: formatMinutes(referenceMinutes) },
          { label: 'Meeting / Chat', value: formatMinutes(meetingMinutes) },
          { label: 'Social Time', value: formatMinutes(socialMinutes) },
          { label: 'Detected Non-Work', value: `${formatMinutes(nonWorkObservations.total_minutes || 0)} review only` },
          { label: 'Follow-Ups', value: String(pendingTasks.length) },
          { label: 'Sources', value: formatList(limitList(summary.app_display_names || summary.apps_used || [], 6)) }
        ])}
      </div>

      ${manualTotalMinutes > 0 ? `
        <div class="daily-section">
          <div class="daily-section-head">
            <div>
              <div class="report-subtitle">Manual Timing Blocks</div>
              <div class="daily-section-copy">Declared work or meetings outside PC evidence. These do not reduce idle minutes.</div>
            </div>
            <div class="daily-section-total">${escapeHtml(formatMinutes(manualNetMinutes))}</div>
          </div>
          ${renderSummaryRows([
            { label: 'Declared', value: formatMinutes(manualTotalMinutes) },
            { label: 'Net Added Work', value: formatMinutes(manualNetMinutes) },
            { label: 'Overlapped PC Active', value: formatMinutes(manualBlocks.overlapping_pc_active_minutes || 0) },
            { label: 'Idle Preserved', value: formatMinutes(manualBlocks.idle_overlap_minutes || 0) }
          ])}
          ${renderManualTimingRows(manualBlocks)}
        </div>
      ` : ''}

      <div class="daily-section">
        <div class="daily-section-head">
          <div>
            <div class="report-subtitle">Work Done</div>
            <div class="daily-section-copy">Readable work blocks from captured windows.</div>
          </div>
            <div class="daily-section-total">${escapeHtml(formatMinutes(pcWorkMinutes))}</div>
        </div>
        ${renderTitleReportRows(reportRows.workRows, 'No work rows over 1 minute were found for this day.', 8)}
      </div>

      <div class="daily-two-column">
        <div class="daily-section">
          <div class="daily-section-head">
            <div>
              <div class="report-subtitle">Meeting / Chat</div>
              <div class="daily-section-copy">Calls, email, messaging, and meeting evidence.</div>
            </div>
            <div class="daily-section-total">${escapeHtml(formatMinutes(meetingMinutes))}</div>
          </div>
          ${renderTitleReportRows(reportRows.meetingRows, 'No meeting or chat rows over 1 minute.', 6)}
        </div>
        <div class="daily-section">
          <div class="daily-section-head">
            <div>
              <div class="report-subtitle">Reviewed / Referenced</div>
              <div class="daily-section-copy">Useful context that was not clear deliverable work.</div>
            </div>
            <div class="daily-section-total">${escapeHtml(formatMinutes(referenceMinutes))}</div>
          </div>
          ${renderTitleReportRows(reportRows.referencedRows, 'No reviewed/reference rows over 1 minute.', 6)}
        </div>
      </div>

      <div class="daily-section">
        <div class="daily-section-head">
          <div>
            <div class="report-subtitle">Non-Work Signals</div>
            <div class="daily-section-copy">Detection-only evidence from app, title, and domain. These minutes do not change work hours.</div>
          </div>
          <div class="daily-section-total">${escapeHtml(formatMinutes(nonWorkObservations.total_minutes || 0))}</div>
        </div>
        ${renderNonWorkObservations(nonWorkObservations)}
      </div>

      <div class="daily-section">
        <div class="daily-section-head">
          <div>
            <div class="report-subtitle">Focus Pattern</div>
            <div class="daily-section-copy">Deep work trend and distraction signal.</div>
          </div>
        </div>
        ${focusUseNote ? `<div class="report-note">${escapeHtml(focusUseNote)}</div>` : ''}
        ${renderFocusScore(summary, data.focus_trend || {})}
      </div>

      <div class="daily-two-column">
        <div class="daily-section">
          <div class="report-subtitle">Likely Pending Follow-Ups</div>
          <div class="daily-section-copy">Derived from screen text and later completion evidence.</div>
          ${renderTaskList(tasks)}
        </div>
        <div class="daily-section">
          <div class="report-subtitle">Browser Sources</div>
          <div class="daily-section-copy">${escapeHtml(`${(browserActivity.sites || []).length} captured site(s)`)}</div>
          ${renderChips(limitList(browserActivity.sites || [], 14), 'No captured browser sites')}
          ${socialMinutes > 1 ? `
            <div class="daily-social-block">
              <div class="report-subtitle">Social</div>
              ${renderTitleReportRows(reportRows.socialRows, 'No social rows over 1 minute.', 4)}
            </div>
          ` : ''}
        </div>
      </div>
    </div>
  `;
}

function formatHodDraftHtml(draft = {}) {
  const categories = draft.categories || [];
  const reviewCount = categories.filter((item) => item.review_required).length;
  const safeCopyCount = categories.filter((item) => item.copy_allowed).length;
  const readiness = hodDraftReadiness(draft, reviewCount, safeCopyCount);
  return `
    <div class="hod-draft-report">
      <div class="hod-draft-header">
        <div class="hod-draft-title-block">
          <div class="daily-kicker">${escapeHtml(draft.profile_label || 'HOD Appraisal Review Draft')}</div>
          <div class="hod-draft-title">Weekly HOD Draft</div>
          <div class="hod-meta-row">
            <span>${escapeHtml(formatHodWeekLabel(draft.week || {}))}</span>
            <span>${escapeHtml(draft.role?.role || 'Role not confirmed')}</span>
            ${draft.role?.role_notes ? `<span>${escapeHtml(draft.role.role_notes)}</span>` : ''}
          </div>
        </div>
        <div class="hod-draft-actions">
          <button onclick="window.panelActions.saveReviewedHodDraft()">Save Reviewed</button>
          <button onclick="window.panelActions.copyReviewedHodDraft()">Copy Reviewed</button>
        </div>
      </div>
      <div class="hod-readiness-card ${escapeHtml(readiness.level)}">
        <div>
          <div class="hod-readiness-title">${escapeHtml(readiness.title)}</div>
          <div class="hod-readiness-copy">${escapeHtml(readiness.copy)}</div>
        </div>
        <div class="hod-readiness-action">${escapeHtml(readiness.action)}</div>
      </div>
      ${draft.role_fit?.message ? `<div class="report-note">${escapeHtml(draft.role_fit.message)}</div>` : ''}
      <div class="hod-stat-row">
        <div class="hod-stat">
          <span class="hod-stat-value">${escapeHtml(draft.evidence_confidence?.level || 'low')}</span>
          <span class="hod-stat-label">Evidence confidence</span>
        </div>
        <div class="hod-stat">
          <span class="hod-stat-value">${escapeHtml(String(reviewCount))}</span>
          <span class="hod-stat-label">Need HOD review</span>
        </div>
        <div class="hod-stat">
          <span class="hod-stat-value">${escapeHtml(String(safeCopyCount))}</span>
          <span class="hod-stat-label">Safe to copy</span>
        </div>
        <div class="hod-stat">
          <span class="hod-stat-value">${escapeHtml(String(draft.rules_hash || '').slice(0, 8) || 'rules')}</span>
          <span class="hod-stat-label">${escapeHtml(draft.rules_version || 'Rules version')}</span>
        </div>
      </div>
      <div class="hod-section-header">
        <div class="report-subtitle">Appraisal Fields</div>
        <div class="report-note">Open each field, verify evidence, then copy or save the reviewed draft.</div>
      </div>
      <div class="hod-field-grid">
        ${categories.map(renderHodDraftCategory).join('')}
      </div>
      <div class="hod-overall-card">
        <div class="report-subtitle">${escapeHtml(draft.overall_remark?.label || 'Remark')}</div>
        <textarea class="hod-review-text hod-overall-text" data-hod-kind="overall">${escapeHtml(draft.overall_remark?.draft || '')}</textarea>
        ${renderHodSafety(draft.overall_remark || {})}
      </div>
    </div>
  `;
}

function hodDraftReadiness(draft = {}, reviewCount = 0, safeCopyCount = 0) {
  const confidence = draft.evidence_confidence?.level || 'low';
  if (reviewCount > safeCopyCount || confidence !== 'high') {
    return {
      level: 'needs-context',
      title: 'Needs HOD Context Before Use',
      copy: 'Cognify can prepare evidence-backed wording, but this draft should not be used as a final appraisal until offline work, outcomes, and HOD judgment are added.',
      action: 'Review marked fields'
    };
  }
  return {
    level: 'ready',
    title: 'Good Evidence Coverage',
    copy: 'Most fields have enough observed evidence for a first draft. HOD should still confirm quality, outcomes, and exceptions before submitting.',
    action: 'Verify and copy'
  };
}

function formatMyWeeklyReportHtml(report = {}) {
  const sections = report.sections || [];
  const totals = report.totals || {};
  const pcAvailableMinutes = Number(totals.pc_available_minutes || 0);
  return `
    <div class="hod-draft-report">
      <div class="hod-draft-header">
        <div class="hod-draft-title-block">
          <div class="daily-kicker">Personal Weekly Review</div>
          <div class="hod-draft-title">${escapeHtml(report.title || 'My Weekly Report')}</div>
          <div class="hod-meta-row">
            <span>${escapeHtml(formatHodWeekLabel(report.week || {}))}</span>
            <span>${escapeHtml(report.role?.role || 'Role not confirmed')}</span>
            <span>${escapeHtml(report.confidence?.level || 'low')} confidence</span>
          </div>
        </div>
        <div class="hod-draft-actions">
          <button onclick="window.panelActions.copyMyWeeklyReport()">Copy Report</button>
        </div>
      </div>
      <div class="hod-stat-row">
        <div class="hod-stat">
          <span class="hod-stat-value">${escapeHtml(String(report.totals?.active_days || 0))}</span>
          <span class="hod-stat-label">Active days</span>
        </div>
        <div class="hod-stat">
          <span class="hod-stat-value">${escapeHtml(formatMinutes(totals.work_minutes || 0))}</span>
          <span class="hod-stat-label">Work Hours</span>
        </div>
        <div class="hod-stat">
          <span class="hod-stat-value">${escapeHtml(formatMinutes(totals.meeting_minutes || 0))}</span>
          <span class="hod-stat-label">Meeting/chat</span>
        </div>
        <div class="hod-stat">
          <span class="hod-stat-value">${escapeHtml(formatMinutes(pcAvailableMinutes || totals.active_minutes || 0))}</span>
          <span class="hod-stat-label">${pcAvailableMinutes ? 'PC Available' : 'Observed time'}</span>
        </div>
      </div>
      ${sections.map(renderMyWeeklySection).join('')}
    </div>
  `;
}

function renderMyWeeklySection(section = {}) {
  return `
    <section class="my-weekly-section">
      <div class="report-subtitle">${escapeHtml(section.label || section.id || 'Section')}</div>
      <div class="my-weekly-items">
        ${(section.items || []).map(renderMyWeeklyItem).join('')}
      </div>
    </section>
  `;
}

function renderMyWeeklyItem(item = {}) {
  return `
    <div class="my-weekly-item">
      <div class="my-weekly-item-head">
        <div class="my-weekly-item-title">${escapeHtml(item.label || 'Item')}</div>
        <div class="my-weekly-source">${escapeHtml(item.source || 'evidence')}</div>
      </div>
      <div class="my-weekly-item-copy">${escapeHtml(item.text || '')}</div>
    </div>
  `;
}

function formatMyWeeklyReportText(report = {}) {
  const lines = [
    report.title || 'My Weekly Report',
    formatHodWeekLabel(report.week || {}),
    `Role: ${report.role?.role || 'Role not confirmed'}`,
    `Evidence confidence: ${report.confidence?.level || 'low'} (${Number(report.confidence?.score || 0)}%)`
  ];
  (report.sections || []).forEach((section) => {
    lines.push('', section.label || section.id || 'Section');
    (section.items || []).forEach((item) => {
      lines.push(`- ${item.label || 'Item'} [${item.source || 'evidence'}]: ${item.text || ''}`);
    });
  });
  return lines.join('\n');
}

function renderHodDraftCategory(item = {}, index = 0) {
  const reviewControl = item.review_required
    ? `
      <label class="hod-review-check">
        <input type="checkbox" class="hod-reviewed-checkbox" data-field-id="${escapeHtml(item.field_id || '')}">
        <span>Reviewed by HOD</span>
      </label>
    `
    : '';
  const copyAction = item.copy_allowed
    ? `<button onclick="window.panelActions.copyReviewedHodField('${encodeActionValue(item.field_id || '')}')">Copy</button>`
    : `<button onclick="window.panelActions.copyReviewedHodField('${encodeActionValue(item.field_id || '')}')">Copy Reviewed</button>`;
  const openAttribute = index < 2 ? 'open' : '';
  return `
    <details class="hod-field-card" ${openAttribute}>
      <summary>
        <span class="hod-field-title">${escapeHtml(item.label || item.field_id || 'Field')}</span>
        <span class="hod-field-badge">${escapeHtml(item.feedback_type || 'Needs Review')}</span>
        <span class="hod-field-badge">${escapeHtml(item.confidence || 'low')} confidence</span>
        ${item.review_required ? '<span class="hod-field-warning">Review</span>' : ''}
      </summary>
      <textarea class="hod-review-text" data-hod-kind="category" data-field-id="${escapeHtml(item.field_id || '')}" data-label="${escapeHtml(item.label || '')}" data-feedback-type="${escapeHtml(item.feedback_type || '')}" data-review-required="${item.review_required ? 'true' : 'false'}" data-copy-allowed="${item.copy_allowed ? 'true' : 'false'}">${escapeHtml(item.draft || '')}</textarea>
      <div class="hod-field-actions">${reviewControl}${copyAction}</div>
      <div class="hod-field-notes">${renderHodSafety(item)}</div>
      ${renderHodEvidence(item.evidence || [])}
    </details>
  `;
}

function renderHodSafety(item = {}) {
  const parts = [];
  if (item.review_required) {
    parts.push(`<div class="report-note">Review required: ${escapeHtml((item.review_reasons || []).join(' '))}</div>`);
  }
  if (item.missing_context_prompt) {
    parts.push(`<div class="report-note">Missing context: ${escapeHtml(item.missing_context_prompt)}</div>`);
  }
  if ((item.language_flags || []).length) {
    parts.push(`<div class="report-note">Language flags: ${escapeHtml(item.language_flags.join(', '))}</div>`);
  }
  return parts.join('');
}

function renderHodEvidence(evidence = []) {
  if (!evidence.length) {
    return '<div class="empty-state">No bound evidence available.</div>';
  }
  return `
    <div class="timeline">
      <div class="hod-evidence-title">Evidence Used</div>
      ${evidence.map((item) => `
        <div class="timeline-row">
          <div class="timeline-main">
            <div class="timeline-title">${escapeHtml(item.label || '')}</div>
            <div class="session-meta">${escapeHtml(item.source || 'evidence')}</div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}

function formatHodWeekLabel(week = {}) {
  const start = week.start_time ? String(week.start_time).slice(0, 10) : '';
  const end = week.end_time ? String(week.end_time).slice(0, 10) : '';
  return [start, end].filter(Boolean).join(' to ') || 'Last 7 days';
}

function formatReviewedHodDraftText(item = {}) {
  const lines = (item.reviewed_categories || [])
    .filter((category) => category.reviewed_text)
    .map((category) => `${category.label || category.field_id}: ${category.reviewed_text}`);
  if (item.overall_remark) {
    lines.push(`Remark: ${item.overall_remark}`);
  }
  return lines.join('\n\n');
}

function formatHodDraftHistoryHtml(items = []) {
  if (!items.length) {
    return '<div class="report-block"><div class="empty-state">No reviewed HOD drafts saved yet.</div></div>';
  }
  return `
    <div class="daily-report">
      <div class="report-hero">
        <div>
          <div class="report-hero-title">Reviewed HOD Drafts</div>
          <div class="report-hero-copy">Saved reviewed appraisal drafts with rules and evidence references.</div>
        </div>
      </div>
      <div class="report-block">
        <div class="report-subtitle">Saved Reviews</div>
        <div class="app-list">
          ${items.map((item) => `
            <details class="app-item">
              <summary>
                <span class="app-name">${escapeHtml(formatHodWeekLabel(item.week || {}))}</span>
                <span class="app-meta">${escapeHtml(String(item.review_summary?.field_count || 0))} fields</span>
                <span class="app-meta">${escapeHtml(String(item.rules_hash || '').slice(0, 12))}</span>
              </summary>
              <div class="report-note">Saved ${escapeHtml(formatCompactTime(item.saved_at))} | ${escapeHtml(item.role?.role || 'Role not saved')}</div>
              <div class="report-copy">${escapeHtml(formatReviewedHodDraftText(item) || 'No reviewed text saved.')}</div>
              <div class="daily-hero-actions">
                <button onclick="window.panelActions.copySavedHodDraft('${encodeActionValue(item.id || '')}')">Copy Text</button>
              </div>
            </details>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

function activityReportRangeLabel(report = {}) {
  const start = report.startTime ? new Date(report.startTime) : null;
  const end = report.endTime ? new Date(report.endTime) : null;
  if (!start || Number.isNaN(start.getTime())) {
    return 'Selected range';
  }
  const startDate = start.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' });
  if (!end || Number.isNaN(end.getTime()) || isoDateOnly(start) === isoDateOnly(end)) {
    return startDate;
  }
  return `${startDate} to ${end.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' })}`;
}

function formatActivitySummaryStats(report = {}) {
  const summary = report.summary || {};
  const categoryRows = summary.category_minutes || [];
  const canonicalSummary = report.canonical_summary || {};
  const officialSummary = hasPcAvailableEvidence(summary) ? summary : canonicalSummary;
  const coverage = canonicalCoverageForReport(report, officialSummary);
  const hasOfficialEvidence = hasOfficialWorkEvidence(officialSummary);
  const pcAvailableMinutes = canonicalPcAvailableMinutes(officialSummary);
  const workMinutes = canonicalWorkMinutes(officialSummary);
  const idleMinutes = Math.min(pcAvailableMinutes, Math.max(0, Math.round(Number(officialSummary.idle_minutes || officialSummary.input_idle_minutes || 0))));
  const missingMinutes = Math.max(0, Math.round(Number(officialSummary.missing_minutes || 0)));
  const activityVisibleMinutes = Math.max(0, Math.round(Number(summary.activity_visible_minutes ?? summary.visible_minutes ?? 0)));
  const activityMissingMinutes = Math.max(0, Math.round(Number(summary.activity_missing_minutes ?? 0)));
  const capturedEvidenceMinutes = Math.max(0, activityVisibleMinutes - activityMissingMinutes);
  const activeEvidenceMinutes = Math.max(0, Math.round(Number(summary.activity_active_minutes ?? summary.active_minutes ?? 0)));
  const passiveEvidenceMinutes = Math.max(0, Math.round(Number(summary.activity_passive_candidate_minutes ?? summary.passive_candidate_minutes ?? 0)));
  const category = (label) => {
    if (label === 'Work' && Number.isFinite(Number(summary.work_minutes))) {
      return canonicalWorkMinutes(summary);
    }
    return Number((categoryRows.find((row) => row.label === label) || {}).minutes || 0);
  };
  const stats = [
    { label: 'PC Available', value: formatOfficialMinutes(pcAvailableMinutes, hasOfficialEvidence, coverage) },
    { label: 'Work Hours', value: formatOfficialMinutes(workMinutes, hasOfficialEvidence, coverage) },
    { label: 'Idle deducted', value: formatOfficialMinutes(idleMinutes, hasOfficialEvidence, coverage) },
    { label: 'Missing/no evidence', value: formatOfficialMinutes(missingMinutes, hasOfficialEvidence, coverage) },
    { label: 'Captured evidence', value: formatMinutes(capturedEvidenceMinutes) },
    { label: 'Active evidence', value: formatMinutes(activeEvidenceMinutes) },
    { label: 'Passive / Review', value: formatMinutes(passiveEvidenceMinutes) },
    { label: 'Meeting / Chat', value: formatMinutes(category('Meeting / Chat')) },
    { label: 'Social', value: formatMinutes(category('Social')) },
    { label: 'Private Excluded', value: formatMinutes(category('Private/Sensitive')) },
    { label: 'Review Blocks', value: String(summary.review_block_count || 0) }
  ];
  const coverageLabel = canonicalCoverageLabel(coverage);
  if (coverageLabel) {
    stats.splice(4, 0, { label: 'Canonical coverage', value: coverageLabel });
  }
  return renderReportStats(stats);
}

function formatBlockTime(block = {}) {
  return `${formatTimeOnly(block.start)}-${formatTimeOnly(block.end)}`;
}

function formatActivityTimelineDetail(block = {}) {
  const summary = String(block.summary || '').trim();
  const action = String(block.action || '').trim();
  const actionKey = action.toLowerCase().replace(/\.$/, '');
  const summaryKey = summary.toLowerCase().replace(/\.$/, '');
  const includeSummary = summary && (!actionKey || !summaryKey.startsWith(actionKey));
  return [
    block.category,
    block.area,
    action,
    block.needs_activity_review ? `${formatMinutes(block.passive_minutes || 0)} passive/review` : '',
    block.input_idle_minutes ? `${formatMinutes(block.input_idle_minutes || 0)} input-idle` : '',
    includeSummary ? summary : ''
  ].filter(Boolean).join(' | ');
}

function renderActivityTimeline(blocks = [], { compact = false } = {}) {
  const rows = compact
    ? blocks.filter((block) => block.minutes >= 2 || block.category !== 'Work')
    : blocks;
  if (!rows.length) {
    return '<div class="empty-state">No activity timeline found for this range.</div>';
  }
  const visibleRows = rows.slice(0, MAX_TIMELINE_ROWS_RENDERED);
  const hiddenCount = Math.max(0, rows.length - visibleRows.length);

  return `
    <div class="activity-timeline-list">
      ${visibleRows.map((block) => `
        <div class="activity-timeline-row">
          <div class="activity-timeline-head">
            <div class="activity-timeline-title">${escapeHtml(formatBlockTime(block))} | ${escapeHtml(block.tool_app || 'Unknown tool')}</div>
            <div class="activity-timeline-duration">${escapeHtml(formatMinutes(block.minutes || 0))}</div>
          </div>
          <div class="activity-timeline-meta">${escapeHtml(formatActivityTimelineDetail(block))}</div>
        </div>
      `).join('')}
      ${hiddenCount ? `<div class="report-note">Showing ${escapeHtml(String(visibleRows.length))} of ${escapeHtml(String(rows.length))} timeline rows. Narrow the date range for more detail.</div>` : ''}
    </div>
  `;
}

function renderActivityGroupRows(rows = [], empty) {
  if (!rows.length) {
    return `<div class="empty-state">${escapeHtml(empty)}</div>`;
  }

  return `
    <div class="activity-timeline-list">
      ${rows.map((row) => `
        <div class="activity-timeline-row">
          <div class="activity-timeline-head">
            <div class="activity-timeline-title">${escapeHtml(row.label)}</div>
            <div class="activity-timeline-duration">${escapeHtml(formatMinutes(row.minutes || 0))}</div>
          </div>
          <div class="activity-timeline-meta">${escapeHtml([
            (row.tool_apps || []).join(', ') || 'No tool label',
            row.active_minutes ? `${formatMinutes(row.active_minutes)} active-looking` : '',
            row.passive_minutes ? `${formatMinutes(row.passive_minutes)} passive/review` : '',
            row.input_idle_minutes ? `${formatMinutes(row.input_idle_minutes)} input-idle` : '',
            ...(row.summaries || []).slice(0, 1)
          ].filter(Boolean).join(' | '))}</div>
        </div>
      `).join('')}
    </div>
  `;
}

function formatTimelineReportHtml(report = {}) {
  return `
    ${formatSyncStatusNote(report.sync)}
    ${renderSystemProcessNote(report.system_process_records || [])}
    <div class="report-hero">
      <div>
        <div class="report-hero-title">Timeline</div>
        <div class="report-hero-copy">${escapeHtml(activityReportRangeLabel(report))} | Compact chronological activity view.</div>
      </div>
      <div class="report-actions">
        <button onclick="window.panelActions.fullActivityReport()">Full Activity Report</button>
      </div>
    </div>
    ${formatActivitySummaryStats(report)}
    <div class="report-block">
      <div class="report-subtitle">Timeline</div>
      <div class="report-note">Non-overlapping primary activity blocks from captured screen data.</div>
      ${renderActivityTimeline(report.timeline || [], { compact: true })}
    </div>
  `;
}

function formatFullActivityReportHtml(report = {}) {
  const full = report.full || {};
  return `
    ${formatSyncStatusNote(report.sync)}
    ${renderSystemProcessNote(report.system_process_records || [])}
    <div class="report-hero">
      <div>
        <div class="report-hero-title">Full Activity Report</div>
        <div class="report-hero-copy">${escapeHtml(activityReportRangeLabel(report))} | Detailed activity summary and timeline.</div>
      </div>
    </div>
    ${formatActivitySummaryStats(report)}
    <div class="report-block">
      <div class="report-subtitle">Work Summary</div>
      ${renderActivityGroupRows(full.work_summary || [], 'No work blocks found.')}
    </div>
    <div class="report-block">
      <div class="report-subtitle">Meeting / Chat Summary</div>
      ${renderActivityGroupRows(full.meeting_chat_summary || [], 'No meeting or chat blocks found.')}
    </div>
    <div class="report-block">
      <div class="report-subtitle">Social</div>
      ${renderActivityGroupRows(full.social_summary || [], 'No social activity found.')}
    </div>
    <div class="report-block">
      <div class="report-subtitle">Reference / Research</div>
      ${renderActivityGroupRows(full.reference_summary || [], 'No reference activity found.')}
    </div>
    <div class="report-block">
      <div class="report-subtitle">Timeline</div>
      ${renderActivityTimeline(report.timeline || [])}
    </div>
    <div class="report-block">
      <div class="report-subtitle">Review Notes</div>
      ${renderActivityTimeline(full.review_blocks || [])}
    </div>
  `;
}

function taskConfidencePercent(task = {}) {
  return `${Math.round(Number(task.confidence_score || 0) * 100)}%`;
}

function renderTaskCards(tasks = [], mode = 'high') {
  if (!tasks.length) {
    return `<div class="empty-state">${mode === 'high' ? 'No high-confidence pending tasks found.' : 'No review candidates found.'}</div>`;
  }

  return `<div class="app-list">${tasks.slice(0, mode === 'high' ? 20 : 12).map((task) => {
    const sources = (task.evidence_sources || [])
      .slice(0, 2)
      .map((source) => source.text || source.label)
      .filter(Boolean);
    return `
      <div class="task-card ${mode === 'high' ? 'high' : 'review'}">
        <div class="task-title-row">
          <div class="task-title">${escapeHtml(task.task_title || 'Task candidate')}</div>
          <div class="task-score">${escapeHtml(taskConfidencePercent(task))}</div>
        </div>
        <div class="task-meta">
          <span>${escapeHtml(task.status || 'candidate')}</span>
          <span>${escapeHtml(task.priority || 'normal')} priority</span>
          <span>${escapeHtml(task.context || 'Unknown context')}</span>
          <span>${escapeHtml(formatCompactTime(task.source_timestamp))}</span>
        </div>
        <div class="task-evidence">${escapeHtml(task.status_reason || 'Detected from task-like wording and work context.')}</div>
        ${sources.length ? `<div class="task-meta">${sources.map((source) => `<span>${escapeHtml(source)}</span>`).join('')}</div>` : ''}
      </div>
    `;
  }).join('')}</div>`;
}

function formatTasksHtml(tasks = [], sync) {
  const pending = tasks.filter((task) => task.status === 'pending');
  const candidates = tasks.filter((task) => task.status === 'candidate');
  const high = pending.filter((task) => Number(task.confidence_score || 0) >= 0.78);
  const review = [
    ...pending.filter((task) => Number(task.confidence_score || 0) < 0.78),
    ...candidates
  ];
  const partial = sync && !sync.complete
    ? `<div class="report-note">Activity may be partial: ${escapeHtml(String(sync.incomplete_window_count || 0))} sync window(s) still need backfill.</div>`
    : '';
  const debug = latestSystemProcessRecords.length
    ? `<div class="report-note">System Process captured for debugging but not analyzed: ${escapeHtml(String(latestSystemProcessRecords.length))} log item(s).</div>`
    : '';

  return `
    ${partial}
    ${debug}
    <div class="report-hero">
      <div>
        <div class="report-hero-title">Extracted Tasks</div>
        <div class="report-hero-copy">High-confidence pending work from screen, transcript, context, and repeated evidence.</div>
      </div>
    </div>
    <div class="report-stat-grid">
      <div class="report-stat"><div class="report-stat-label">High Confidence</div><div class="report-stat-value">${escapeHtml(String(high.length))}</div></div>
      <div class="report-stat"><div class="report-stat-label">Needs Review</div><div class="report-stat-value">${escapeHtml(String(review.length))}</div></div>
      <div class="report-stat"><div class="report-stat-label">Total Candidates</div><div class="report-stat-value">${escapeHtml(String(tasks.length))}</div></div>
    </div>
    <div class="task-report-grid">
      <div class="report-block">
        <div class="report-subtitle">High Confidence Tasks</div>
        <div class="report-note">Use these for action planning. Cognify still shows evidence so the user can judge correctness.</div>
        ${renderTaskCards(high, 'high')}
      </div>
      <div class="report-block">
        <div class="report-subtitle">Needs Review</div>
        <div class="report-note">Useful candidates with weaker proof, vague context, or unresolved status.</div>
        ${renderTaskCards(review, 'review')}
      </div>
    </div>
  `;
}

function formatRecentActivityHtml(records = []) {
  if (!records.length) {
    return '<div class="empty-state">No recent activity found.</div>';
  }

  return `
    <div class="report-block">
      <div class="report-title">Recent Activity</div>
      <div class="report-note">Last 2 hours of captured activity.</div>
      <div class="app-list">
        ${records.slice(-25).reverse().map((record) => `
          <div class="timeline-row">
            <div class="timeline-time">${escapeHtml(formatCompactTime(record.timestamp_start))}</div>
            <div class="timeline-main">
              <div class="timeline-title">${escapeHtml(record.window_title || record.app_name || 'Untitled activity')}</div>
              <div class="session-meta">${escapeHtml(record.app_name || 'Unknown')}</div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function setFocusCards({
  events = '--',
  apps = '--',
  timeSpent = '--',
  sites = '--',
  eventsCopy = 'Recent captured activity count.',
  appsCopy = 'Apps active in the selected range.',
  timeCopy = 'Estimated focused session time.',
  sitesCopy = 'Browser sites seen in this range.'
} = {}) {
  if (!focusEvents || !focusApps || !focusTime || !focusSites) {
    return;
  }

  focusEvents.textContent = String(events);
  focusApps.textContent = String(apps);
  focusTime.textContent = String(timeSpent);
  focusSites.textContent = String(sites);
  if (focusEventsCopy) {
    focusEventsCopy.textContent = eventsCopy;
  }
  if (focusAppsCopy) {
    focusAppsCopy.textContent = appsCopy;
  }
  if (focusTimeCopy) {
    focusTimeCopy.textContent = timeCopy;
  }
  if (focusSitesCopy) {
    focusSitesCopy.textContent = sitesCopy;
  }
}

function updateFocusCardsFromSummary(summary = {}, fallbackEventCount = 0) {
  summary = safeSummary(summary);
  const appTimeline = summary.app_timeline || [];
  const browserActivity = summary.browser_activity || {};
  const topApp = appTimeline[0]?.app_name || 'No app data';
  const totalMinutes = Number.isFinite(Number(summary.estimated_active_minutes))
    ? Number(summary.estimated_active_minutes)
    : appTimeline.reduce((sum, group) => sum + Number(group.total_time_minutes_estimate || 0), 0);
  const workMinutes = canonicalWorkMinutes(summary);
  const appCount = (summary.app_display_names || summary.apps_used || []).length;
  const siteCount = (browserActivity.sites || []).length;
  const rangeCopy = summary.range_minutes ? `Bounded to the selected ${formatMinutes(summary.range_minutes)} window.` : 'Bounded to the selected range.';
  const idleCopy = summary.idle_adjusted
    ? `${formatMinutes(summary.input_idle_minutes || 0)} input-idle time deducted.`
    : rangeCopy;

  setFocusCards({
    events: fallbackEventCount,
    apps: appCount,
    timeSpent: formatMinutes(workMinutes),
    sites: siteCount,
    eventsCopy: `Top app: ${topApp}`,
    appsCopy: `${appCount ? `${appCount} apps in focus` : 'No app activity yet'}.`,
    timeCopy: totalMinutes ? `Work time. ${idleCopy}` : 'No grouped session time yet.',
    sitesCopy: siteCount ? `${siteCount} captured browser site(s).` : 'No browser sites in this range.'
  });
  setClassificationSnapshot(summary.classified_minutes || {});
}

function updateFocusCardsFromRecords(records = []) {
  const visibleRecords = records.filter((record) => isVisibleAppName(record.app_name));
  const appNames = [...new Set(visibleRecords.map((record) => record.app_name).filter(Boolean))];
  const browserSites = [...new Set(records.map((record) => record.url_if_available).filter(Boolean))];
  const latestApp = visibleRecords[0]?.app_name || 'No app data';

  setFocusCards({
    events: visibleRecords.length,
    apps: appNames.length,
    timeSpent: visibleRecords.length ? formatMinutes(visibleRecords.length) : '--',
    sites: browserSites.length,
    eventsCopy: latestApp === 'No app data' ? 'No recent records yet.' : `Latest app: ${latestApp}`,
    appsCopy: appNames.length ? appNames.slice(0, 3).join(', ') : 'No active apps found.',
    timeCopy: 'Quick estimate from recent captured events.',
    sitesCopy: browserSites.length ? `${browserSites.length} recent browser site(s).` : 'No recent browser sites.'
  });
  setClassificationSnapshot({});
}

window.addEventListener('error', (event) => {
  setOutput(`Renderer error: ${event.message}`);
  debugLog('renderer_error', { message: event.message, filename: event.filename, lineno: event.lineno });
});

window.addEventListener('unhandledrejection', (event) => {
  const reason = event.reason?.message || String(event.reason);
  setOutput(`Unhandled rejection: ${reason}`);
  debugLog('renderer_unhandled_rejection', { reason });
});

async function runSafely(label, action, fallback = 'Operation failed') {
  if (runningActions.has(label)) {
    await debugLog('panel_action_skipped_duplicate', { label });
    return;
  }
  if (REPORT_ACTION_LABELS.has(label) && [...runningActions].some((active) => REPORT_ACTION_LABELS.has(active))) {
    setOutput('Another report is still generating. Wait for it to finish before starting a new report.');
    await debugLog('panel_action_skipped_report_busy', { label, active: [...runningActions] });
    return;
  }
  runningActions.add(label);
  setOutput(`Running ${label}...`);
  const startedAt = performance.now();
  const slowTimer = setTimeout(() => {
    if (runningActions.has(label)) {
      setOutput(`Still generating ${label}... Large date ranges or first-time cache builds can take a little longer.`);
    }
  }, 10000);
  await debugLog('panel_action_started', { label });
  try {
    await action();
    await debugLog('panel_action_completed', {
      label,
      duration_ms: Math.round(performance.now() - startedAt)
    });
  } catch (error) {
    const message = error?.message || String(error);
    setOutput(`${fallback}: ${message}`);
    await debugLog('panel_action_failed', {
      label,
      message,
      duration_ms: Math.round(performance.now() - startedAt)
    });
  } finally {
    clearTimeout(slowTimer);
    runningActions.delete(label);
  }
}

async function refreshStatus() {
  await runSafely('refreshStatus', async () => {
    const status = await window.assistantApi.getStatus();
    setRecordingStatus({
      running: Boolean(status.running),
      paused: Boolean(status.paused)
    });
    setListeningStatus(Boolean(status.listeningEnabled), { mode: status.audioMode || 'off' });
    await refreshRuntimeHealth();
  }, 'Unable to refresh status');
}

async function refreshIdleSummary() {
  if (document.hidden) {
    return;
  }

  try {
    const summary = await window.assistantApi.getIdleSummary();
    setIdleSnapshot(summary);
  } catch {
    setIdleSnapshot({});
  }
}

function getTimeRange() {
  return validatedTimeRange() || {};
}

function parseDateOnly(value) {
  const raw = String(value || '').trim();
  let match = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  let year;
  let month;
  let day;
  if (match) {
    year = Number(match[1]);
    month = Number(match[2]);
    day = Number(match[3]);
  } else {
    match = raw.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/);
    if (!match) {
      return null;
    }
    day = Number(match[1]);
    month = Number(match[2]);
    year = Number(match[3]);
  }

  const date = new Date(year, month - 1, day, 0, 0, 0, 0);
  if (
    date.getFullYear() !== year ||
    date.getMonth() !== month - 1 ||
    date.getDate() !== day
  ) {
    return null;
  }
  return date;
}

function startOfLocalDay(value = new Date()) {
  const date = new Date(value);
  date.setHours(0, 0, 0, 0);
  return date;
}

function shiftedLocalDay(daysFromToday = 0) {
  const date = startOfLocalDay();
  date.setDate(date.getDate() + daysFromToday);
  return date;
}

function sameLocalDay(left, right) {
  return Boolean(left && right) &&
    left.getFullYear() === right.getFullYear() &&
    left.getMonth() === right.getMonth() &&
    left.getDate() === right.getDate();
}

function detectRangePreset(start, endDate) {
  const today = shiftedLocalDay(0);
  const yesterday = shiftedLocalDay(-1);
  const last7Start = shiftedLocalDay(-6);
  if (sameLocalDay(start, yesterday) && sameLocalDay(endDate, yesterday)) {
    return 'yesterday';
  }
  if (sameLocalDay(start, today) && sameLocalDay(endDate, today)) {
    return 'today';
  }
  if (sameLocalDay(start, last7Start) && sameLocalDay(endDate, today)) {
    return 'last7';
  }
  return '';
}

function updateRangePresetState(activePreset = '') {
  rangePresetButtons.forEach((button) => {
    const active = button.dataset.rangePreset === activePreset;
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', active ? 'true' : 'false');
  });
}

function setReportDateInputs(startDate, endDate, preset = '') {
  const startInput = document.getElementById('start');
  const endInput = document.getElementById('end');
  if (!startInput || !endInput) {
    return;
  }
  startInput.value = formatReportDateInput(startDate);
  endInput.value = formatReportDateInput(endDate);
  updateRangePresetState(preset);
  validatedTimeRange({ requireComplete: true });
}

function setReportRangePreset(preset = 'yesterday') {
  if (preset === 'today') {
    const today = shiftedLocalDay(0);
    setReportDateInputs(today, today, 'today');
    return;
  }
  if (preset === 'last7') {
    setReportDateInputs(shiftedLocalDay(-6), shiftedLocalDay(0), 'last7');
    return;
  }
  const yesterday = shiftedLocalDay(-1);
  setReportDateInputs(yesterday, yesterday, 'yesterday');
}

function setDefaultReportRange({ force = false } = {}) {
  const startInput = document.getElementById('start');
  const endInput = document.getElementById('end');
  if (!startInput || !endInput) {
    return;
  }
  if (!force && (startInput.value.trim() || endInput.value.trim())) {
    validatedTimeRange();
    return;
  }
  setReportRangePreset('yesterday');
}

function normalizeReportDateInput(input) {
  if (!input?.value) {
    return;
  }
  const date = parseDateOnly(input.value);
  if (date) {
    input.value = formatReportDateInput(date);
  }
}

function normalizeReportDateInputs() {
  normalizeReportDateInput(document.getElementById('start'));
  normalizeReportDateInput(document.getElementById('end'));
}

function selectedReportWeekStart() {
  const range = reportRange();
  if (!range) {
    return '';
  }
  return mondayDateInputValue(new Date(range.startTime));
}

function selectedReportWeekRange() {
  const weekStart = selectedReportWeekStart();
  if (!weekStart) {
    return null;
  }
  const weekInput = document.getElementById('weeklyContextWeek');
  if (weekInput) {
    weekInput.value = weekStart;
  }
  const start = new Date(`${weekStart}T00:00:00`);
  const end = new Date(start.getTime() + (7 * 24 * 60 * 60 * 1000));
  return {
    startTime: start.toISOString(),
    endTime: end.toISOString(),
    weekStart
  };
}

function runSelectedReport() {
  const config = REPORT_ACTION_CONFIG[selectedReportAction] || REPORT_ACTION_CONFIG.summary;
  normalizeReportDateInputs();
  const range = reportRange();
  if (!range) {
    setReportOptionsOpen(true);
    return null;
  }
  if (selectedReportAction === 'summary' || selectedReportAction === 'dailyReport') {
    try {
      validateDailyReportRange(range);
    } catch {
      setReportOptionsOpen(true);
      return null;
    }
  }
  setReportOptionsOpen(false);
  return config.run();
}

function syncReportWorkspaceUi() {
  const config = REPORT_ACTION_CONFIG[selectedReportAction] || REPORT_ACTION_CONFIG.summary;
  reportActionButtons.forEach((button) => {
    const active = button.dataset.reportAction === selectedReportAction;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', active ? 'true' : 'false');
  });

  if (reportSelectedTitle) {
    reportSelectedTitle.textContent = config.label;
  }
  if (reportSelectedDescription) {
    reportSelectedDescription.textContent = config.description || '';
  }
  if (reportRunButton) {
    reportRunButton.textContent = selectedReportAction === 'ask' ? 'Ask Evidence' : `Run ${config.label}`;
  }
  if (reportQuestionRow) {
    reportQuestionRow.hidden = selectedReportAction !== 'ask';
  }
  validatedTimeRange();
}

function setReportOptionsOpen(open) {
  if (!reportOptions) {
    return;
  }
  reportOptions.hidden = false;
  reportWorkspace?.classList.toggle('editing', Boolean(open));
  reportCompactView?.setAttribute('aria-expanded', 'true');
  reportEditToggle?.setAttribute('aria-expanded', 'true');
  if (reportEditToggle) {
    reportEditToggle.textContent = 'Filters';
  }
}

function selectReportAction(action) {
  const config = REPORT_ACTION_CONFIG[action];
  if (!config) {
    return;
  }
  selectedReportAction = action;
  selectedReportTab = config.tab || selectedReportTab;
  syncReportWorkspaceUi();
}

function initializeReportWorkspace() {
  if (!reportWorkspace) {
    return;
  }

  reportActionButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const action = button.dataset.reportAction;
      selectReportAction(action);
      if (action === 'ask') {
        document.getElementById('question')?.focus();
      }
    });
  });
  rangePresetButtons.forEach((button) => {
    button.addEventListener('click', () => setReportRangePreset(button.dataset.rangePreset));
  });
  reportCompactView?.addEventListener('click', () => {
    setReportOptionsOpen(true);
  });
  reportEditToggle?.addEventListener('click', () => {
    setReportOptionsOpen(reportOptions?.hidden);
  });
  [document.getElementById('start'), document.getElementById('end')].forEach((input) => {
    input?.addEventListener('input', () => {
      setRangeError('');
      setRangeStatus('Editing range');
      updateRangePresetState('');
    });
    input?.addEventListener('blur', () => {
      normalizeReportDateInput(input);
      validatedTimeRange({ requireComplete: true });
    });
    input?.addEventListener('change', () => {
      normalizeReportDateInput(input);
      validatedTimeRange({ requireComplete: true });
    });
  });

  document.getElementById('question')?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      selectReportAction('ask');
      runSelectedReport();
    }
  });

  setDefaultReportRange({ force: true });
  syncReportWorkspaceUi();
}

function formatSelectedRangeStatus(range) {
  if (selectedReportTab === 'weekly') {
    const weekStart = mondayDateInputValue(new Date(range.startTime));
    const start = new Date(`${weekStart}T00:00:00`);
    const end = new Date(start.getTime() + (7 * 24 * 60 * 60 * 1000));
    return `Week: ${formatReportDateRangeLabel(start.toISOString(), end.toISOString())}`;
  }
  return `Range: ${formatReportDateRangeLabel(range.startTime, range.endTime)}`;
}

function reportRange() {
  return validatedTimeRange({ requireComplete: true });
}

function validateDailyReportRange(range = {}) {
  const startMs = new Date(range.startTime).getTime();
  const endMs = new Date(range.endTime).getTime();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
    setRangeError('Choose one valid date for Daily reports.');
    throw new Error('Choose one valid date for Daily reports.');
  }
  if ((endMs - startMs) > MAX_DAILY_REPORT_MS) {
    setRangeError('Daily reports support one day. Use Timeline or Weekly for multi-day review.');
    throw new Error('Daily reports support one day. Use Timeline or Weekly for multi-day review.');
  }
}

function validatedTimeRange({ requireComplete = false } = {}) {
  setRangeError('');
  const startInput = document.getElementById('start');
  const endInput = document.getElementById('end');
  const startValue = startInput?.value.trim() || '';
  const endValue = endInput?.value.trim() || '';

  if (!startValue && !endValue) {
    if (requireComplete) {
      setRangeError('Enter From and To as dd-mm-yyyy.');
      return null;
    }
    return {};
  }

  if (!startValue || !endValue) {
    setRangeError('Enter both From and To as dd-mm-yyyy.');
    return null;
  }

  const start = parseDateOnly(startValue);
  const endDate = parseDateOnly(endValue);
  if (!start || !endDate) {
    setRangeError('Use date format dd-mm-yyyy.');
    return null;
  }

  if (endDate < start) {
    setRangeError('To date must be same as or later than From date.');
    return null;
  }

  const end = new Date(endDate);
  end.setDate(end.getDate() + 1);
  if ((end.getTime() - start.getTime()) > MAX_RANGE_MS) {
    setRangeError('Date range cannot be more than 7 days.');
    return null;
  }

  const range = {
    startTime: start.toISOString(),
    endTime: end.toISOString()
  };
  updateRangePresetState(detectRangePreset(start, endDate));
  setRangeStatus(formatSelectedRangeStatus(range));
  return range;
}

function formatDeletionDateRange(startTime, endTime) {
  const start = new Date(startTime);
  const endInclusive = new Date(new Date(endTime).getTime() - 1);
  const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
  if (Number.isNaN(start.getTime()) || Number.isNaN(endInclusive.getTime())) {
    return 'the selected date range';
  }
  const startLabel = start.toLocaleDateString([], options);
  const endLabel = endInclusive.toLocaleDateString([], options);
  return startLabel === endLabel ? startLabel : `${startLabel} to ${endLabel}`;
}

function confirmDeleteRange(startTime, endTime) {
  const rangeLabel = formatDeletionDateRange(startTime, endTime);
  return window.confirm([
    'Delete captured activity for this date range?',
    '',
    `Range: ${rangeLabel}`,
    '',
    'This will delete:',
    '- Screenpipe captured activity data in this range',
    '- Cognify local activity-store rows and sync-window metadata in this range',
    '',
    'This will not delete:',
    '- Your profile, notes, privacy settings, retention settings, or app files',
    '',
    'This action cannot be undone.'
  ].join('\n'));
}

async function ask() {
  await runSafely('ask', async () => {
    await renderCurrentQuestion();
  }, 'Ask failed');
}

async function renderCurrentQuestion() {
  const question = document.getElementById('question').value;
  const range = reportRange();
  if (!range) {
    return;
  }
  const { startTime, endTime } = range;
  const data = safeObject(await window.assistantApi.ask({ message: question, startTime, endTime }));
  setSystemProcessRecords(data.system_process_records || []);
  updateFocusCardsFromSummary(data.summary, data.context_count || 0);
  setOutputHtml(formatAskResultHtml(data));
}

async function summary() {
  await runSafely('summary', async () => {
    const range = reportRange();
    if (!range) {
      return;
    }
    validateDailyReportRange(range);
    const { startTime, endTime } = range;
    const data = safeObject(await window.assistantApi.dailyReportCached({
      startTime,
      endTime,
      force: false,
      sync: false,
      staleOk: true,
      passive: false,
      includeTasks: false
    }));
    setSystemProcessRecords(data.system_process_records || []);
    updateFocusCardsFromSummary(data.summary, data.context_count || 0);
    setOutputHtml(formatSummaryHtml(data.summary, data.sync), {
      report: true,
      title: 'Daily Summary',
      subtitle: `${formatReportDateRangeLabel(startTime, endTime)} summary`,
      kind: 'daily-summary'
    });
  }, 'Daily summary failed');
}

async function dailyReport() {
  await runSafely('dailyReport', async () => {
    const range = reportRange();
    if (!range) {
      return;
    }
    validateDailyReportRange(range);
    const { startTime, endTime } = range;
    const dataStart = performance.now();
    const [reportResult, focusTrend] = await Promise.all([
      window.assistantApi.dailyReportCached({
        startTime,
        endTime,
        force: false,
        sync: false,
        passive: false,
        includeTasks: false
      }),
      window.assistantApi.getFocusTrend(7, { passive: true }).catch(() => null)
    ]);
    await debugLog('daily_report_data_ready', { duration_ms: Math.round(performance.now() - dataStart) });
    const data = safeObject(reportResult);
    data.focus_trend = focusTrend;
    latestDailyReportData = data;
    setSystemProcessRecords(data.system_process_records || []);
    updateFocusCardsFromSummary(data.summary, data.context_count || 0);
    const renderStart = performance.now();
    const html = formatDailyReportHtml(data);
    const payrollPayload = buildPayrollReportPayload(data);
    await debugLog('daily_report_render_ready', {
      duration_ms: Math.round(performance.now() - renderStart),
      payload_bytes: JSON.stringify(payrollPayload).length
    });
    setOutputHtml(html, {
      report: true,
      title: 'Daily Report',
      subtitle: formatReportDateRangeLabel(startTime, endTime),
      kind: 'daily-report',
      data: {
        payroll_payload: payrollPayload
      }
    });
  }, 'Daily report failed');
}

async function sendPayrollReport() {
  await runSafely('sendPayrollReport', async () => {
    if (!latestDailyReportData) {
      setOutput('Generate the Daily Report first, then send it to payroll.');
      return;
    }

    const status = document.getElementById('payrollSendStatus');
    if (status) {
      status.textContent = 'Sending...';
    }

    const result = await window.assistantApi.sendPayrollReport(buildPayrollReportPayload(latestDailyReportData));
    if (status) {
      status.textContent = `Sent (${result.status})`;
    }
    setOutput(`Payroll report sent to ${result.endpoint}\n${JSON.stringify(result.response, null, 2)}`);
  }, 'Sending payroll report failed');
}

async function timelineReport() {
  await runSafely('timelineReport', async () => {
    const range = reportRange();
    if (!range) {
      return;
    }
    const { startTime, endTime } = range;
    const data = safeObject(await window.assistantApi.activityReport({
      ...range,
      mode: 'timeline'
    }));
    latestActivityReportData = data;
    latestActivityReportRangeKey = reportRangeKey(range);
    setSystemProcessRecords(data.system_process_records || []);
    const summary = data.summary || {};
    const categoryRows = summary.category_minutes || [];
    const categoryMinutes = (label) => {
      if (label === 'Work' && Number.isFinite(Number(summary.work_minutes))) {
        return canonicalWorkMinutes(summary);
      }
      return Number((categoryRows.find((row) => row.label === label) || {}).minutes || 0);
    };
    setFocusCards({
      events: data.record_count || 0,
      apps: categoryMinutes('Work'),
      timeSpent: formatMinutes(data.summary?.visible_minutes || 0),
      sites: categoryMinutes('Social'),
      eventsCopy: 'Activity records used for timeline.',
      appsCopy: 'Work minutes found in selected range.',
      timeCopy: `${formatMinutes(data.summary?.passive_candidate_minutes || 0)} passive/review candidate.`,
      sitesCopy: 'Social minutes found in selected range.'
    });
    setOutputHtml(formatTimelineReportHtml(data), {
      report: true,
      title: 'Timeline Report',
      subtitle: formatReportDateRangeLabel(startTime, endTime),
      kind: 'timeline-report'
    });
  }, 'Timeline report failed');
}

async function fullActivityReport() {
  await runSafely('fullActivityReport', async () => {
    const range = reportRange();
    if (!range) {
      return;
    }
    const rangeKey = reportRangeKey(range);
    let data = latestActivityReportData;
    if (!data || !data.full || latestActivityReportRangeKey !== rangeKey) {
      data = safeObject(await window.assistantApi.activityReport({
        ...range,
        mode: 'full'
      }));
    }
    latestActivityReportData = data;
    latestActivityReportRangeKey = rangeKey;
    setSystemProcessRecords(data.system_process_records || []);
    setOutputHtml(formatFullActivityReportHtml(data), {
      report: true,
      title: 'Full Activity Report',
      subtitle: formatReportDateRangeLabel(range.startTime, range.endTime),
      kind: 'full-activity-report'
    });
  }, 'Full activity report failed');
}

async function myWeeklyReport() {
  await runSafely('myWeeklyReport', async () => {
    const weekRange = selectedReportWeekRange();
    if (!weekRange) {
      return;
    }
    const report = await window.assistantApi.getMyWeeklyReport({
      startTime: weekRange.startTime,
      endTime: weekRange.endTime
    });
    latestMyWeeklyReportData = report;
    setOutputHtml(formatMyWeeklyReportHtml(report), {
      report: true,
      title: report.title || 'My Weekly Report',
      subtitle: formatHodWeekLabel(report.week || {}),
      kind: 'my-weekly-report',
      text: formatMyWeeklyReportText(report),
      data: report
    });
  }, 'My weekly report failed');
}

async function copyMyWeeklyReport() {
  if (!latestMyWeeklyReportData) {
    setOutput('Generate My Weekly Report before copying it.');
    return;
  }
  await window.assistantApi.copyText(formatMyWeeklyReportText(latestMyWeeklyReportData));
}

async function hodDraft() {
  await runSafely('hodDraft', async () => {
    const weekRange = selectedReportWeekRange();
    if (!weekRange) {
      return;
    }
    const draft = await window.assistantApi.getHodAppraisalDraft({
      startTime: weekRange.startTime,
      endTime: weekRange.endTime
    });
    latestHodDraftData = draft;
    setOutputHtml(formatHodDraftHtml(draft), {
      report: true,
      title: 'Weekly HOD Draft',
      subtitle: formatHodWeekLabel(draft.week || {}),
      kind: 'hod-draft',
      data: draft
    });
  }, 'HOD draft failed');
}

function collectReviewedHodDraft() {
  const categoryInputs = [...document.querySelectorAll('.hod-review-text[data-hod-kind="category"]')];
  const overallInput = document.querySelector('.hod-review-text[data-hod-kind="overall"]');
  return {
    draft: latestHodDraftData || {},
    reviewed_categories: categoryInputs.map((input) => ({
      field_id: input.dataset.fieldId || '',
      label: input.dataset.label || '',
      feedback_type: input.dataset.feedbackType || '',
      review_required: input.dataset.reviewRequired === 'true',
      copy_allowed: input.dataset.copyAllowed === 'true',
      reviewed: isHodFieldReviewed(input.dataset.fieldId || ''),
      reviewed_text: input.value
    })),
    overall_remark: overallInput?.value || ''
  };
}

function isHodFieldReviewed(fieldId) {
  const checkbox = document.querySelector(`.hod-reviewed-checkbox[data-field-id="${cssEscape(fieldId)}"]`);
  return checkbox ? checkbox.checked : false;
}

function reviewedHodCategoriesForCopy() {
  return collectReviewedHodDraft().reviewed_categories.filter((item) => (
    item.reviewed_text && (item.copy_allowed || item.reviewed)
  ));
}

async function saveReviewedHodDraft() {
  await runSafely('saveReviewedHodDraft', async () => {
    if (!latestHodDraftData) {
      setOutput('Generate HOD Draft before saving a reviewed version.');
      return;
    }
    const result = await window.assistantApi.saveHodAppraisalDraft(collectReviewedHodDraft());
    setOutput(`Saved reviewed HOD draft for ${formatHodWeekLabel(result.draft?.week || {})}.\nID: ${result.draft?.id || 'unknown'}`);
  }, 'Saving reviewed HOD draft failed');
}

async function copyReviewedHodField(encodedFieldId) {
  const fieldId = decodeURIComponent(encodedFieldId);
  const input = document.querySelector(`.hod-review-text[data-hod-kind="category"][data-field-id="${cssEscape(fieldId)}"]`);
  const copyAllowed = input?.dataset.copyAllowed === 'true';
  if (!copyAllowed && !isHodFieldReviewed(fieldId)) {
    setOutput('Mark this field as reviewed before copying it.');
    return;
  }
  await window.assistantApi.copyText(input?.value || '');
}

async function copyReviewedHodDraft() {
  const reviewed = collectReviewedHodDraft();
  const lines = reviewedHodCategoriesForCopy()
    .map((item) => `${item.label || item.field_id}: ${item.reviewed_text}`);
  if (reviewed.overall_remark) {
    lines.push(`Remark: ${reviewed.overall_remark}`);
  }
  await window.assistantApi.copyText(lines.join('\n\n'));
}

async function hodDraftHistory() {
  await runSafely('hodDraftHistory', async () => {
    const result = await window.assistantApi.listHodAppraisalDrafts(20);
    latestHodReviewedDrafts = result.items || [];
    setOutputHtml(formatHodDraftHistoryHtml(latestHodReviewedDrafts), {
      report: true,
      title: 'Reviewed HOD Drafts',
      subtitle: `${latestHodReviewedDrafts.length} saved draft(s)`,
      kind: 'hod-draft-history'
    });
  }, 'Loading reviewed HOD drafts failed');
}

async function copySavedHodDraft(encodedId) {
  const id = decodeURIComponent(encodedId);
  const item = latestHodReviewedDrafts.find((candidate) => candidate.id === id);
  if (!item) {
    setOutput('Saved HOD draft not found in the current history view.');
    return;
  }
  await window.assistantApi.copyText(formatReviewedHodDraftText(item));
}

async function tasks() {
  await runSafely('tasks', async () => {
    const range = reportRange();
    if (!range) {
      return;
    }
    const data = await window.assistantApi.ask({
      message: 'What follow-ups are pending?',
      startTime: range.startTime,
      endTime: range.endTime
    });
    setSystemProcessRecords(data.system_process_records || []);
    updateFocusCardsFromSummary(data.summary || {}, data.context_count || 0);
    setOutputHtml(formatTasksHtml(data.tasks || [], data.sync), {
      report: true,
      title: 'Extracted Tasks',
      subtitle: formatReportDateRangeLabel(range.startTime, range.endTime),
      kind: 'tasks',
      data
    });
  }, 'Task extraction failed');
}

async function recentActivity() {
  await runSafely('recentActivity', async () => {
    const records = await window.assistantApi.getRecentActivity(2, { sync: false });
    setSystemProcessRecords([]);
    updateFocusCardsFromRecords(records);
    setOutputHtml(formatRecentActivityHtml(records), { report: true });
  }, 'Recent activity lookup failed');
}

async function toggleCapture() {
  await runSafely('toggleCapture', async () => {
    const status = await window.assistantApi.getStatus();
    if (!status.running && !status.paused) {
      setOutput('Capture is offline.');
      return;
    }

    if (status.paused) {
      await window.assistantApi.resume();
    } else {
      await window.assistantApi.pause();
    }

    await refreshStatus();
  }, 'Capture toggle failed');
}

async function toggleListening() {
  const nextMode = currentAudioMode === 'off'
    ? 'meeting'
    : (currentAudioMode === 'meeting' ? 'always' : 'off');
  const previous = { enabled: listeningEnabled, mode: currentAudioMode };
  setListeningStatus(nextMode !== 'off', { busy: true, mode: nextMode });
  await runSafely('toggleListening', async () => {
    const result = await window.assistantApi.updateCapture({ audioMode: nextMode });
    setListeningStatus(Boolean(result.capture?.listeningEnabled), { mode: result.capture?.audioMode || 'off' });
    syncAudioControls(result.capture || {});
    await refreshStatus();
    if (result.ok === false) {
      setOutput(result.detail || 'Listening could not start. Cognify switched Listening Off and restarted screen capture.');
      return;
    }
    setOutput(result.capture?.audioMode === 'off'
      ? 'Listening disabled. Cognify restarted local capture with microphone access blocked.'
      : `Listening mode set to ${result.capture?.audioMode === 'meeting' ? 'Meeting Only' : 'Always On'}. Cognify restarted local capture.`);
  }, 'Listening toggle failed');
  if (listening?.disabled) {
    setListeningStatus(previous.enabled, { mode: previous.mode });
  }
}

async function openAudioSettings() {
  await runSafely('openAudioSettings', async () => {
    const settings = await window.assistantApi.getSettings();
    await loadAudioDevices(settings.capture?.audioDeviceNames || []);
    syncAudioControls(settings.capture || {});
    if (audioDrawer) {
      audioDrawer.open = true;
      audioDrawer.dispatchEvent(new Event('toggle'));
    }
    setOutput([
      'Choose audio mode and devices, then click Save Audio.',
      'Recommended: Meeting Only + Mic + Speaker + Whisper Tiny Quantized.',
      'Cognify will disable Listening automatically if Screenpipe RAM gets too high.'
    ].join('\n'));
  }, 'Opening audio settings failed');
}

function selectedAudioDevices() {
  return [...(audioDeviceNames?.querySelectorAll('input[name="audioDeviceName"]:checked') || [])]
    .map((input) => input.value)
    .filter(Boolean);
}

function checkedRadioValue(name, fallback) {
  return document.querySelector(`input[name="${name}"]:checked`)?.value || fallback;
}

function setRadioValue(name, value) {
  [...document.querySelectorAll(`input[name="${name}"]`)].forEach((input) => {
    input.checked = input.value === String(value || '');
  });
}

function syncAudioControls(capture = {}) {
  setRadioValue('visionMode', capture.visionMode || 'normal');
  setRadioValue('audioMode', capture.audioMode || (capture.listeningEnabled ? 'always' : 'off'));
  setRadioValue('audioDeviceMode', capture.audioDeviceMode || 'input-output');
  setRadioValue('audioTranscriptionEngine', capture.audioTranscriptionEngine || 'whisper-tiny-quantized');
  if (audioDeviceNames) {
    const selected = new Set(capture.audioDeviceNames || []);
    [...audioDeviceNames.querySelectorAll('input[name="audioDeviceName"]')].forEach((input) => {
      input.checked = selected.has(input.value);
    });
  }
}

async function loadAudioDevices(selected = []) {
  if (!audioDeviceNames) {
    return;
  }
  const selectedSet = new Set(selected || []);
  const devices = await window.assistantApi.getAudioDevices().catch(() => []);
  audioDeviceNames.innerHTML = devices.length
    ? devices.map((device) => {
      const name = String(device.name || '');
      const shortName = name
        .replace(/\s*\((input|output)\)$/i, '')
        .replace(/\s*\([^)]*\)\s*$/g, '')
        .slice(0, 36);
      const label = `${shortName}${device.is_default ? ' *' : ''}`;
      return `
        <label class="audio-device" title="${escapeHtml(name)}">
          <input type="checkbox" name="audioDeviceName" value="${escapeHtml(name)}" ${selectedSet.has(name) ? 'checked' : ''}>
          <span>${escapeHtml(label)}</span>
        </label>
      `;
    }).join('')
    : '<div class="audio-helper">No audio devices found.</div>';
}

async function saveAudio() {
  await runSafely('saveAudio', async () => {
    const payload = {
      visionMode: checkedRadioValue('visionMode', 'normal'),
      audioMode: checkedRadioValue('audioMode', 'off'),
      audioDeviceMode: checkedRadioValue('audioDeviceMode', 'input-output'),
      audioDeviceNames: selectedAudioDevices(),
      audioTranscriptionEngine: checkedRadioValue('audioTranscriptionEngine', 'whisper-tiny-quantized')
    };
    const result = await window.assistantApi.updateCapture(payload);
    syncAudioControls(result.capture || {});
    setListeningStatus(Boolean(result.capture?.listeningEnabled), { mode: result.capture?.audioMode || 'off' });
    await refreshRuntimeHealth();
    setOutput(`Saved capture settings:\n${JSON.stringify(result.capture, null, 2)}`);
  }, 'Saving capture settings failed');
}

async function savePrivacy() {
  await runSafely('savePrivacy', async () => {
    const apps = document.getElementById('apps').value
      .split(',')
      .map((v) => v.trim())
      .filter(Boolean);
    const domains = document.getElementById('domains').value
      .split(',')
      .map((v) => v.trim())
      .filter(Boolean);

    const saved = await window.assistantApi.updatePrivacy({ excludedApps: apps, excludedDomains: domains });
    setOutput(`Saved privacy settings:\n${JSON.stringify(saved.privacy, null, 2)}`);
  }, 'Saving privacy settings failed');
}

async function saveProfile() {
  await runSafely('saveProfile', async () => {
    const saved = await window.assistantApi.updateProfile({
      name: profileName.value,
      email: profileEmail.value
    });
    profileName.value = saved.profile?.name || '';
    profileEmail.value = saved.profile?.email || '';
    savedProfileSnapshot = profileValues();
    updateProfileDisplay();
    setOutput(`Saved profile: ${saved.profile?.name || 'No name'}${saved.profile?.email ? ` <${saved.profile.email}>` : ''}`);
  }, 'Saving profile failed');
}

async function saveRoleProfile() {
  await runSafely('saveRoleProfile', async () => {
    const roleId = profileRoleId.value || 'custom';
    const role = selectedRoleLabel();
    const saved = await window.assistantApi.updateRoleProfile({
      role,
      roleId,
      roleSource: roleId === 'custom' ? 'custom' : 'confirmed_selected',
      roleNotes: profileRoleNotes.value
    });
    profileRoleId.value = saved.profile?.roleId || 'custom';
    profileRole.value = saved.profile?.role || '';
    profileRoleNotes.value = saved.profile?.roleNotes || '';
    syncRoleCustomField();
    renderRoleDetectionHint(saved.profile || {});
    setOutput(`Saved role profile: ${saved.profile?.role || 'No role'}${saved.profile?.roleNotes ? `\nContext: ${saved.profile.roleNotes}` : ''}`);
  }, 'Saving role profile failed');
}

async function openExternalUrl(encodedUrl) {
  const url = decodeURIComponent(encodedUrl);
  await window.assistantApi.openExternalUrl(url);
}

async function copyText(encodedText) {
  const text = decodeURIComponent(encodedText);
  await window.assistantApi.copyText(text);
}

async function closePanel() {
  await window.assistantApi.hidePanel();
  outputExpanded = false;
  updateExpandedOutputButton();
}

async function saveConnection() {
  await runSafely('saveConnection', async () => {
    setOutput('Connection settings are managed from the Cognify tray menu.');
  }, 'Saving connection settings failed');
}

async function deleteRange() {
  await runSafely('deleteRange', async () => {
    const range = validatedTimeRange({ requireComplete: true });
    if (!range) {
      return;
    }

    const { startTime, endTime } = range;
    if (!confirmDeleteRange(startTime, endTime)) {
      setOutput(`Delete Range cancelled for ${formatDeletionDateRange(startTime, endTime)}.`);
      return;
    }

    const result = await window.assistantApi.deleteRange({ startTime, endTime });
    setOutput(JSON.stringify(result, null, 2));
  }, 'Delete range failed');
}

async function saveRetention() {
  await runSafely('saveRetention', async () => {
    const payload = {
      retentionDays: document.getElementById('retentionDays').value.trim(),
      screenpipeRawRetentionDays: document.getElementById('screenpipeRawRetentionDays').value.trim(),
      screenpipeRawRetentionHardCapDays: document.getElementById('screenpipeRawRetentionHardCapDays').value.trim()
    };
    const saved = await window.assistantApi.updateRetention(payload);
    setOutput([
      `Saved evidence retention: ${saved.retentionDays} days`,
      `Raw capture buffer: ${saved.screenpipeRawRetentionDays} days`,
      `Screenpipe hard cap: ${saved.screenpipeRawRetentionHardCapDays} days`
    ].join('\n'));
  }, 'Saving retention failed');
}

function setDefaultWeeklyContextWeek() {
  const input = document.getElementById('weeklyContextWeek');
  if (input && !input.value) {
    input.value = mondayDateInputValue();
  }
}

async function loadWeeklySelfInput() {
  const weekInput = document.getElementById('weeklyContextWeek');
  if (!weekInput) {
    return;
  }
  setDefaultWeeklyContextWeek();
  const result = await window.assistantApi.getWeeklySelfInput(weekInput.value).catch(() => ({ self_input: null }));
  const item = result.self_input || {};
  document.getElementById('weeklyCompletedTasks').value = (item.completed_tasks || []).join('\n');
  document.getElementById('weeklyBlockers').value = (item.blockers || []).join('\n');
  document.getElementById('weeklyOfflineWork').value = item.offline_work || '';
  document.getElementById('weeklyDeadlineWork').value = item.deadline_work || '';
  document.getElementById('weeklyMisreadContext').value = item.misread_context || '';
}

async function saveWeeklySelfInput() {
  await runSafely('saveWeeklySelfInput', async () => {
    setDefaultWeeklyContextWeek();
    const result = await window.assistantApi.saveWeeklySelfInput({
      week_start: document.getElementById('weeklyContextWeek').value,
      completed_tasks: document.getElementById('weeklyCompletedTasks').value,
      blockers: document.getElementById('weeklyBlockers').value,
      offline_work: document.getElementById('weeklyOfflineWork').value,
      deadline_work: document.getElementById('weeklyDeadlineWork').value,
      misread_context: document.getElementById('weeklyMisreadContext').value
    });
    setOutput(`Saved weekly context for ${result.self_input?.week_start || 'this week'}.`);
  }, 'Saving weekly context failed');
}

async function addManualBlock() {
  await runSafely('addManualBlock', async () => {
    const kind = checkedRadioValue('manualKind', 'work');
    const block = selectedManualIdleBlock();
    const note = document.getElementById('manualNote').value.trim();
    if (!block) {
      setManualBlockStatus('Choose one of the detected idle blocks before saving.', 'error');
      return;
    }
    if (!note) {
      setManualBlockStatus('Add a short note before saving manual time.', 'error');
      document.getElementById('manualNote')?.focus();
      return;
    }

    setManualBlockBusy(true);
    setManualBlockStatus('Saving...');
    try {
      const result = await window.assistantApi.addManualActivityBlock({
        kind,
        startTime: block.startTime,
        endTime: block.endTime,
        note
      });
      const tone = result.status === 'saved_with_warning' ? 'warn' : 'success';
      const message = result.message || `Added manual block: ${formatMinutes(result.block?.minutes || 0)} ${kind}`;
      setManualBlockStatus(message, tone);
      setOutput(message);
      document.getElementById('manualNote').value = '';
      await refreshIdleSummary();
    } catch (error) {
      setManualBlockStatus(error?.message || 'Manual block was not saved.', 'error');
      setOutput(`Adding manual block failed: ${error?.message || String(error)}`);
    } finally {
      setManualBlockBusy(false);
    }
  }, 'Adding manual block failed');
}

async function runRetention() {
  await runSafely('runRetention', async () => {
    const days = document.getElementById('retentionDays').value.trim() || '10';
    setOutput([
      'Running retention cleanup...',
      `Evidence policy: keep the last ${days} day(s).`,
      'This removes local activity-store files, old sync-window metadata, and old Cognify audit-log entries older than the retention cutoff.',
      'It does not delete Screenpipe raw capture files; raw cleanup is controlled separately by the Screenpipe cap and finalized-day cleanup.'
    ].join('\n'));
    const result = await window.assistantApi.enforceRetention();
    setOutput([
      'Retention cleanup complete.',
      `Cutoff: ${result.cutoff_iso || 'Unknown'}`,
      `Audit log rows removed: ${result.pruned || 0}`,
      `Audit log rows remaining: ${result.remaining || 0}`,
      `Activity files removed: ${result.activity_pruned_files || 0}`,
      `Sync windows removed: ${result.activity_pruned_sync_windows || 0}`
    ].join('\n'));
  }, 'Retention cleanup failed');
}

async function bootstrapSettings() {
  await runSafely('bootstrapSettings', async () => {
    const settings = await window.assistantApi.getSettings();
    profileName.value = settings.profile?.name || '';
    profileEmail.value = settings.profile?.email || '';
    profileRoleId.value = settings.profile?.roleId || settings.profile?.roleDetection?.lastDetectedRoleId || '';
    if (!profileRoleId.value || !ROLE_LABELS[profileRoleId.value]) {
      profileRoleId.value = settings.profile?.role ? 'custom' : '';
    }
    profileRole.value = settings.profile?.role || settings.profile?.roleDetection?.lastDetectedRole || '';
    profileRoleNotes.value = settings.profile?.roleNotes || '';
    if (setupName) setupName.value = settings.profile?.name || '';
    if (setupEmail) setupEmail.value = settings.profile?.email || '';
    if (setupRoleId) setupRoleId.value = settings.profile?.roleId || settings.profile?.roleDetection?.lastDetectedRoleId || '';
    if (setupRoleId && (!setupRoleId.value || !ROLE_LABELS[setupRoleId.value])) {
      setupRoleId.value = settings.profile?.role ? 'custom' : '';
    }
    if (setupRole) setupRole.value = settings.profile?.role || settings.profile?.roleDetection?.lastDetectedRole || '';
    if (setupRoleNotes) setupRoleNotes.value = settings.profile?.roleNotes || '';
    syncRoleCustomField();
    syncSetupRoleCustomField();
    renderRoleDetectionHint(settings.profile || {});
    savedProfileSnapshot = profileValues();
    updateProfileDisplay();
    setProfileEditorVisible(Boolean(!savedProfileSnapshot.name && !savedProfileSnapshot.email));
    document.getElementById('apps').value = settings.privacy.excludedApps.join(', ');
    document.getElementById('domains').value = settings.privacy.excludedDomains.join(', ');
    document.getElementById('retentionDays').value = String(settings.retentionDays);
    document.getElementById('screenpipeRawRetentionDays').value = String(settings.screenpipeRawRetentionDays || 2);
    document.getElementById('screenpipeRawRetentionHardCapDays').value = String(settings.screenpipeRawRetentionHardCapDays || 7);
    await loadAudioDevices(settings.capture?.audioDeviceNames || []);
    syncAudioControls(settings.capture || {});
    setListeningStatus(Boolean(settings.capture?.listeningEnabled), { mode: settings.capture?.audioMode || 'off' });
    await loadWeeklySelfInput();
    setSystemProcessRecords([]);
    setFocusCards();
    setClassificationSnapshot();
    await refreshIdleSummary();
    if (!settings.onboarding?.completedAt) {
      openOnboardingModal();
    }
  }, 'Loading settings failed');
  clearOutputStatus('Running bootstrapSettings...');
}

async function refreshPanel() {
  await runSafely('refresh', async () => {
    await refreshStatus();
    await refreshRuntimeHealth();
    await refreshIdleSummary();
    await renderCurrentQuestion();
  }, 'Refresh failed');
}

window.panelActions = {
  ask,
  summary,
  dailyReport,
  myWeeklyReport,
  copyMyWeeklyReport,
  timelineReport,
  fullActivityReport,
  hodDraft,
  hodDraftHistory,
  saveReviewedHodDraft,
  copyReviewedHodDraft,
  copyReviewedHodField,
  copySavedHodDraft,
  sendPayrollReport,
  tasks,
  recentActivity,
  deleteRange,
  saveProfile,
  saveRoleProfile,
  saveWeeklySelfInput,
  finishOnboarding,
  exitOnboarding,
  onboardingNext,
  onboardingBack,
  editProfile,
  savePrivacy,
  saveAudio,
  saveConnection,
  saveRetention,
  addManualBlock,
  runRetention,
  openExternalUrl,
  copyText,
  closePanel,
  toggleExpandedOutput,
  toggleTools,
  openSystemProcessModal,
  closeSystemProcessModal,
  openManualBlockModal,
  closeManualBlockModal,
  closeProfileModal,
  runSelectedReport,
  selectReportAction,
  setReportRangePreset,
  refresh: refreshPanel,
  openGuide: () => window.assistantApi.openGuide(),
  openAudioSettings,
  toggleCapture,
  toggleListening
};

window.assistantApi.onPanelMode((mode) => {
  setPanelMode(mode);
});

systemProcessModal.addEventListener('click', (event) => {
  if (event.target === systemProcessModal) {
    closeSystemProcessModal();
  }
});

manualBlockModal.addEventListener('click', (event) => {
  if (event.target === manualBlockModal) {
    closeManualBlockModal();
  }
});

document.getElementById('manualIdleBlock')?.addEventListener('change', () => {
  const block = selectedManualIdleBlock();
  if (block) {
    setManualBlockStatus(`Selected ${block.label}. Add a note, then save.`);
  }
});

profileModal?.addEventListener('click', (event) => {
  if (event.target === profileModal) {
    closeProfileModal();
  }
});

onboardingModal?.addEventListener('click', (event) => {
  if (event.target === onboardingModal) {
    setOnboardingError('Complete setup to continue.');
  }
});

profileName.addEventListener('focus', updateProfileEditorVisibility);
profileEmail.addEventListener('focus', updateProfileEditorVisibility);
profileName.addEventListener('input', updateProfileEditorVisibility);
profileEmail.addEventListener('input', updateProfileEditorVisibility);
profileView.addEventListener('click', editProfile);
profileRoleId.addEventListener('change', syncRoleCustomField);
setupRoleId?.addEventListener('change', syncSetupRoleCustomField);
[setupName, setupEmail, setupRole, setupRoleNotes].forEach((input) => {
  input?.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && input !== setupRoleNotes) {
      onboardingNext();
    }
  });
});
document.getElementById('weeklyContextWeek')?.addEventListener('change', () => {
  loadWeeklySelfInput().catch(() => {});
});
profileName.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    saveProfile();
  }
});
profileEmail.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    saveProfile();
  }
});

wireSecondaryDrawers();
initializeReportWorkspace();
updateExpandedOutputButton();
refreshStatus();
bootstrapSettings();
refreshRuntimeHealth();
setInterval(refreshIdleSummary, 120000);
setInterval(refreshRuntimeHealth, 300000);
