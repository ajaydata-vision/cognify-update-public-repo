class ChatService {
  constructor(activityQueryService, contextBuilder, dailySummaryService, taskExtractionService, auditLogService, systemIdleService = null, focusEventStore = null) {
    this.activityQueryService = activityQueryService;
    this.contextBuilder = contextBuilder;
    this.dailySummaryService = dailySummaryService;
    this.taskExtractionService = taskExtractionService;
    this.auditLogService = auditLogService;
    this.systemIdleService = systemIdleService;
    this.focusEventStore = focusEventStore;
  }

  async ask({ message, startTime, endTime }) {
    let rangeStart = startTime;
    let rangeEnd = endTime;
    let query;
    if (startTime && endTime) {
      query = await this.activityQueryService.getRangeData(startTime, endTime);
    } else {
      const end = new Date();
      const start = new Date(end.getTime() - 2 * 60 * 60 * 1000);
      rangeStart = start.toISOString();
      rangeEnd = end.toISOString();
      query = await this.activityQueryService.getRangeData(rangeStart, rangeEnd);
    }

    const sourceRecords = query.records;
    const sync = query.sync;

    const context = this.contextBuilder.build(sourceRecords);

    if (context.length === 0) {
      const empty = {
        message: 'No activity found in that range. Check Cognify status/permissions or expand the time window.',
        context_count: 0,
        tasks: [],
        summary: null,
        sync,
        system_process_records: query.system_process_records || [],
        suggestions: ['Try “today” or a larger time range.']
      };
      await this.auditLogService.log('assistant_suggestion_generated', { prompt: message, context_count: 0, suggestion_count: 1 });
      return empty;
    }

    const tasks = await this.taskExtractionService.extract(context, {
      maxRecords: 500,
      maxLines: 1200,
      maxCandidates: 40,
      maxRelatedScanLines: 1200
    });
    const idleIntervals = this.systemIdleService
      ? this.systemIdleService.getIntervalsInRange(rangeStart, rangeEnd)
      : [];
    const focusIntervals = this.focusEventStore?.getActiveIntervals
      ? this.focusEventStore.getActiveIntervals(rangeStart, rangeEnd)
      : [];
    const summary = await this.dailySummaryService.generate(context, {
      startTime: rangeStart,
      endTime: rangeEnd,
      idleIntervals,
      focusIntervals,
      tasks
    });

    const response = {
      message: this._answer(message, context, tasks, summary),
      context_count: context.length,
      tasks,
      summary,
      sync,
      system_process_records: query.system_process_records || [],
      suggestions: this._suggestions(tasks, sync)
    };

    await this.auditLogService.log('assistant_suggestion_generated', {
      prompt: message,
      suggestion_count: response.suggestions.length,
      context_count: response.context_count
    });

    return response;
  }

  _answer(message, context, tasks, summary) {
    if (/last 2 hours/i.test(message)) {
      return `In the last 2 hours I found ${context.length} activity events across ${summary.apps_used.length} apps and ${summary.browser_activity.sites.length} captured browser sites.`;
    }
    if (/today|work on/i.test(message)) {
      return `Today you used ${summary.apps_used.length} apps and visited ${summary.websites_visited.length} websites in captured activity.`;
    }
    if (/website|web site|browser|site|url/i.test(message)) {
      if (!summary.browser_activity.event_count) {
        return 'I did not detect any browser activity in the selected range.';
      }
      return `I found ${summary.browser_activity.event_count} browser events across ${summary.browser_activity.apps_used.length} browser apps and ${summary.browser_activity.sites.length} captured sites.`;
    }
    if (/follow[- ]?ups|pending/i.test(message)) {
      const pending = tasks.filter((task) => task.status === 'pending').length;
      const candidates = tasks.filter((task) => task.status === 'candidate').length;
      return `I found ${pending} likely pending follow-up(s) and ${candidates} possible candidate(s) from screen evidence.`;
    }
    if (/meeting/i.test(message)) {
      const meetings = summary.meetings_or_calls?.event_count || 0;
      const meetingTime = summary.meetings_or_calls?.total_label || '0m';
      return `I found ${meetings} meeting-related session(s), totaling ${meetingTime}. I used foreground app and meeting URL evidence.`;
    }
    if (/tomorrow.?plan/i.test(message)) {
      return `Tomorrow plan draft: ${tasks.slice(0, 3).map((t) => t.task_title).join(' | ') || 'No explicit tasks detected.'}`;
    }
    return 'I can summarize activity, extract tasks, and draft a tomorrow plan while respecting privacy controls.';
  }

  _suggestions(tasks, sync) {
    const suggestions = [];

    if (sync && !sync.complete) {
      suggestions.push(`Activity may be partial: ${sync.incomplete_window_count} sync window(s) need backfill.`);
    }

    const pending = tasks.filter((task) => task.status === 'pending');
    const candidates = tasks.filter((task) => task.status === 'candidate');

    if (pending.length === 0 && candidates.length === 0) {
      suggestions.push('No likely pending follow-ups detected in the selected range.');
      return suggestions;
    }

    suggestions.push(`You have ${pending.length} likely pending follow-up(s).`);
    if (candidates.length) {
      suggestions.push(`${candidates.length} possible follow-up candidate(s) need manual review.`);
    }
    suggestions.push('Review high-priority pending follow-ups first.');
    return suggestions;
  }
}

module.exports = { ChatService };
