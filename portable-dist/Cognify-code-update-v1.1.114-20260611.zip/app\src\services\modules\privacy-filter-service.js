class PrivacyFilterService {
  constructor(settings) {
    this.settings = settings;
    this.redactionPatterns = [
      /\b\d{3}-\d{2}-\d{4}\b/g,
      /\b(?:\d[ -]*?){13,16}\b/g,
      /\b\d{6}\b/g,
      /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi
    ];
    this.sensitiveHints = ['bank', 'payment', 'password', 'otp', 'signin', '2fa', 'card'];
    this.companionHints = [
      'cognify',
      'screenpipe companion',
      'screenpipe-companion-mvp',
      'daily summary',
      'extract tasks',
      'cognify setup',
      'screenpipe setup',
      'start iso time',
      'end iso time'
    ];
  }

  apply(records = []) {
    const excludedApps = new Set(this.settings.privacy.excludedApps.map((v) => v.toLowerCase()));
    const excludedDomains = this.settings.privacy.excludedDomains.map((v) => v.toLowerCase());

    return records
      .filter((r) => !this._isExcluded(r, excludedApps, excludedDomains))
      .map((r) => this._sanitizeRecord(r));
  }

  _payload(record) {
    return record && record.content ? record.content : record;
  }

  _isExcluded(record, excludedApps, excludedDomains) {
    const payload = this._payload(record);
    const app = (payload.app_name || '').toLowerCase();
    const url = (payload.browser_url || payload.url_if_available || '').toLowerCase();
    const title = (payload.window_name || payload.window_title || '').toLowerCase();
    const text = `${payload.text || payload.ocr_text || record.text || record.ocr_text || ''}`.toLowerCase();

    if (excludedApps.has(app)) return true;
    if (excludedDomains.some((d) => d && url.includes(d))) return true;
    if (this._isCompanionCapture(app, title, text)) return true;
    if (this.settings.privacy.excludePrivateWindows && /incognito|inprivate|private browsing/.test(title)) return true;
    if (this.settings.privacy.blockSensitiveSurfaces && this.sensitiveHints.some((h) => url.includes(h) || title.includes(h))) return true;

    return false;
  }

  _isCompanionCapture(app, title, text) {
    const haystack = `${title} ${text}`.trim();
    const normalizedApp = String(app || '').toLowerCase();

    if (normalizedApp === 'electron.exe' && (haystack.includes('screenpipe') || haystack.includes('cognify'))) {
      return true;
    }

    if (normalizedApp === 'mstsc.exe') {
      return false;
    }

    const companionMatches = this.companionHints.filter((hint) => haystack.includes(hint)).length;
    return companionMatches >= 2 && (
      normalizedApp.includes('electron') ||
      title.includes('cognify') ||
      title.includes('screenpipe companion')
    );
  }

  _sanitizeRecord(record) {
    const payload = this._payload(record);
    const ocr = this._redact(payload.text || payload.ocr_text || record.text || record.ocr_text || '');
    const transcript = this._redact(payload.transcription || payload.transcript_text || record.transcription || record.transcript_text || '');
    const title = payload.window_name || payload.window_title || '';
    const url = payload.browser_url || payload.url_if_available || '';

    return {
      ...record,
      content: payload,
      text: ocr,
      transcription: transcript,
      sensitivity_level: this.sensitiveHints.some((h) => `${title} ${url}`.toLowerCase().includes(h)) ? 'high' : 'normal'
    };
  }

  _redact(value) {
    let output = value;
    this.redactionPatterns.forEach((pattern) => {
      output = output.replace(pattern, '[REDACTED]');
    });
    return output;
  }
}

module.exports = { PrivacyFilterService };
