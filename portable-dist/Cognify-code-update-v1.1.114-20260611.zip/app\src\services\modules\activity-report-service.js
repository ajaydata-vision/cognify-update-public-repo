const SOCIAL_DOMAINS = [
  'x.com',
  'twitter.com',
  'linkedin.com',
  'facebook.com',
  'instagram.com',
  'threads.net',
  'reddit.com',
  'youtube.com',
  'youtu.be',
  'tiktok.com',
  'pinterest.com',
  'snapchat.com'
];

const { meaningfulWindowTitle, normalizeWindowTitle } = require('./window-title-normalizer');
const {
  buildWorkHoursLedger,
  safePcAvailableMinutesFromSummary
} = require('./work-hours-ledger');

const MEETING_DOMAINS = [
  'meet.google.com',
  'zoom.us',
  'teams.microsoft.com',
  'webex.com',
  'meet.jit.si',
  'jitsi.org',
  'videomeet.in'
];

const COMMUNICATION_DOMAINS = [
  'mail.google.com',
  'gmail.com',
  'outlook.office.com',
  'outlook.live.com',
  'mail.dil.net.in',
  'web.whatsapp.com',
  'whatsapp.com',
  'im.xgen.in',
  'slack.com'
];

const MEETING_APPS = [
  'zoom.exe',
  'teams.exe',
  'ms-teams.exe',
  'webex.exe',
  'ciscocollabhost.exe',
  'jitsi.exe',
  'videomeet.exe'
];

const COMMUNICATION_APPS = [
  'outlook.exe',
  'slack.exe',
  'whatsapp.exe',
  'telegram.exe'
];

const WORK_APPS = [
  'code.exe',
  'cursor.exe',
  'powershell.exe',
  'windowsterminal.exe',
  'cmd.exe',
  'node.exe',
  'python.exe',
  'excel.exe',
  'winword.exe',
  'powerpnt.exe'
];

const PROJECT_ALIASES = [
  {
    project: 'ORION AI Agent',
    patterns: ['orion - ai agent', 'dr. data\'s personal ai', 'outreach emails']
  },
  {
    project: 'Cognify',
    patterns: ['cognify', 'companion-agent', 'screenpipe', 'daily report', 'sqlite', 'activity-store', 'work-classification', 'update bundle']
  },
  {
    project: 'Payroll Reporting',
    patterns: ['payroll', 'dailyreport', 'daily report api', 'payrollapi.dil.in', 'payroll server']
  },
  {
    project: 'XgenPlus/Data Group',
    patterns: ['xgenplus', 'xgen', 'data group', 'datamail', 'im.xgen.in', 'dil.in', 'dil.net.in']
  }
];

const VALID_DOMAIN_TLDS = new Set(['com', 'in', 'net', 'org', 'io', 'ai', 'dev', 'co', 'me', 'us', 'uk']);
const UNCHANGED_PASSIVE_MINUTES = 10;
const LONG_BLOCK_REVIEW_MINUTES = 30;

class ActivityReportService {
  constructor(options = {}) {
    this.passiveAfterMinutes = Number(options.passiveAfterMinutes || UNCHANGED_PASSIVE_MINUTES);
  }

  generate(records = [], options = {}) {
    const startTime = options.startTime || firstTimestamp(records);
    const endTime = options.endTime || lastTimestamp(records);
    const mode = options.mode === 'full' ? 'full' : 'timeline';
    const sortedRecords = records
      .filter((record) => record?.timestamp_start || record?.timestamp)
      .sort((left, right) => timestampMs(left) - timestampMs(right));
    const reportDateKey = singleLocalDateKeyForRange(new Date(startTime || 0).getTime(), new Date(endTime || 0).getTime());
    const manualRecords = sortedRecords.filter((record) => (
      this.isManualRecord(record) && manualRecordBelongsToDate(record, reportDateKey)
    ));
    const pcRecords = sortedRecords.filter((record) => !this.isManualRecord(record));
    const idleIntervals = normalizeIdleIntervals(options.idleIntervals || []);
    const focusIntervals = normalizeFocusIntervals(options.focusIntervals || [], startTime, endTime);
    const focusBackedRecords = buildFocusBackedRecords(focusIntervals, pcRecords);
    const focusFilteredRecords = filterRecordsContradictedByFocus(pcRecords, focusIntervals);
    const reportRecords = focusFilteredRecords.concat(focusBackedRecords)
      .sort((left, right) => timestampMs(left) - timestampMs(right));
    const minuteFacts = this.addMissingMinuteFacts(
      this.addIdleOnlyMinuteFacts(
        this.annotateMinuteStates(this.buildMinuteFacts(reportRecords), idleIntervals),
        idleIntervals,
        startTime,
        endTime
      ),
      startTime,
      endTime
    );
    const manualTimingBlocks = this.buildManualTimingBlocks(
      manualRecords,
      startTime,
      endTime,
      minuteFacts,
      options.canonicalSummary,
      idleIntervals
    );
    const blocks = this.buildSessionBlocks(minuteFacts);
    const report = {
      source: 'activity_records',
      mode,
      startTime,
      endTime,
      generated_at: new Date().toISOString(),
      record_count: reportRecords.length,
      captured_record_count: pcRecords.length,
      manual_timing_event_count: manualRecords.length,
      focus_filtered_record_count: pcRecords.length - focusFilteredRecords.length,
      focus_backed_record_count: focusBackedRecords.length,
      manual_timing_blocks: manualTimingBlocks,
      minute_count: minuteFacts.length,
      block_count: blocks.length,
      summary: this.buildSummary(minuteFacts, blocks, options.canonicalSummary, options.canonicalCoverage),
      timeline: blocks
    };

    if (mode === 'full') {
      report.full = {
        work_summary: this.groupBlocks(blocks.filter((block) => block.category === 'Work'), (block) => block.area),
        meeting_chat_summary: this.groupBlocks(blocks.filter((block) => block.category === 'Meeting / Chat'), (block) => block.area),
        social_summary: this.groupBlocks(blocks.filter((block) => block.category === 'Social'), (block) => block.area),
        reference_summary: this.groupBlocks(blocks.filter((block) => block.category === 'Reference'), (block) => block.area),
        review_blocks: blocks.filter((block) => block.needs_review || block.needs_activity_review)
      };
    }

    return report;
  }

  generateWorkSummary(records = [], options = {}) {
    const startTime = options.startTime || firstTimestamp(records);
    const endTime = options.endTime || lastTimestamp(records);
    const rangeStartMs = new Date(startTime || 0).getTime();
    const rangeEndMs = new Date(endTime || 0).getTime();
    if (!Number.isFinite(rangeStartMs) || !Number.isFinite(rangeEndMs) || rangeEndMs <= rangeStartMs) {
      return {
        source: 'none',
        rows: [],
        app_totals: [],
        manual_timing_blocks: {
          event_count: 0,
          total_minutes: 0,
          work_minutes: 0,
          meeting_minutes: 0,
          break_minutes: 0,
          other_minutes: 0,
          net_added_work_minutes: 0,
          net_added_meeting_minutes: 0,
          net_added_minutes: 0,
          overlapping_pc_active_minutes: 0,
          idle_overlap_minutes: 0,
          items: []
        },
        activity_minutes: 0,
        captured_record_count: 0,
        focus_interval_count: 0
      };
    }

    const idleIntervals = normalizeIdleIntervals(options.idleIntervals || []);
    const focusIntervals = normalizeFocusIntervals(options.focusIntervals || [], startTime, endTime);
    const reportDateKey = singleLocalDateKeyForRange(rangeStartMs, rangeEndMs);
    const manualRecords = (records || [])
      .filter((record) => this.isManualRecord(record))
      .filter((record) => manualRecordBelongsToDate(record, reportDateKey));
    const manualTimingBlocks = this.buildManualTimingBlocks(
      manualRecords,
      startTime,
      endTime,
      [],
      options.canonicalSummary,
      idleIntervals
    );
    const capturedRecords = (records || [])
      .filter((record) => !this.isManualRecord(record))
      .filter((record) => timestampMs(record));
    const manualDetailRows = manualRecords
      .map((record) => this._manualWorkSummaryRow(record, rangeStartMs, rangeEndMs))
      .filter(Boolean);
    const focusBackedRecords = buildFocusBackedRecords(focusIntervals, [], {
        limit: Math.max(0, Math.round(Number(options.maxFocusRecords || 20000))),
        includeShort: true
      });
    const capturedDetailRecords = focusBackedRecords.length
      ? capturedRecords.filter((record) => !recordOverlapsFocusInterval(record, focusIntervals))
      : filterRecordsContradictedByFocus(capturedRecords, focusIntervals);
    const minuteChoices = new Map();
    const rowsByKey = new Map();

    capturedDetailRecords.forEach((record) => {
      const startMs = timestampMs(record);
      if (!Number.isFinite(startMs)) {
        return;
      }
      const explicitEndMs = record.timestamp_end ? new Date(record.timestamp_end).getTime() : Number.NaN;
      const durationMs = Number(record.duration_ms_estimate || 0);
      const endMs = Math.max(
        Number.isFinite(explicitEndMs) ? explicitEndMs : startMs,
        startMs + Math.max(60000, durationMs || 60000)
      );
      minuteKeysForInterval(Math.max(rangeStartMs, startMs), Math.min(rangeEndMs, endMs)).forEach((minuteKey) => {
        const minuteStartMs = new Date(minuteKey).getTime();
        if (!isFocusBackedRecord(record) && intervalOverlapMs(minuteStartMs, minuteStartMs + 60000, idleIntervals) >= 30000) {
          return;
        }
        const existing = minuteChoices.get(minuteKey);
        if (!existing || workSummaryRecordScore(record) >= workSummaryRecordScore(existing)) {
          minuteChoices.set(minuteKey, record);
        }
      });
    });

    minuteChoices.forEach((record, minuteKey) => {
      const minuteStartMs = new Date(minuteKey).getTime();
      this._addWorkSummaryRow(rowsByKey, record, {
        startMs: minuteStartMs,
        endMs: minuteStartMs + 60000,
        durationMs: 60000
      });
    });

    focusBackedRecords.forEach((record) => {
      const startMs = timestampMs(record);
      if (!Number.isFinite(startMs)) {
        return;
      }
      const endMs = new Date(record.timestamp_end || 0).getTime();
      const durationMs = Math.max(0, Math.min(rangeEndMs, Number.isFinite(endMs) ? endMs : startMs) - Math.max(rangeStartMs, startMs));
      if (durationMs <= 0) {
        return;
      }
      this._addWorkSummaryRow(rowsByKey, record, {
        startMs: Math.max(rangeStartMs, startMs),
        endMs: Math.min(rangeEndMs, Number.isFinite(endMs) ? endMs : startMs + durationMs),
        durationMs
      });
    });

    const rawRows = Array.from(rowsByKey.values());
    const rawTotalActivityMinutes = Math.max(0, Math.round(rawRows.reduce((sum, row) => (
      sum + Number(row.duration_ms || 0)
    ), 0) / 60000));
    const targetActivityMinutes = Number(options.targetActivityMinutes);
    const totalActivityMinutes = Number.isFinite(targetActivityMinutes) && targetActivityMinutes >= 0
      ? Math.max(0, Math.round(targetActivityMinutes))
      : rawTotalActivityMinutes;
    const rows = allocateRoundedWorkSummaryMinutes(rawRows, totalActivityMinutes)
      .filter((row) => Number(row.minutes || 0) > 0)
      .sort((left, right) => Number(right.minutes || 0) - Number(left.minutes || 0)
        || String(left.app_name || '').localeCompare(String(right.app_name || ''))
        || String(left.window_title || '').localeCompare(String(right.window_title || '')));
    const reportRows = rows.concat(manualDetailRows)
      .sort((left, right) => Number(right.minutes || 0) - Number(left.minutes || 0)
        || String(left.app_name || '').localeCompare(String(right.app_name || ''))
        || String(left.window_title || '').localeCompare(String(right.window_title || '')));
    const appTotals = Array.from(rows.reduce((map, row) => {
      const key = row.app_name || 'Unknown app';
      const existing = map.get(key) || { app_name: key, minutes: 0 };
      existing.minutes += Number(row.minutes || 0);
      map.set(key, existing);
      return map;
    }, new Map()).values())
      .sort((left, right) => Number(right.minutes || 0) - Number(left.minutes || 0)
        || String(left.app_name || '').localeCompare(String(right.app_name || '')));
    const capturedDurationMs = rawRows.reduce((sum, row) => (
      sum + Number(row.source_duration_ms?.captured_activity || 0)
    ), 0);
    const focusDurationMs = rawRows.reduce((sum, row) => (
      sum + Number(row.source_duration_ms?.windows_focus_evidence || 0)
    ), 0);
    const totalDurationMs = capturedDurationMs + focusDurationMs;
    const capturedMinutes = totalDurationMs > 0
      ? Math.max(0, Math.round(totalActivityMinutes * (capturedDurationMs / totalDurationMs)))
      : 0;
    const focusMinutes = Math.max(0, totalActivityMinutes - capturedMinutes);

    return {
      source: capturedMinutes > 0
        ? (focusMinutes > 0 ? 'captured-and-focus-evidence' : 'captured-activity-records')
        : (focusMinutes > 0 ? 'windows-focus-evidence' : 'none'),
      rows: reportRows,
      app_totals: appTotals,
      manual_timing_blocks: manualTimingBlocks,
      activity_minutes: totalActivityMinutes,
      captured_record_count: capturedRecords.length,
      focus_interval_count: focusIntervals.length,
      captured_minutes: capturedMinutes,
      focus_minutes: focusMinutes,
      raw_activity_minutes: rawTotalActivityMinutes
    };
  }

  _addWorkSummaryRow(rowsByKey, record, { startMs, endMs, durationMs }) {
    const surface = this.normalizeRecord(record);
    const app = displayAppName(record.app_name || surface.app || 'Unknown app');
    const title = surface.title || record.window_title || record.window_name || app;
    const url = surface.url || record.url_if_available || record.browser_url || '';
    const name = url || surface.domain || title || app;
    const source = isFocusBackedRecord(record) ? 'windows_focus_evidence' : 'captured_activity';
    const key = [app, title, name].map((value) => String(value || '').toLowerCase()).join('|');
    const row = rowsByKey.get(key) || {
      app_name: app,
      window_title: title,
      url_or_name: name,
      latest_url: url,
      source,
      source_types: [],
      duration_ms: 0,
      first_seen: new Date(startMs).toISOString(),
      last_seen: new Date(endMs).toISOString(),
      event_count: 0,
      source_duration_ms: {}
    };

    row.duration_ms += Math.max(0, Number(durationMs || 0));
    row.source_duration_ms[source] = Number(row.source_duration_ms[source] || 0) + Math.max(0, Number(durationMs || 0));
    row.event_count += 1;
    row.first_seen = new Date(Math.min(new Date(row.first_seen).getTime(), startMs)).toISOString();
    row.last_seen = new Date(Math.max(new Date(row.last_seen).getTime(), endMs)).toISOString();
    if (!row.source_types.includes(source)) {
      row.source_types.push(source);
    }
    row.source = row.source_types.length > 1 ? 'mixed' : row.source_types[0];
    rowsByKey.set(key, row);
  }

  _manualWorkSummaryRow(record = {}, rangeStartMs, rangeEndMs) {
    const kind = manualKind(record);
    if (kind !== 'work' && kind !== 'meeting') {
      return null;
    }
    const startMs = timestampMs(record);
    if (!Number.isFinite(startMs)) {
      return null;
    }
    const endMs = this.recordEndExclusiveMs(record, new Date(startMs));
    const clippedStartMs = Math.max(rangeStartMs, startMs);
    const clippedEndMs = Math.min(rangeEndMs, endMs);
    if (!Number.isFinite(clippedStartMs) || !Number.isFinite(clippedEndMs) || clippedEndMs <= clippedStartMs) {
      return null;
    }
    const minutes = minuteKeysForInterval(clippedStartMs, clippedEndMs).length;
    if (minutes <= 0) {
      return null;
    }
    const label = kind === 'meeting' ? 'Manual Meeting' : 'Manual Work';
    const detail = String(
      record.window_title || record.ocr_text || record.text || record.note || record.app_name || 'Manual Timing Block'
    ).trim() || 'Manual Timing Block';
    const title = detail.toLowerCase().startsWith(label.toLowerCase()) ? detail : `${label}: ${detail}`;

    return {
      app_name: label,
      window_title: title,
      url_or_name: detail,
      latest_url: '',
      source: 'manual_timing',
      source_types: ['manual_timing'],
      duration_ms: clippedEndMs - clippedStartMs,
      minutes,
      duration_minutes: minutes,
      first_seen: new Date(clippedStartMs).toISOString(),
      last_seen: new Date(clippedEndMs).toISOString(),
      event_count: 1,
      manual_kind: kind,
      report_only: true,
      excluded_from_totals: true
    };
  }

  buildMinuteFacts(records = []) {
    const buckets = new Map();

    records.forEach((record) => {
      const start = new Date(record.timestamp_start || record.timestamp || 0);
      if (Number.isNaN(start.getTime())) {
        return;
      }

      if (!this.isManualRecord(record) && !isFocusBackedRecord(record)) {
        const key = floorMinuteIso(start);
        if (!buckets.has(key)) {
          buckets.set(key, []);
        }
        buckets.get(key).push(record);
        return;
      }

      const startMs = start.getTime();
      const endExclusiveMs = this.recordEndExclusiveMs(record, start);
      const durationMs = Math.max(0, endExclusiveMs - startMs);
      let cursor = new Date(start);
      cursor.setSeconds(0, 0);
      let added = false;
      let bestMinuteIso = '';
      let bestOverlapMs = 0;

      while (cursor.getTime() < endExclusiveMs) {
        const minuteStartMs = cursor.getTime();
        const minuteEndMs = minuteStartMs + 60000;
        const overlapMs = intervalOverlapMs(minuteStartMs, minuteEndMs, [{ startMs, endMs: endExclusiveMs }]);
        const key = cursor.toISOString();
        if (overlapMs > bestOverlapMs) {
          bestOverlapMs = overlapMs;
          bestMinuteIso = key;
        }
        if (overlapMs >= 30000) {
          if (!buckets.has(key)) {
            buckets.set(key, []);
          }
          buckets.get(key).push(record);
          added = true;
        }
        cursor = new Date(cursor.getTime() + 60000);
      }

      if (!added && durationMs >= 30000 && bestMinuteIso) {
        if (!buckets.has(bestMinuteIso)) {
          buckets.set(bestMinuteIso, []);
        }
        buckets.get(bestMinuteIso).push(record);
      }
    });

    return Array.from(buckets.entries())
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([minuteIso, bucket]) => this.classifyMinute(minuteIso, bucket));
  }

  manualRecordEnd(record = {}, start) {
    if (!this.isManualRecord(record) && !isFocusBackedRecord(record)) {
      return start;
    }

    const startMs = start.getTime();
    const explicitEndMs = this.recordEndExclusiveMs(record, start);
    return new Date(explicitEndMs > startMs ? explicitEndMs - 1 : startMs);
  }

  recordEndExclusiveMs(record = {}, start) {
    const startMs = start.getTime();
    const endMs = new Date(record.timestamp_end || 0).getTime();
    const durationMs = Number(record.duration_ms_estimate || 0);
    return Math.max(
      Number.isFinite(endMs) ? endMs : startMs,
      startMs + Math.max(0, durationMs)
    );
  }

  isManualRecord(record = {}) {
    return record.source === 'manual' || record.activity_type === 'manual' || record.type === 'manual';
  }

  classifyMinute(minuteIso, records) {
    const surfaces = records.map((record) => this.normalizeRecord(record));
    const manualSurface = surfaces.find((surface) => surface.manual);
    const strongest = pickStrongestSurface(surfaces);
    const domains = unique(surfaces.map((surface) => surface.domain).filter(Boolean));
    const apps = unique(surfaces.map((surface) => surface.app).filter(Boolean));
    const appLabels = unique(surfaces.map((surface) => surface.tool).filter(Boolean));
    const titles = unique(surfaces.map((surface) => surface.title).filter(Boolean));
    const chatContact = unique(surfaces.map((surface) => surface.chat_contact).filter(Boolean))[0] || '';
    const documentName = unique(surfaces.map((surface) => surface.document_name).filter(Boolean))[0] || '';
    const text = surfaces.map((surface) => `${surface.title} ${surface.url} ${surface.ocr}`).join(' ').toLowerCase();
    const socialDomain = domains.find((domain) => SOCIAL_DOMAINS.some((pattern) => domainMatches(domain, pattern)));
    const meetingDomain = domains.find((domain) => MEETING_DOMAINS.some((pattern) => domainMatches(domain, pattern)));
    const communicationDomain = domains.find((domain) => COMMUNICATION_DOMAINS.some((pattern) => domainMatches(domain, pattern)));
    const meetingApp = apps.find((app) => MEETING_APPS.includes(app));
    const communicationApp = apps.find((app) => COMMUNICATION_APPS.includes(app));
    const workApp = apps.find((app) => WORK_APPS.includes(app));
    const activityPattern = detectActivityPattern(text);
    const sensitive = /\b(password|otp|secret|api token|private key|credit card|auth token)\b/i.test(text);
    const project = inferProject(text, strongest, {
      socialDomain,
      meetingDomain,
      communicationDomain,
      sensitive,
      chatContact,
      documentName
    });
    const followupSignal = /\b(to do|todo|follow[- ]?up|pending task|lets do later|will take up later|takeup later|do tomorrow)\b/i.test(text);

    let category = 'Unclear';
    let action = 'Viewed';
    let confidence = 'Low';
    let area = project;

    if (manualSurface) {
      category = manualSurface.manual_kind === 'meeting'
        ? 'Meeting / Chat'
        : (manualSurface.manual_kind === 'break' ? 'Reference' : 'Work');
      area = manualSurface.manual_kind === 'break'
        ? 'Break'
        : (manualSurface.title || manualSurface.tool || 'Manual Entry');
      action = manualSurface.manual_kind === 'break' ? 'Manual break' : 'Manual entry';
      confidence = 'High';
    } else if (sensitive) {
      category = 'Private/Sensitive';
      action = 'Excluded';
      confidence = 'High';
    } else if (socialDomain) {
      category = 'Social';
      action = 'Social platform activity';
      confidence = 'High';
    } else if (meetingDomain || meetingApp) {
      category = 'Meeting / Chat';
      action = 'Video/audio meeting';
      confidence = 'High';
    } else if (communicationDomain || communicationApp || surfaces.some((surface) => /\b(send email|compose email|new email|inbox|outbox|drafts?|mailbox|reply email|forward email)\b/i.test(`${surface.app || ''} ${surface.title || ''}`))) {
      category = 'Meeting / Chat';
      action = 'Messaging/email';
      confidence = 'High';
    } else if (activityPattern) {
      category = 'Work';
      action = activityPattern.action;
      confidence = activityPattern.confidence;
    } else if (workApp || /\b(code|git|npm|node|electron|sqlite|api|bundle|report|debug|test|build|terminal|powershell)\b/i.test(text)) {
      category = 'Work';
      action = /\b(test|debug|error|fix|build|bundle|commit|push)\b/i.test(text) ? 'Built/edited/tested' : 'Worked';
      confidence = project === 'Unclear' ? 'Medium' : 'High';
    }

    if (category === 'Unclear' && project !== 'Unclear') {
      category = 'Reference';
      confidence = 'Medium';
    }

    return {
      minute_start: minuteIso,
      minute_end: addMinutes(minuteIso, 1),
      surface_key: buildSurfaceKey(strongest),
      content_fingerprint: fingerprintText(text),
      category,
      area,
      action,
      tool_app: labelTools(appLabels, apps, domains, strongest),
      raw_apps: apps,
      domains,
      document_name: documentName,
      chat_contact: chatContact,
      window_titles: titles.slice(0, 3),
      evidence_count: records.length,
      confidence,
      privacy_level: sensitive ? 'private' : 'normal',
      followup_signal: followupSignal,
      needs_review: confidence === 'Low' || category === 'Unclear' || followupSignal,
      manual: Boolean(manualSurface)
    };
  }

  addIdleOnlyMinuteFacts(minuteFacts = [], idleIntervals = [], startTime, endTime) {
    const existing = new Set(minuteFacts.map((fact) => fact.minute_start));
    const startMs = new Date(startTime || minuteFacts[0]?.minute_start || 0).getTime();
    const endMs = new Date(endTime || minuteFacts[minuteFacts.length - 1]?.minute_end || 0).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return minuteFacts;
    }

    const idleFacts = [];
    idleIntervals.forEach((interval) => {
      const intervalStartMs = Math.max(startMs, Number(interval.startMs));
      const intervalEndMs = Math.min(endMs, Number(interval.endMs));
      if (!Number.isFinite(intervalStartMs) || !Number.isFinite(intervalEndMs) || intervalEndMs <= intervalStartMs) {
        return;
      }

      let cursor = new Date(intervalStartMs);
      cursor.setSeconds(0, 0);
      while (cursor.getTime() < intervalEndMs) {
        const minuteStartMs = cursor.getTime();
        const minuteEndMs = minuteStartMs + 60000;
        if (!existing.has(cursor.toISOString()) && intervalOverlapMs(minuteStartMs, minuteEndMs, [interval]) >= 30000) {
          idleFacts.push(this.idleMinuteFact(cursor.toISOString()));
          existing.add(cursor.toISOString());
        }
        cursor = new Date(minuteEndMs);
      }
    });

    return minuteFacts.concat(idleFacts)
      .sort((left, right) => left.minute_start.localeCompare(right.minute_start));
  }

  idleMinuteFact(minuteIso) {
    return {
      minute_start: minuteIso,
      minute_end: addMinutes(minuteIso, 1),
      surface_key: 'idle:away',
      content_fingerprint: 'idle',
      category: 'Input Idle',
      area: 'Away',
      action: 'No keyboard/mouse input',
      tool_app: 'PC idle',
      raw_apps: ['PC idle'],
      domains: [],
      document_name: '',
      chat_contact: '',
      window_titles: [],
      evidence_count: 0,
      confidence: 'High',
      privacy_level: 'normal',
      followup_signal: false,
      needs_review: true,
      content_changed: true,
      unchanged_run_minutes: 0,
      input_idle: true,
      activity_state: 'input_idle',
      needs_activity_review: true
    };
  }

  addMissingMinuteFacts(minuteFacts = [], startTime, endTime) {
    const existing = new Set(minuteFacts.map((fact) => fact.minute_start));
    const startMs = new Date(startTime || minuteFacts[0]?.minute_start || 0).getTime();
    const endMs = new Date(endTime || minuteFacts[minuteFacts.length - 1]?.minute_end || 0).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return minuteFacts;
    }

    const missingFacts = [];
    let cursor = new Date(startMs);
    cursor.setSeconds(0, 0);
    while (cursor.getTime() < endMs) {
      const minuteStartMs = cursor.getTime();
      const minuteEndMs = minuteStartMs + 60000;
      if (
        !existing.has(cursor.toISOString()) &&
        intervalOverlapMs(minuteStartMs, minuteEndMs, [{ startMs, endMs }]) >= 30000
      ) {
        missingFacts.push(this.missingMinuteFact(cursor.toISOString()));
        existing.add(cursor.toISOString());
      }
      cursor = new Date(minuteEndMs);
    }

    return minuteFacts.concat(missingFacts)
      .sort((left, right) => left.minute_start.localeCompare(right.minute_start));
  }

  missingMinuteFact(minuteIso) {
    return {
      minute_start: minuteIso,
      minute_end: addMinutes(minuteIso, 1),
      surface_key: 'missing:unknown',
      content_fingerprint: 'missing',
      category: 'Missing / Unknown',
      area: 'No evidence',
      action: 'No activity evidence captured',
      tool_app: 'Unknown',
      raw_apps: [],
      domains: [],
      document_name: '',
      chat_contact: '',
      window_titles: [],
      evidence_count: 0,
      confidence: 'Low',
      privacy_level: 'normal',
      followup_signal: false,
      needs_review: true,
      content_changed: true,
      unchanged_run_minutes: 0,
      input_idle: false,
      missing_evidence: true,
      activity_state: 'missing',
      needs_activity_review: true
    };
  }

  buildManualTimingBlocks(records = [], startTime, endTime, minuteFacts = [], canonicalSummary = null, idleIntervals = []) {
    if (canonicalSummary?.manual_timing_blocks) {
      return canonicalSummary.manual_timing_blocks;
    }

    const rangeStartMs = new Date(startTime || 0).getTime();
    const rangeEndMs = new Date(endTime || 0).getTime();
    const pcActiveMinutes = new Set(
      minuteFacts
        .filter((fact) => fact.activity_state === 'active')
        .map((fact) => fact.minute_start)
    );
    const idleMinutes = new Set(
      minuteFacts
        .filter((fact) => fact.activity_state === 'input_idle')
        .map((fact) => fact.minute_start)
    );
    idleIntervals.forEach((interval) => {
      minuteKeysForInterval(interval.startMs, interval.endMs).forEach((key) => idleMinutes.add(key));
    });
    const totals = {
      event_count: records.length,
      total_minutes: 0,
      work_minutes: 0,
      meeting_minutes: 0,
      break_minutes: 0,
      other_minutes: 0,
      net_added_work_minutes: 0,
      net_added_meeting_minutes: 0,
      net_added_minutes: 0,
      overlapping_pc_active_minutes: 0,
      idle_overlap_minutes: 0,
      items: []
    };
    const allMinutes = new Set();
    const kindMinutes = {
      work: new Set(),
      meeting: new Set(),
      break: new Set(),
      other: new Set()
    };
    const netWork = new Set();
    const netMeeting = new Set();
    const overlapPc = new Set();
    const overlapIdle = new Set();

    records.forEach((record) => {
      const startMs = Math.max(timestampMs(record), Number.isFinite(rangeStartMs) ? rangeStartMs : timestampMs(record));
      const endMs = Math.min(this.recordEndExclusiveMs(record, new Date(timestampMs(record))), Number.isFinite(rangeEndMs) ? rangeEndMs : Number.POSITIVE_INFINITY);
      if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
        return;
      }

      const kind = manualKind(record);
      const minuteKeys = minuteKeysForInterval(startMs, endMs);
      minuteKeys.forEach((key) => {
        allMinutes.add(key);
        kindMinutes[kind].add(key);
        if (pcActiveMinutes.has(key)) {
          overlapPc.add(key);
        }
        if (idleMinutes.has(key)) {
          overlapIdle.add(key);
        }
        if (kind === 'work' && idleMinutes.has(key)) {
          netWork.add(key);
        } else if (kind === 'meeting' && idleMinutes.has(key)) {
          netMeeting.add(key);
        }
      });

      totals.items.push({
        start: new Date(startMs).toISOString(),
        end: new Date(endMs).toISOString(),
        kind,
        title: record.window_title || record.ocr_text || record.app_name || 'Manual Timing Block',
        minutes: minuteKeys.length,
        net_added_minutes: minuteKeys.filter((key) => (
          (kind === 'work' || kind === 'meeting') && idleMinutes.has(key)
        )).length,
        overlapping_pc_active_minutes: minuteKeys.filter((key) => pcActiveMinutes.has(key)).length,
        idle_overlap_minutes: minuteKeys.filter((key) => idleMinutes.has(key)).length
      });
    });

    totals.total_minutes = allMinutes.size;
    totals.work_minutes = kindMinutes.work.size;
    totals.meeting_minutes = kindMinutes.meeting.size;
    totals.break_minutes = kindMinutes.break.size;
    totals.other_minutes = kindMinutes.other.size;
    totals.net_added_work_minutes = netWork.size;
    totals.net_added_meeting_minutes = netMeeting.size;
    totals.net_added_minutes = netWork.size + netMeeting.size;
    totals.overlapping_pc_active_minutes = overlapPc.size;
    totals.idle_overlap_minutes = overlapIdle.size;
    return totals;
  }

  normalizeRecord(record = {}) {
    const app = String(record.app_name || '').trim().toLowerCase();
    const title = meaningfulWindowTitle(record);
    const url = String(record.url_if_available || record.browser_url || '').trim();
    const ocr = String(record.ocr_text || record.text || '').trim();
    return {
      app,
      title,
      url,
      domain: extractDomain(url) || extractKnownDomain(`${title} ${ocr}`),
      ocr,
      chat_contact: extractChatContact(title, ocr),
      document_name: extractDocumentName(app, title),
      tool: inferTool(app, title, url),
      manual: this.isManualRecord(record),
      manual_kind: manualKind(record)
    };
  }

  annotateMinuteStates(minuteFacts, idleIntervals = []) {
    let previous = null;
    let unchangedRun = 0;

    return minuteFacts.map((fact) => {
      const minuteStartMs = new Date(fact.minute_start).getTime();
      const minuteEndMs = new Date(fact.minute_end).getTime();
      const inputIdle = !fact.manual && intervalOverlapMs(minuteStartMs, minuteEndMs, idleIntervals) >= 30000;
      const contentChanged = !previous ||
        fact.surface_key !== previous.surface_key ||
        fact.content_fingerprint !== previous.content_fingerprint ||
        fact.category !== previous.category ||
        fact.area !== previous.area ||
        fact.action !== previous.action;

      unchangedRun = contentChanged ? 0 : unchangedRun + 1;
      const next = {
        ...fact,
        content_changed: contentChanged,
        unchanged_run_minutes: unchangedRun,
        input_idle: inputIdle,
        activity_state: 'active',
        needs_activity_review: false
      };

      if (inputIdle) {
        next.activity_state = 'input_idle';
        next.category = 'Input Idle';
        next.area = 'Away';
        next.action = 'No keyboard/mouse input';
        next.tool_app = 'PC idle';
        next.needs_activity_review = true;
      } else if (!fact.manual && unchangedRun >= this.passiveAfterMinutes) {
        next.activity_state = 'passive_candidate';
        next.needs_activity_review = true;
      }

      previous = next;
      return next;
    });
  }

  buildSessionBlocks(minuteFacts = []) {
    const blocks = [];

    minuteFacts.forEach((fact) => {
      const previous = blocks[blocks.length - 1];
      if (previous && canMerge(previous, fact)) {
        previous.end = fact.minute_end;
        previous.minutes += 1;
        previous.active_minutes += fact.activity_state === 'active' ? 1 : 0;
        previous.passive_minutes += fact.activity_state === 'passive_candidate' ? 1 : 0;
        previous.input_idle_minutes += fact.activity_state === 'input_idle' ? 1 : 0;
        previous.missing_minutes += fact.activity_state === 'missing' ? 1 : 0;
        previous.unchanged_minutes += fact.content_changed ? 0 : 1;
        previous.evidence_count += fact.evidence_count;
        previous.tool_app = mergeLabel(previous.tool_app, fact.tool_app);
        previous.raw_apps = unique(previous.raw_apps.concat(fact.raw_apps));
        previous.domains = unique(previous.domains.concat(fact.domains));
        previous.needs_review = previous.needs_review || fact.needs_review;
        previous.needs_activity_review = previous.needs_activity_review || fact.needs_activity_review;
        previous.followup_signal = previous.followup_signal || fact.followup_signal;
        previous.confidence = lowerConfidence(previous.confidence, fact.confidence);
        previous.summary = summarizeBlock(previous);
        return;
      }

      const block = {
        start: fact.minute_start,
        end: fact.minute_end,
        minutes: 1,
        category: fact.category,
        area: fact.area,
        action: fact.action,
        activity_state: fact.activity_state,
        tool_app: fact.tool_app,
        raw_apps: fact.raw_apps,
        domains: fact.domains,
        active_minutes: fact.activity_state === 'active' ? 1 : 0,
        passive_minutes: fact.activity_state === 'passive_candidate' ? 1 : 0,
        input_idle_minutes: fact.activity_state === 'input_idle' ? 1 : 0,
        missing_minutes: fact.activity_state === 'missing' ? 1 : 0,
        unchanged_minutes: fact.content_changed ? 0 : 1,
        evidence_count: fact.evidence_count,
        confidence: fact.confidence,
        needs_review: fact.needs_review,
        needs_activity_review: fact.needs_activity_review,
        followup_signal: fact.followup_signal,
        summary: ''
      };
      block.summary = summarizeBlock(block);
      blocks.push(block);
    });

    blocks.forEach((block) => {
      if (block.minutes >= LONG_BLOCK_REVIEW_MINUTES && block.passive_minutes >= Math.ceil(block.minutes * 0.25)) {
        block.needs_activity_review = true;
        block.needs_review = true;
        block.summary = summarizeBlock(block);
      }
    });

    return blocks;
  }

  buildSummary(minuteFacts, blocks, canonicalSummary = null, canonicalCoverage = null) {
    const activeFacts = minuteFacts.filter((fact) => fact.activity_state === 'active');
    const summary = {
      visible_minutes: minuteFacts.length,
      active_minutes: countBy(minuteFacts, (fact) => fact.activity_state === 'active'),
      passive_candidate_minutes: countBy(minuteFacts, (fact) => fact.activity_state === 'passive_candidate'),
      input_idle_minutes: countBy(minuteFacts, (fact) => fact.activity_state === 'input_idle'),
      missing_minutes: countBy(minuteFacts, (fact) => fact.activity_state === 'missing'),
      coverage_complete: !minuteFacts.some((fact) => fact.activity_state === 'missing'),
      category_minutes: groupMinutes(activeFacts, (fact) => fact.category),
      visible_category_minutes: groupMinutes(minuteFacts, (fact) => fact.category),
      area_category_minutes: groupMinutes(activeFacts, (fact) => `${fact.area} | ${fact.category}`).slice(0, 20),
      review_block_count: blocks.filter((block) => block.needs_review || block.needs_activity_review).length
    };

    return applyCanonicalWorkMinutes(summary, canonicalSummary, canonicalCoverage);
  }

  groupBlocks(blocks, keyFn) {
    const grouped = new Map();
    blocks.forEach((block) => {
      const key = keyFn(block) || 'Unclear';
      if (!grouped.has(key)) {
        grouped.set(key, {
          label: key,
          minutes: 0,
          active_minutes: 0,
          passive_minutes: 0,
          input_idle_minutes: 0,
          missing_minutes: 0,
          tool_apps: new Set(),
          summaries: new Set()
        });
      }
      const entry = grouped.get(key);
      entry.minutes += block.active_minutes || 0;
      entry.active_minutes += block.active_minutes;
      entry.passive_minutes += block.passive_minutes;
      entry.input_idle_minutes += block.input_idle_minutes || 0;
      entry.missing_minutes += block.missing_minutes || 0;
      if (block.tool_app) {
        entry.tool_apps.add(block.tool_app);
      }
      if (block.summary) {
        entry.summaries.add(block.summary);
      }
    });

    return Array.from(grouped.values())
      .map((entry) => ({
        label: entry.label,
        minutes: entry.minutes,
        active_minutes: entry.active_minutes,
        passive_minutes: entry.passive_minutes,
        input_idle_minutes: entry.input_idle_minutes,
        missing_minutes: entry.missing_minutes,
        tool_apps: Array.from(entry.tool_apps).slice(0, 4),
        summaries: Array.from(entry.summaries).slice(0, 3)
      }))
      .sort((left, right) => right.minutes - left.minutes);
  }
}

function inferProject(text, strongest, context = {}) {
  if (context.sensitive) {
    return inferSensitiveProject(text, strongest);
  }
  if (context.socialDomain) {
    return `Social / ${context.socialDomain}`;
  }
  if (context.meetingDomain) {
    return `Meeting / ${context.meetingDomain}`;
  }
  if (context.communicationDomain && context.chatContact) {
    return `Chat with ${context.chatContact}`;
  }
  if (context.documentName) {
    return context.documentName;
  }
  for (const entry of PROJECT_ALIASES) {
    if (entry.patterns.some((pattern) => text.includes(pattern))) {
      return entry.project;
    }
  }
  if (context.communicationDomain) {
    return `Communication / ${context.communicationDomain}`;
  }
  return strongest.domain || 'Unclear';
}

function inferSensitiveProject(text, strongest) {
  for (const entry of PROJECT_ALIASES) {
    if (entry.patterns.some((pattern) => text.includes(pattern))) {
      return entry.project;
    }
  }
  return strongest.domain || 'Private/Sensitive';
}

function detectActivityPattern(text) {
  return detectEmailDraftingPattern(text) || detectCodingPattern(text) || detectSpreadsheetPattern(text);
}

function detectEmailDraftingPattern(text) {
  const hasComposeSurface = /\b(send email|compose|new message|to:|cc:|bcc:|subject:|send next|send)\b/i.test(text);
  const hasDraftingSignal = /\b(generate with ai|claude api|calling claude api|email draft|draft generated|personalized email|compose manually|outreach emails)\b/i.test(text);
  const hasEmailBodySignal = /\b(hello\s+[a-z]|dear\s+[a-z]|subject:|from:|to:)\b/i.test(text);
  const hasOutreachSignal = /\b(outreach|sent today|unsent|recipient|lead|prospect)\b/i.test(text);
  if (hasComposeSurface && hasDraftingSignal && (hasEmailBodySignal || hasOutreachSignal)) {
    return { action: 'AI-assisted outbound email drafting', confidence: 'High' };
  }
  if (hasComposeSurface && hasEmailBodySignal && hasOutreachSignal) {
    return { action: 'Outbound email drafting', confidence: 'Medium' };
  }
  return null;
}

function detectCodingPattern(text) {
  if (/\b(git|npm|node|electron|sqlite|api|bundle|debug|test|build|commit|push|stack trace|exception)\b/i.test(text)) {
    return { action: 'Built/edited/tested', confidence: 'High' };
  }
  return null;
}

function detectSpreadsheetPattern(text) {
  if (/\b(microsoft excel|worksheet|workbook|formula|pivot|rows|columns|spreadsheet)\b/i.test(text)) {
    return { action: 'Spreadsheet/admin work', confidence: 'High' };
  }
  return null;
}

function extractChatContact(title, ocr) {
  const titleValue = String(title || '').trim();
  const elementMatch = titleValue.match(/^Element\s*-\s*.+?\|\s*(.+)$/i);
  if (elementMatch) {
    return cleanChatContact(elementMatch[1]);
  }
  const ocrValue = String(ocr || '');
  const openRoomMatch = ocrValue.match(/\bOpen room\s+([^.\n]+?)(?:\s+with\s+\d+\s+unread message|\s+Open room|\s+More Options|$)/i);
  return openRoomMatch ? cleanChatContact(openRoomMatch[1]) : '';
}

function cleanChatContact(value) {
  return String(value || '')
    .replace(/\s+/g, ' ')
    .replace(/\s+-\s*Google Chrome$/i, '')
    .replace(/\s+\[\d+\]$/i, '')
    .trim()
    .slice(0, 80);
}

function extractDocumentName(app, title) {
  const appName = String(app || '').toLowerCase();
  const value = String(title || '').trim();
  if (!value) {
    return '';
  }
  const patterns = [
    { app: /excel\.exe/, suffix: /\s+-\s+Excel$/i },
    { app: /winword\.exe/, suffix: /\s+-\s+Word$/i },
    { app: /powerpnt\.exe/, suffix: /\s+-\s+PowerPoint$/i }
  ];
  const match = patterns.find((entry) => entry.app.test(appName));
  if (!match || !match.suffix.test(value)) {
    return '';
  }
  return value.replace(match.suffix, '').replace(/\s+•\s+Saved$/i, '').trim();
}

function inferTool(app, title, url) {
  const domain = extractDomain(url);
  if (domain === 'im.xgen.in') return 'Xgen IM';
  if (domain) return friendlyDomain(domain);
  const appName = String(app || '').toLowerCase();
  if (appName === 'excel.exe') return 'Excel';
  if (appName === 'winword.exe') return 'Word';
  if (appName === 'powerpnt.exe') return 'PowerPoint';
  if (appName === 'chrome.exe') return 'Chrome';
  if (appName === 'windowsterminal.exe') return 'Terminal';
  if (appName === 'python.exe' && /orion/i.test(title)) return 'ORION AI Agent';
  return appName ? appName.replace(/\.exe$/i, '') : (title || 'Unknown');
}

function manualKind(record = {}) {
  const explicit = normalizeManualKind(record.manual_kind);
  if (explicit) {
    return explicit;
  }
  const text = `${record.app_name || ''} ${record.window_title || ''} ${record.ocr_text || ''}`.toLowerCase();
  if (/\b(meeting|call|chat)\b/.test(text)) {
    return 'meeting';
  }
  if (/\b(break|lunch|walk|away)\b/.test(text)) {
    return 'break';
  }
  if (/\b(other|manual entry)\b/.test(text)) {
    return 'other';
  }
  return 'work';
}

function normalizeManualKind(value) {
  const normalized = String(value || '').trim().toLowerCase();
  return ['work', 'meeting', 'break', 'other'].includes(normalized) ? normalized : '';
}

function localDateKeyFromMs(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) {
    return '';
  }
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function singleLocalDateKeyForRange(startMs, endMs) {
  if (!Number.isFinite(Number(startMs)) || !Number.isFinite(Number(endMs)) || Number(endMs) <= Number(startMs)) {
    return '';
  }
  const startKey = localDateKeyFromMs(startMs);
  const endKey = localDateKeyFromMs(Number(endMs) - 1);
  return startKey && startKey === endKey ? startKey : '';
}

function manualRecordBelongsToDate(record = {}, dateKey = '') {
  if (!dateKey) {
    return true;
  }
  const explicit = String(record.manual_local_date_key || '').trim();
  if (explicit) {
    return explicit === dateKey;
  }
  return localDateKeyFromMs(record.timestamp_start || record.timestamp || record.timestamp_end || 0) === dateKey;
}

function labelTools(appLabels, apps, domains, strongest) {
  if (apps.includes('chrome.exe') && domains.length) {
    if (domains.some((domain) => domain === 'im.xgen.in')) {
      return 'Xgen IM';
    }
    return `Chrome / ${domains.slice(0, 2).map(friendlyDomain).join(' / ')}`;
  }
  const labels = unique(appLabels).filter((label) => label && label !== 'Unknown');
  if (labels.length) {
    return labels.slice(0, 3).join(' / ');
  }
  if (domains.length) {
    return domains.slice(0, 2).map(friendlyDomain).join(' / ');
  }
  if (apps.length) {
    return apps.slice(0, 2).map((app) => app.replace(/\.exe$/i, '')).join(' / ');
  }
  return strongest.tool || 'Unknown';
}

function friendlyDomain(domain) {
  if (domain === 'im.xgen.in') return 'Xgen IM';
  return domain;
}

function canMerge(block, fact) {
  if (block.category !== fact.category || block.area !== fact.area || block.action !== fact.action) {
    return false;
  }
  if (block.activity_state !== fact.activity_state) {
    return false;
  }
  if (normalizeToolLabel(block.tool_app) !== normalizeToolLabel(fact.tool_app)) {
    return false;
  }
  return new Date(fact.minute_start).getTime() - new Date(block.end).getTime() <= 2 * 60 * 1000;
}

function summarizeBlock(block) {
  if (block.category === 'Input Idle') {
    return 'No keyboard or mouse input was detected; this period is treated as away/idle, not work done.';
  }
  if (block.category === 'Missing / Unknown') {
    return 'No screen, focus, manual, or idle evidence was captured for this period.';
  }
  if (block.category === 'Private/Sensitive') {
    return 'Private or sensitive screen content was excluded from report details.';
  }
  if (block.category === 'Social') {
    return 'Social platform activity detected.';
  }
  if (block.category === 'Meeting / Chat') {
    return block.action === 'Video/audio meeting' ? 'Video/audio meeting activity.' : 'Chat or messaging activity.';
  }
  const passive = block.passive_minutes ? `; ${formatMinutes(block.passive_minutes)} passive/unchanged candidate` : '';
  const idle = block.input_idle_minutes ? `; ${formatMinutes(block.input_idle_minutes)} input-idle` : '';
  return `${block.action}${passive}${idle}.`;
}

function groupMinutes(items, keyFn) {
  const totals = new Map();
  items.forEach((item) => {
    const key = keyFn(item) || 'Unclear';
    totals.set(key, (totals.get(key) || 0) + 1);
  });
  return Array.from(totals.entries())
    .map(([label, minutes]) => ({ label, minutes }))
    .sort((left, right) => right.minutes - left.minutes);
}

function canonicalWorkMinutes(summary = {}) {
  const idle = Number(summary.idle_minutes || summary.input_idle_minutes || 0);
  const manualNet = Number.isFinite(Number(summary.manual_net_added_work_minutes))
    ? Number(summary.manual_net_added_work_minutes)
    : Number(summary.manual_timing_blocks?.net_added_minutes || 0);
  if (
    Number.isFinite(Number(summary.gross_pc_available_minutes)) ||
    Number.isFinite(Number(summary.work_minutes_breakdown?.gross_pc_available_minutes)) ||
    Number.isFinite(Number(summary.runtime_available_minutes))
  ) {
    return buildWorkHoursLedger({
      pcAvailableMinutes: safePcAvailableMinutesFromSummary(summary),
      idleMinutes: idle,
      manualAddedMinutes: manualNet,
      rangeMinutes: summary.range_minutes
    }).work_minutes;
  }
  if (Number.isFinite(Number(summary.work_minutes))) {
    return Math.max(0, Math.round(Number(summary.work_minutes || 0)));
  }
  if (Number.isFinite(Number(summary.work_minutes_breakdown?.total_work_minutes))) {
    return Math.max(0, Math.round(Number(summary.work_minutes_breakdown.total_work_minutes || 0)));
  }
  return buildWorkHoursLedger({
    pcAvailableMinutes: safePcAvailableMinutesFromSummary(summary),
    idleMinutes: idle,
    manualAddedMinutes: manualNet,
    rangeMinutes: summary.range_minutes
  }).work_minutes;
}

function applyCanonicalWorkMinutes(summary = {}, canonicalSummary = null, canonicalCoverage = null) {
  const coverage = canonicalCoverage || canonicalSummary?.canonical_coverage || null;
  if (!canonicalSummary) {
    return coverage ? { ...summary, canonical_coverage: coverage } : summary;
  }

  const workMinutes = canonicalWorkMinutes(canonicalSummary);
  const pcAvailableMinutes = safePcAvailableMinutesFromSummary(canonicalSummary);
  const idleMinutes = Math.min(
    pcAvailableMinutes,
    Math.max(0, Math.round(Number(canonicalSummary.idle_minutes || canonicalSummary.input_idle_minutes || 0)))
  );
  const missingMinutes = Math.max(0, Math.round(Number(canonicalSummary.missing_minutes || 0)));
  const focusScore = canonicalSummary.focus_score || {};
  const rows = Array.isArray(summary.category_minutes)
    ? summary.category_minutes.filter((row) => row.label !== 'Work')
    : [];
  rows.push({ label: 'Work', minutes: workMinutes });
  rows.sort((left, right) => right.minutes - left.minutes);

  return {
    ...summary,
    activity_visible_minutes: summary.visible_minutes || 0,
    activity_active_minutes: summary.active_minutes || 0,
    activity_passive_candidate_minutes: summary.passive_candidate_minutes || 0,
    activity_input_idle_minutes: summary.input_idle_minutes || 0,
    activity_missing_minutes: summary.missing_minutes || 0,
    work_minutes: workMinutes,
    canonical_coverage: coverage,
    work_source: 'report_cache_canonical',
    official_time_source: canonicalSummary.official_time_source || canonicalSummary.source || 'report_cache',
    pc_available_source: canonicalSummary.pc_available_source || 'report_cache',
    gross_pc_available_minutes: pcAvailableMinutes,
    runtime_available_minutes: canonicalSummary.runtime_available_minutes || 0,
    idle_minutes: idleMinutes,
    input_idle_minutes: idleMinutes,
    missing_minutes: missingMinutes,
    pc_work_minutes: canonicalSummary.pc_work_minutes || focusScore.deep_work_minutes || 0,
    focus_minutes: canonicalSummary.focus_minutes || 0,
    messaging_minutes: canonicalSummary.messaging_minutes || canonicalSummary.pc_messaging_minutes || 0,
    pc_messaging_minutes: canonicalSummary.pc_messaging_minutes || canonicalSummary.messaging_minutes || 0,
    social_minutes: canonicalSummary.social_minutes || 0,
    range_minutes: canonicalSummary.range_minutes || summary.range_minutes,
    activity_events: canonicalSummary.activity_events || canonicalSummary.event_count || summary.activity_events || 0,
    manual_timing_blocks: canonicalSummary.manual_timing_blocks || null,
    manual_timing_minutes: canonicalSummary.manual_timing_minutes || canonicalSummary.manual_timing_blocks?.total_minutes || 0,
    manual_net_added_work_minutes: Number.isFinite(Number(canonicalSummary.manual_net_added_work_minutes))
      ? canonicalSummary.manual_net_added_work_minutes
      : canonicalSummary.manual_timing_blocks?.net_added_minutes || 0,
    work_minutes_breakdown: canonicalSummary.work_minutes_breakdown || null,
    focus_score: canonicalSummary.focus_score || summary.focus_score || null,
    category_minutes: rows
  };
}

function countBy(items, predicate) {
  return items.reduce((sum, item) => sum + (predicate(item) ? 1 : 0), 0);
}

function pickStrongestSurface(surfaces) {
  return surfaces.find((surface) => surface.domain) || surfaces.find((surface) => surface.app) || surfaces[0] || {
    app: '',
    title: '',
    url: '',
    domain: '',
    ocr: '',
    tool: 'Unknown'
  };
}

function buildSurfaceKey(surface = {}) {
  return [surface.app || '', surface.title || '', surface.url || ''].join('|').toLowerCase();
}

function fingerprintText(text) {
  const normalized = String(text || '').toLowerCase().replace(/[0-9]+/g, '#').replace(/\s+/g, ' ').trim().slice(0, 1200);
  let hash = 0;
  for (let index = 0; index < normalized.length; index += 1) {
    hash = ((hash << 5) - hash) + normalized.charCodeAt(index);
    hash |= 0;
  }
  return String(hash);
}

function extractDomain(urlValue) {
  if (!urlValue) return '';
  try {
    return new URL(urlValue).hostname.replace(/^www\./i, '').toLowerCase();
  } catch {
    return '';
  }
}

function extractKnownDomain(text) {
  const matches = Array.from(String(text || '').toLowerCase().matchAll(/\b((?:[a-z0-9-]+\.)+[a-z]{2,})(?:[/?#:]|$)?/gi));
  const domains = matches.map((match) => match[1].replace(/^www\./i, '').toLowerCase()).filter(isLikelyDomain);
  return domains.find((domain) => SOCIAL_DOMAINS.some((pattern) => domainMatches(domain, pattern)))
    || domains.find((domain) => MEETING_DOMAINS.some((pattern) => domainMatches(domain, pattern)))
    || domains.find((domain) => COMMUNICATION_DOMAINS.some((pattern) => domainMatches(domain, pattern)))
    || domains[0]
    || '';
}

function isLikelyDomain(domain) {
  const parts = String(domain || '').split('.');
  const tld = parts[parts.length - 1];
  return VALID_DOMAIN_TLDS.has(tld) && !/\.(exe|js|json|dll|ps1|bat|cmd|zip|png|jpg|jpeg|svg|css|html)$/i.test(domain);
}

function domainMatches(candidate, pattern) {
  return candidate === pattern || candidate.endsWith(`.${pattern}`);
}

function timestampMs(record = {}) {
  return new Date(record.timestamp_start || record.timestamp || record.timestamp_end || 0).getTime();
}

function firstTimestamp(records) {
  return records.length ? records[0].timestamp_start || records[0].timestamp || null : null;
}

function lastTimestamp(records) {
  return records.length ? records[records.length - 1].timestamp_start || records[records.length - 1].timestamp || null : null;
}

function addMinutes(iso, minutes) {
  const date = new Date(iso);
  date.setMinutes(date.getMinutes() + minutes);
  return date.toISOString();
}

function floorMinuteIso(date) {
  const minute = new Date(date);
  minute.setSeconds(0, 0);
  return minute.toISOString();
}

function minuteKeysForInterval(startMs, endMs) {
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
    return [];
  }
  const keys = [];
  const cursor = new Date(startMs);
  cursor.setSeconds(0, 0);
  while (cursor.getTime() < endMs) {
    const minuteStartMs = cursor.getTime();
    if (intervalOverlapMs(minuteStartMs, minuteStartMs + 60000, [{ startMs, endMs }]) >= 30000) {
      keys.push(cursor.toISOString());
    }
    cursor.setTime(cursor.getTime() + 60000);
  }
  return keys;
}

function lowerConfidence(left, right) {
  const order = ['Low', 'Medium', 'High'];
  return order[Math.min(order.indexOf(left), order.indexOf(right))];
}

function mergeLabel(left, right) {
  return unique(String(left || '').split(' / ').concat(String(right || '').split(' / '))).slice(0, 4).join(' / ');
}

function normalizeToolLabel(value) {
  return String(value || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function unique(values) {
  return Array.from(new Set(values.filter(Boolean)));
}

function formatMinutes(minutes) {
  const rounded = Math.max(0, Math.round(Number(minutes) || 0));
  if (rounded >= 60) {
    const hours = Math.floor(rounded / 60);
    const mins = rounded % 60;
    return mins ? `${hours}h ${mins}m` : `${hours}h`;
  }
  return `${rounded}m`;
}

function normalizeIdleIntervals(intervals = []) {
  return (intervals || [])
    .map((interval) => ({
      startMs: new Date(interval.start || interval.start_time || interval.startTime).getTime(),
      endMs: new Date(interval.end || interval.end_time || interval.endTime).getTime()
    }))
    .filter((interval) => Number.isFinite(interval.startMs) && Number.isFinite(interval.endMs) && interval.endMs > interval.startMs);
}

function normalizeFocusIntervals(intervals = [], startTime, endTime) {
  const rangeStartMs = new Date(startTime || 0).getTime();
  const rangeEndMs = new Date(endTime || 0).getTime();
  return (intervals || [])
    .map((interval) => {
      const startMs = Number.isFinite(Number(interval.startMs))
        ? Number(interval.startMs)
        : new Date(interval.start || interval.start_time || interval.startTime).getTime();
      const endMs = Number.isFinite(Number(interval.endMs))
        ? Number(interval.endMs)
        : new Date(interval.end || interval.end_time || interval.endTime).getTime();
      if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
        return null;
      }
      return {
        ...interval,
        startMs: Number.isFinite(rangeStartMs) ? Math.max(startMs, rangeStartMs) : startMs,
        endMs: Number.isFinite(rangeEndMs) ? Math.min(endMs, rangeEndMs) : endMs,
        process_name: String(interval.process_name || '').trim(),
        window_title: String(interval.window_title || '').trim()
      };
    })
    .filter((interval) => interval && interval.endMs > interval.startMs);
}

function buildFocusBackedRecords(focusIntervals = [], capturedRecords = [], options = {}) {
  const limit = Math.max(0, Math.round(Number(options.limit || 120)));
  return focusIntervals
    .filter((interval) => options.includeShort || interval.endMs - interval.startMs >= 30000)
    .filter((interval) => (interval.process_name || interval.window_title) && String(interval.hwnd || '1') !== '0')
    .filter((interval) => !hasMatchingCapturedRecord(interval, capturedRecords))
    .slice(0, limit)
    .map((interval, index) => ({
      id: `focus-report-${interval.hwnd || 'window'}-${interval.startMs}-${index}`,
      source: 'windows_focus_evidence',
      activity_type: 'focus_evidence',
      app_name: interval.process_name || 'Unknown app',
      window_title: interval.window_title || interval.process_name || 'Active window',
      timestamp_start: new Date(interval.startMs).toISOString(),
      timestamp_end: new Date(interval.endMs).toISOString(),
      duration_ms_estimate: interval.endMs - interval.startMs,
      focus_evidence: true
    }));
}

function allocateRoundedWorkSummaryMinutes(rows = [], targetMinutes = 0) {
  const target = Math.max(0, Math.round(Number(targetMinutes || 0)));
  const totalRawMinutes = rows.reduce((sum, row) => (
    sum + Math.max(0, Number(row.duration_ms || 0) / 60000)
  ), 0);
  const allocated = rows.map((row, index) => {
    const rawMinutes = Math.max(0, Number(row.duration_ms || 0) / 60000);
    const scaledMinutes = totalRawMinutes > 0
      ? rawMinutes * (target / totalRawMinutes)
      : 0;
    const baseMinutes = Math.floor(scaledMinutes);
    return {
      row,
      index,
      rawMinutes: scaledMinutes,
      minutes: baseMinutes,
      remainder: scaledMinutes - baseMinutes
    };
  });
  let remaining = Math.max(0, target - allocated.reduce((sum, item) => sum + item.minutes, 0));
  allocated
    .slice()
    .sort((left, right) => Number(right.remainder || 0) - Number(left.remainder || 0)
      || Number(right.rawMinutes || 0) - Number(left.rawMinutes || 0)
      || left.index - right.index)
    .forEach((item) => {
      if (remaining <= 0 || item.rawMinutes <= 0) {
        return;
      }
      item.minutes += 1;
      remaining -= 1;
    });
  return allocated.map((item) => ({
    ...item.row,
    minutes: item.minutes,
    duration_minutes: item.minutes
  }));
}

function filterRecordsContradictedByFocus(records = [], focusIntervals = []) {
  if (!focusIntervals.length) {
    return records;
  }
  return records.filter((record) => {
    if (record.source === 'manual' || record.activity_type === 'manual') {
      return true;
    }
    const recordMs = timestampMs(record);
    if (!Number.isFinite(recordMs)) {
      return true;
    }
    const overlapping = focusIntervals.filter((interval) => recordMs >= interval.startMs && recordMs < interval.endMs);
    if (!overlapping.length) {
      return true;
    }
    return overlapping.some((interval) => recordMatchesFocusInterval(record, interval));
  });
}

function hasMatchingCapturedRecord(interval = {}, capturedRecords = []) {
  const intervalMs = interval.endMs - interval.startMs;
  const matchingMs = capturedRecords.reduce((sum, record) => {
    if (!recordMatchesFocusInterval(record, interval)) {
      return sum;
    }
    const recordStartMs = new Date(record.timestamp_start || record.timestamp).getTime();
    if (!Number.isFinite(recordStartMs)) {
      return sum;
    }
    const explicitEndMs = record.timestamp_end ? new Date(record.timestamp_end).getTime() : Number.NaN;
    const recordEndMs = Number.isFinite(explicitEndMs) && explicitEndMs > recordStartMs
      ? explicitEndMs
      : recordStartMs + Math.max(30000, Number(record.duration_ms_estimate || 30000));
    return sum + Math.max(0, Math.min(interval.endMs, recordEndMs) - Math.max(interval.startMs, recordStartMs));
  }, 0);
  return matchingMs >= Math.min(intervalMs * 0.5, 30000);
}

function recordMatchesFocusInterval(record = {}, interval = {}) {
  const recordApp = normalizeProcessName(record.app_name);
  const focusApp = normalizeProcessName(interval.process_name);
  if (!recordApp || !focusApp || recordApp !== focusApp) {
    return false;
  }
  const recordTitle = normalizeComparableTitle(record.window_title || record.window_name || record.url_if_available || '');
  const focusTitle = normalizeComparableTitle(interval.window_title || '');
  if (!recordTitle || !focusTitle) {
    return true;
  }
  return titlesAreSimilar(recordTitle, focusTitle);
}

function recordOverlapsFocusInterval(record = {}, focusIntervals = []) {
  const recordMs = timestampMs(record);
  if (!Number.isFinite(recordMs)) {
    return false;
  }
  return focusIntervals.some((interval) => recordMs >= interval.startMs && recordMs < interval.endMs);
}

function isFocusBackedRecord(record = {}) {
  return record.source === 'windows_focus_evidence' || record.activity_type === 'focus_evidence' || record.focus_evidence === true;
}

function normalizeProcessName(value) {
  const text = String(value || '').trim().toLowerCase();
  if (!text) {
    return '';
  }
  const fileName = text.split(/[\\/]/).pop();
  return fileName.endsWith('.exe') ? fileName : `${fileName}.exe`;
}

function normalizeComparableTitle(value) {
  return normalizeWindowTitle(value)
    .toLowerCase()
    .replace(/https?:\/\/\S+/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\b(?:google chrome|microsoft edge|mozilla firefox|visual studio code|excel|word|powerpoint)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 180);
}

function titlesAreSimilar(left, right) {
  if (!left || !right) {
    return false;
  }
  if (left === right || left.includes(right) || right.includes(left)) {
    return true;
  }
  const leftTokens = titleTokens(left);
  const rightTokens = titleTokens(right);
  if (!leftTokens.length || !rightTokens.length) {
    return false;
  }
  const rightSet = new Set(rightTokens);
  const shared = leftTokens.filter((token) => rightSet.has(token)).length;
  return shared >= Math.min(3, Math.max(1, Math.min(leftTokens.length, rightTokens.length)));
}

function titleTokens(value) {
  return String(value || '')
    .split(/\s+/)
    .filter((token) => token.length >= 3)
    .slice(0, 24);
}

function displayAppName(value) {
  const text = String(value || '').trim();
  if (!text) {
    return 'Unknown app';
  }
  const fileName = text.split(/[\\/]/).pop().trim();
  const normalized = fileName.toLowerCase().replace(/\.exe$/i, '');
  const knownNames = {
    chrome: 'Google Chrome',
    msedge: 'Microsoft Edge',
    firefox: 'Mozilla Firefox',
    code: 'Visual Studio Code',
    excel: 'Microsoft Excel',
    winword: 'Microsoft Word',
    powerpnt: 'Microsoft PowerPoint',
    outlook: 'Microsoft Outlook',
    teams: 'Microsoft Teams',
    notepad: 'Notepad'
  };
  if (knownNames[normalized]) {
    return knownNames[normalized];
  }
  return fileName || text || 'Unknown app';
}

function workSummaryRecordScore(record = {}) {
  return (isFocusBackedRecord(record) ? 0 : 10) +
    (record.url_if_available || record.browser_url ? 5 : 0) +
    (record.window_title || record.window_name ? 3 : 0) +
    (record.app_name ? 1 : 0);
}

function intervalOverlapMs(startMs, endMs, intervals = []) {
  return intervals.reduce((total, interval) => {
    const start = Math.max(startMs, interval.startMs);
    const end = Math.min(endMs, interval.endMs);
    return total + Math.max(0, end - start);
  }, 0);
}

module.exports = {
  ActivityReportService,
  extractChatContact,
  extractDocumentName
};
