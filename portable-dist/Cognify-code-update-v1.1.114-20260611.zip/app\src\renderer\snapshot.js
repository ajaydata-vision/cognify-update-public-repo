const shell = document.getElementById('shell');
const closeButton = document.getElementById('close');
const openPanelButton = document.getElementById('openPanel');
const notesPanelButton = document.getElementById('notesPanel');
const healthPanelButton = document.getElementById('healthPanel');
const healthRing = document.getElementById('healthRing');
const healthScore = document.getElementById('healthScore');
const statusTitle = document.getElementById('statusTitle');
const statusCopy = document.getElementById('statusCopy');
const eventCount = document.getElementById('eventCount');
const appCount = document.getElementById('appCount');
const verifiedTillValue = document.getElementById('verifiedTillValue');
const verifiedTillNote = document.getElementById('verifiedTillNote');
const gapHoursNotice = document.getElementById('gapHoursNotice');
const activityList = document.getElementById('activityList');
const updatedAt = document.getElementById('updatedAt');
const appVersion = document.getElementById('appVersion');
const workScoreTile = document.getElementById('workScoreTile');
const workMode = document.getElementById('workMode');
const truthHint = document.getElementById('truthHint');

let workScoreIndex = 0;
let latestWorkScoreState = null;
let refreshInFlight = false;
let pendingForceRefresh = false;
const WORK_SCORE_ROTATION_INTERVAL_MS = 30000;
const SNAPSHOT_REFRESH_INTERVAL_MS = 120000;
const SNAPSHOT_CATEGORY_REFRESH_INTERVAL_MS = 5 * 60 * 1000;
let lastCategoryRefreshAt = 0;
let cachedCategorySnapshot = null;
let cachedDiagnostics = null;
let refreshActivated = false;

async function perfLog(label, startedAt, extra = {}) {
  const durationMs = Math.round(performance.now() - startedAt);
  if (durationMs < 750) {
    return;
  }
  try {
    await window.assistantApi.debugLog({
      event: 'snapshot_perf_timing',
      payload: {
        label,
        duration_ms: durationMs,
        ...extra
      }
    });
  } catch {
    // Ignore debug logging failures.
  }
}

async function timedCall(label, action) {
  const startedAt = performance.now();
  try {
    const result = await action();
    await perfLog(label, startedAt, { ok: true });
    return result;
  } catch (error) {
    await perfLog(label, startedAt, { ok: false, error: error?.message || String(error) });
    throw error;
  }
}

function withTimeout(promise, timeoutMs, fallback) {
  let timeoutId;
  return Promise.race([
    promise,
    new Promise((resolve) => {
      timeoutId = setTimeout(() => resolve(fallback), timeoutMs);
    })
  ]).finally(() => clearTimeout(timeoutId));
}

const fills = {
  work: document.getElementById('workFill'),
  meeting: document.getElementById('meetingFill'),
  social: document.getElementById('socialFill'),
  idle: document.getElementById('idleFill')
};

const values = {
  work: document.getElementById('workVal'),
  meeting: document.getElementById('meetingVal'),
  social: document.getElementById('socialVal'),
  idle: document.getElementById('idleVal')
};

function unique(valuesList = []) {
  return [...new Set(valuesList.filter(Boolean))];
}

function formatMinutes(minutes) {
  const rounded = Math.max(0, Math.round(Number(minutes) || 0));
  if (rounded >= 60) {
    const hours = Math.floor(rounded / 60);
    const mins = rounded % 60;
    return mins ? `${hours}h ${mins}m` : `${hours}h`;
  }
  return `${rounded}m`;
}

function formatClock(iso) {
  const date = new Date(iso || 0);
  if (!Number.isFinite(date.getTime())) {
    return '--';
  }
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function formatHourToken(date) {
  return date.toLocaleTimeString([], { hour: 'numeric' }).replace(/\s/g, '');
}

function formatHourSlot(startIso) {
  const start = new Date(startIso || 0);
  if (!Number.isFinite(start.getTime())) {
    return '';
  }
  const end = new Date(start);
  end.setHours(end.getHours() + 1);
  return `${formatHourToken(start)}-${formatHourToken(end)}`;
}

function todayStart() {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  return start;
}

function timestampMs(record = {}) {
  return new Date(record.timestamp_start || record.timestamp || record.timestamp_end || 0).getTime();
}

function hostname(url) {
  try {
    return new URL(url).hostname.replace(/^www\./i, '');
  } catch {
    return '';
  }
}

function recordText(record = {}) {
  return [
    record.app_name,
    record.window_title,
    record.ocr_text,
    record.url_if_available
  ].map((value) => String(value || '').toLowerCase()).join(' ');
}

function isCognifyUiRecord(record = {}) {
  const app = String(record.app_name || '').toLowerCase();
  const title = String(record.window_title || '').toLowerCase();
  const text = recordText(record);
  return app === 'electron.exe' && (
    title.includes('cognify') ||
    text.includes('/companion-agent/src/renderer/snapshot.html') ||
    text.includes('/companion-agent/src/renderer/panel.html') ||
    text.includes('live snapshot') ||
    text.includes('everything is in place')
  );
}

function isTransientFocusRecord(record = {}) {
  const app = String(record.app_name || '').toLowerCase();
  const title = String(record.window_title || '').toLowerCase();
  const text = recordText(record);
  return (
    title === 'task switching' ||
    app === 'git-credential-manager.exe' ||
    text.includes('select an account') ||
    text.includes('git-credential-manager.exe')
  );
}

function isRelevantFocusRecord(record = {}) {
  const app = String(record.app_name || '').toLowerCase();
  return app &&
    app !== 'system process' &&
    !isCognifyUiRecord(record) &&
    !isTransientFocusRecord(record);
}

function classifySnapshotRecord(record = {}) {
  const text = [
    record.app_name,
    record.window_title,
    record.url_if_available,
    record.ocr_text
  ].filter(Boolean).join(' ').toLowerCase();

  if (/\b(teams|zoom|meet|slack|whatsapp|calendar|outlook)\b/.test(text)) {
    return 'meeting';
  }
  if (/\b(youtube|instagram|facebook|twitter|x\.com|reddit|netflix)\b/.test(text)) {
    return 'social';
  }
  return 'work';
}

function recordMinutes(record = {}, startOfDay = todayStart()) {
  const startMs = Math.max(timestampMs(record), startOfDay.getTime());
  const endMs = new Date(record.timestamp_end || 0).getTime();
  if (Number.isFinite(endMs) && endMs > startMs) {
    return Math.max(1 / 6, Math.min(30, (endMs - startMs) / 60000));
  }
  return 1 / 6;
}

function hasSummaryData(summary = {}) {
  const metricKeys = [
    'gross_pc_available_minutes',
    'active_minutes',
    'estimated_active_minutes',
    'work_minutes',
    'focus_minutes',
    'messaging_minutes',
    'social_minutes',
    'idle_minutes'
  ];
  return Boolean(
    metricKeys.some((key) => Number(summary[key] || 0) > 0) ||
    Object.values(summary.classified_minutes || {}).some((value) => Number(value || 0) > 0)
  );
}

function estimateSummaryFromRecords(records = [], startOfDay = todayStart()) {
  const classified = { work: 0, meeting: 0, social: 0, idle: 0 };
  records.filter(isRelevantFocusRecord).forEach((record) => {
    const category = classifySnapshotRecord(record);
    classified[category] += recordMinutes(record, startOfDay);
  });

  Object.keys(classified).forEach((key) => {
    classified[key] = Math.round(classified[key]);
  });
  const activeMinutes = classified.work + classified.meeting + classified.social;
  return {
    active_minutes: activeMinutes,
    estimated_active_minutes: activeMinutes,
    focus_minutes: classified.work,
    messaging_minutes: classified.meeting,
    social_minutes: classified.social,
    idle_minutes: classified.idle,
    work_minutes: classified.work,
    classified_minutes: classified,
    focus_score: {
      deep_work_minutes: classified.work,
      total_active_minutes: activeMinutes,
      score_percent: activeMinutes ? Math.round((classified.work / activeMinutes) * 100) : 0
    }
  };
}

function estimateBucketsFromSummary(summary = {}) {
  const elapsedTodayMinutes = Math.max(0, Math.ceil((Date.now() - todayStart().getTime()) / 60000));
  const availableMinutes = Math.min(
    elapsedTodayMinutes,
    canonicalPcAvailableMinutes(summary)
  );
  const idleMinutes = Math.min(
    canonicalIdleMinutes(summary),
    availableMinutes
  );
  const classified = summary.classified_minutes || {};
  const officialWorkMinutes = canonicalWorkMinutes(summary);
  const messagingMinutes = canonicalMessagingMinutes(summary);
  const rawBuckets = {
    work: Math.max(0, officialWorkMinutes - messagingMinutes),
    meeting: messagingMinutes,
    social: Math.max(0, Math.round(Number(summary.social_minutes ?? classified.social ?? 0)))
  };
  const rawActive = rawBuckets.work + rawBuckets.meeting + rawBuckets.social;
  const nonIdleAvailable = Math.max(0, availableMinutes - idleMinutes);
  const displayActiveLimit = Math.max(nonIdleAvailable, Math.min(availableMinutes, officialWorkMinutes));
  const buckets = { work: 0, meeting: 0, social: 0, idle: idleMinutes };

  if (rawActive <= displayActiveLimit) {
    buckets.work = rawBuckets.work;
    buckets.meeting = rawBuckets.meeting;
    buckets.social = rawBuckets.social;
    return buckets;
  }

  let assigned = 0;
  Object.entries(rawBuckets).forEach(([key, value]) => {
    buckets[key] = Math.floor((value / rawActive) * displayActiveLimit);
    assigned += buckets[key];
  });

  const remainderOrder = Object.entries(rawBuckets)
    .map(([key, value]) => ({
      key,
      remainder: ((value / rawActive) * displayActiveLimit) - Math.floor((value / rawActive) * displayActiveLimit)
    }))
    .sort((left, right) => right.remainder - left.remainder);

  for (const entry of remainderOrder) {
    if (assigned >= displayActiveLimit) {
      break;
    }
    buckets[entry.key] += 1;
    assigned += 1;
  }

  return buckets;
}

function canonicalWorkMinutes(summary = {}) {
  const available = canonicalPcAvailableMinutes(summary);
  const idle = canonicalIdleMinutes(summary);
  const manualNet = canonicalManualAddedMinutes(summary);
  // When PC Available is present, always recompute from the product formula and ignore stale work_minutes.
  if (hasPcAvailableEvidence(summary)) {
    const idleDeducted = Math.min(available, idle);
    const manualRestored = Math.min(idleDeducted, manualNet);
    return Math.min(available, Math.max(0, Math.round(available - idleDeducted + manualRestored)));
  }
  if (Number.isFinite(Number(summary.work_minutes))) {
    return Math.max(0, Math.round(Number(summary.work_minutes || 0)));
  }
  if (Number.isFinite(Number(summary.work_minutes_breakdown?.total_work_minutes))) {
    return Math.max(0, Math.round(Number(summary.work_minutes_breakdown.total_work_minutes || 0)));
  }
  const idleDeducted = Math.min(available, idle);
  const manualRestored = Math.min(idleDeducted, manualNet);
  return Math.min(available, Math.max(0, Math.round(available - idleDeducted + manualRestored)));
}

function canonicalPcAvailableMinutes(summary = {}) {
  const active = canonicalActiveMinutes(summary);
  const idle = canonicalIdleMinutes(summary);
  const captured = Math.max(0, Math.round(Number(summary.captured_minutes_estimate || 0)));
  const range = finiteNumber(summary.range_minutes);
  const localEvidence = clampMinutes(Math.max(active + idle, captured), range);
  const runtime = finiteNumber(summary.runtime_available_minutes);
  const explicit = finiteNumber(
    summary.gross_pc_available_minutes,
    summary.work_minutes_breakdown?.gross_pc_available_minutes
  );

  if (explicit !== null) {
    const trustedExplicit = Boolean(summary.pc_available_source) ||
      (runtime !== null && runtime > 0) ||
      summary.source === 'cognify-runtime-availability' ||
      summary.official_time_source === 'cognify-runtime-availability';
    return trustedExplicit
      ? clampMinutes(explicit, range)
      : clampMinutes(Math.min(explicit, localEvidence), range);
  }
  if (runtime !== null && runtime > 0) {
    return clampMinutes(runtime, range);
  }
  return localEvidence;
}

function hasPcAvailableEvidence(summary = {}) {
  return Number.isFinite(Number(summary.gross_pc_available_minutes)) ||
    Number.isFinite(Number(summary.work_minutes_breakdown?.gross_pc_available_minutes)) ||
    Number(summary.runtime_available_minutes || 0) > 0;
}

function finiteNumber(...values) {
  for (const value of values) {
    if (value === null || value === undefined || value === '') {
      continue;
    }
    const number = Number(value);
    if (Number.isFinite(number)) {
      return number;
    }
  }
  return null;
}

function clampMinutes(minutes, rangeMinutes = null) {
  const value = Math.max(0, Math.round(Number(minutes) || 0));
  const range = Number(rangeMinutes);
  if (!Number.isFinite(range) || range <= 0) {
    return value;
  }
  return Math.min(Math.max(0, Math.round(range)), value);
}

function canonicalActiveMinutes(summary = {}) {
  const value = Number.isFinite(Number(summary.active_minutes))
    ? Number(summary.active_minutes)
    : Number(summary.estimated_active_minutes || 0);
  return Math.max(0, Math.round(value));
}

function canonicalFocusMinutes(summary = {}) {
  const classified = summary.classified_minutes || {};
  const value = Number.isFinite(Number(summary.focus_minutes))
    ? Number(summary.focus_minutes)
    : (Number.isFinite(Number(summary.focus_score?.deep_work_minutes))
      ? Number(summary.focus_score.deep_work_minutes)
      : Number(summary.pc_work_minutes || classified.work || 0));
  return Math.max(0, Math.round(value));
}

function canonicalMessagingMinutes(summary = {}) {
  const classified = summary.classified_minutes || {};
  const manualMeeting = Number(summary.manual_timing_blocks?.meeting_minutes || summary.manual_timing_blocks?.net_added_meeting_minutes || 0);
  const value = Number.isFinite(Number(summary.messaging_minutes))
    ? Number(summary.messaging_minutes)
    : Number(classified.meeting || 0) + manualMeeting;
  return Math.max(0, Math.round(value));
}

function canonicalIdleMinutes(summary = {}) {
  const value = Number.isFinite(Number(summary.idle_minutes))
    ? Number(summary.idle_minutes)
    : Number(summary.input_idle_minutes || 0);
  return Math.max(0, Math.round(value));
}

function canonicalManualAddedMinutes(summary = {}) {
  const manual = summary.manual_timing_blocks || {};
  const value = Number.isFinite(Number(summary.manual_net_added_work_minutes))
    ? Number(summary.manual_net_added_work_minutes)
    : Number(manual.net_added_minutes || manual.net_added_work_minutes || 0) +
      Number(manual.net_added_meeting_minutes || 0);
  return Math.min(canonicalIdleMinutes(summary), Math.max(0, Math.round(value)));
}

function openWorkBreakdownModal() {
  if (typeof window.assistantApi.openWorkHoursPanel === 'function') {
    window.assistantApi.openWorkHoursPanel().catch(() => {});
  }
}

function renderBars(buckets) {
  const total = Math.max(1, buckets.work + buckets.meeting + buckets.social + buckets.idle);
  Object.entries(buckets).forEach(([key, value]) => {
    fills[key].style.width = `${Math.round((value / total) * 100)}%`;
    values[key].textContent = formatMinutes(value);
  });
}

function renderWorkScore(summary = {}) {
  const elapsedTodayMinutes = Math.max(1, Math.ceil((Date.now() - todayStart().getTime()) / 60000));
  const availableMinutes = canonicalPcAvailableMinutes(summary);
  const workMinutes = canonicalWorkMinutes(summary);
  const focusMinutes = canonicalFocusMinutes(summary);
  const modes = [
    {
      label: 'Work Hours',
      value: formatMinutes(workMinutes),
      width: Math.round((workMinutes / elapsedTodayMinutes) * 100)
    },
    {
      label: 'PC Available',
      value: formatMinutes(availableMinutes),
      width: Math.round((availableMinutes / elapsedTodayMinutes) * 100)
    },
    {
      label: 'Focus Hours',
      value: formatMinutes(focusMinutes),
      width: availableMinutes > 0 ? Math.round((focusMinutes / availableMinutes) * 100) : 0
    }
  ];
  const mode = modes[workScoreIndex % modes.length];

  workMode.textContent = mode.label;
  values.work.textContent = mode.value;
  workScoreTile.title = `${mode.label}. Work is official work time; PC Available is Cognify-observed PC-on time before idle deduction; Focus is strict work-classified activity.`;
  workMode.classList.remove('swap');
  values.work.classList.remove('swap');
  window.requestAnimationFrame(() => {
    workMode.classList.add('swap');
    values.work.classList.add('swap');
  });
  latestWorkScoreState = { summary };
}

function renderActivities(records = []) {
  const rows = records
    .slice(-5)
    .reverse()
    .map((record) => {
      const source = hostname(record.url_if_available) || record.app_name || 'Unknown';
      const title = record.window_title || record.ocr_text || 'Captured activity';
      return `
        <div class="activity">
          <div class="activity-title">${escapeHtml(title)}</div>
          <div class="activity-meta">${escapeHtml(source)}</div>
        </div>
      `;
    });

  activityList.innerHTML = rows.length
    ? rows.join('')
    : '<div class="activity"><div class="activity-title">No recent focus captured</div><div class="activity-meta">Keep Cognify running for a few minutes</div></div>';
}

function recordsFromActivitySummary(summary = {}) {
  const textRecords = (summary.recent_texts || summary.key_texts || []).map((item) => ({
    timestamp_start: item.timestamp,
    app_name: item.app_name,
    window_title: item.window_name || item.text,
    url_if_available: item.browser_url || item.url_if_available || '',
    ocr_text: item.text
  }));

  const windowRecords = (summary.windows || []).map((item) => ({
    timestamp_start: item.last_seen || item.first_seen || summary.time_range?.end,
    app_name: item.app_name,
    window_title: item.window_name || item.app_name || 'Captured activity',
    url_if_available: item.browser_url || '',
    ocr_text: item.window_name || item.app_name || ''
  }));

  const appRecords = (summary.apps || []).map((item) => ({
    timestamp_start: item.last_seen || item.first_seen || summary.time_range?.end,
    app_name: item.name,
    window_title: item.name || 'Captured app activity',
    ocr_text: item.name || ''
  }));

  return [...textRecords, ...windowRecords, ...appRecords]
    .filter((record) => record.timestamp_start)
    .sort((left, right) => timestampMs(left) - timestampMs(right));
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderDiagnostics(diagnostics = {}) {
  if (!diagnostics || !Object.keys(diagnostics).length) {
    return;
  }
  const healthItems = [
    diagnostics.localhost,
    diagnostics.screenpipe,
    diagnostics.screenpipe_ownership,
    diagnostics.ffmpeg,
    diagnostics.focus_events,
    diagnostics.windows_focus,
    diagnostics.system_idle,
    diagnostics.listening,
    diagnostics.screenpipe_memory,
    diagnostics.recording
  ].filter(Boolean);
  const runtimeItems = healthItems.filter((item) => !item.informational);
  const okCount = runtimeItems.filter((item) => item.ok).length;
  const healthPercent = runtimeItems.length ? Math.round((okCount / runtimeItems.length) * 100) : 100;

  shell.classList.toggle('bad', healthPercent < 100);
  appVersion.textContent = `v${diagnostics.version || '--'}`;
  healthRing.style.setProperty('--health', `${Math.round((healthPercent / 100) * 360)}deg`);
  healthScore.textContent = `${healthPercent}%`;
  statusTitle.textContent = healthPercent === 100 ? 'Everything is in place' : 'Needs attention';
  statusCopy.textContent = healthPercent === 100
    ? 'Capture, API, ffmpeg, listening preference, and recording are available.'
    : (runtimeItems.find((item) => !item.ok)?.detail || 'Runtime check is incomplete.');
}

function renderTruthStatus(truth = {}) {
  if (!truthHint) {
    return;
  }
  const health = truth.health || {};
  const cache = truth.cache || {};
  const current = truth.current_hour || {};
  const status = health.status || 'checking';
  const pending = Number(cache.pending_hours?.length || 0);
  const gaps = Number(cache.gap_hours?.length || 0);
  const detail = health.detail || 'Reading capture state...';
  const slot = formatHourSlot(current.start_time);
  const verified = truth.verified_until ? formatClock(truth.verified_until) : '';
  let label = slot ? `Calc ${slot}` : 'Calculating';
  if (gaps) {
    label = `${gaps} gap${gaps === 1 ? '' : 's'}`;
  } else if (status === 'ok') {
    label = verified ? `OK ${verified}` : 'Verified';
  } else if (pending) {
    label = slot ? `Calc ${slot}` : `${pending} pending`;
  }
  truthHint.className = `truth-hint ${status}`;
  truthHint.textContent = label;
  truthHint.title = [health.label || 'Live truth', detail, verified ? `Verified through ${verified}` : ''].filter(Boolean).join(' | ');
}

function renderVerifiedTillMetric(truth = {}) {
  if (!verifiedTillValue || !verifiedTillNote) {
    return;
  }

  const cache = truth.cache || {};
  const health = truth.health || {};
  const pending = Number(cache.pending_hours?.length || 0);
  const gaps = Number(cache.gap_hours?.length || 0);
  const missing = Number(cache.missing_hours?.length || 0);
  const verified = truth.verified_until ? formatClock(truth.verified_until) : '--';
  let verifiedNote = truth.verified_until ? 'Closed hours OK' : 'Awaiting close';
  if (gaps) {
    verifiedNote = `${gaps} gap${gaps === 1 ? '' : 's'}`;
  } else if (pending) {
    verifiedNote = `${pending} pending`;
  } else if (missing) {
    verifiedNote = `${missing} missing`;
  }

  verifiedTillValue.textContent = verified;
  verifiedTillNote.textContent = verifiedNote;
  verifiedTillNote.title = [
    health.label || '',
    health.detail || '',
    truth.verified_until ? `Verified through ${verified}` : ''
  ].filter(Boolean).join(' | ');

  if (gapHoursNotice) {
    if (gaps > 0) {
      gapHoursNotice.textContent = `${gaps} gap hour${gaps === 1 ? '' : 's'} not included in total`;
      gapHoursNotice.style.display = '';
    } else {
      gapHoursNotice.style.display = 'none';
    }
  }
}

async function refresh({ force = false } = {}) {
  if (!refreshActivated && !force) {
    return;
  }
  if (document.hidden && !force) {
    return;
  }
  if (refreshInFlight) {
    pendingForceRefresh = pendingForceRefresh || Boolean(force);
    return;
  }

  refreshInFlight = true;
  const refreshStartedAt = performance.now();
  try {
    const startOfDay = todayStart();
    const hoursSinceDayStart = Math.max(1 / 60, (Date.now() - startOfDay.getTime()) / 3600000);
    const options = { force: Boolean(force), sync: Boolean(force), passive: !force };
    const shouldRefreshCategory = Boolean(force) ||
      !cachedCategorySnapshot ||
      (Date.now() - lastCategoryRefreshAt) >= SNAPSHOT_CATEGORY_REFRESH_INTERVAL_MS;
    const diagnosticsPromise = timedCall('snapshot.getDiagnostics', () => window.assistantApi.getDiagnostics(options))
      .then((diagnostics) => {
        cachedDiagnostics = diagnostics || {};
        renderDiagnostics(cachedDiagnostics);
        return cachedDiagnostics;
      })
      .catch(() => cachedDiagnostics || {});
    renderDiagnostics(cachedDiagnostics);

    const timeoutMs = force ? 30000 : 5000;
    const [categorySnapshotResult, liveTruthResult, activitySummary] = await Promise.all([
      shouldRefreshCategory
        ? withTimeout(timedCall('snapshot.getTodayCategorySnapshot', () => window.assistantApi.getTodayCategorySnapshot({
          force: Boolean(force),
          sync: Boolean(force),
          passive: !force
        })).catch(() => null), timeoutMs, cachedCategorySnapshot)
        : Promise.resolve(cachedCategorySnapshot),
      typeof window.assistantApi.getLiveDayTruth === 'function'
        ? withTimeout(timedCall('snapshot.getLiveDayTruth', () => window.assistantApi.getLiveDayTruth()).catch(() => null), 1500, null)
        : Promise.resolve(null),
      withTimeout(timedCall('snapshot.getActivitySummary', () => window.assistantApi.getActivitySummary({
        startTime: startOfDay.toISOString(),
        endTime: new Date().toISOString(),
        passive: !force,
        force: Boolean(force)
      })).catch(() => null), timeoutMs, null)
    ]);
    if (shouldRefreshCategory && categorySnapshotResult?.summary) {
      cachedCategorySnapshot = categorySnapshotResult;
      lastCategoryRefreshAt = Date.now();
    }
    const categorySnapshot = categorySnapshotResult || cachedCategorySnapshot || {};

    const summaryRecords = activitySummary ? recordsFromActivitySummary(activitySummary) : [];
    const records = summaryRecords.length ? summaryRecords : (await withTimeout(
      timedCall('snapshot.getRecentActivityFallback', () => (
        window.assistantApi.getRecentActivity(hoursSinceDayStart, { sync: false })
      )).catch(() => []),
      force ? 10000 : 3000,
      []
    ));
    const visibleRecords = (records || []).filter((record) => (
      isRelevantFocusRecord(record) &&
      timestampMs(record) >= startOfDay.getTime()
    ));
    const apps = unique(visibleRecords.map((record) => record.app_name));

    eventCount.textContent = String(visibleRecords.length);
    appCount.textContent = String(apps.length);
    updatedAt.textContent = new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

    const liveTruth = liveTruthResult || {};
    renderTruthStatus(liveTruth);
    renderVerifiedTillMetric(liveTruth);
    const selectedSummary = hasSummaryData(liveTruth.summary)
      ? liveTruth.summary
      : (hasSummaryData(categorySnapshot.summary)
        ? categorySnapshot.summary
        : estimateSummaryFromRecords(visibleRecords, startOfDay));
    const summary = {
      ...(categorySnapshot.summary || {}),
      ...(selectedSummary || {}),
      app_timeline: selectedSummary?.app_timeline || categorySnapshot.summary?.app_timeline || [],
      manual_timing_blocks: selectedSummary?.manual_timing_blocks || categorySnapshot.summary?.manual_timing_blocks || {}
    };
    const buckets = estimateBucketsFromSummary(summary);
    renderBars(buckets);
    renderWorkScore(summary);
    if (categorySnapshot.cache && categorySnapshot.cache.complete === false) {
      workScoreTile.title = `${workScoreTile.title} Category cache is backfilling ${categorySnapshot.cache.missing_hours?.length || 0} earlier hour(s).`;
    }
    renderActivities(visibleRecords);
    await perfLog('snapshot.refresh.total', refreshStartedAt, {
      records: visibleRecords.length,
      apps: apps.length,
      category_cache_hours: categorySnapshot.cache?.hour_count || 0,
      category_cache_complete: Boolean(categorySnapshot.cache?.complete),
      category_missing_hours: categorySnapshot.cache?.missing_hours || [],
      truth_status: liveTruth.health?.status || null,
      truth_pending_hours: liveTruth.cache?.pending_hours?.length || 0,
      truth_gap_hours: liveTruth.cache?.gap_hours?.length || 0,
      force: Boolean(force),
      category_refresh: shouldRefreshCategory
    });
    diagnosticsPromise.catch(() => {});
  } finally {
    refreshInFlight = false;
    if (pendingForceRefresh && refreshActivated) {
      pendingForceRefresh = false;
      refresh({ force: true });
    }
  }
}

closeButton.addEventListener('click', () => {
  window.assistantApi.hideSnapshot();
});

openPanelButton.addEventListener('click', () => {
  window.assistantApi.openPanel();
});

healthPanelButton.addEventListener('click', () => {
  window.assistantApi.openHealthPanel();
});

notesPanelButton.addEventListener('click', () => {
  window.assistantApi.openNotesPanel();
});

workScoreTile?.addEventListener('click', () => {
  openWorkBreakdownModal();
});

workScoreTile?.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    openWorkBreakdownModal();
  }
});

setInterval(() => {
  workScoreIndex = (workScoreIndex + 1) % 3;
  if (latestWorkScoreState) {
    renderWorkScore(latestWorkScoreState.summary);
  }
}, WORK_SCORE_ROTATION_INTERVAL_MS);
function activateRefresh(options = {}) {
  refreshActivated = true;
  refresh(options);
}

function deactivateRefresh() {
  refreshActivated = false;
  pendingForceRefresh = false;
}

if (typeof window.assistantApi.onSnapshotVisible === 'function') {
  window.assistantApi.onSnapshotVisible(() => activateRefresh());
}

if (typeof window.assistantApi.onSnapshotHidden === 'function') {
  window.assistantApi.onSnapshotHidden(() => deactivateRefresh());
}

window.addEventListener('focus', () => activateRefresh());
document.addEventListener('visibilitychange', () => {
  const shine = document.querySelector('.shine');
  if (document.hidden) {
    deactivateRefresh();
    if (shine) shine.style.animationPlayState = 'paused';
  } else {
    activateRefresh();
    if (shine) shine.style.animationPlayState = 'running';
  }
});

// Resume shine animation if window is already visible on load
if (!document.hidden) {
  const shine = document.querySelector('.shine');
  if (shine) shine.style.animationPlayState = 'running';
}

setInterval(() => {
  if (refreshActivated && !document.hidden) {
    refresh();
  }
}, SNAPSHOT_REFRESH_INTERVAL_MS);
