# Screenpipe Raw Retention And Day Finalization Plan

## Goal

Keep Cognify responsive during all-day use by making Screenpipe raw capture data a short-lived safety buffer, while Cognify's normalized activity store remains the durable evidence source for reports, HOD drafts, weekly reviews, role detection, and audit behavior.

The target design is:

- Screenpipe raw DB/media: short retention, default 2 days.
- Cognify normalized activity store: evidence retention, default 10 days.
- Report cache: derived summaries retained with Cognify evidence.
- Runtime hot path: current day/current hour only; previous days are cached/local reads.

## Current State

Today one setting, `retentionDays`, does two jobs:

- `src/main.js` passes `settings.retentionDays` to Screenpipe as `--retention-days`.
- `src/services/modules/retention-service.js` uses the same setting to prune Cognify activity records and focus events.

This coupling blocks safe raw retention reduction. Setting retention to 1 or 2 days would also prune Cognify's own evidence store, breaking weekly/HOD reports and long-range local evidence.

Current data flow:

- `ActivityQueryService.getRangeData()` optionally queries Screenpipe, privacy-filters records, ingests them into Cognify's activity store, records sync windows, then returns merged local and fresh records.
- `ReportCacheService.dailyReport()` builds hourly summary cache from Cognify activity queries.
- Weekly/HOD evidence reads directly from Cognify's activity store, not from Screenpipe.
- Report-cache reads can be passive/stale, but a cache hit is not the same as durable raw record ingestion.

## Design Principles

1. Do not keep heavy raw data longer than needed.
2. Do not delete raw data until Cognify has a durable replacement.
3. Treat report cache as derived data, not the source of truth.
4. Keep user-facing windows responsive; finalization must run in background and yield to active UI.
5. Deletion/privacy must cross all stores: Screenpipe raw data, Cognify activity records, report cache, and sync metadata.
6. Retention state must be inspectable in Health Details so support can diagnose incomplete days.

## Data Tiers

### Tier 1: Screenpipe Raw Capture Buffer

Purpose:

- Short recovery window for OCR/audio/UI capture data before Cognify has synced it.
- Backfill source for recent incomplete windows.

Default retention:

- 2 days for screen-only capture.
- 3 days minimum when audio/listening is enabled.

Storage:

- `app.getPath('userData')/screenpipe-data`.

Not for:

- Weekly report source of truth.
- Long-term HOD evidence.
- Historical trend rebuilds after finalization.

### Tier 2: Cognify Activity Evidence Store

Purpose:

- Durable normalized evidence for all Cognify reports and analysis.
- Stores app/window/url/OCR/transcript metadata, classifications, durations, deletion tombstones, and sync windows.

Default retention:

- 10 days.

Storage:

- SQLite activity store, with JSONL fallback/dual-write where configured.

### Tier 3: Report Cache

Purpose:

- Fast daily/hourly summaries for snapshot, daily reports, focus trends, and category charts.

Default retention:

- Same as Cognify evidence retention, or slightly longer if needed for audit.

Important:

- Cache completeness can prove a report is fast to read, but it does not prove raw data is safe to delete unless activity sync coverage is also complete.

## Adversarial Review

### 1. Sleep, Clean Exit, Crash, Or Orphaned Capture

Risk:

- Normal clean-exit behavior is that Cognify owns Screenpipe and stops its owned Screenpipe processes when Cognify exits. In that normal case, Screenpipe should not keep capturing while Cognify is closed.
- The real clean-exit risk is different: raw records that were captured before exit can age while Cognify is not running. On the next launch, a too-short Screenpipe age-based retention cap can prune those old raw records before Cognify gets a chance to catch up or finalize them.
- Sleep is similar: the app may not process finalization work while suspended, and age-based retention can still become eligible after resume.
- Hidden capture while Cognify is down should be treated as an abnormal condition only: crash, force-kill, failed update/relaunch, orphaned child process, manually started Screenpipe, or legacy/global Screenpipe process.

Mitigation:

- Keep clean exit as a hard invariant: Cognify must stop owned Screenpipe processes on quit/relaunch/update.
- Detect and stop orphaned/non-owned local Screenpipe APIs on startup before starting Cognify's private Screenpipe.
- Do not set the Screenpipe built-in age cap so low that it can prune unfinalized raw data immediately on next launch.
- Track unfinalized days.
- Use explicit raw cleanup only for finalized days. Treat hidden capture while Cognify is closed as a bug to fix, not as a normal retention design assumption.

### 2. Partial Sync Looks Complete

Risk:

- A day can have some report-cache hours but missing raw Screenpipe windows. A cached daily summary may hide missing activity.

Mitigation:

- Finalization requires both:
  - Cognify activity sync coverage has no incomplete windows for the day.
  - Report cache has all expected hours for the day.

### 3. Report Logic Changes Later

Risk:

- If only report summaries are retained, future classification/report improvements cannot rebuild evidence.

Mitigation:

- Keep normalized records for evidence retention window.
- Treat report cache as rebuildable derived data.

### 4. Delete Range Privacy

Risk:

- Deleting a range from only Cognify records can allow later Screenpipe sync to re-ingest the same records.
- Deleting only raw Screenpipe can leave cached summaries or normalized evidence behind.

Mitigation:

- Existing tombstones prevent re-ingest; retain tombstones longer than activity rows.
- Invalidate report cache for deleted ranges.
- Call Screenpipe delete-range for raw data when available.
- Health/audit should record all deletion outcomes.

### 5. Audio Capture Lag

Risk:

- Audio transcription can lag or fail separately from frame capture. Short raw retention can drop audio before transcript ingestion.

Mitigation:

- Raw retention minimum 3 days when audio mode is not off.
- Day finalization must include audio/transcript sync health once audio is enabled.

### 6. Existing Global Screenpipe Data

Risk:

- Cognify now uses a private Screenpipe data directory. Old global `~/.screenpipe` data may contain historical records that are not in Cognify's activity store.

Mitigation:

- Do not automatically scan global data on every startup.
- Add an explicit one-time import/backfill tool if old global data matters.
- After migration, Cognify owns only its private Screenpipe data.

### 7. Current Day Reports

Risk:

- Aggressive raw pruning during the current day can remove data before current-hour sync and cache warmers process it.

Mitigation:

- Never raw-prune the current local day.
- Keep today plus yesterday at minimum.

### 8. Performance Regressions From Finalization

Risk:

- Finalizing a day can query many Screenpipe windows, build summaries, and compete with user input.

Mitigation:

- Run finalization only after startup settles, when no user-facing window is visible.
- Use bounded query budgets.
- Process one hour at a time.
- Persist progress so work resumes after restart.
- Set backoff on repeated failure.

### 9. Cache Growth

Risk:

- Report cache can grow forever if it is not pruned separately.

Mitigation:

- Add `ReportCacheService.prune(cutoffMs)`.
- Retention service should prune report cache using evidence retention cutoff.

## Adversarial Review Required Corrections

These corrections must be applied before implementation. Without them, the plan can report a day as safe while data is still missing, or it can let Screenpipe delete raw records before Cognify proves durable coverage.

### A. Built-In Screenpipe Retention Cannot Respect Finalization

Problem:

- `--retention-days` is enforced by Screenpipe, not by Cognify finalization state.
- Cleanly closing Cognify should also stop Screenpipe, so this is not about Screenpipe normally continuing to capture while Cognify is closed.
- The risk is that raw records already captured before exit can age while Cognify is closed, sleeping, crashed, or mid-update.
- If Cognify later launches Screenpipe with `--retention-days 2`, Screenpipe can age out an unfinalized previous day before Cognify has completed catch-up sync/cache verification.
- Therefore the rule "never prune an unfinalized previous day inside the raw buffer" cannot be guaranteed if the built-in Screenpipe retention is the only pruning mechanism.

Correction:

- Preserve the ownership invariant first: on normal exit, relaunch, and update, Cognify stops owned Screenpipe processes.
- Treat Screenpipe built-in retention as a hard age cap, not the exact cleanup policy, whenever explicit delete-range is reliable.
- Add two concepts:
  - `screenpipeRawRetentionDays`: target raw buffer after finalization, default 2.
  - `screenpipeRawRetentionHardCapDays`: Screenpipe CLI retention cap, default 7 or `max(screenpipeRawRetentionDays + 2, 3)`.
- Explicit raw cleanup should delete only finalized days older than `screenpipeRawRetentionDays`.
- If delete-range is not reliable, use the hard cap as the actual retention and do not claim that raw cleanup is finalization-aware.

### B. Sync Summary Does Not Prove Full-Day Coverage

Problem:

- Existing sync windows record individual query attempts.
- A sync summary that contains only complete windows is not enough to prove that windows cover the entire day.
- A single complete 10-minute window inside a 24-hour range could make a naive "no incomplete windows" check look clean while most of the day is unsynced.

Correction:

- Add an explicit coverage verifier, for example `activityStore.getSyncCoverage(startTime, endTime)`.
- It must merge complete sync windows, subtract failed/incomplete/budget-exhausted windows, and return:
  - `covered_ms`
  - `expected_ms`
  - `missing_ranges`
  - `incomplete_windows`
  - `complete`
- Day finalization must require `missing_ranges.length === 0` and no failed/incomplete windows overlapping the day.

### C. Report Cache Completeness Is Not Evidence Completeness

Problem:

- Report cache `complete` currently means expected hour keys are present.
- It does not necessarily prove that each hour was synced from Screenpipe, that the hour summary has full minute coverage, or that the query did not hit a budget/limit.

Correction:

- Day finalization must verify cache and evidence separately.
- Cache verification should require:
  - all expected hour keys exist;
  - each hour cache range exactly matches the expected hour range;
  - each hour's `sync.complete` is true or the independent sync coverage verifier says that hour is covered;
  - each hour has no impossible zero summary unless the activity store also proves the user was idle/offline.
- Do not use report cache presence alone as a raw-delete signal.

### D. `dailyReport(sync: true)` Does Not Sync Old Hours

Problem:

- Existing report-cache building only requests Screenpipe sync for the current hour or very recent hours.
- Calling `dailyReport({ sync: true })` for yesterday can build cache from local records only, because old hours are intentionally not synced in that hot path.

Correction:

- Finalization must explicitly call `ActivityQueryService.getRangeData()` per missing hour with `sync: true` and a finalization-specific budget before report-cache generation.
- After sync coverage is verified, build report cache with `sync: false`, `force: true`, and `includeTasks: false`.
- If a new report-cache API is added, name it clearly, for example `buildFinalizedDayCache()`, so it cannot be confused with user-facing report generation.

### E. Audio Retention Must Use Requested Mode, Not Only Active State

Problem:

- Meeting audio can be requested but inactive until a meeting is detected.
- If raw retention is raised only when audio is currently active, Screenpipe may relaunch with the shorter screen-only raw cap between meetings and age out recent audio/transcript recovery data earlier than intended.

Correction:

- The audio minimum should apply when configured audio mode is not `off`, not only when audio is actively recording.
- Effective raw target: `max(screenpipeRawRetentionDays, 3)` when `capture.audioMode !== 'off'`.
- Effective hard cap: at least the audio-adjusted target plus a safety margin.

### F. Finalization Must Be Cheap By Default

Problem:

- `dailyReport()` defaults `includeTasks` to true, which can invoke task extraction and increase CPU/latency.
- A background finalizer that extracts tasks for every old hour can slow the PC, which is exactly the failure mode this plan is trying to avoid.

Correction:

- Finalization report-cache builds must use `includeTasks: false`.
- User-triggered report views can rebuild task-bearing hours later if needed.
- The finalizer should use a small per-run budget and yield after each hour.

### G. Privacy Delete Semantics Need A Hard Acceptance Gate

Problem:

- Deleting Cognify rows and cache is not enough if Screenpipe delete-range fails.
- Deleting Screenpipe raw is not enough if tombstones/cache are not preserved.
- The UI and audit trail must not imply raw data was deleted when the adapter call failed.

Correction:

- Delete-range results must separately report:
  - Screenpipe raw delete status;
  - Cognify evidence delete status;
  - report-cache invalidation count;
  - tombstone creation status.
- The user-facing result should say "raw delete failed, Cognify will block re-ingest with tombstone" when adapter deletion fails.
- Tombstones must outlive evidence retention by at least `screenpipeRawRetentionHardCapDays + 7`.

### H. Local-Day Boundaries Need DST/Timezone Tests

Problem:

- User-facing reports use local-day boundaries, while records and sync windows are stored as ISO timestamps.
- Day finalization can get off-by-one-hour behavior around DST or timezone changes if it assumes every local day is exactly 24 hours.

Correction:

- Compute day start/end from local midnight to next local midnight, then store those exact ISO bounds in finalization metadata.
- Do not assume 24 hourly buckets; derive expected buckets from actual local-day bounds.
- Add tests for normal days plus DST-short/DST-long days, even if the current primary user timezone does not observe DST.

## Proposed Settings

Add separate retention fields:

```json
{
  "retentionDays": 10,
  "screenpipeRawRetentionDays": 2,
  "screenpipeRawRetentionHardCapDays": 7,
  "reportCacheRetentionDays": 10
}
```

Compatibility:

- Keep `retentionDays` as evidence retention to avoid breaking user expectations.
- On load, if `screenpipeRawRetentionDays` is missing, default to 2.
- On load, if `screenpipeRawRetentionHardCapDays` is missing, default to 7.
- If audio mode is enabled, effective raw target is `max(screenpipeRawRetentionDays, 3)`.
- Effective hard cap must be at least the effective raw target plus a safety margin.
- Clamp raw retention to a safe range, for example 1 to 14 days.
- Clamp the hard cap to a safe support range, for example 3 to 30 days.
- Clamp evidence retention to the existing safe range.

UI wording:

- Primary: "Evidence retention: 10 days"
- Advanced: "Raw capture buffer: 2 days"
- Helper: "Raw capture is kept only as a short recovery buffer. Reports use Cognify's normalized evidence store."

## Day Finalization Model

Create a finalization state file/table, for example:

```json
{
  "days": {
    "2026-05-10": {
      "date": "2026-05-10",
      "status": "finalized",
      "syncComplete": true,
      "cacheComplete": true,
      "recordCount": 1240,
      "missingHours": [],
      "lastAttemptAt": "2026-05-11T00:10:00.000Z",
      "finalizedAt": "2026-05-11T00:12:30.000Z",
      "schemaVersion": 1,
      "degradedReason": ""
    }
  }
}
```

Statuses:

- `pending`: needs sync/cache work.
- `syncing`: currently syncing activity windows.
- `caching`: building report cache.
- `finalized`: safe for raw data to age out.
- `degraded`: not complete after repeated attempts; requires Health visibility.

Finalization requirements:

1. Day is not today in local time.
2. Activity store coverage verifier proves the full local-day ISO range has no missing ranges and no incomplete/failed windows.
3. Report cache has expected hourly coverage for the day and each hour matches its expected bounds.
4. Deletion tombstones, if any, have been applied.
5. No active heavy report is running.
6. No user-facing Cognify windows are visible.

## Finalization Algorithm

Run on:

- Startup after Screenpipe health is stable.
- Midnight plus a short delay.
- Periodic retry, for example every 6 hours, for unfinalized days inside raw retention buffer.

Pseudo-flow:

```text
for each local day older than today and newer than raw retention cutoff:
  if day finalized:
    continue
  if user-facing window visible or heavy report in flight:
    defer
  sync each missing hour from Screenpipe with bounded finalization budget
  record sync windows
  verify full-day sync coverage using merged sync-window intervals
  build hourly report cache from Cognify activity store with sync=false and includeTasks=false
  verify cache coverage separately
  mark finalized or degraded
```

Important detail:

- For old hours, `ReportCacheService._shouldSyncHour()` should stay conservative. Finalization owns explicit sync, not random report views.

## Raw Pruning Policy

Screenpipe itself gets `--retention-days <effectiveRawDays>`.

Optional explicit pruning:

- Use Screenpipe delete-range for finalized raw days older than raw retention if API behavior is reliable.
- If using Screenpipe's built-in retention only, treat the configured retention as a hard cap and do not claim finalization-aware pruning.
- Preferred policy: use Screenpipe built-in retention as a hard cap and explicit delete-range as the normal finalized-day cleanup mechanism.

Rules:

- Never prune current local day.
- Never intentionally prune an unfinalized previous day inside the raw buffer.
- If a day ages beyond target raw retention without finalization, do not explicit-delete it. Mark it `degraded` and preserve all Cognify records already ingested.
- If a day ages beyond the Screenpipe hard cap without finalization, surface a Health warning that raw backfill may no longer be possible.

## Cognify Evidence Pruning Policy

Retention service should prune:

- Activity records older than `retentionDays`.
- Focus events older than `retentionDays`.
- Audit logs older than `retentionDays`.
- Report cache older than `reportCacheRetentionDays`.

Do not prune:

- Deletion tombstones at the same cutoff unless they can no longer protect against raw re-ingest. Prefer a longer tombstone retention, for example max evidence retention plus raw buffer plus 7 days.
- Finalization metadata needed for Health/audit, except after a long metadata retention window.

## Health And Diagnostics

Add Health Details fields:

- Raw buffer days.
- Evidence retention days.
- Screenpipe data directory.
- Screenpipe ownership status.
- Last clean Screenpipe stop result.
- Latest finalized day.
- Oldest unfinalized day.
- Finalization status for yesterday.
- Report cache coverage for today/yesterday.
- Activity sync coverage for today/yesterday.
- Raw data warning if private Screenpipe DB grows over threshold.

Healthy examples:

- "Raw capture buffer: 2 days"
- "Yesterday finalized at 12:12 AM"
- "Evidence retained for 10 days"

Warning examples:

- "Yesterday not finalized; raw buffer still available"
- "Finalization deferred while Cognify window is open"
- "Raw buffer may expire before sync completes"

## Implementation Phases

### Phase 1: Decouple Retention Settings

Files:

- `src/services/modules/settings-service.js`
- `src/main.js`
- `src/renderer/panel.js`
- `src/renderer/panel.html`
- `scripts/unit-test.js`

Tasks:

- Add `screenpipeRawRetentionDays` default 2.
- Add `reportCacheRetentionDays` default 10 or derive from `retentionDays`.
- Keep existing `retentionDays` as evidence retention.
- Update Screenpipe launch args to use effective raw retention.
- Update settings UI labels to avoid user confusion.
- Add tests for defaults, migration, clamping, and audio minimum.
- Add tests that Screenpipe launch args use the hard cap, while explicit cleanup uses the target raw buffer.

Acceptance:

- Changing evidence retention does not silently change raw Screenpipe retention.
- Screenpipe launch args show raw hard cap retention.
- Existing settings files migrate without data loss.

### Phase 2: Report Cache Pruning

Files:

- `src/services/modules/report-cache-service.js`
- `src/services/modules/retention-service.js`
- `scripts/unit-test.js`

Tasks:

- Add `ReportCacheService.prune(cutoffMs)`.
- Delete per-day cache files older than cutoff.
- Include pruned cache count in retention result.
- Add tests for cache prune behavior.

Acceptance:

- Running retention removes old report-cache files.
- Current cache files are preserved.
- Retention result reports cache pruning.

### Phase 3: Day Finalization Service

New file:

- `src/services/modules/day-finalization-service.js`

Likely touched files:

- `src/services/index.js`
- `src/main.js`
- `scripts/unit-test.js`

Tasks:

- Track finalization metadata.
- Determine local day bounds.
- Sync missing previous-day hours through `ActivityQueryService.getRangeData` with finalization-specific budgets.
- Build report cache for previous day with `sync: false`, `force: true`, and `includeTasks: false`.
- Verify activity sync coverage with merged interval coverage, not only `getSyncSummary().complete`.
- Verify cache coverage independently from sync coverage.
- Persist `finalized` or `degraded` state.
- Add backoff and in-flight guard.

Acceptance:

- Yesterday finalizes after records are synced and cache coverage is complete.
- Restart resumes partial finalization.
- UI-visible state defers finalization.
- Failure marks a clear degraded reason.

### Phase 4: Health And User Visibility

Files:

- `src/main.js`
- `src/renderer/health.js`
- `src/renderer/index.html`

Tasks:

- Add finalization diagnostics.
- Show raw buffer and evidence retention separately.
- Surface degraded/unfinalized days without making transient startup states look fatal.

Acceptance:

- Health Details explains raw/evidence/cache status.
- No false red state during normal startup.
- Degraded finalization is visible and actionable.

### Phase 5: Explicit Raw Cleanup

Files:

- `src/services/modules/screenpipe-adapter.js`
- `src/main.js`
- `scripts/unit-test.js`

Tasks:

- Decide whether to rely on Screenpipe built-in retention or call delete-range for finalized old days.
- If explicit cleanup is used, call only for finalized days outside raw buffer.
- Audit cleanup attempts and failures.

Acceptance:

- Raw cleanup never runs for current day.
- Raw cleanup never runs for unfinalized days inside buffer.
- Delete failures do not block Cognify startup.

## Test Plan

Unit tests:

- Settings migration and retention clamping.
- Effective raw target and hard cap with audio off/on/requested-meeting mode.
- Report cache prune.
- Day finalization success path.
- Day finalization rejects partial sync coverage even when all returned windows are individually complete.
- Day finalization incomplete sync windows.
- Day finalization missing cache hours.
- Day finalization refuses cache-only coverage without sync coverage.
- Finalization defers while user-facing window is visible.
- Raw cleanup refuses current day and unfinalized days.
- Raw cleanup uses explicit delete-range only for finalized days older than target raw retention.
- Local day boundary tests for normal, DST-short, and DST-long days.

Integration/smoke:

- Launch Cognify and confirm Screenpipe args use raw retention, private data dir, English OCR, low video quality.
- Generate records for today, then simulate next day finalization.
- Verify weekly/HOD evidence still works after raw data for older days is gone.
- Delete a range, then verify raw, activity store, report cache, and tombstones behave correctly.

Manual QA:

- Let Cognify run across midnight.
- Open Snapshot/Panel during scheduled finalization and confirm no UI slowdown.
- Check Health Details after finalization.
- Confirm Screenpipe DB/media size stabilizes over multiple days.

## Rollout Plan

1. Ship settings decoupling with raw retention default still conservative, for example 3 days.
2. Add finalization and diagnostics.
3. Observe logs and Health status for a day.
4. Lower default raw retention to 2 days after finalization proves reliable.
5. Keep an environment override:

```text
COGNIFY_SCREENPIPE_RAW_RETENTION_DAYS=7
```

This provides support escape hatch for heavy debugging.

## Open Questions

- Should raw retention be 2 days or 3 days by default for screen-only mode?
- Should audio mode force 3 days or 7 days until transcription reliability is proven?
- Should manual report generation be allowed to force Screenpipe sync for older days, or only use Cognify evidence once raw buffer expires?
- Should old global `~/.screenpipe` data have a one-time import path?
- How long should deletion tombstones be retained?

## Recommended Decision

Implement the split retention model and day finalization first. Do not reduce Screenpipe raw retention below 2 days until finalization state and Health diagnostics are present.

Recommended defaults after implementation:

- `screenpipeRawRetentionDays`: 2
- Effective raw retention with audio enabled: 3
- `retentionDays`: 10
- `reportCacheRetentionDays`: 10

This should keep the PC responsive by limiting active raw Screenpipe data while preserving Cognify's ability to produce reliable weekly/HOD evidence.
