const { normalizeActivity } = require('./activity-schema');

class AIContextBuilder {
  build(records = []) {
    return records.map((record) => normalizeActivity(record));
  }
}

module.exports = { AIContextBuilder };
