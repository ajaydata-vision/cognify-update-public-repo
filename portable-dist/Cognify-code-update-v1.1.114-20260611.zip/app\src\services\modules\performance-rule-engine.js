const crypto = require('crypto');
const fs = require('fs');

const ALLOWED_TEMPLATE_VARIABLES = new Set([
  'active_days',
  'work_minutes',
  'meeting_minutes',
  'meeting_surfaces',
  'project_themes',
  'focus_blocks',
  'idle_minutes',
  'role',
  'self_input',
  'completed_tasks',
  'deadline_work',
  'blockers',
  'learning_themes',
  'evidence_gaps'
]);

const SIGNAL_READERS = {
  active_days: (evidence) => normalizeScore(evidence.totals?.active_days, 5),
  work_minutes: (evidence) => normalizeScore(evidence.totals?.work_minutes, 1200),
  meeting_minutes: (evidence) => normalizeScore(evidence.totals?.meeting_minutes, 300),
  meeting_surfaces: (evidence) => normalizeScore(evidence.meetings_and_chat?.top_surfaces?.length, 3),
  project_themes: (evidence) => normalizeScore(evidence.project_themes?.length, 4),
  focus_blocks: (evidence) => normalizeScore(evidence.focus?.block_count, 5),
  idle_minutes_inverse: (evidence) => Math.max(0, 1 - normalizeScore(evidence.totals?.idle_minutes, 600)),
  role_confirmed: (evidence) => evidence.role?.role_id ? 1 : 0,
  self_input: (evidence) => hasMeaningfulSelfInput(evidence.self_input) ? 1 : 0,
  completed_tasks: (evidence) => normalizeScore(evidence.self_input?.completed_tasks?.length, 3),
  deadline_work: (evidence) => evidence.self_input?.deadline_work ? 1 : 0,
  blockers: (evidence) => evidence.self_input?.blockers?.length ? 1 : 0,
  learning_themes: (evidence) => normalizeScore(countLearningThemes(evidence.project_themes), 2)
};

const EVIDENCE_LEVEL_RANK = {
  low: 1,
  medium: 2,
  high: 3
};

function loadPerformanceRulesConfig(configPath) {
  const raw = fs.readFileSync(configPath, 'utf8');
  return parsePerformanceRulesConfig(raw);
}

function parsePerformanceRulesConfig(raw) {
  const config = JSON.parse(raw);
  validatePerformanceRulesConfig(config);
  return config;
}

function validatePerformanceRulesConfig(config = {}) {
  if (!config.version || typeof config.version !== 'string') {
    throw new Error('Performance rules config requires a string version.');
  }
  if (!config.categories || typeof config.categories !== 'object') {
    throw new Error('Performance rules config requires categories.');
  }

  Object.entries(config.categories).forEach(([categoryId, category]) => {
    if (!category.label || typeof category.label !== 'string') {
      throw new Error(`Category ${categoryId} requires a label.`);
    }
    if (!Array.isArray(category.signals) || !category.signals.length) {
      throw new Error(`Category ${categoryId} requires at least one signal.`);
    }
    const totalWeight = category.signals.reduce((sum, signal) => {
      if (!SIGNAL_READERS[signal.name]) {
        throw new Error(`Category ${categoryId} uses unknown signal: ${signal.name}`);
      }
      const weight = Number(signal.weight);
      if (!Number.isFinite(weight) || weight < 0 || weight > 1) {
        throw new Error(`Category ${categoryId} signal ${signal.name} has invalid weight.`);
      }
      return sum + weight;
    }, 0);
    if (totalWeight <= 0 || totalWeight > 1.01) {
      throw new Error(`Category ${categoryId} signal weights must total between 0 and 1.`);
    }
    if (!Array.isArray(category.evidence) || !category.evidence.length) {
      throw new Error(`Category ${categoryId} requires evidence bindings.`);
    }
    if (!category.templates?.positive || !category.templates?.needs_review) {
      throw new Error(`Category ${categoryId} requires positive and needs_review templates.`);
    }
    if (category.risk_level && !['low', 'medium', 'high'].includes(category.risk_level)) {
      throw new Error(`Category ${categoryId} has invalid risk_level.`);
    }
    if (category.risk_level === 'high' && !(category.review_required_when || []).includes('missing_self_input')) {
      throw new Error(`High-risk category ${categoryId} must require missing_self_input review.`);
    }
    validateTemplate(category.templates.positive, categoryId);
    validateTemplate(category.templates.needs_review, categoryId);
  });

  if (config.output_profiles) {
    Object.entries(config.output_profiles).forEach(([profileId, profile]) => {
      if (!Array.isArray(profile.categories) || !profile.categories.length) {
        throw new Error(`Output profile ${profileId} requires categories.`);
      }
      profile.categories.forEach((field) => {
        if (!field.field_id || !field.label || !field.source_category) {
          throw new Error(`Output profile ${profileId} contains an invalid field mapping.`);
        }
        if (!config.categories[field.source_category]) {
          throw new Error(`Output profile ${profileId} maps to unknown source category: ${field.source_category}`);
        }
        const sourceCategory = config.categories[field.source_category];
        const fieldRisk = field.risk_level || sourceCategory.risk_level || 'medium';
        if (profileId === 'hod_appraisal' && fieldRisk === 'high' && !field.force_review) {
          throw new Error(`HOD high-risk field ${field.field_id} must force human review.`);
        }
      });
      if (profile.remark?.template) {
        validateTemplate(profile.remark.template, `${profileId}.remark`);
      }
    });
  }

  return true;
}

function evaluatePerformanceRules(evidencePack = {}, config = {}) {
  validatePerformanceRulesConfig(config);
  const rulesHash = hashConfig(config);
  const categories = Object.entries(config.categories).map(([categoryId, category]) => {
    return evaluateCategory(categoryId, {
      ...category,
      language_guard_terms: config.language_guard?.flag_terms || [],
      minimum_evidence_level_for_positive: config.minimum_evidence_level_for_positive || 'medium'
    }, evidencePack);
  });

  return {
    generated_at: new Date().toISOString(),
    rules_version: config.version,
    rules_hash: rulesHash,
    role: evidencePack.role || {},
    evidence_confidence: evidencePack.confidence || { level: 'low', score: 0 },
    categories
  };
}

function evaluateCategory(categoryId, category, evidencePack) {
  const signalScore = category.signals.reduce((sum, signal) => {
    return sum + (SIGNAL_READERS[signal.name](evidencePack) * Number(signal.weight || 0));
  }, 0);
  const evidence = buildEvidenceItems(category.evidence, evidencePack);
  const evidenceLevel = evidencePack.confidence?.level || 'low';
  const reviewReasons = reviewReasonsFor(category, evidencePack, evidence);
  const reviewRequired = reviewReasons.length > 0;
  const template = reviewRequired ? category.templates.needs_review : category.templates.positive;
  const draft = renderTemplate(template, templateVariables(evidencePack));
  const languageFlags = languageFlagsFor(draft, category.language_guard_terms || []);
  if (languageFlags.length) {
    reviewReasons.push(`Draft language requires review: ${languageFlags.join(', ')}.`);
  }
  const finalReviewRequired = reviewReasons.length > 0;

  return {
    category_id: categoryId,
    label: category.label,
    signal_score: Number(signalScore.toFixed(3)),
    evidence_strength: evidenceLevel,
    risk_level: category.risk_level || 'medium',
    suggested_tone: finalReviewRequired ? 'needs_review' : 'positive',
    review_required: finalReviewRequired,
    review_reasons: reviewReasons,
    copy_allowed: !finalReviewRequired,
    draft,
    language_flags: languageFlags,
    evidence,
    missing_context_prompt: finalReviewRequired ? (category.missing_context_prompt || '') : ''
  };
}

function reviewReasonsFor(category, evidencePack, evidence) {
  const reasons = [];
  const conditions = new Set(category.review_required_when || []);
  if (!minimumEvidenceMet(evidencePack.confidence?.level || 'low', category.minimum_evidence_level_for_positive || 'medium')) {
    reasons.push(`Evidence strength is below ${category.minimum_evidence_level_for_positive || 'medium'}.`);
  }
  if (conditions.has('low_evidence') && evidencePack.confidence?.level === 'low') {
    reasons.push('Evidence strength is low.');
  }
  if (conditions.has('missing_self_input') && !hasMeaningfulSelfInput(evidencePack.self_input)) {
    reasons.push('Employee self-input is missing.');
  }
  if (!evidence.length) {
    reasons.push('No bound evidence is available for this category.');
  }
  return reasons;
}

function languageFlagsFor(text, terms = []) {
  const normalized = String(text || '').toLowerCase();
  return terms.filter((term) => {
    const escaped = String(term).toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`\\b${escaped}\\b`, 'i').test(normalized);
  });
}

function minimumEvidenceMet(evidenceLevel, minimum = 'medium') {
  return (EVIDENCE_LEVEL_RANK[evidenceLevel] || 0) >= (EVIDENCE_LEVEL_RANK[minimum] || 2);
}

function buildEvidenceItems(bindings = [], evidencePack = {}) {
  return bindings.flatMap((binding) => evidenceForBinding(binding, evidencePack)).filter(Boolean).slice(0, 6);
}

function evidenceForBinding(binding, evidencePack) {
  if (binding === 'active_days' && evidencePack.totals?.active_days) {
    return [{ label: `${evidencePack.totals.active_days} active day(s)`, source: 'weekly_evidence' }];
  }
  if (binding === 'work_minutes' && evidencePack.totals?.work_minutes) {
    return [{ label: `${evidencePack.totals.work_minutes} work minute(s)`, source: 'weekly_evidence' }];
  }
  if (binding === 'meeting_minutes' && evidencePack.totals?.meeting_minutes) {
    return [{ label: `${evidencePack.totals.meeting_minutes} meeting/chat minute(s)`, source: 'weekly_evidence' }];
  }
  if (binding === 'meeting_surfaces') {
    return (evidencePack.meetings_and_chat?.top_surfaces || []).slice(0, 3).map((item) => ({
      label: `${item.label} (${item.minutes}m)`,
      source: 'meeting_surface'
    }));
  }
  if (binding === 'project_themes') {
    return (evidencePack.project_themes || []).slice(0, 3).map((item) => ({
      label: `${item.label} (${item.count})`,
      source: 'project_theme'
    }));
  }
  if (binding === 'focus_blocks' && evidencePack.focus?.block_count) {
    return [{ label: `${evidencePack.focus.block_count} focus block(s)`, source: 'weekly_evidence' }];
  }
  if (binding === 'idle_minutes' && Number.isFinite(Number(evidencePack.totals?.idle_minutes))) {
    return [{ label: `${evidencePack.totals.idle_minutes} idle minute(s)`, source: 'weekly_evidence' }];
  }
  if (binding === 'role' && evidencePack.role?.role) {
    return [{ label: `Role: ${evidencePack.role.role}`, source: 'role_profile' }];
  }
  if (binding === 'self_input' && hasMeaningfulSelfInput(evidencePack.self_input)) {
    return [{ label: summarizeSelfInput(evidencePack.self_input), source: 'self_input' }];
  }
  if (binding === 'completed_tasks') {
    return listSelfInputItems(evidencePack.self_input?.completed_tasks, 'Completed').map((label) => ({
      label,
      source: 'self_input'
    }));
  }
  if (binding === 'deadline_work' && evidencePack.self_input?.deadline_work) {
    return [{ label: `Deadline work: ${truncate(evidencePack.self_input.deadline_work, 160)}`, source: 'self_input' }];
  }
  if (binding === 'blockers') {
    return listSelfInputItems(evidencePack.self_input?.blockers, 'Blocker').map((label) => ({
      label,
      source: 'self_input'
    }));
  }
  if (binding === 'learning_themes') {
    return learningThemes(evidencePack.project_themes).slice(0, 3).map((item) => ({
      label: `${item.label} (${item.count})`,
      source: 'project_theme'
    }));
  }
  return [];
}

function templateVariables(evidencePack = {}) {
  return {
    active_days: String(evidencePack.totals?.active_days || 0),
    work_minutes: String(evidencePack.totals?.work_minutes || 0),
    meeting_minutes: String(evidencePack.totals?.meeting_minutes || 0),
    meeting_surfaces: joinLabels(evidencePack.meetings_and_chat?.top_surfaces),
    project_themes: joinLabels(evidencePack.project_themes),
    focus_blocks: String(evidencePack.focus?.block_count || 0),
    idle_minutes: String(evidencePack.totals?.idle_minutes || 0),
    role: evidencePack.role?.role || 'unconfirmed role',
    self_input: hasMeaningfulSelfInput(evidencePack.self_input) ? summarizeSelfInput(evidencePack.self_input) : 'no self-input',
    completed_tasks: summarizeList(evidencePack.self_input?.completed_tasks, 'no completed tasks provided'),
    deadline_work: evidencePack.self_input?.deadline_work ? truncate(evidencePack.self_input.deadline_work, 180) : 'no deadline context provided',
    blockers: summarizeList(evidencePack.self_input?.blockers, 'no blockers provided'),
    learning_themes: joinLabels(learningThemes(evidencePack.project_themes)),
    evidence_gaps: (evidencePack.evidence_gaps || []).join('; ') || 'limited supporting evidence'
  };
}

function validateTemplate(template, categoryId) {
  const variables = template.match(/\{[a-zA-Z0-9_]+\}/g) || [];
  variables.forEach((variable) => {
    const key = variable.slice(1, -1);
    if (!ALLOWED_TEMPLATE_VARIABLES.has(key)) {
      throw new Error(`Category ${categoryId} template uses unknown placeholder: ${variable}`);
    }
  });
}

function renderTemplate(template, variables) {
  return String(template).replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, key) => {
    if (!ALLOWED_TEMPLATE_VARIABLES.has(key)) {
      throw new Error(`Unknown template placeholder: {${key}}`);
    }
    return variables[key] || '';
  });
}

function hashConfig(config) {
  return crypto
    .createHash('sha256')
    .update(JSON.stringify(config))
    .digest('hex');
}

function normalizeScore(value, target) {
  return Math.min(1, Math.max(0, Number(value || 0) / target));
}

function joinLabels(items = []) {
  const labels = items.slice(0, 3).map((item) => item.label).filter(Boolean);
  return labels.length ? labels.join(', ') : 'limited visible evidence';
}

function summarizeSelfInput(selfInput = {}) {
  if (Array.isArray(selfInput.completed_tasks) && selfInput.completed_tasks.length) {
    return selfInput.completed_tasks.slice(0, 2).join(', ');
  }
  if (selfInput.offline_work) {
    return String(selfInput.offline_work).slice(0, 160);
  }
  return 'self-input provided';
}

function hasMeaningfulSelfInput(selfInput = {}) {
  if (!selfInput || typeof selfInput !== 'object') {
    return false;
  }
  if (Array.isArray(selfInput.completed_tasks) && selfInput.completed_tasks.some((item) => String(item || '').trim())) {
    return true;
  }
  if (Array.isArray(selfInput.blockers) && selfInput.blockers.some((item) => String(item || '').trim())) {
    return true;
  }
  return ['offline_work', 'deadline_work', 'misread_context'].some((key) => String(selfInput[key] || '').trim());
}

function summarizeList(items = [], fallback) {
  const values = Array.isArray(items) ? items.filter(Boolean).slice(0, 3) : [];
  return values.length ? values.join(', ') : fallback;
}

function listSelfInputItems(items = [], prefix) {
  return (Array.isArray(items) ? items : [])
    .filter(Boolean)
    .slice(0, 3)
    .map((item) => `${prefix}: ${truncate(item, 140)}`);
}

function learningThemes(items = []) {
  return (items || []).filter((item) => /\b(learn|learning|training|course|certification|documentation|docs|tutorial|prototype|research|poc)\b/i.test(item.label || ''));
}

function countLearningThemes(items = []) {
  return learningThemes(items).length;
}

function truncate(value, maxLength) {
  const text = String(value || '').trim();
  return text.length > maxLength ? `${text.slice(0, maxLength - 1)}...` : text;
}

module.exports = {
  ALLOWED_TEMPLATE_VARIABLES,
  evaluatePerformanceRules,
  hasMeaningfulSelfInput,
  loadPerformanceRulesConfig,
  parsePerformanceRulesConfig,
  validatePerformanceRulesConfig
};
