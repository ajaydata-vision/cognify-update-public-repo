# Cognify Performance Contract

This is a hard engineering rule for Cognify.

Cognify must never make the user machine feel slow. Every function, loop, timer,
refresh, IPC handler, report generator, and background task must be designed to
avoid blocking UI interaction and avoid unnecessary CPU, RAM, disk, or Screenpipe
load.

## Hard Rules

- UI clicks, scroll, typing, and window movement must remain responsive while
  capture, reports, diagnostics, nudges, cache warming, and summaries run.
- Background refreshes must be passive by default. They may read cached or
  lightweight state, but must not recompute full-day reports or multi-day trends.
- Expensive work must be user-triggered, coalesced, cancellable where practical,
  and guarded against duplicate clicks.
- Timers must never start a new expensive job if the previous job is still
  running.
- Any loop over activity records must have a bounded range, a clear maximum
  workload, and a reason it cannot use cached hourly summaries.
- Report generation must prefer hourly report cache. Rebuilding current-hour
  cache is acceptable; rebuilding whole days during passive UI refresh is not.
- Diagnostics and health checks must be cheap. They must not call report,
  summary, trend, or Screenpipe backfill paths.
- Nudges must avoid multi-day or full-day computation unless explicitly forced
  by the user.
- Memory guards must use active memory pressure, not misleading reserved memory
  alone. Reserved/private bytes may be logged as diagnostics, not used as the
  only restart signal.
- Screenpipe restarts must be rare and justified. A guard must not create a
  restart loop.
- Renderer updates must avoid huge `innerHTML` replacements during interaction
  unless the user explicitly requested a report view refresh.
- Overlay and expanded-mode UI must not steal clicks or leave hidden moved DOM
  panels intercepting input.

## Review Checklist

Before merging any Cognify change, check:

- What timers or refreshes does this add?
- Can this run while the user is scrolling or clicking?
- Can repeated clicks create duplicate work?
- Does this use cached summaries before querying Screenpipe or scanning records?
- Is the selected date/time range bounded?
- Does this run in the Electron main process, and if so can it block IPC?
- Does this allocate large arrays, large HTML strings, or whole-day record sets?
- Does this write to disk or SQLite inside a frequent loop?
- Does this make Screenpipe capture, restart, backfill, or sync more often?
- What does the user see if it takes 5-10 seconds?

If any answer is uncertain, treat the change as unsafe until measured.

## Default Design

- Passive UI: cached state only.
- User report click: cached hourly report first, current hour rebuild only.
- Heavy full report: explicit action, one in-flight job per range/mode.
- Trend analytics: cached or background only, never required for first paint.
- Health checks: process/API status only.
- Timers: short work only, no overlapping runs.

