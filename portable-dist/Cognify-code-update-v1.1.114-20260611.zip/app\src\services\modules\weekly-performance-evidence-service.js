const { contextSwitchAnalysis } = require('./nudge-analysis-service');
const { hasMeaningfulSelfInput } = require('./performance-rule-engine');
const {
  buildWorkHoursLedger,
  safePcAvailableMinutesFromSummary
} = require('./work-hours-ledger');

const CLASSIFICATION_KEYS = ['work', 'meeting', 'social', 'other', 'unclear'];

function buildWeeklyPerformanceEvidence(input = {}) {
  const now = new Date(input.now || Date.now());
  const endMs = Number.isFinite(new Date(input.endTime || now).getTime())
    ? new Date(input.endTime || now).getTime()
    : now.getTime();
  const startMs = Number.isFinite(new Date(input.startTime || (endMs - (7 * 24 * 60 * 60 * 1000))).getTime())
    ? new Date(input.startTime || (endMs - (7 * 24 * 60 * 60 * 1000))).getTime()
    : endMs - (7 * 24 * 60 * 60 * 1000);
  const records = normalizeRecords(input.records || [], startMs, endMs);
  const roleProfile = input.roleProfile || {};
  const idleSummary = input.idleSummary || {};
  const dailySummaries = input.dailySummaries || [];
  const canonicalCoverage = normalizeCanonicalCoverage(input.canonicalCoverage, dailySummaries);
  const selfInput = input.selfInput || null;
  const fallbackRecords = fallbackRecordsForUncoveredDays(records, dailySummaries, canonicalCoverage);
  const fallbackRecordMs = fallbackRecords.reduce((sum, record) => sum + Number(record.durationMs || 0), 0);

  const classificationMs = mergeClassificationMs(fallbackRecords.length || dailySummaries.length ? fallbackRecords : records, dailySummaries);
  const manualRecords = records.filter((record) => isManualRecord(record));
  const appUsage = topUsage(records, (record) => normalizedApp(record.app_name || 'Unknown'), 8);
  const siteUsage = topUsage(records, (record) => hostFromRecord(record), 8).filter((item) => item.label);
  const activeDays = activeDayBreakdown(records, dailySummaries);
  const focusBlocks = findFocusBlocks(records);
  const context = contextSwitchAnalysis(records, {
    startMs,
    endMs,
    windowMs: endMs - startMs
  });
  const meetingLoad = buildMeetingLoad(records, classificationMs);
  const projectThemes = inferThemes(records);
  const confidence = evidenceConfidence({
    records,
    activeDays,
    roleProfile,
    selfInput,
    projectThemes
  });

  return {
    generated_at: now.toISOString(),
    week: {
      start_time: new Date(startMs).toISOString(),
      end_time: new Date(endMs).toISOString()
    },
    role: {
      role_id: roleProfile.roleId || roleProfile.roleDetection?.lastDetectedRoleId || '',
      role: roleProfile.role || roleProfile.roleDetection?.lastDetectedRole || '',
      role_source: roleProfile.roleSource || '',
      role_notes: roleProfile.roleNotes || '',
      detection_confidence: Number(roleProfile.roleDetection?.lastConfidence || 0)
    },
    totals: {
      record_count: records.length,
      active_days: activeDays.days.length,
      active_minutes: dailySummaries.length
        ? weeklyPcAvailableMinutes(dailySummaries) + minutes(fallbackRecordMs)
        : minutes(Object.values(classificationMs).reduce((sum, value) => sum + value, 0)),
      pc_available_minutes: weeklyPcAvailableMinutes(dailySummaries) + minutes(fallbackRecordMs),
      work_minutes: minutes(weeklyWorkMs(classificationMs, dailySummaries, fallbackRecordMs)),
      meeting_minutes: minutes(classificationMs.meeting),
      social_minutes: minutes(classificationMs.social),
      other_minutes: minutes(classificationMs.other),
      unclear_minutes: minutes(classificationMs.unclear),
      manual_minutes: minutes(manualRecords.reduce((sum, record) => sum + record.durationMs, 0)),
      idle_minutes: weeklyIdleMinutes(dailySummaries, idleSummary, startMs, endMs)
    },
    canonical_coverage: canonicalCoverage,
    active_days: activeDays.days,
    top_apps: appUsage,
    top_sites: siteUsage,
    project_themes: projectThemes,
    focus: {
      block_count: focusBlocks.length,
      longest_block_minutes: focusBlocks.length ? Math.max(...focusBlocks.map((block) => block.minutes)) : 0,
      blocks: focusBlocks.slice(0, 8)
    },
    context_switching: {
      switches: context.switches,
      unique_surfaces: context.unique_surface_count,
      meaningful_segments: context.meaningful_segment_count,
      window_minutes: context.window_minutes
    },
    meetings_and_chat: meetingLoad,
    manual_entries: manualRecords.slice(0, 10).map((record) => ({
      start_time: record.timestamp_start,
      label: record.window_title || record.ocr_text || record.app_name || 'Manual entry',
      minutes: minutes(record.durationMs)
    })),
    self_input: selfInput,
    confidence,
    evidence_gaps: evidenceGaps({ records, activeDays, roleProfile, selfInput, projectThemes, canonicalCoverage })
  };
}

function normalizeRecords(records, startMs, endMs) {
  return records
    .map((record) => {
      const recordStartMs = new Date(record.timestamp_start || record.timestamp).getTime();
      if (!Number.isFinite(recordStartMs)) {
        return null;
      }
      const explicitEndMs = new Date(record.timestamp_end || '').getTime();
      const durationMs = Number(record.duration_ms_estimate || 0);
      const recordEndMs = Number.isFinite(explicitEndMs) && explicitEndMs > recordStartMs
        ? explicitEndMs
        : recordStartMs + Math.max(60000, durationMs || 60000);
      if (recordEndMs < startMs || recordStartMs > endMs) {
        return null;
      }
      return {
        ...record,
        startMs: Math.max(startMs, recordStartMs),
        endMs: Math.min(endMs, recordEndMs),
        durationMs: Math.max(0, Math.min(endMs, recordEndMs) - Math.max(startMs, recordStartMs))
      };
    })
    .filter(Boolean)
    .sort((left, right) => left.startMs - right.startMs);
}

function mergeClassificationMs(records, dailySummaries = []) {
  const merged = emptyClassificationMs();
  dailySummaries.forEach((summary) => {
    const source = summary.classified_ms || minutesToMs(summary.classified_minutes || {});
    CLASSIFICATION_KEYS.forEach((key) => {
      merged[key] += Number(source[key] || 0);
    });
  });

  records.forEach((record) => {
    const key = ['work', 'meeting', 'social', 'other', 'unclear'].includes(record.classification)
      ? record.classification
      : (isManualRecord(record) ? manualClassification(record) : 'unclear');
    merged[key] += record.durationMs || 0;
  });
  return merged;
}

function topUsage(records, labelFn, limit) {
  const map = new Map();
  records.forEach((record) => {
    const label = labelFn(record);
    if (!label) {
      return;
    }
    map.set(label, (map.get(label) || 0) + (record.durationMs || 0));
  });
  return Array.from(map.entries())
    .map(([label, durationMs]) => ({ label, minutes: minutes(durationMs) }))
    .sort((left, right) => right.minutes - left.minutes)
    .slice(0, limit);
}

function activeDayBreakdown(records, dailySummaries = []) {
  const map = new Map();
  const summaryDays = new Set();
  dailySummaries.forEach((summary) => {
    const day = dailySummaryDate(summary);
    if (!day) {
      return;
    }
    summaryDays.add(day);
    const pcAvailable = safePcAvailableMinutesFromSummary(summary);
    const workMinutes = dailySummaryWorkMinutes(summary);
    const activeMinutes = Number(summary.estimated_active_minutes || summary.active_minutes || 0);
    const minutesForDay = Math.max(pcAvailable, workMinutes, activeMinutes);
    if (minutesForDay > 0) {
      map.set(day, (map.get(day) || 0) + (minutesForDay * 60000));
    }
  });
  records.forEach((record) => {
    const day = localDateKeyFromMs(record.startMs);
    if (summaryDays.has(day)) {
      return;
    }
    map.set(day, (map.get(day) || 0) + (record.durationMs || 0));
  });
  const days = Array.from(map.entries())
    .map(([date, durationMs]) => ({
      date,
      active_minutes: minutes(durationMs),
      pc_available_minutes: summaryDays.has(date) ? minutes(durationMs) : 0
    }))
    .filter((day) => day.active_minutes > 0)
    .sort((left, right) => left.date.localeCompare(right.date));
  return { days };
}

function findFocusBlocks(records) {
  const blocks = [];
  let current = null;
  records.forEach((record) => {
    if (record.classification !== 'work' && manualClassification(record) !== 'work') {
      current = null;
      return;
    }
    const surface = `${normalizedApp(record.app_name || 'Unknown')}|${hostFromRecord(record) || ''}`;
    if (current && current.surface === surface && record.startMs - current.endMs <= 5 * 60000) {
      current.endMs = Math.max(current.endMs, record.endMs);
      current.minutes = minutes(current.endMs - current.startMs);
      return;
    }
    current = {
      start_time: new Date(record.startMs).toISOString(),
      end_time: new Date(record.endMs).toISOString(),
      surface,
      label: hostFromRecord(record) || normalizedApp(record.app_name || 'Unknown'),
      startMs: record.startMs,
      endMs: record.endMs,
      minutes: minutes(record.durationMs)
    };
    blocks.push(current);
  });
  return blocks
    .filter((block) => block.minutes >= 25)
    .sort((left, right) => right.minutes - left.minutes);
}

function buildMeetingLoad(records, classificationMs) {
  const meetingRecords = records.filter((record) => (
    record.classification === 'meeting' ||
    record.meeting_flag ||
    /\b(meeting|call|teams|zoom|meet|xgen im|whatsapp|slack)\b/i.test(`${record.app_name || ''} ${record.window_title || ''} ${record.ocr_text || ''}`)
  ));
  return {
    meeting_minutes: minutes(classificationMs.meeting),
    event_count: meetingRecords.length,
    top_surfaces: topUsage(meetingRecords, (record) => hostFromRecord(record) || normalizedApp(record.app_name || 'Meeting'), 5)
  };
}

function inferThemes(records) {
  const counts = new Map();
  records.forEach((record) => {
    const text = `${record.window_title || ''} ${record.url_if_available || ''} ${record.ocr_text || ''}`;
    extractThemeTokens(text).forEach((token) => {
      counts.set(token, (counts.get(token) || 0) + 1);
    });
  });
  return Array.from(counts.entries())
    .sort((left, right) => right[1] - left[1])
    .slice(0, 12)
    .map(([label, count]) => ({ label, count }));
}

function extractThemeTokens(text) {
  const normalized = String(text || '').toLowerCase();
  const tokens = new Set();
  const ticketMatches = normalized.match(/\b[a-z]{2,10}-\d{1,8}\b/g) || [];
  ticketMatches.forEach((token) => tokens.add(token.toUpperCase()));
  [
    'appraisal', 'approval', 'payroll', 'invoice', 'crm', 'campaign', 'contract',
    'support', 'ticket', 'dashboard', 'report', 'design', 'prototype', 'requirement',
    'social media', 'content', 'meeting', 'learning', 'training', 'course',
    'certification', 'documentation', 'tutorial', 'research', 'poc'
  ].forEach((keyword) => {
    if (normalized.includes(keyword)) {
      tokens.add(keyword);
    }
  });
  return Array.from(tokens);
}

function evidenceConfidence({ records, activeDays, roleProfile, selfInput, projectThemes }) {
  let score = 0;
  if (records.length >= 250) score += 30;
  else if (records.length >= 100) score += 22;
  else if (records.length >= 40) score += 12;
  if ((activeDays.days || []).length >= 5) score += 25;
  else if ((activeDays.days || []).length >= 3) score += 15;
  if (roleProfile.roleId || roleProfile.role) score += 18;
  if ((projectThemes || []).length >= 3) score += 12;
  if (hasMeaningfulSelfInput(selfInput)) score += 15;
  const level = score >= 75 ? 'high' : (score >= 45 ? 'medium' : 'low');
  return { score: Math.min(100, score), level };
}

function evidenceGaps({ records, activeDays, roleProfile, selfInput, projectThemes, canonicalCoverage }) {
  const gaps = [];
  if (canonicalCoverage && canonicalCoverage.complete === false) {
    const missing = Number(canonicalCoverage.missing_dates?.length || 0);
    const incomplete = Number(canonicalCoverage.incomplete_dates?.length || 0);
    gaps.push(`Canonical hour coverage is incomplete for ${missing + incomplete} day(s). Report hours may be partial for those days.`);
  }
  if (!roleProfile.roleId && !roleProfile.role) gaps.push('Role profile is not confirmed.');
  if ((activeDays.days || []).length < 3) gaps.push('Fewer than three active days are available for the week.');
  if (records.length < 100) gaps.push('Low activity sample size may miss work context.');
  if (!(projectThemes || []).length) gaps.push('No clear project or task themes were detected.');
  if (!hasMeaningfulSelfInput(selfInput)) gaps.push('Employee self-input is missing for offline work, blockers, and completed tasks.');
  return gaps;
}

function idleMinutes(idleSummary = {}, startMs, endMs) {
  return Math.round((idleSummary.intervals || []).reduce((total, interval) => {
    const intervalStart = new Date(interval.start).getTime();
    const intervalEnd = new Date(interval.end).getTime();
    if (!Number.isFinite(intervalStart) || !Number.isFinite(intervalEnd)) {
      return total;
    }
    return total + Math.max(0, Math.min(endMs, intervalEnd) - Math.max(startMs, intervalStart));
  }, 0) / 60000);
}

function weeklyIdleMinutes(dailySummaries = [], idleSummary = {}, startMs, endMs) {
  if (dailySummaries.length) {
    return dailySummaries.reduce((sum, summary) => {
      const pcAvailable = safePcAvailableMinutesFromSummary(summary);
      const idle = Number(summary.idle_minutes || summary.input_idle_minutes || 0);
      return sum + Math.min(pcAvailable, Math.max(0, Math.round(Number(idle) || 0)));
    }, 0);
  }
  return idleMinutes(idleSummary, startMs, endMs);
}

function weeklyPcAvailableMinutes(dailySummaries = []) {
  return dailySummaries.reduce((sum, summary) => (
    sum + safePcAvailableMinutesFromSummary(summary)
  ), 0);
}

function dailySummaryWorkMinutes(summary = {}) {
  const idle = Number(summary.idle_minutes || summary.input_idle_minutes || 0);
  const manual = Number.isFinite(Number(summary.manual_net_added_work_minutes))
    ? Number(summary.manual_net_added_work_minutes)
    : Number(summary.manual_timing_blocks?.net_added_minutes || 0);
  return buildWorkHoursLedger({
    pcAvailableMinutes: safePcAvailableMinutesFromSummary(summary),
    idleMinutes: idle,
    manualAddedMinutes: manual,
    rangeMinutes: summary.range_minutes
  }).work_minutes;
}

function dailySummaryDate(summary = {}) {
  const explicit = summary.canonical_date || summary.date;
  if (/^\d{4}-\d{2}-\d{2}$/.test(String(explicit || ''))) {
    return String(explicit);
  }
  const source = summary.canonical_range_start || summary.range_start || summary.start_time || '';
  if (!source) {
    return '';
  }
  const date = new Date(source);
  if (!Number.isFinite(date.getTime())) {
    return '';
  }
  return date.toISOString().slice(0, 10);
}

function emptyClassificationMs() {
  return { work: 0, meeting: 0, social: 0, other: 0, unclear: 0 };
}

function weeklyWorkMs(classificationMs = {}, dailySummaries = [], fallbackRecordMs = 0) {
  const summaryWorkMs = dailySummaries.reduce((sum, summary) => {
    if (
      Number.isFinite(Number(summary.gross_pc_available_minutes)) ||
      Number.isFinite(Number(summary.work_minutes_breakdown?.gross_pc_available_minutes)) ||
      Number.isFinite(Number(summary.runtime_available_minutes))
    ) {
      return sum + (dailySummaryWorkMinutes(summary) * 60000);
    }
    if (Number.isFinite(Number(summary.work_minutes))) {
      return sum + (Number(summary.work_minutes || 0) * 60000);
    }
    if (Number.isFinite(Number(summary.work_minutes_breakdown?.total_work_minutes))) {
      return sum + (Number(summary.work_minutes_breakdown.total_work_minutes || 0) * 60000);
    }
    return sum + (dailySummaryWorkMinutes(summary) * 60000);
  }, 0);
  if (dailySummaries.length) {
    return summaryWorkMs + Number(fallbackRecordMs || 0);
  }
  return CLASSIFICATION_KEYS.reduce((sum, key) => sum + Number(classificationMs[key] || 0), 0);
}

function normalizeCanonicalCoverage(coverage = null, dailySummaries = []) {
  if (coverage && typeof coverage === 'object') {
    return {
      ...coverage,
      complete: coverage.complete !== false,
      expected_days: Math.max(0, Math.round(Number(coverage.expected_days || 0))),
      covered_days: Math.max(0, Math.round(Number(coverage.covered_days || dailySummaries.length || 0))),
      missing_dates: Array.isArray(coverage.missing_dates) ? coverage.missing_dates : [],
      incomplete_dates: Array.isArray(coverage.incomplete_dates) ? coverage.incomplete_dates : []
    };
  }
  if (!dailySummaries.length) {
    return null;
  }
  return {
    complete: true,
    expected_days: dailySummaries.length,
    covered_days: dailySummaries.length,
    missing_dates: [],
    incomplete_dates: []
  };
}

function fallbackRecordsForUncoveredDays(records = [], dailySummaries = [], canonicalCoverage = null) {
  if (!dailySummaries.length) {
    return records;
  }
  if (!canonicalCoverage || canonicalCoverage.complete !== false) {
    return [];
  }
  const coveredDays = new Set(dailySummaries.map(dailySummaryDate).filter(Boolean));
  return records.filter((record) => !coveredDays.has(localDateKeyFromMs(record.startMs)));
}

function localDateKeyFromMs(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) {
    return '';
  }
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function minutesToMs(value = {}) {
  return CLASSIFICATION_KEYS.reduce((acc, key) => {
    acc[key] = Number(value[key] || 0) * 60000;
    return acc;
  }, {});
}

function minutes(durationMs) {
  return Math.round(Number(durationMs || 0) / 60000);
}

function isManualRecord(record = {}) {
  return record.source === 'manual' || record.activity_type === 'manual' || record.type === 'manual';
}

function manualClassification(record = {}) {
  const text = `${record.window_title || ''} ${record.ocr_text || ''}`.toLowerCase();
  if (/\b(meeting|call|chat)\b/.test(text)) return 'meeting';
  if (/\b(break|away|idle)\b/.test(text)) return 'other';
  return 'work';
}

function normalizedApp(value = '') {
  return String(value || 'Unknown').replace(/\.exe$/i, '').trim() || 'Unknown';
}

function hostFromRecord(record = {}) {
  const explicit = String(record.url_host || '').trim().toLowerCase();
  if (explicit) {
    return explicit.replace(/^www\./, '');
  }
  try {
    return new URL(record.url_if_available || '').hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

module.exports = {
  buildWeeklyPerformanceEvidence
};
