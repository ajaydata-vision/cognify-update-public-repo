const crypto = require('crypto');
const { normalizeActivity } = require('./activity-schema');

class ActivityStoreComparisonService {
  constructor(leftStore, rightStore, options = {}) {
    this.leftStore = leftStore;
    this.rightStore = rightStore;
    this.leftName = options.leftName || 'left';
    this.rightName = options.rightName || 'right';
  }

  compareRange(startTime, endTime) {
    const leftRecords = this.leftStore.queryRange(startTime, endTime);
    const rightRecords = this.rightStore.queryRange(startTime, endTime);
    const leftSync = this.leftStore.getSyncSummary(startTime, endTime);
    const rightSync = this.rightStore.getSyncSummary(startTime, endTime);
    const leftStats = this._stats(leftRecords, leftSync);
    const rightStats = this._stats(rightRecords, rightSync);
    const recordDiff = this._recordKeyDiff(leftRecords, rightRecords);
    const mismatches = this._mismatches(leftStats, rightStats, recordDiff);

    return {
      ok: mismatches.length === 0,
      startTime,
      endTime,
      left: {
        name: this.leftName,
        ...leftStats
      },
      right: {
        name: this.rightName,
        ...rightStats
      },
      diff: {
        missing_from_right: recordDiff.missingFromRight,
        missing_from_left: recordDiff.missingFromLeft,
        count_delta: rightStats.record_count - leftStats.record_count,
        sync_window_delta: rightStats.sync.window_count - leftStats.sync.window_count,
        classification_minute_delta: this._bucketDelta(leftStats.classified_minutes, rightStats.classified_minutes),
        app_event_delta: this._bucketDelta(leftStats.apps, rightStats.apps),
        host_event_delta: this._bucketDelta(leftStats.hosts, rightStats.hosts)
      },
      mismatches
    };
  }

  _stats(records, sync) {
    const sorted = [...records].sort((left, right) => {
      const timeDelta = new Date(left.timestamp_start).getTime() - new Date(right.timestamp_start).getTime();
      if (timeDelta !== 0) {
        return timeDelta;
      }
      return this._recordIdentity(left).localeCompare(this._recordIdentity(right));
    });
    const apps = {};
    const hosts = {};
    const classifiedMinutes = {
      work: 0,
      meeting: 0,
      social: 0,
      other: 0,
      unclear: 0
    };
    let durationMinutes = 0;

    sorted.forEach((record) => {
      const app = this._key(record.app_name || 'Unknown');
      apps[app] = (apps[app] || 0) + 1;

      const host = this._host(record.url_if_available);
      if (host) {
        hosts[host] = (hosts[host] || 0) + 1;
      }

      const minutes = this._recordMinutes(record);
      durationMinutes += minutes;
      const classification = this._classification(record);
      classifiedMinutes[classification] = (classifiedMinutes[classification] || 0) + minutes;
    });

    return {
      record_count: sorted.length,
      first_timestamp: sorted[0]?.timestamp_start || null,
      last_timestamp: sorted[sorted.length - 1]?.timestamp_start || null,
      record_hash: this._recordHash(sorted),
      estimated_duration_minutes: Math.round(durationMinutes),
      classified_minutes: this._roundBuckets(classifiedMinutes),
      apps,
      hosts,
      sync: {
        complete: Boolean(sync?.complete),
        incomplete_window_count: Number(sync?.incomplete_window_count || 0),
        window_count: Array.isArray(sync?.windows) ? sync.windows.length : 0,
        window_hash: this._syncHash(sync?.windows || [])
      }
    };
  }

  _mismatches(leftStats, rightStats, recordDiff) {
    const mismatches = [];
    this._pushIf(mismatches, leftStats.record_count !== rightStats.record_count, 'record_count', leftStats.record_count, rightStats.record_count);
    this._pushIf(mismatches, leftStats.first_timestamp !== rightStats.first_timestamp, 'first_timestamp', leftStats.first_timestamp, rightStats.first_timestamp);
    this._pushIf(mismatches, leftStats.last_timestamp !== rightStats.last_timestamp, 'last_timestamp', leftStats.last_timestamp, rightStats.last_timestamp);
    this._pushIf(mismatches, leftStats.record_hash !== rightStats.record_hash, 'record_hash', leftStats.record_hash, rightStats.record_hash);
    this._pushIf(mismatches, leftStats.sync.complete !== rightStats.sync.complete, 'sync.complete', leftStats.sync.complete, rightStats.sync.complete);
    this._pushIf(mismatches, leftStats.sync.incomplete_window_count !== rightStats.sync.incomplete_window_count, 'sync.incomplete_window_count', leftStats.sync.incomplete_window_count, rightStats.sync.incomplete_window_count);
    this._pushIf(mismatches, leftStats.sync.window_count !== rightStats.sync.window_count, 'sync.window_count', leftStats.sync.window_count, rightStats.sync.window_count);
    this._pushIf(mismatches, leftStats.sync.window_hash !== rightStats.sync.window_hash, 'sync.window_hash', leftStats.sync.window_hash, rightStats.sync.window_hash);
    this._pushIf(mismatches, recordDiff.missingFromRight.length > 0, 'missing_from_right', 0, recordDiff.missingFromRight.length);
    this._pushIf(mismatches, recordDiff.missingFromLeft.length > 0, 'missing_from_left', 0, recordDiff.missingFromLeft.length);
    return mismatches;
  }

  _pushIf(mismatches, condition, field, left, right) {
    if (condition) {
      mismatches.push({ field, left, right });
    }
  }

  _recordKeyDiff(leftRecords, rightRecords) {
    const leftKeys = new Set(leftRecords.map((record) => this._recordIdentity(record)));
    const rightKeys = new Set(rightRecords.map((record) => this._recordIdentity(record)));
    return {
      missingFromRight: Array.from(leftKeys).filter((key) => !rightKeys.has(key)).slice(0, 25),
      missingFromLeft: Array.from(rightKeys).filter((key) => !leftKeys.has(key)).slice(0, 25)
    };
  }

  _recordIdentity(record) {
    const normalized = normalizeActivity(record);
    return [
      normalized.source || 'screenpipe',
      normalized.id || record.record_key || '',
      normalized.timestamp_start || '',
      normalized.timestamp_end || '',
      normalized.app_name || '',
      normalized.window_title || '',
      normalized.url_if_available || ''
    ].join('|');
  }

  _recordHash(records) {
    const hash = crypto.createHash('sha1');
    records.forEach((record) => {
      const normalized = normalizeActivity(record);
      hash.update(JSON.stringify([
        this._recordIdentity(record),
        normalized.timestamp_start || null,
        normalized.timestamp_end || null,
        normalized.app_name || null,
        normalized.window_title || null,
        normalized.url_if_available || null,
        normalized.activity_type || null
      ]));
      hash.update('\n');
    });
    return hash.digest('hex');
  }

  _syncHash(windows) {
    const hash = crypto.createHash('sha1');
    [...windows]
      .sort((left, right) => [
        left.start_time || '',
        left.end_time || '',
        Number(left.fetched_count || 0),
        Number(left.limit || left.limit_value || 0),
        Number(left.depth || 0)
      ].join('|').localeCompare([
        right.start_time || '',
        right.end_time || '',
        Number(right.fetched_count || 0),
        Number(right.limit || right.limit_value || 0),
        Number(right.depth || 0)
      ].join('|')))
      .forEach((window) => {
        hash.update(JSON.stringify([
          window.start_time || null,
          window.end_time || null,
          Number(window.fetched_count || 0),
          Number(window.limit || window.limit_value || 0),
          Boolean(window.limit_hit),
          Boolean(window.complete),
          Boolean(window.fetch_failed),
          Number(window.depth || 0)
        ]));
        hash.update('\n');
      });
    return hash.digest('hex');
  }

  _classification(record) {
    if (record.meeting_flag || record.classification === 'meeting') {
      return 'meeting';
    }
    if (record.social_flag || record.classification === 'social') {
      return 'social';
    }
    const value = String(record.classification || '').toLowerCase();
    return ['work', 'meeting', 'social', 'other', 'unclear'].includes(value) ? value : 'unclear';
  }

  _recordMinutes(record) {
    const explicit = Number(record.duration_ms_estimate);
    if (Number.isFinite(explicit) && explicit > 0) {
      return explicit / 60000;
    }

    const startMs = new Date(record.timestamp_start).getTime();
    const endMs = new Date(record.timestamp_end || record.timestamp_start).getTime();
    if (Number.isFinite(startMs) && Number.isFinite(endMs) && endMs > startMs) {
      return (endMs - startMs) / 60000;
    }

    return 0;
  }

  _host(url) {
    try {
      return new URL(url).hostname.replace(/^www\./i, '').toLowerCase();
    } catch {
      return null;
    }
  }

  _key(value) {
    return String(value || 'Unknown').trim().toLowerCase() || 'unknown';
  }

  _roundBuckets(buckets) {
    return Object.fromEntries(Object.entries(buckets).map(([key, value]) => [key, Math.round(value)]));
  }

  _bucketDelta(left, right) {
    const keys = new Set([...Object.keys(left || {}), ...Object.keys(right || {})]);
    return Object.fromEntries(Array.from(keys).sort().map((key) => [key, Number(right?.[key] || 0) - Number(left?.[key] || 0)]));
  }
}

module.exports = { ActivityStoreComparisonService };
