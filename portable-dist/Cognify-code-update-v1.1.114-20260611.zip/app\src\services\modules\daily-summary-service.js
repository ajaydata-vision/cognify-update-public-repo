const CLASSIFICATION_KEYS = ['work', 'meeting', 'social', 'other', 'unclear'];
const NON_WORK_OBSERVATION_RULES = [
  {
    category: 'Shopping',
    hosts: ['amazon.', 'flipkart.', 'myntra.', 'ajio.', 'meesho.', 'nykaa.', 'snapdeal.', 'shopclues.'],
    text: /\b(shopping cart|wishlist|checkout|order placed|sale|coupon|myntra|flipkart|amazon|ajio|meesho|nykaa)\b/i
  },
  {
    category: 'Entertainment',
    hosts: ['netflix.', 'primevideo.', 'hotstar.', 'jiocinema.', 'sonyliv.', 'spotify.', 'gaana.', 'wynk.', 'youtube.', 'youtu.be'],
    text: /\b(shorts|trending|song|songs|music video|movie|web series|episode|comedy|standup|trailer|vlog|reels|netflix|prime video|hotstar|jiocinema|spotify)\b/i
  },
  {
    category: 'Social',
    hosts: ['facebook.', 'instagram.', 'threads.', 'x.com', 'twitter.', 'reddit.', 'snapchat.', 'pinterest.', 'tiktok.'],
    text: /\b(facebook|instagram|threads|twitter|reddit|snapchat|pinterest|tiktok|reels|status update)\b/i
  },
  {
    category: 'News',
    hosts: ['ndtv.', 'timesofindia.', 'indiatoday.', 'indianexpress.', 'hindustantimes.', 'news18.', 'bbc.', 'cnn.'],
    text: /\b(breaking news|latest news|politics|cricket news|bollywood news|entertainment news)\b/i
  },
  {
    category: 'Games',
    hosts: ['steampowered.', 'epicgames.', 'roblox.', 'chess.com', 'miniclip.'],
    apps: ['steam.exe', 'epicgameslauncher.exe', 'riotclientservices.exe', 'robloxplayerbeta.exe', 'minecraft.exe'],
    text: /\b(game|gaming|steam|epic games|roblox|minecraft|valorant|pubg|free fire)\b/i
  }
];
const {
  isGenericTerminalTitle,
  isTerminalAppName,
  meaningfulWindowTitle,
  normalizeWindowTitle
} = require('./window-title-normalizer');
const { buildWorkHoursLedger } = require('./work-hours-ledger');

class DailySummaryService {
  constructor(taskExtractionService, workClassificationService = null) {
    this.taskExtractionService = taskExtractionService;
    this.workClassificationService = workClassificationService;
    this.sessionMergeGapMs = 2 * 60 * 1000;
  }

  async generate(contextRecords = [], options = {}) {
    const capturedVisibleRecords = contextRecords.filter((record) => !this._isExcludedAppName(record?.app_name));
    const range = this._resolveRangeBounds(contextRecords, options);
    const rangeDateKey = singleLocalDateKeyForRange(range.startMs, range.endMs);
    const manualRecords = capturedVisibleRecords.filter((record) => (
      this._isManualRecord(record) && manualRecordBelongsToDate(record, rangeDateKey)
    ));
    const pcCapturedRecords = capturedVisibleRecords.filter((record) => !this._isManualRecord(record));
    const rawIdleIntervals = this._normalizeIdleIntervals(options.idleIntervals || [], range.startMs, range.endMs);
    const passiveWorkIntervals = this._normalizePassiveWorkIntervals(options.passiveWorkIntervals || [], range.startMs, range.endMs);
    const idleIntervals = rawIdleIntervals;
    const focusIntervals = this._normalizeFocusIntervals(options.focusIntervals || [], range.startMs, range.endMs);
    const syntheticFocusRecords = this._buildFocusBackedRecords(focusIntervals, pcCapturedRecords, range, options);
    const visibleRecords = pcCapturedRecords.concat(syntheticFocusRecords);
    const apps = [...new Set(visibleRecords.map((r) => r.app_name).filter(Boolean))];
    const websites = this._dedupeUrls(pcCapturedRecords.map((r) => r.url_if_available).filter(Boolean));
    const docs = [...new Set(pcCapturedRecords.map((r) => r.file_path_if_available).filter(Boolean))];
    const browserActivity = this._browserActivity(visibleRecords);
    const tasks = Array.isArray(options.tasks)
      ? options.tasks
      : (options.includeTasks === false ? [] : await this.taskExtractionService.extract(contextRecords, options.taskExtractionLimits || {
        maxRecords: 500,
        maxLines: 1200,
        maxCandidates: 40,
        maxRelatedScanLines: 1200
      }));
    const capturedMinutes = this._estimateCapturedMinutesForRange(pcCapturedRecords, range.startMs, range.endMs);
    const rawEstimatedActiveMinutes = this._estimateActiveMinutesForRange(visibleRecords, range.startMs, range.endMs, idleIntervals, focusIntervals);
    const pcActiveMinuteKeys = this._activeMinuteKeysForRecords(visibleRecords, idleIntervals, focusIntervals, range);
    const manualTimingBlocks = this._manualTimingSummary(manualRecords, {
      rangeStartMs: range.startMs,
      rangeEndMs: range.endMs,
      idleIntervals,
      pcActiveMinuteKeys
    });
    const rawAppTimeline = this._appTimeline(visibleRecords, {
      idleIntervals,
      focusIntervals,
      rangeStartMs: range.startMs,
      rangeEndMs: range.endMs
    });
    const estimatedActiveMinutes = this._reconcileEstimatedActiveMinutes(rawEstimatedActiveMinutes, rawAppTimeline, range.minutes);
    const appTimeline = this._rebalanceAppTimelineMinutes(rawAppTimeline, estimatedActiveMinutes);
    const nonWorkObservations = this._nonWorkObservationSummary(appTimeline);
    const classificationTotals = this._summaryClassificationTotals(appTimeline, estimatedActiveMinutes);
    const focusScore = this._focusScore(classificationTotals, estimatedActiveMinutes);
    const pcMeetings = this._meetingSummary(appTimeline);
    const rawIdleSeconds = this._idleSecondsInRange(rawIdleIntervals);
    const idleSeconds = this._idleSecondsInRange(idleIntervals);
    const idleMinutes = Math.round(idleSeconds / 60);
    const rawInputIdleMinutes = Math.round(rawIdleSeconds / 60);
    const passiveWorkCandidateMinutes = this._intervalMinutes(passiveWorkIntervals);
    // Without runtime availability, fall back only to concrete local evidence.
    const grossPcAvailableMinutes = Math.max(0, Math.min(range.minutes, Math.max(estimatedActiveMinutes + idleMinutes, capturedMinutes)));
    const coverage = this._minuteCoverageSummary({
      rangeMinutes: range.minutes,
      capturedMinutes,
      activeMinutes: estimatedActiveMinutes,
      idleMinutes,
      availableMinutes: grossPcAvailableMinutes
    });
    const pcWorkMinutes = focusScore.deep_work_minutes;
    const pcMessagingMinutes = classificationTotals.meeting;
    const messagingMinutes = pcMessagingMinutes + manualTimingBlocks.meeting_minutes;
    const manualMeetingItems = this._manualMeetingItems(manualTimingBlocks);
    const meetings = {
      ...pcMeetings,
      event_count: Number(pcMeetings.event_count || 0) + manualMeetingItems.length,
      total_minutes: messagingMinutes,
      total_label: this._formatDuration(messagingMinutes),
      items: [
        ...(pcMeetings.items || []),
        ...manualMeetingItems
      ].slice(0, 80)
    };
    const manualNetWorkMinutes = manualTimingBlocks.net_added_minutes;
    const confirmedNonWorkMinutes = this._summaryConfirmedNonWorkMinutes(appTimeline, estimatedActiveMinutes);
    // Work Hours = PC Available - idle + manual work/meeting minutes that overlapped idle slots.
    const workLedger = buildWorkHoursLedger({
      pcAvailableMinutes: grossPcAvailableMinutes,
      idleMinutes: coverage.input_idle_minutes,
      manualAddedMinutes: manualNetWorkMinutes,
      rangeMinutes: range.minutes
    });
    const pcAvailableWorkMinutes = workLedger.pc_available_work_minutes;
    const workMinutes = workLedger.work_minutes;

    return {
      activity_events: visibleRecords.length,
      captured_activity_events: pcCapturedRecords.length,
      focus_backed_activity_events: syntheticFocusRecords.length,
      manual_timing_event_count: manualRecords.length,
      major_work_blocks: this._majorWorkBlocks(visibleRecords),
      apps_used: apps,
      app_display_names: apps.map((app) => this._displayAppName(app)),
      app_timeline: appTimeline,
      websites_visited: websites,
      browser_activity: browserActivity,
      files_documents_seen: docs,
      meetings_or_calls: meetings,
      important_decisions: [],
      tasks_created: tasks,
      pending_follow_ups: tasks,
      pc_available_source: grossPcAvailableMinutes > 0 ? 'local_collector_evidence' : 'none',
      range_start: range.start,
      range_end: range.end,
      range_minutes: range.minutes,
      raw_input_idle_minutes: rawInputIdleMinutes,
      passive_work_candidate_minutes: passiveWorkCandidateMinutes,
      input_idle_minutes: coverage.input_idle_minutes,
      idle_adjusted: idleIntervals.length > 0,
      focus_adjusted: focusIntervals.length > 0,
      focus_evidence: this._focusEvidenceSummary(focusIntervals, range.startMs, range.endMs, syntheticFocusRecords),
      measurement_confidence: this._measurementConfidenceSummary({
        rangeMinutes: range.minutes,
        capturedMinutes,
        activeMinutes: estimatedActiveMinutes,
        inputIdleMinutes: coverage.input_idle_minutes,
        rawInputIdleMinutes,
        passiveWorkCandidateMinutes,
        missingMinutes: coverage.missing_minutes,
        focusBackedRecords: syntheticFocusRecords
      }),
      captured_minutes_estimate: capturedMinutes,
      accounted_minutes: coverage.accounted_minutes,
      gross_pc_available_minutes: grossPcAvailableMinutes,
      missing_minutes: coverage.missing_minutes,
      coverage_complete: coverage.coverage_complete,
      coverage_percent: coverage.coverage_percent,
      minute_partition: coverage.minute_partition,
      passive_candidate_minutes: coverage.passive_candidate_minutes,
      estimated_active_minutes: estimatedActiveMinutes,
      estimated_active_label: this._formatDuration(estimatedActiveMinutes),
      pc_work_minutes: pcWorkMinutes,
      pc_messaging_minutes: pcMessagingMinutes,
      messaging_minutes: messagingMinutes,
      confirmed_non_work_minutes: confirmedNonWorkMinutes,
      manual_timing_blocks: manualTimingBlocks,
      manual_timing_minutes: manualTimingBlocks.total_minutes,
      manual_net_added_work_minutes: workLedger.manual_restored_minutes,
      work_minutes: workMinutes,
      work_label: this._formatDuration(workMinutes),
      work_minutes_breakdown: {
        pc_work_minutes: pcWorkMinutes,
        pc_messaging_minutes: pcMessagingMinutes,
        pc_active_work_minutes: pcAvailableWorkMinutes,
        gross_pc_available_minutes: workLedger.pc_available_minutes,
        idle_minutes: workLedger.idle_deducted_minutes,
        confirmed_non_work_minutes: confirmedNonWorkMinutes,
        manual_net_added_minutes: workLedger.manual_restored_minutes,
        total_work_minutes: workMinutes
      },
      pc_classified_minutes: classificationTotals,
      classified_minutes: classificationTotals,
      focus_score: focusScore,
      time_distribution_estimate: this._distributionByApp(contextRecords),
      non_work_observations: nonWorkObservations,
      possible_distractions: websites.filter((url) => /youtube|reddit|x.com|facebook/.test(url)),
      recommended_next_actions: tasks.slice(0, 5).map((task) => `Follow up: ${task.task_title}`)
    };
  }

  _minuteCoverageSummary({ rangeMinutes = 0, capturedMinutes = 0, activeMinutes = 0, idleMinutes = 0, availableMinutes = 0 } = {}) {
    const range = Math.max(0, Math.round(Number(rangeMinutes) || 0));
    const active = Math.min(range, Math.max(0, Math.round(Number(activeMinutes) || 0)));
    const idle = Math.min(
      Math.max(0, Math.round(Number(idleMinutes) || 0)),
      Math.max(0, range - active)
    );
    const captured = Math.min(range, Math.max(0, Math.round(Number(capturedMinutes) || 0)));
    const available = Math.min(range, Math.max(0, Math.round(Number(availableMinutes) || 0)));
    const accounted = Math.min(range, Math.max(captured, active + idle, available));
    const passive = Math.max(0, accounted - active - idle);
    const missing = Math.max(0, range - accounted);

    return {
      accounted_minutes: accounted,
      gross_pc_available_minutes: available,
      active_minutes: active,
      passive_candidate_minutes: passive,
      input_idle_minutes: idle,
      missing_minutes: missing,
      coverage_complete: range > 0 && missing === 0,
      coverage_percent: range > 0 ? Math.min(100, Math.round((accounted / range) * 100)) : 0,
      minute_partition: {
        active_minutes: active,
        passive_candidate_minutes: passive,
        input_idle_minutes: idle,
        missing_minutes: missing
      }
    };
  }

  _distributionByApp(records) {
    const bins = {};
    records.forEach((r) => {
      if (this._isExcludedAppName(r?.app_name)) {
        return;
      }

      const key = r.app_name || 'Unknown';
      bins[key] = (bins[key] || 0) + 1;
    });
    return bins;
  }

  _majorWorkBlocks(records) {
    return records
      .filter((record) => !this._isExcludedAppName(record?.app_name))
      .slice(0, 8)
      .map((r) => ({
      start: r.timestamp_start,
      end: r.timestamp_end,
      app: this._displayAppName(r.app_name),
      title: r.window_title
      }));
  }

  _appTimeline(records, options = {}) {
    const groups = new Map();
    const orderedRecords = [...records]
      .filter((record) => record && record.timestamp_start && !this._isExcludedAppName(record.app_name))
      .sort((a, b) => new Date(a.timestamp_start).getTime() - new Date(b.timestamp_start).getTime());

    const sessionsByApp = this._buildAppSessions(orderedRecords, options);

    orderedRecords.forEach((record) => {
      const key = record.app_name || 'Unknown';
      if (!groups.has(key)) {
        groups.set(key, {
          app_id: key,
          app_name: this._displayAppName(key),
          dates: new Set(),
          event_count: 0,
          items: [],
          timestamps: []
        });
      }

      const group = groups.get(key);
      group.event_count += 1;

      if (record.timestamp_start) {
        group.dates.add(String(record.timestamp_start).slice(0, 10));
        group.timestamps.push(record.timestamp_start);
      }
    });

    const timeline = Array.from(groups.values())
      .map((group) => {
        const sessions = this._collapseSessionsByTitle(sessionsByApp.get(group.app_id) || []).slice(0, 24);
        const totalMs = sessions.reduce((sum, session) => sum + Number(session.duration_ms_estimate || 0), 0);
        const classifiedMs = this._classificationBucketsFromSessions(sessions);
        const evidenceScores = this._classificationEvidenceFromSessions(sessions);
        const confirmedNonWorkMs = this._confirmedNonWorkMsFromSessions(sessions);

        return {
          app_id: group.app_id,
          app_name: group.app_name,
          dates: Array.from(group.dates),
          event_count: group.event_count,
          total_time_ms_estimate: totalMs,
          total_time_minutes_estimate: 0,
          total_time_label: '0m',
          classified_ms: classifiedMs,
          confirmed_non_work_ms: confirmedNonWorkMs,
          classification_evidence: evidenceScores,
          classified_minutes: {
            ...this._emptyClassifiedMs()
          },
          items: sessions
        };
      })
      .sort((a, b) => b.event_count - a.event_count);

    const distributedMinutes = this._distributeRoundedMinutes(timeline.map((group) => group.total_time_ms_estimate || 0));

    return timeline.map((group, index) => {
      const totalMinutes = distributedMinutes[index] || 0;
      const classifiedMinutes = this._rebalanceClassificationMinutes(group.classified_ms || {}, totalMinutes);
      const classification = this._dominantClassification(group.classification_evidence || group.classified_ms || {});
      const confirmedNonWorkMinutes = this._confirmedNonWorkMinutesFromMs(group.confirmed_non_work_ms, totalMinutes);
      return {
        ...group,
        classification: classification.classification,
        classification_confidence: classification.confidence,
        total_time_minutes_estimate: totalMinutes,
        total_time_label: this._formatDuration(totalMinutes),
        confirmed_non_work_minutes: confirmedNonWorkMinutes,
        classified_minutes: classifiedMinutes
      };
    }).filter((group) => Number(group.total_time_minutes_estimate || 0) > 0);
  }

  _buildAppSessions(records, options = {}) {
    const sessionsByApp = new Map();
    let currentSession = null;
    const allocationWindows = this._buildRecordAllocationWindows(records, options.idleIntervals || [], {
      focusIntervals: options.focusIntervals || [],
      rangeStartMs: options.rangeStartMs,
      rangeEndMs: options.rangeEndMs
    });

    records.forEach((record, index) => {
      if (this._isIgnorableInterruption(record) || this._isExcludedAppName(record?.app_name)) {
        return;
      }

      const appId = record.app_name || 'Unknown';
      const title = this._sessionTitle(record);
      const urlIdentity = this._sessionUrlIdentityForRecord(record);
      const timestamp = record.timestamp_start;
      const timestampMs = new Date(timestamp).getTime();
      const eventClassification = this._classifyRecord(record);

      if (!Number.isFinite(timestampMs) || !title) {
        return;
      }

      if (
        !currentSession ||
        currentSession.app_id !== appId ||
        currentSession.title !== title ||
        currentSession.url_identity !== urlIdentity ||
        (timestampMs - currentSession.endMs) > this.sessionMergeGapMs
      ) {
        currentSession = {
          app_id: appId,
          title,
          url_identity: urlIdentity,
          start: timestamp,
          end: timestamp,
          startMs: timestampMs,
          endMs: timestampMs,
          timestamps: [timestampMs],
          urls: this._sessionUrlsForRecord(record),
          texts: this._sessionTextsForRecord(record),
          transcripts: this._sessionTranscriptsForRecord(record),
          event_count: 1,
          allocated_ms: 0,
          classified_ms: this._emptyClassifiedMs(),
          confirmed_non_work_ms: 0,
          matched_rules: [],
          matched_rule_details: [],
          classification_confidences: [],
          classification_evidence: this._emptyClassifiedMs()
        };

        if (!sessionsByApp.has(appId)) {
          sessionsByApp.set(appId, []);
        }

        sessionsByApp.get(appId).push(currentSession);
      } else {
        currentSession.end = timestamp;
        currentSession.endMs = timestampMs;
        currentSession.timestamps.push(timestampMs);
        currentSession.urls.push(...this._sessionUrlsForRecord(record));
        currentSession.texts.push(...this._sessionTextsForRecord(record));
        currentSession.transcripts.push(...this._sessionTranscriptsForRecord(record));
        currentSession.event_count += 1;
      }

      const allocatedMs = allocationWindows[index]?.active_ms || 0;
      if (allocatedMs <= 0) {
        return;
      }
      currentSession.allocated_ms += allocatedMs;
      const classificationKey = this._classificationKey(eventClassification.classification);
      currentSession.classified_ms[classificationKey] += allocatedMs;
      if (this._isConfirmedNonWorkClassification(eventClassification)) {
        currentSession.confirmed_non_work_ms += allocatedMs;
      }
      currentSession.classification_evidence[classificationKey] += this._classificationEvidenceScore(eventClassification, allocatedMs);
      currentSession.matched_rules = this._mergeMatchedRules(currentSession.matched_rules, eventClassification.matched_rules || []);
      currentSession.matched_rule_details = this._mergeMatchedRuleDetails(currentSession.matched_rule_details, eventClassification.matched_rule_details || []);
      if (eventClassification.confidence) {
        currentSession.classification_confidences.push(eventClassification.confidence);
      }
    });

    return new Map(
      Array.from(sessionsByApp.entries()).map(([appId, sessions]) => ([
        appId,
        this._mergeNearbySessions(sessions)
          .map((session) => {
            const durationMinutes = this._roundMinutes(session.allocated_ms || 0);
            const classification = this._classifySession(session);

            return {
              timestamp: session.start,
              title: session.title.slice(0, 220),
              event_count: session.event_count,
              duration_ms_estimate: session.allocated_ms || 0,
              duration_minutes_estimate: durationMinutes,
              duration_label: this._formatDuration(durationMinutes),
              classification: classification.classification,
              classification_confidence: classification.confidence,
              classified_ms: session.classified_ms || this._emptyClassifiedMs(),
              confirmed_non_work_ms: session.confirmed_non_work_ms || 0,
              confirmed_non_work_minutes: this._confirmedNonWorkMinutesFromMs(session.confirmed_non_work_ms || 0, durationMinutes),
              classification_evidence: session.classification_evidence || this._emptyClassifiedMs(),
              matched_rules: classification.matched_rules || [],
              matched_rule_details: classification.matched_rule_details || [],
              latest_url: this._latestSessionUrl(session.urls),
              captured_urls: this._collapseSessionUrls(session.urls).slice(0, 5)
            };
          })
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      ]))
    );
  }

  _mergeNearbySessions(sessions = []) {
    if (sessions.length <= 1) {
      return sessions;
    }

    const merged = [sessions[0]];

    for (let i = 1; i < sessions.length; i += 1) {
      const current = sessions[i];
      const previous = merged[merged.length - 1];
      const gapMs = current.startMs - previous.endMs;

      if (
        previous.app_id === current.app_id &&
        previous.title === current.title &&
        previous.url_identity === current.url_identity &&
        gapMs >= 0 &&
        gapMs <= this.sessionMergeGapMs
      ) {
        previous.end = current.end;
        previous.endMs = current.endMs;
        previous.timestamps.push(...current.timestamps);
        previous.urls.push(...current.urls);
        previous.texts.push(...current.texts);
        previous.transcripts.push(...current.transcripts);
        previous.event_count += current.event_count;
        previous.allocated_ms += current.allocated_ms || 0;
        previous.classified_ms = this._mergeClassifiedMs(previous.classified_ms, current.classified_ms);
        previous.confirmed_non_work_ms += Number(current.confirmed_non_work_ms || 0);
        previous.classification_evidence = this._mergeClassifiedMs(previous.classification_evidence, current.classification_evidence);
        previous.matched_rules = this._mergeMatchedRules(previous.matched_rules, current.matched_rules || []);
        previous.matched_rule_details = this._mergeMatchedRuleDetails(previous.matched_rule_details, current.matched_rule_details || []);
        previous.classification_confidences.push(...(current.classification_confidences || []));
        continue;
      }

      merged.push(current);
    }

    return merged;
  }

  _collapseSessionsByTitle(sessions = []) {
    const grouped = new Map();

    sessions.forEach((session) => {
      const key = `${session.title}\n${session.latest_url || session.url_identity || ''}`;
      if (!grouped.has(key)) {
        grouped.set(key, {
          timestamp: session.timestamp,
          title: session.title,
          event_count: 0,
          duration_ms_estimate: 0,
          duration_minutes_estimate: 0,
          session_count: 0,
          classified_ms: this._emptyClassifiedMs(),
          confirmed_non_work_ms: 0,
          classification: 'unclear',
          classification_confidence: 'low',
          matched_rules: [],
          matched_rule_details: [],
          classification_evidence: this._emptyClassifiedMs(),
          latest_url: null,
          captured_urls: []
        });
      }

      const entry = grouped.get(key);
      if (new Date(session.timestamp).getTime() > new Date(entry.timestamp).getTime()) {
        entry.timestamp = session.timestamp;
      }

      entry.event_count += session.event_count || 0;
      entry.duration_ms_estimate += session.duration_ms_estimate || 0;
      entry.duration_minutes_estimate += session.duration_minutes_estimate || 0;
      entry.session_count += 1;
      entry.classified_ms = this._mergeClassifiedMs(entry.classified_ms, session.classified_ms || {
        [session.classification || 'unclear']: session.duration_ms_estimate || 0
      });
      entry.confirmed_non_work_ms += Number(session.confirmed_non_work_ms || 0);
      entry.classification_evidence = this._mergeClassifiedMs(entry.classification_evidence, session.classification_evidence || {});
      entry.captured_urls = this._mergeCapturedUrls(entry.captured_urls, session.captured_urls || []);
      entry.latest_url = entry.captured_urls[0]?.url || entry.latest_url;
      entry.matched_rules = this._mergeMatchedRules(entry.matched_rules, session.matched_rules || []);
      entry.matched_rule_details = this._mergeMatchedRuleDetails(entry.matched_rule_details, session.matched_rule_details || []);
    });

    return Array.from(grouped.values())
      .map((entry) => {
        const durationMinutes = this._roundMinutes(entry.duration_ms_estimate || 0);
        const classification = this._dominantClassification(entry.classification_evidence || entry.classified_ms);
        const confirmedNonWorkMinutes = this._confirmedNonWorkMinutesFromMs(entry.confirmed_non_work_ms, durationMinutes);
        return {
          ...entry,
          classification: classification.classification,
          classification_confidence: classification.confidence,
          duration_minutes_estimate: durationMinutes,
          duration_label: this._formatDuration(durationMinutes),
          confirmed_non_work_minutes: confirmedNonWorkMinutes,
          classified_minutes: this._rebalanceClassificationMinutes(entry.classified_ms, durationMinutes)
        };
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  _sessionTitle(record) {
    const rawTitle = this._meaningfulTerminalTitle(record) || meaningfulWindowTitle(record) || record.url_if_available || record.ocr_text || '';
    return this._normalizeSessionTitle(rawTitle);
  }

  _meaningfulTerminalTitle(record = {}) {
    const title = meaningfulWindowTitle(record);
    if (!isTerminalAppName(record.app_name) && !/(terminal|powershell|cmd)/i.test(title)) {
      return '';
    }
    if (title && !isGenericTerminalTitle(title)) {
      return title;
    }
    const ocr = String(record.ocr_text || '');
    const candidates = [];
    const tabMatches = ocr.match(/([A-Za-z0-9][A-Za-z0-9 ._:/\\-]{3,80}?)\s+Close Tab/g) || [];
    tabMatches.forEach((match) => candidates.push(match.replace(/\s+Close Tab$/i, '').trim()));
    ocr.split(/\s{2,}|\||\n/).forEach((part) => candidates.push(part.trim()));
    return candidates
      .map((candidate) => normalizeWindowTitle(candidate))
      .find((candidate) => (
        candidate &&
        !/^(windows powershell|powershell|terminal|cmd|system|minimize|maximize|close|restore)$/i.test(candidate) &&
        !/^c:\\windows\\system32\\cmd\.exe$/i.test(candidate) &&
        candidate.length >= 4 &&
        candidate.length <= 80
      )) || '';
  }

  _sessionUrlsForRecord(record) {
    if (!record?.url_if_available || !record?.timestamp_start) {
      return [];
    }

    return [{
      url: record.url_if_available,
      timestamp: record.timestamp_start
    }];
  }

  _sessionUrlIdentityForRecord(record) {
    if (!this._isBrowserRecord(record) || !record?.url_if_available) {
      return '';
    }

    return this._normalizeUrl(record.url_if_available) || String(record.url_if_available);
  }

  _sessionTextsForRecord(record) {
    if (!record?.ocr_text) {
      return [];
    }

    return [String(record.ocr_text).slice(0, 240)];
  }

  _sessionTranscriptsForRecord(record) {
    if (!record?.transcript_text) {
      return [];
    }

    return [String(record.transcript_text).slice(0, 240)];
  }

  _collapseSessionUrls(urls = []) {
    const deduped = new Map();

    urls.forEach((entry) => {
      if (!entry?.url || !entry?.timestamp) {
        return;
      }

      const current = deduped.get(entry.url);
      if (!current || new Date(entry.timestamp).getTime() > new Date(current.timestamp).getTime()) {
        deduped.set(entry.url, {
          url: entry.url,
          timestamp: entry.timestamp
        });
      }
    });

    return Array.from(deduped.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  _mergeCapturedUrls(existing = [], incoming = []) {
    return this._collapseSessionUrls([...existing, ...incoming]).slice(0, 5);
  }

  _latestSessionUrl(urls = []) {
    return this._collapseSessionUrls(urls)[0]?.url || null;
  }

  _normalizeSessionTitle(value) {
    if (!value) {
      return '';
    }

    const normalized = String(value)
      .replace(/^[\s\p{P}\p{S}\uFE0F]+/gu, '')
      .replace(/\s+/g, ' ')
      .trim();

    return normalized;
  }

  _isIgnorableInterruption(record) {
    const appName = String(record?.app_name || '').toLowerCase();
    const title = String(record?.window_title || record?.window_name || '').toLowerCase();

    return appName === 'electron.exe' && (title.includes('screenpipe-companion-mvp') || title.includes('cognify'));
  }

  _isExcludedAppName(appName) {
    const normalized = String(appName || '').trim().toLowerCase().replace(/^\[|\]$/g, '');
    return normalized === 'system process';
  }

  _estimateSessionMinutes(session) {
    if (!session?.timestamps?.length) {
      return 0;
    }

    return this._estimateMinutes(session.timestamps);
  }

  _classifySession(session) {
    const dominant = this._dominantClassification(session.classification_evidence || session.classified_ms || {});
    if (session.classified_ms && Object.values(session.classified_ms).some((value) => Number(value) > 0)) {
      return {
        classification: dominant.classification,
        confidence: dominant.classification === 'unclear' ? dominant.confidence : this._confidenceForSession(session, dominant.confidence),
        matched_rules: session.matched_rules || [],
        matched_rule_details: session.matched_rule_details || []
      };
    }

    if (!this.workClassificationService) {
      return {
        classification: 'unclear',
        confidence: 'low',
        matched_rules: [],
        matched_rule_details: []
      };
    }

    return this.workClassificationService.classifyRecord({
      app_name: session.app_id,
      window_title: session.title,
      url_if_available: this._latestSessionUrl(session.urls),
      ocr_text: (session.texts || []).slice(0, 3).join(' '),
      transcript_text: (session.transcripts || []).slice(0, 2).join(' ')
    });
  }

  _classifyRecord(record) {
    if (!this.workClassificationService) {
      return {
        classification: 'unclear',
        confidence: 'low',
        matched_rules: [],
        matched_rule_details: []
      };
    }

    return this.workClassificationService.classifyRecord(record);
  }

  _buildRecordAllocations(records = []) {
    return this._buildRecordAllocationWindows(records).map((window) => window.active_ms);
  }

  _buildRecordAllocationWindows(records = [], idleIntervals = [], options = {}) {
    const rangeStartMs = Number(options.rangeStartMs);
    const rawRangeEndMs = Number(options.rangeEndMs);
    const rangeEndMs = Number.isFinite(rangeStartMs) && Number.isFinite(rawRangeEndMs) && rawRangeEndMs <= rangeStartMs
      ? rangeStartMs + 60000
      : rawRangeEndMs;
    const hasRangeStart = Number.isFinite(rangeStartMs);
    const hasRangeEnd = Number.isFinite(rangeEndMs);
    const values = records.map((record) => new Date(record?.timestamp_start).getTime());
    const windows = records.map((record, index) => {
      const startMs = values[index];
      const explicitDurationMs = Number(record?.duration_ms_estimate || 0);
      const explicitEndMs = new Date(record?.timestamp_end || 0).getTime();
      const hasExplicitDuration = (this._isManualRecord(record) || this._isFocusBackedRecord(record)) && (
        explicitDurationMs > 0 ||
        (Number.isFinite(explicitEndMs) && Number.isFinite(startMs) && explicitEndMs > startMs)
      );
      const endMs = hasExplicitDuration
        ? Math.max(
          Number.isFinite(explicitEndMs) ? explicitEndMs : startMs,
          startMs + Math.max(0, explicitDurationMs)
        )
        : startMs;
      return {
        startMs,
        endMs,
        record,
        gross_ms: hasExplicitDuration && Number.isFinite(startMs) && Number.isFinite(endMs)
          ? Math.max(0, endMs - startMs)
          : 0,
        idle_ms: 0,
        active_ms: 0,
        skip_idle_deduction: this._isManualRecord(record)
      };
    });
    const clipWindowsToRange = () => {
      windows.forEach((window) => {
        if (!Number.isFinite(window.startMs) || !Number.isFinite(window.endMs)) {
          window.gross_ms = 0;
          return;
        }
        if (hasRangeStart) {
          window.startMs = Math.max(window.startMs, rangeStartMs);
        }
        if (hasRangeEnd) {
          window.endMs = Math.min(window.endMs, rangeEndMs);
        }
        window.gross_ms = Math.max(0, window.endMs - window.startMs);
      });
    };

    if (!values.length) {
      return windows;
    }

    if (values.length === 1) {
      if (Number.isFinite(values[0]) && !windows[0].skip_idle_deduction) {
        windows[0].startMs = values[0];
        windows[0].endMs = values[0] + 30000;
        windows[0].gross_ms = 30000;
      }
      clipWindowsToRange();
      return this._applyFocusToAllocationWindows(
        this._applyIdleToAllocationWindows(windows, idleIntervals),
        options.focusIntervals || []
      );
    }

    if (Number.isFinite(values[0]) && !windows[0].skip_idle_deduction) {
      windows[0].startMs = Math.min(windows[0].startMs, values[0] - 15000);
      windows[0].endMs = Math.max(windows[0].endMs, values[0]);
    }

    if (Number.isFinite(values[values.length - 1])) {
      const last = windows[windows.length - 1];
      if (!last.skip_idle_deduction) {
        last.startMs = Math.min(last.startMs, values[values.length - 1]);
        last.endMs = Math.max(last.endMs, values[values.length - 1] + 15000);
      }
    }

    for (let i = 0; i < values.length - 1; i += 1) {
      const current = values[i];
      const next = values[i + 1];
      if (!Number.isFinite(current) || !Number.isFinite(next)) {
        continue;
      }

      if (!windows[i].skip_idle_deduction && !windows[i + 1].skip_idle_deduction) {
        const gapMs = Math.min(Math.max(0, next - current), 120000);
        const leftShare = Math.floor(gapMs / 2);
        const rightShare = gapMs - leftShare;
        windows[i].endMs = Math.max(windows[i].endMs, current + leftShare);
        windows[i + 1].startMs = Math.min(windows[i + 1].startMs, next - rightShare);
      }
    }

    windows.forEach((window) => {
      if (window.skip_idle_deduction) {
        return;
      }
      window.gross_ms = Number.isFinite(window.startMs) && Number.isFinite(window.endMs)
        ? Math.max(0, window.endMs - window.startMs)
        : 0;
    });
    clipWindowsToRange();

    return this._applyFocusToAllocationWindows(
      this._applyIdleToAllocationWindows(windows, idleIntervals),
      options.focusIntervals || []
    );
  }

  _resolveRangeBounds(records = [], options = {}) {
    const timestamps = records
      .flatMap((record) => [record?.timestamp_start, record?.timestamp_end])
      .map((value) => new Date(value).getTime())
      .filter((value) => Number.isFinite(value))
      .sort((a, b) => a - b);

    const optionStartValue = options.startTime || options.rangeStart;
    const optionEndValue = options.endTime || options.rangeEnd;
    const optionStartMs = optionStartValue ? new Date(optionStartValue).getTime() : Number.NaN;
    const optionEndMs = optionEndValue ? new Date(optionEndValue).getTime() : Number.NaN;
    const derivedStartMs = timestamps[0];
    const derivedEndMs = timestamps[timestamps.length - 1];
    const startMs = Number.isFinite(optionStartMs) ? optionStartMs : derivedStartMs;
    const endMs = Number.isFinite(optionEndMs) ? optionEndMs : derivedEndMs;

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return {
        start: null,
        end: null,
        startMs: null,
        endMs: null,
        minutes: 0
      };
    }

    return {
      start: new Date(startMs).toISOString(),
      end: new Date(endMs).toISOString(),
      startMs,
      endMs,
      minutes: Math.max(1, Math.round((endMs - startMs) / 60000))
    };
  }

  _estimateActiveMinutesForRange(records = [], startMs, endMs, idleIntervals = [], focusIntervals = []) {
    const allocationWindows = this._buildRecordAllocationWindows(
      records
        .filter((record) => record && record.timestamp_start && !this._isExcludedAppName(record.app_name))
        .sort((a, b) => new Date(a.timestamp_start).getTime() - new Date(b.timestamp_start).getTime()),
      idleIntervals,
      { focusIntervals, rangeStartMs: startMs, rangeEndMs: endMs }
    );
    const estimatedMinutes = this._roundMinutes(allocationWindows.reduce((sum, window) => sum + Number(window.active_ms || 0), 0));

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return estimatedMinutes;
    }

    const rangeMinutes = Math.max(1, Math.round((endMs - startMs) / 60000));
    return Math.min(estimatedMinutes, rangeMinutes);
  }

  _estimateCapturedMinutesForRange(records = [], startMs, endMs) {
    const allocationWindows = this._buildRecordAllocationWindows(
      records
        .filter((record) => record && record.timestamp_start && !this._isExcludedAppName(record.app_name))
        .sort((a, b) => new Date(a.timestamp_start).getTime() - new Date(b.timestamp_start).getTime()),
      [],
      { rangeStartMs: startMs, rangeEndMs: endMs }
    );
    const estimatedMinutes = this._roundMinutes(allocationWindows.reduce((sum, window) => sum + Number(window.gross_ms || 0), 0));

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return estimatedMinutes;
    }

    const rangeMinutes = Math.max(1, Math.round((endMs - startMs) / 60000));
    return Math.min(estimatedMinutes, rangeMinutes);
  }

  _activeMinuteKeysForRecords(records = [], idleIntervals = [], focusIntervals = [], range = {}) {
    const windows = this._buildRecordAllocationWindows(
      records
        .filter((record) => record && record.timestamp_start && !this._isExcludedAppName(record.app_name))
        .sort((a, b) => new Date(a.timestamp_start).getTime() - new Date(b.timestamp_start).getTime()),
      idleIntervals,
      { focusIntervals, rangeStartMs: range.startMs, rangeEndMs: range.endMs }
    );
    const keys = new Set();

    windows.forEach((window) => {
      if (Number(window.active_ms || 0) <= 0) {
        return;
      }
      this._minuteKeysForInterval(window.startMs, window.endMs).forEach((minute) => {
        const minuteEndMs = minute.startMs + 60000;
        const grossOverlapMs = this._overlapMs(minute.startMs, minuteEndMs, [window]);
        if (grossOverlapMs <= 0) {
          return;
        }
        const idleOverlapMs = this._overlapMs(minute.startMs, minuteEndMs, idleIntervals);
        const focusMismatchMs = this._focusMismatchOverlapMs(window.record, minute.startMs, minuteEndMs, focusIntervals);
        const activeOverlapMs = Math.max(0, grossOverlapMs - idleOverlapMs - focusMismatchMs);
        if (activeOverlapMs >= 30000) {
          keys.add(minute.key);
        }
      });
    });

    return keys;
  }

  _manualTimingSummary(records = [], options = {}) {
    const rangeStartMs = Number(options.rangeStartMs);
    const rangeEndMs = Number(options.rangeEndMs);
    const idleIntervals = options.idleIntervals || [];
    const pcActiveMinuteKeys = options.pcActiveMinuteKeys || new Set();
    const kindMinutes = {
      work: new Set(),
      meeting: new Set(),
      break: new Set(),
      other: new Set()
    };
    const allManualMinutes = new Set();
    const netWorkMinutes = new Set();
    const netMeetingMinutes = new Set();
    const overlappingPcMinutes = new Set();
    const idleOverlapMinutes = new Set();
    const items = [];

    records.forEach((record) => {
      const interval = this._recordIntervalMs(record);
      if (!Number.isFinite(interval.startMs) || !Number.isFinite(interval.endMs) || interval.endMs <= interval.startMs) {
        return;
      }

      const startMs = Number.isFinite(rangeStartMs) ? Math.max(interval.startMs, rangeStartMs) : interval.startMs;
      const endMs = Number.isFinite(rangeEndMs) ? Math.min(interval.endMs, rangeEndMs) : interval.endMs;
      if (endMs <= startMs) {
        return;
      }

      const kind = this._manualRecordKind(record);
      const minuteKeys = this._minuteKeysForInterval(startMs, endMs)
        .filter((minute) => this._overlapMs(minute.startMs, minute.startMs + 60000, [{ startMs, endMs }]) >= 30000)
        .map((minute) => minute.key);
      minuteKeys.forEach((key) => {
        allManualMinutes.add(key);
        kindMinutes[kind].add(key);
        const overlapsIdle = this._minuteOverlapsIntervals(key, idleIntervals);
        if (pcActiveMinuteKeys.has(key)) {
          overlappingPcMinutes.add(key);
        }
        if (overlapsIdle) {
          idleOverlapMinutes.add(key);
        }
        if (kind === 'work' && overlapsIdle) {
          netWorkMinutes.add(key);
        }
        if (kind === 'meeting' && overlapsIdle) {
          netMeetingMinutes.add(key);
        }
      });
      items.push({
        start: new Date(startMs).toISOString(),
        end: new Date(endMs).toISOString(),
        kind,
        title: record.window_title || record.ocr_text || record.app_name || 'Manual Timing Block',
        minutes: minuteKeys.length,
        net_added_minutes: minuteKeys.filter((key) => (
          (kind === 'work' || kind === 'meeting') && this._minuteOverlapsIntervals(key, idleIntervals)
        )).length,
        overlapping_pc_active_minutes: minuteKeys.filter((key) => pcActiveMinuteKeys.has(key)).length
      });
    });

    return {
      event_count: records.length,
      total_minutes: allManualMinutes.size,
      work_minutes: kindMinutes.work.size,
      meeting_minutes: kindMinutes.meeting.size,
      break_minutes: kindMinutes.break.size,
      other_minutes: kindMinutes.other.size,
      net_added_work_minutes: netWorkMinutes.size,
      net_added_meeting_minutes: netMeetingMinutes.size,
      net_added_minutes: netWorkMinutes.size + netMeetingMinutes.size,
      overlapping_pc_active_minutes: overlappingPcMinutes.size,
      idle_overlap_minutes: idleOverlapMinutes.size,
      items
    };
  }

  _manualMeetingItems(blocks = {}) {
    return (blocks.items || [])
      .filter((item) => item?.kind === 'meeting')
      .map((item) => ({
        title: item.title || 'Manual Meeting',
        start: item.start || null,
        end: item.end || null,
        minutes: Number(item.minutes || 0),
        total_time_minutes_estimate: Number(item.minutes || 0),
        net_added_minutes: Number(item.net_added_minutes || 0),
        source: 'manual',
        manual: true
      }))
      .filter((item) => item.minutes > 0)
      .slice(0, 80);
  }

  _reconcileEstimatedActiveMinutes(estimatedMinutes = 0, appTimeline = [], rangeMinutes = 0) {
    const positiveClassificationBuckets = new Set();
    appTimeline.forEach((group) => {
      CLASSIFICATION_KEYS.forEach((key) => {
        if (Number(group.classified_ms?.[key] || 0) > 0) {
          positiveClassificationBuckets.add(key);
        }
      });
    });

    const minimumUsefulMinutes = positiveClassificationBuckets.size;
    const rangeCap = Math.max(0, Math.round(Number(rangeMinutes) || 0));
    const reconciled = Math.max(
      Math.max(0, Math.round(Number(estimatedMinutes) || 0)),
      minimumUsefulMinutes
    );
    return rangeCap > 0 ? Math.min(reconciled, rangeCap) : reconciled;
  }

  _browserActivity(records) {
    const browserRecords = records.filter((record) => this._isBrowserRecord(record));
    const sites = this._dedupeUrls(browserRecords.map((record) => record.url_if_available).filter(Boolean));
    const windows = [...new Set(browserRecords.map((record) => record.window_title).filter(Boolean))];
    const apps = [...new Set(browserRecords.map((record) => record.app_name).filter(Boolean))];

    return {
      event_count: browserRecords.length,
      apps_used: apps,
      browser_names: apps.map((app) => this._displayAppName(app)),
      sites,
      windows: windows.slice(0, 20),
      recent_events: browserRecords.slice(0, 10).map((record) => ({
        timestamp: record.timestamp_start,
        app: this._displayAppName(record.app_name),
        title: record.window_title,
        url: record.url_if_available
      }))
    };
  }

  _meetingSummary(appTimeline = []) {
    const rows = [];

    appTimeline.forEach((group) => {
      (group.items || []).forEach((item) => {
        const meetingMs = Number(item.classified_ms?.meeting || 0);
        if (item.classification !== 'meeting' && meetingMs <= 0) {
          return;
        }

        rows.push({
          timestamp: item.timestamp,
          title: item.title,
          app: group.app_name,
          duration_ms_estimate: item.duration_ms_estimate || meetingMs,
          duration_minutes_estimate: item.duration_minutes_estimate || this._roundMinutes(meetingMs),
          duration_label: item.duration_label || this._formatDuration(this._roundMinutes(meetingMs)),
          latest_url: item.latest_url,
          captured_urls: item.captured_urls || []
        });
      });
    });

    const totalMinutes = rows.reduce((sum, row) => sum + Number(row.duration_minutes_estimate || 0), 0);
    return {
      event_count: rows.length,
      total_minutes: totalMinutes,
      total_label: this._formatDuration(totalMinutes),
      items: rows
    };
  }

  _nonWorkObservationSummary(appTimeline = []) {
    const byKey = new Map();

    appTimeline.forEach((group) => {
      (group.items || []).forEach((item) => {
        const observation = this._detectNonWorkObservation({
          appName: group.app_name || group.app_id || '',
          title: item.title || '',
          url: item.latest_url || item.captured_urls?.[0]?.url || ''
        });
        const minutes = Math.max(0, Math.round(Number(item.duration_minutes_estimate || 0)));
        if (!observation || minutes <= 0) {
          return;
        }
        const key = `${observation.category}|${group.app_name || group.app_id || ''}|${item.title || ''}|${observation.host || ''}`;
        if (!byKey.has(key)) {
          byKey.set(key, {
            category: observation.category,
            app_name: group.app_name || group.app_id || 'Unknown',
            title: item.title || 'Untitled',
            host: observation.host || '',
            rule: observation.rule,
            minutes: 0
          });
        }
        byKey.get(key).minutes += minutes;
      });
    });

    const items = Array.from(byKey.values())
      .sort((left, right) => right.minutes - left.minutes)
      .slice(0, 20);
    const categoryTotals = new Map();
    items.forEach((item) => {
      categoryTotals.set(item.category, (categoryTotals.get(item.category) || 0) + item.minutes);
    });

    return {
      detection_only: true,
      affects_work_hours: false,
      total_minutes: items.reduce((sum, item) => sum + item.minutes, 0),
      category_minutes: Array.from(categoryTotals.entries())
        .map(([label, minutes]) => ({ label, minutes }))
        .sort((left, right) => right.minutes - left.minutes),
      items
    };
  }

  _detectNonWorkObservation({ appName = '', title = '', url = '' } = {}) {
    const app = String(appName || '').toLowerCase();
    const text = `${appName || ''} ${title || ''} ${url || ''}`;
    const host = this._urlHost(url);
    for (const rule of NON_WORK_OBSERVATION_RULES) {
      const hostMatched = host && (rule.hosts || []).some((pattern) => host.includes(pattern));
      const appMatched = (rule.apps || []).some((pattern) => app === pattern || app.endsWith(`\\${pattern}`));
      const textMatched = rule.text?.test(text);
      if (hostMatched || appMatched || textMatched) {
        return {
          category: rule.category,
          host,
          rule: hostMatched ? 'domain' : (appMatched ? 'app' : 'title')
        };
      }
    }
    return null;
  }

  _urlHost(rawUrl = '') {
    if (!rawUrl) {
      return '';
    }
    try {
      return new URL(rawUrl).hostname.replace(/^www\./i, '').toLowerCase();
    } catch {
      const match = String(rawUrl).toLowerCase().match(/\b([a-z0-9.-]+\.[a-z]{2,})\b/i);
      return match ? match[1].replace(/^www\./i, '') : '';
    }
  }

  _normalizeIdleIntervals(intervals = [], rangeStartMs = null, rangeEndMs = null) {
    return (intervals || [])
      .map((interval) => {
        const startMs = Number.isFinite(Number(interval.startMs))
          ? Number(interval.startMs)
          : new Date(interval.start).getTime();
        const endMs = Number.isFinite(Number(interval.endMs))
          ? Number(interval.endMs)
          : new Date(interval.end).getTime();
        if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
          return null;
        }

        const clippedStartMs = Number.isFinite(rangeStartMs) ? Math.max(startMs, rangeStartMs) : startMs;
        const clippedEndMs = Number.isFinite(rangeEndMs) ? Math.min(endMs, rangeEndMs) : endMs;
        if (clippedEndMs <= clippedStartMs) {
          return null;
        }

        return { startMs: clippedStartMs, endMs: clippedEndMs };
      })
      .filter(Boolean)
      .sort((left, right) => left.startMs - right.startMs);
  }

  _normalizeFocusIntervals(intervals = [], rangeStartMs = null, rangeEndMs = null) {
    return (intervals || [])
      .map((interval) => {
        const startMs = Number.isFinite(Number(interval.startMs))
          ? Number(interval.startMs)
          : new Date(interval.start).getTime();
        const endMs = Number.isFinite(Number(interval.endMs))
          ? Number(interval.endMs)
          : new Date(interval.end).getTime();
        if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
          return null;
        }

        const clippedStartMs = Number.isFinite(rangeStartMs) ? Math.max(startMs, rangeStartMs) : startMs;
        const clippedEndMs = Number.isFinite(rangeEndMs) ? Math.min(endMs, rangeEndMs) : endMs;
        if (clippedEndMs <= clippedStartMs) {
          return null;
        }

        return {
          ...interval,
          startMs: clippedStartMs,
          endMs: clippedEndMs,
          process_name: String(interval.process_name || '').trim(),
          window_title: String(interval.window_title || '').trim()
        };
      })
      .filter(Boolean)
      .sort((left, right) => left.startMs - right.startMs);
  }

  _normalizePassiveWorkIntervals(intervals = [], rangeStartMs = null, rangeEndMs = null) {
    return (intervals || [])
      .map((interval) => {
        const startMs = Number.isFinite(Number(interval.startMs))
          ? Number(interval.startMs)
          : new Date(interval.start || interval.start_time || interval.timestamp_start || 0).getTime();
        const endMs = Number.isFinite(Number(interval.endMs))
          ? Number(interval.endMs)
          : new Date(interval.end || interval.end_time || interval.timestamp_end || 0).getTime();
        if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
          return null;
        }
        if (!this._isPassiveWorkInterval(interval)) {
          return null;
        }

        const clippedStartMs = Number.isFinite(rangeStartMs) ? Math.max(startMs, rangeStartMs) : startMs;
        const clippedEndMs = Number.isFinite(rangeEndMs) ? Math.min(endMs, rangeEndMs) : endMs;
        if (clippedEndMs <= clippedStartMs) {
          return null;
        }

        return { ...interval, startMs: clippedStartMs, endMs: clippedEndMs };
      })
      .filter(Boolean)
      .sort((left, right) => left.startMs - right.startMs);
  }

  _isPassiveWorkInterval(interval = {}) {
    if (interval.passive_work_evidence !== true && interval.source !== 'focus_idle_work_evidence') {
      return false;
    }
    const classification = this._classificationKey(interval.classification);
    if (classification !== 'work' && classification !== 'meeting') {
      return false;
    }
    return String(interval.classification_confidence || '').toLowerCase() === 'high';
  }

  _subtractIntervals(baseIntervals = [], subtractIntervals = []) {
    if (!subtractIntervals.length) {
      return baseIntervals;
    }
    const subtractors = this._mergeIntervalsByMs(subtractIntervals);
    const result = [];
    baseIntervals.forEach((base) => {
      let segments = [{ startMs: base.startMs, endMs: base.endMs }];
      subtractors.forEach((subtract) => {
        segments = segments.flatMap((segment) => {
          if (subtract.endMs <= segment.startMs || subtract.startMs >= segment.endMs) {
            return [segment];
          }
          const pieces = [];
          if (subtract.startMs > segment.startMs) {
            pieces.push({ startMs: segment.startMs, endMs: subtract.startMs });
          }
          if (subtract.endMs < segment.endMs) {
            pieces.push({ startMs: subtract.endMs, endMs: segment.endMs });
          }
          return pieces;
        });
      });
      segments
        .filter((segment) => segment.endMs > segment.startMs)
        .forEach((segment) => result.push({
          ...base,
          startMs: segment.startMs,
          endMs: segment.endMs
        }));
    });
    return result;
  }

  _applyIdleToAllocationWindows(windows = [], idleIntervals = []) {
    const manualIntervals = this._manualIntervalsFromAllocationWindows(windows);
    const nonManualExclusionIntervals = this._mergeIntervalsByMs([...idleIntervals, ...manualIntervals]);

    return windows.map((window) => {
      const idleMs = window.skip_idle_deduction ? 0 : this._overlapMs(window.startMs, window.endMs, idleIntervals);
      const manualOverlapMs = window.skip_idle_deduction ? 0 : this._overlapMs(window.startMs, window.endMs, manualIntervals);
      const exclusionMs = window.skip_idle_deduction
        ? 0
        : this._overlapMs(window.startMs, window.endMs, nonManualExclusionIntervals);
      const activeMs = Math.max(0, Number(window.gross_ms || 0) - exclusionMs);
      return {
        ...window,
        idle_ms: idleMs,
        manual_overlap_ms: manualOverlapMs,
        active_ms: activeMs
      };
    });
  }

  _applyFocusToAllocationWindows(windows = [], focusIntervals = []) {
    if (!focusIntervals.length) {
      return windows;
    }

    return windows.map((window) => {
      if (window.skip_idle_deduction || Number(window.active_ms || 0) <= 0) {
        return window;
      }

      const overlapping = focusIntervals.filter((interval) => (
        Number(interval.startMs) < Number(window.endMs) &&
        Number(interval.endMs) > Number(window.startMs)
      ));
      if (!overlapping.length) {
        return window;
      }

      const focusOverlapMs = this._overlapMs(window.startMs, window.endMs, overlapping);
      const focusMatchingMs = this._overlapMs(
        window.startMs,
        window.endMs,
        overlapping.filter((interval) => this._recordMatchesFocusInterval(window.record, interval))
      );
      const mismatchedFocusMs = Math.max(0, focusOverlapMs - focusMatchingMs);

      return {
        ...window,
        focus_overlap_ms: focusOverlapMs,
        focus_matching_ms: focusMatchingMs,
        focus_mismatched_ms: mismatchedFocusMs,
        focus_adjusted: mismatchedFocusMs > 0,
        active_ms: Math.max(0, Number(window.active_ms || 0) - mismatchedFocusMs)
      };
    });
  }

  _recordMatchesFocusInterval(record = {}, interval = {}) {
    const recordApp = normalizeProcessName(record.app_name);
    const focusApp = normalizeProcessName(interval.process_name);
    if (!recordApp || !focusApp || recordApp !== focusApp) {
      return false;
    }

    const recordTitle = normalizeComparableTitle(record.window_title || record.window_name || record.url_if_available || '');
    const focusTitle = normalizeComparableTitle(interval.window_title || '');
    if (!recordTitle || !focusTitle) {
      return true;
    }
    return titlesAreSimilar(recordTitle, focusTitle);
  }

  _focusMismatchOverlapMs(record = {}, startMs, endMs, focusIntervals = []) {
    if (!focusIntervals.length) {
      return 0;
    }
    const overlapping = focusIntervals.filter((interval) => (
      Number(interval.startMs) < Number(endMs) &&
      Number(interval.endMs) > Number(startMs)
    ));
    if (!overlapping.length) {
      return 0;
    }
    const focusOverlapMs = this._overlapMs(startMs, endMs, overlapping);
    const focusMatchingMs = this._overlapMs(
      startMs,
      endMs,
      overlapping.filter((interval) => this._recordMatchesFocusInterval(record, interval))
    );
    return Math.max(0, focusOverlapMs - focusMatchingMs);
  }

  _buildFocusBackedRecords(focusIntervals = [], capturedRecords = [], range = {}, options = {}) {
    if (options.includeFocusBackedRecords === false || !focusIntervals.length) {
      return [];
    }

    const minMs = Math.max(30000, Number(options.minFocusBackedRecordMs || 30000));
    const maxTotalMs = Math.max(0, Number(options.maxFocusBackedRecordMs || 2 * 60 * 60 * 1000));
    let acceptedMs = 0;
    const records = [];

    focusIntervals.forEach((interval, index) => {
      const startMs = Math.max(Number(range.startMs) || interval.startMs, interval.startMs);
      const endMs = Math.min(Number(range.endMs) || interval.endMs, interval.endMs);
      const durationMs = Math.max(0, endMs - startMs);
      if (durationMs < minMs || !this._isUsableFocusInterval(interval)) {
        return;
      }
      if (this._hasMatchingCapturedRecord(interval, capturedRecords)) {
        return;
      }
      if (maxTotalMs > 0 && acceptedMs >= maxTotalMs) {
        return;
      }

      const cappedDurationMs = maxTotalMs > 0
        ? Math.min(durationMs, maxTotalMs - acceptedMs)
        : durationMs;
      if (cappedDurationMs < minMs) {
        return;
      }
      acceptedMs += cappedDurationMs;
      records.push({
        id: `focus-${interval.hwnd || 'window'}-${startMs}-${index}`,
        source: 'windows_focus_evidence',
        activity_type: 'focus_evidence',
        app_name: interval.process_name,
        window_title: interval.window_title || interval.process_name,
        timestamp_start: new Date(startMs).toISOString(),
        timestamp_end: new Date(startMs + cappedDurationMs).toISOString(),
        duration_ms_estimate: cappedDurationMs,
        focus_evidence: true,
        focus_confidence: 'medium',
        monitor_device: interval.monitor_device || '',
        cursor_monitor_device: interval.cursor_monitor_device || ''
      });
    });

    return records;
  }

  _isUsableFocusInterval(interval = {}) {
    if (!interval.process_name || !interval.window_title) {
      return false;
    }
    if (String(interval.hwnd || '') === '0') {
      return false;
    }
    const app = normalizeProcessName(interval.process_name);
    if (!app || this._isExcludedAppName(app)) {
      return false;
    }
    const title = normalizeComparableTitle(interval.window_title);
    return title.length >= 3;
  }

  _hasMatchingCapturedRecord(interval = {}, capturedRecords = []) {
    const intervalStartMs = Number(interval.startMs);
    const intervalEndMs = Number(interval.endMs);
    if (!Number.isFinite(intervalStartMs) || !Number.isFinite(intervalEndMs) || intervalEndMs <= intervalStartMs) {
      return true;
    }

    const intervalMs = intervalEndMs - intervalStartMs;
    const matchingMs = capturedRecords.reduce((sum, record) => {
      if (!this._recordMatchesFocusInterval(record, interval)) {
        return sum;
      }
      const recordStartMs = new Date(record.timestamp_start || record.timestamp).getTime();
      if (!Number.isFinite(recordStartMs)) {
        return sum;
      }
      const explicitEndMs = record.timestamp_end ? new Date(record.timestamp_end).getTime() : Number.NaN;
      const recordEndMs = Number.isFinite(explicitEndMs) && explicitEndMs > recordStartMs
        ? explicitEndMs
        : recordStartMs + Math.max(30000, Number(record.duration_ms_estimate || 30000));
      return sum + Math.max(0, Math.min(intervalEndMs, recordEndMs) - Math.max(intervalStartMs, recordStartMs));
    }, 0);

    return matchingMs >= Math.min(intervalMs * 0.5, 30000);
  }

  _focusEvidenceSummary(focusIntervals = [], rangeStartMs = null, rangeEndMs = null, focusBackedRecords = []) {
    const totalMs = focusIntervals.reduce((sum, interval) => (
      sum + Math.max(0, Number(interval.endMs || 0) - Number(interval.startMs || 0))
    ), 0);
    const backedMs = focusBackedRecords.reduce((sum, record) => sum + Number(record.duration_ms_estimate || 0), 0);
    const rangeMs = Number.isFinite(rangeStartMs) && Number.isFinite(rangeEndMs)
      ? Math.max(0, rangeEndMs - rangeStartMs)
      : 0;
    const apps = new Set(focusIntervals.map((interval) => interval.process_name).filter(Boolean));
    return {
      interval_count: focusIntervals.length,
      active_focus_minutes: this._roundMinutes(totalMs),
      focus_backed_minutes: this._roundMinutes(backedMs),
      focus_backed_event_count: focusBackedRecords.length,
      coverage_percent: rangeMs > 0 ? Math.min(100, Math.round((totalMs / rangeMs) * 100)) : 0,
      apps: Array.from(apps).slice(0, 12)
    };
  }

  _measurementConfidenceSummary({
    rangeMinutes = 0,
    capturedMinutes = 0,
    activeMinutes = 0,
    inputIdleMinutes = 0,
    rawInputIdleMinutes = 0,
    passiveWorkCandidateMinutes = 0,
    missingMinutes = 0,
    focusBackedRecords = []
  } = {}) {
    const range = Math.max(0, Math.round(Number(rangeMinutes) || 0));
    const captured = Math.max(0, Math.round(Number(capturedMinutes) || 0));
    const missing = Math.max(0, Math.round(Number(missingMinutes) || 0));
    const passive = Math.max(0, Math.round(Number(passiveWorkCandidateMinutes) || 0));
    const rawIdle = Math.max(0, Math.round(Number(rawInputIdleMinutes) || 0));
    let score = 100;
    if (range > 0) {
      score -= Math.min(45, Math.round((missing / range) * 60));
      score -= Math.min(15, Math.round((Math.max(0, range - captured - missing) / range) * 15));
      score -= Math.min(10, Math.round((passive / range) * 15));
    }
    if (focusBackedRecords.length > 0) {
      score -= 5;
    }
    score = Math.max(0, Math.min(100, score));
    const level = score >= 85 ? 'high' : (score >= 65 ? 'medium' : 'low');
    const caveats = [];
    if (missing > 0) {
      caveats.push(`${missing}m had no capture/focus/idle evidence.`);
    }
    if (passive > 0) {
      caveats.push(`${passive}m input-idle had foreground work evidence, but idle was still deducted unless manually restored.`);
    }
    if (focusBackedRecords.length > 0) {
      caveats.push('Some minutes were backed by Windows foreground focus telemetry.');
    }
    return {
      score,
      level,
      range_minutes: range,
      captured_minutes: Math.min(range || captured, captured),
      active_minutes: Math.max(0, Math.round(Number(activeMinutes) || 0)),
      input_idle_minutes: Math.max(0, Math.round(Number(inputIdleMinutes) || 0)),
      raw_input_idle_minutes: rawIdle,
      passive_work_candidate_minutes: passive,
      missing_minutes: missing,
      caveats
    };
  }

  _manualIntervalsFromAllocationWindows(windows = []) {
    return windows
      .filter((window) => window.skip_idle_deduction && Number(window.gross_ms || 0) > 0)
      .map((window) => ({
        startMs: window.startMs,
        endMs: window.endMs
      }))
      .filter((interval) => (
        Number.isFinite(interval.startMs) &&
        Number.isFinite(interval.endMs) &&
        interval.endMs > interval.startMs
      ));
  }

  _mergeIntervalsByMs(intervals = []) {
    const sorted = intervals
      .filter((interval) => (
        Number.isFinite(interval.startMs) &&
        Number.isFinite(interval.endMs) &&
        interval.endMs > interval.startMs
      ))
      .sort((left, right) => left.startMs - right.startMs);

    const merged = [];
    sorted.forEach((interval) => {
      const previous = merged[merged.length - 1];
      if (!previous || interval.startMs > previous.endMs) {
        merged.push({ startMs: interval.startMs, endMs: interval.endMs });
        return;
      }

      previous.endMs = Math.max(previous.endMs, interval.endMs);
    });
    return merged;
  }

  _isManualRecord(record = {}) {
    return record.source === 'manual' || record.activity_type === 'manual' || record.type === 'manual';
  }

  _manualRecordKind(record = {}) {
    const explicit = normalizeManualKind(record.manual_kind);
    if (explicit) {
      return explicit;
    }
    const text = `${record.app_name || ''} ${record.window_title || ''} ${record.ocr_text || ''}`.toLowerCase();
    if (/\b(meeting|call|chat)\b/.test(text)) {
      return 'meeting';
    }
    if (/\b(break|lunch|walk|away)\b/.test(text)) {
      return 'break';
    }
    if (/\b(other|manual entry)\b/.test(text)) {
      return 'other';
    }
    return 'work';
  }

  _isFocusBackedRecord(record = {}) {
    return record.source === 'windows_focus_evidence' || record.activity_type === 'focus_evidence' || record.focus_evidence === true;
  }

  _recordIntervalMs(record = {}) {
    const startMs = new Date(record.timestamp_start || record.timestamp || record.timestamp_end || 0).getTime();
    if (!Number.isFinite(startMs)) {
      return { startMs: Number.NaN, endMs: Number.NaN };
    }
    const explicitEndMs = new Date(record.timestamp_end || 0).getTime();
    const durationMs = Number(record.duration_ms_estimate || 0);
    const endMs = Math.max(
      Number.isFinite(explicitEndMs) ? explicitEndMs : startMs,
      startMs + Math.max(0, durationMs)
    );
    return { startMs, endMs: endMs > startMs ? endMs : startMs };
  }

  _minuteKeysForInterval(startMs, endMs) {
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return [];
    }
    const minutes = [];
    const cursor = new Date(startMs);
    cursor.setSeconds(0, 0);
    while (cursor.getTime() < endMs) {
      minutes.push({
        key: cursor.toISOString(),
        startMs: cursor.getTime()
      });
      cursor.setTime(cursor.getTime() + 60000);
    }
    return minutes;
  }

  _minuteOverlapsIntervals(minuteKey, intervals = []) {
    const startMs = new Date(minuteKey).getTime();
    if (!Number.isFinite(startMs)) {
      return false;
    }
    return this._overlapMs(startMs, startMs + 60000, intervals) >= 30000;
  }

  _overlapMs(startMs, endMs, intervals = []) {
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return 0;
    }

    return intervals.reduce((sum, interval) => {
      const overlapStart = Math.max(startMs, interval.startMs);
      const overlapEnd = Math.min(endMs, interval.endMs);
      return sum + Math.max(0, overlapEnd - overlapStart);
    }, 0);
  }

  _idleSecondsInRange(intervals = []) {
    return Math.round(intervals.reduce((sum, interval) => sum + Math.max(0, interval.endMs - interval.startMs), 0) / 1000);
  }

  _intervalMinutes(intervals = []) {
    return Math.round((intervals || []).reduce((sum, interval) => (
      sum + Math.max(0, Number(interval.endMs || 0) - Number(interval.startMs || 0))
    ), 0) / 60000);
  }

  _isBrowserRecord(record) {
    return /chrome|edge|firefox|browser|brave|opera/i.test(record.app_name || '') || Boolean(record.url_if_available);
  }

  _dedupeUrls(urls) {
    const seen = new Set();
    const deduped = [];

    urls.forEach((rawUrl) => {
      const normalized = this._normalizeUrl(rawUrl);
      if (!normalized || seen.has(normalized)) {
        return;
      }

      seen.add(normalized);
      deduped.push(normalized);
    });

    return deduped;
  }

  _normalizeUrl(rawUrl) {
    if (!rawUrl) {
      return null;
    }

    try {
      const url = new URL(rawUrl);
      const host = url.hostname.replace(/^www\./i, '');
      let path = url.pathname.replace(/\/+$/g, '') || '/';

      if (host === 'gemini.google.com' && path === '/app') {
        path = '/';
      }

      if (path === '/') {
        return `${url.protocol}//${host}/`;
      }

      return `${url.protocol}//${host}${path}`;
    } catch {
      return rawUrl;
    }
  }

  _displayAppName(appName) {
    if (!appName) {
      return 'Unknown';
    }

    const normalized = String(appName).toLowerCase();
    const map = {
      'msedge.exe': 'Microsoft Edge',
      'chrome.exe': 'Google Chrome',
      'firefox.exe': 'Mozilla Firefox',
      'brave.exe': 'Brave',
      'opera.exe': 'Opera',
      'mstsc.exe': 'Remote Desktop',
      'explorer.exe': 'File Explorer',
      'windowsterminal.exe': 'Windows Terminal',
      'electron.exe': 'Electron App'
    };

    return map[normalized] || appName.replace(/\.exe$/i, '');
  }

  _estimateMinutes(timestamps = []) {
    const values = timestamps
      .map((value) => new Date(value).getTime())
      .filter((value) => Number.isFinite(value))
      .sort((a, b) => a - b);

    if (!values.length) {
      return 0;
    }

    let totalMs = 30000;
    for (let i = 0; i < values.length - 1; i += 1) {
      totalMs += Math.min(values[i + 1] - values[i], 120000);
    }

    return Math.max(1, Math.round(totalMs / 60000));
  }

  _sumSessionMinutes(sessions = []) {
    return sessions.reduce((total, session) => total + (session.duration_minutes_estimate || 0), 0);
  }

  _roundMinutes(milliseconds) {
    if (!milliseconds) {
      return 0;
    }

    return Math.max(1, Math.round(milliseconds / 60000));
  }

  _distributeRoundedMinutes(millisecondsByGroup = []) {
    const exactMinutes = millisecondsByGroup.map((value) => Math.max(0, Number(value) || 0) / 60000);
    const targetTotal = this._roundMinutes(exactMinutes.reduce((sum, value) => sum + (value * 60000), 0));
    const distributed = exactMinutes.map((value) => Math.floor(value));
    let assigned = distributed.reduce((sum, value) => sum + value, 0);

    const ranked = exactMinutes
      .map((value, index) => ({
        index,
        remainder: value - Math.floor(value),
        positive: value > 0
      }))
      .sort((a, b) => b.remainder - a.remainder);

    for (const entry of ranked) {
      if (assigned >= targetTotal) {
        break;
      }
      if (!entry.positive) {
        continue;
      }

      distributed[entry.index] += 1;
      assigned += 1;
    }

    return distributed;
  }

  _rebalanceAppTimelineMinutes(appTimeline = [], targetTotalMinutes = 0) {
    if (!appTimeline.length) {
      return [];
    }

    const targetTotalMs = Math.max(0, Math.round(Number(targetTotalMinutes || 0) * 60000));
    const currentTotalMs = appTimeline.reduce((sum, group) => sum + Number(group.total_time_ms_estimate || 0), 0);
    let rebalanced = appTimeline.map((group) => ({
      ...group,
      classified_ms: { ...(group.classified_ms || this._emptyClassifiedMs()) },
      confirmed_non_work_ms: Number(group.confirmed_non_work_ms || 0),
      items: (group.items || []).map((item) => ({
        ...item,
        classified_ms: { ...(item.classified_ms || this._emptyClassifiedMs()) },
        confirmed_non_work_ms: Number(item.confirmed_non_work_ms || 0)
      }))
    }));

    if (targetTotalMs > 0 && currentTotalMs > targetTotalMs) {
      const scale = targetTotalMs / currentTotalMs;
      rebalanced = rebalanced.map((group) => ({
        ...group,
        total_time_ms_estimate: Math.round(Number(group.total_time_ms_estimate || 0) * scale),
        classified_ms: this._scaleClassifiedMs(group.classified_ms || {}, scale),
        confirmed_non_work_ms: Math.round(Number(group.confirmed_non_work_ms || 0) * scale),
        items: (group.items || []).map((item) => ({
          ...item,
          duration_ms_estimate: Math.round(Number(item.duration_ms_estimate || 0) * scale),
          classified_ms: this._scaleClassifiedMs(item.classified_ms || {}, scale),
          confirmed_non_work_ms: Math.round(Number(item.confirmed_non_work_ms || 0) * scale)
        }))
      }));
    }

    const currentTotal = rebalanced.reduce((sum, group) => sum + Number(group.total_time_minutes_estimate || 0), 0);
    if (currentTotal < targetTotalMinutes && targetTotalMinutes > 0) {
      let remaining = targetTotalMinutes - currentTotal;
      const expandable = rebalanced
        .map((group, index) => ({ index, ms: Number(group.total_time_ms_estimate || 0) }))
        .filter((entry) => entry.ms > 0)
        .sort((left, right) => right.ms - left.ms);

      while (remaining > 0 && expandable.length) {
        for (const entry of expandable) {
          if (remaining <= 0) {
            break;
          }
          rebalanced[entry.index].total_time_minutes_estimate += 1;
          rebalanced[entry.index].total_time_label = this._formatDuration(rebalanced[entry.index].total_time_minutes_estimate);
          remaining -= 1;
        }
      }
    }

    const adjustedTotal = rebalanced.reduce((sum, group) => sum + Number(group.total_time_minutes_estimate || 0), 0);
    if (adjustedTotal <= targetTotalMinutes || targetTotalMinutes <= 0) {
      return rebalanced.map((group) => ({
        ...group,
        confirmed_non_work_minutes: this._confirmedNonWorkMinutesFromMs(
          group.confirmed_non_work_ms,
          group.total_time_minutes_estimate || 0
        ),
        classified_minutes: this._rebalanceClassificationMinutes(group.classified_ms || {}, group.total_time_minutes_estimate || 0)
      }));
    }

    const currentTotalAfterExpansion = adjustedTotal;
    if (currentTotalAfterExpansion <= targetTotalMinutes || targetTotalMinutes <= 0) {
      return rebalanced;
    }

    let overflow = currentTotalAfterExpansion - targetTotalMinutes;

    while (overflow > 0) {
      const reducible = rebalanced
        .map((group, index) => ({ index, minutes: Number(group.total_time_minutes_estimate || 0) }))
        .filter((entry) => entry.minutes > 0)
        .sort((a, b) => b.minutes - a.minutes);

      if (!reducible.length) {
        break;
      }

      for (const entry of reducible) {
        if (overflow <= 0) {
          break;
        }

        rebalanced[entry.index].total_time_minutes_estimate -= 1;
        rebalanced[entry.index].total_time_label = this._formatDuration(rebalanced[entry.index].total_time_minutes_estimate);
        overflow -= 1;
      }
    }

    return rebalanced.map((group) => ({
      ...group,
      confirmed_non_work_minutes: this._confirmedNonWorkMinutesFromMs(
        group.confirmed_non_work_ms,
        group.total_time_minutes_estimate || 0
      ),
      classified_minutes: this._rebalanceClassificationMinutes(group.classified_ms || {}, group.total_time_minutes_estimate || 0)
    }));
  }

  _scaleClassifiedMs(classifiedMs = {}, scale = 1) {
    return CLASSIFICATION_KEYS.reduce((value, key) => {
      value[key] = Math.max(0, Math.round(Number(classifiedMs[key] || 0) * scale));
      return value;
    }, this._emptyClassifiedMs());
  }

  _classificationBucketsFromSessions(sessions = []) {
    return sessions.reduce((accumulator, session) => {
      if (session.classified_ms) {
        return this._mergeClassifiedMs(accumulator, session.classified_ms);
      }

      const key = this._classificationKey(session.classification);
      accumulator[key] = (accumulator[key] || 0) + Number(session.duration_ms_estimate || 0);
      return accumulator;
    }, this._emptyClassifiedMs());
  }

  _classificationEvidenceFromSessions(sessions = []) {
    return sessions.reduce((accumulator, session) => {
      const evidence = session.classification_evidence || {};
      CLASSIFICATION_KEYS.forEach((key) => {
        accumulator[key] += Number(evidence[key] || 0);
      });
      return accumulator;
    }, this._emptyClassifiedMs());
  }

  _confirmedNonWorkMsFromSessions(sessions = []) {
    return sessions.reduce((total, session) => total + Number(session.confirmed_non_work_ms || 0), 0);
  }

  _summaryConfirmedNonWorkMinutes(appTimeline = [], activeMinutes = 0) {
    const exactMinutes = appTimeline.reduce((total, group) => {
      if (Number.isFinite(Number(group.confirmed_non_work_minutes))) {
        return total + Number(group.confirmed_non_work_minutes || 0);
      }
      return total + (Number(group.confirmed_non_work_ms || 0) / 60000);
    }, 0);
    return Math.min(
      Math.max(0, Math.round(Number(activeMinutes) || 0)),
      Math.max(0, Math.round(exactMinutes))
    );
  }

  _confirmedNonWorkMinutesFromMs(milliseconds = 0, capMinutes = Number.POSITIVE_INFINITY) {
    const minutes = Math.max(0, Math.round(Number(milliseconds || 0) / 60000));
    const cap = Number.isFinite(Number(capMinutes))
      ? Math.max(0, Math.round(Number(capMinutes) || 0))
      : Number.POSITIVE_INFINITY;
    return Math.min(cap, minutes);
  }

  _isConfirmedNonWorkClassification(result = {}) {
    const classification = this._classificationKey(result.classification);
    if (classification !== 'social' && classification !== 'other') {
      return false;
    }
    return String(result.confidence || '').toLowerCase() === 'high';
  }

  _rebalanceClassificationMinutes(classifiedMs = {}, targetMinutes = 0) {
    const keys = CLASSIFICATION_KEYS;
    const target = Math.max(0, Math.round(Number(targetMinutes) || 0));
    const exactMinutes = keys.map((key) => Math.max(0, Number(classifiedMs[key] || 0) / 60000));
    const totalExactMinutes = exactMinutes.reduce((sum, value) => sum + value, 0);
    const distributed = target > Math.round(totalExactMinutes)
      ? this._distributeMinutesToTarget(exactMinutes, target)
      : this._distributeRoundedMinutes(keys.map((key) => Number(classifiedMs[key] || 0)));
    const base = keys.reduce((value, key, index) => {
      value[key] = distributed[index] || 0;
      return value;
    }, this._emptyClassifiedMs());

    return this._reconcileClassificationMinutes(base, targetMinutes);
  }

  _distributeMinutesToTarget(exactMinutes = [], targetMinutes = 0) {
    const target = Math.max(0, Math.round(Number(targetMinutes) || 0));
    const floors = exactMinutes.map((value) => Math.floor(Math.max(0, Number(value) || 0)));
    let assigned = floors.reduce((sum, value) => sum + value, 0);
    const order = exactMinutes
      .map((value, index) => ({
        index,
        remainder: value - Math.floor(value),
        positive: value > 0
      }))
      .filter((entry) => entry.positive)
      .sort((left, right) => right.remainder - left.remainder);

    while (assigned < target && order.length) {
      for (const entry of order) {
        if (assigned >= target) {
          break;
        }
        floors[entry.index] += 1;
        assigned += 1;
      }
    }

    return floors;
  }

  _summaryClassificationTotals(appTimeline = [], targetMinutes = 0) {
    const raw = appTimeline.reduce((accumulator, group) => {
      CLASSIFICATION_KEYS.forEach((key) => {
        accumulator[key] += Number(group.classified_minutes?.[key] || 0);
      });
      return accumulator;
    }, this._emptyClassifiedMs());

    return this._reconcileClassificationMinutes(raw, targetMinutes);
  }

  _focusScore(classifiedMinutes = {}, activeMinutes = 0) {
    const totalActiveMinutes = Math.max(0, Math.round(Number(activeMinutes) || 0));
    const deepWorkMinutes = Math.min(
      totalActiveMinutes,
      Math.max(0, Math.round(Number(classifiedMinutes.work || 0)))
    );
    const score = totalActiveMinutes > 0 ? deepWorkMinutes / totalActiveMinutes : 0;
    const scorePercent = Math.round(score * 100);

    return {
      deep_work_minutes: deepWorkMinutes,
      total_active_minutes: totalActiveMinutes,
      score,
      score_percent: scorePercent,
      label: totalActiveMinutes > 0 ? `${scorePercent}%` : '0%',
      formula: 'Deep Work / Total Active Time'
    };
  }

  _workMinutesFromAvailable(availableMinutes = 0, idleMinutes = 0) {
    return buildWorkHoursLedger({
      pcAvailableMinutes: availableMinutes,
      idleMinutes
    }).pc_available_work_minutes;
  }

  _reconcileClassificationMinutes(minutes = {}, targetMinutes = 0) {
    const target = Math.max(0, Math.round(Number(targetMinutes) || 0));
    const adjusted = CLASSIFICATION_KEYS.reduce((value, key) => {
      value[key] = Math.max(0, Math.round(Number(minutes[key]) || 0));
      return value;
    }, this._emptyClassifiedMs());

    let total = CLASSIFICATION_KEYS.reduce((sum, key) => sum + adjusted[key], 0);
    if (target <= 0) {
      return this._emptyClassifiedMs();
    }

    if (total < target) {
      adjusted.unclear += target - total;
      return adjusted;
    }

    let overflow = total - target;
    for (const key of ['unclear', 'other', 'social', 'meeting', 'work']) {
      while (overflow > 0 && adjusted[key] > 0) {
        adjusted[key] -= 1;
        overflow -= 1;
      }
    }

    return adjusted;
  }

  _dominantClassification(classifiedMs = {}) {
    const entries = CLASSIFICATION_KEYS.map((key) => ({
      key,
      value: Number(classifiedMs[key] || 0)
    })).sort((a, b) => b.value - a.value);

    if (!entries[0] || entries[0].value <= 0) {
      return { classification: 'unclear', confidence: 'low' };
    }

    if (entries[1] && entries[0].value === entries[1].value) {
      return { classification: 'unclear', confidence: 'low' };
    }

    return {
      classification: entries[0].key,
      confidence: entries[0].value >= 2 * (entries[1]?.value || 0) ? 'high' : 'medium'
    };
  }

  _mergeMatchedRules(existing = [], incoming = []) {
    return [...new Set([...(existing || []), ...(incoming || [])])].slice(0, 10);
  }

  _mergeMatchedRuleDetails(existing = [], incoming = []) {
    const merged = new Map();
    [...(existing || []), ...(incoming || [])].forEach((detail) => {
      if (!detail?.id) {
        return;
      }

      const key = `${detail.id}:${detail.pattern || ''}`;
      if (!merged.has(key)) {
        merged.set(key, detail);
      }
    });

    return Array.from(merged.values()).slice(0, 10);
  }

  _mergeClassifiedMs(left = {}, right = {}) {
    return CLASSIFICATION_KEYS.reduce((merged, key) => {
      merged[key] = Number(left[key] || 0) + Number(right[key] || 0);
      return merged;
    }, this._emptyClassifiedMs());
  }

  _emptyClassifiedMs() {
    return CLASSIFICATION_KEYS.reduce((value, key) => {
      value[key] = 0;
      return value;
    }, {});
  }

  _classificationKey(value) {
    const normalized = String(value || 'unclear').toLowerCase();
    return CLASSIFICATION_KEYS.includes(normalized) ? normalized : 'unclear';
  }

  _classificationEvidenceScore(classification = {}, allocatedMs = 0) {
    const confidenceWeight = {
      high: 9,
      medium: 3,
      low: 1
    };
    const matchTypeWeight = {
      domain: 5,
      domain_or_app: 4,
      app_or_title: 4,
      app_plus_text: 4,
      title_or_text: 3,
      app: 2,
      app_only: 2,
      fallback: 0
    };
    const details = classification.matched_rule_details || [];
    const specificity = details.reduce((best, detail) => Math.max(best, matchTypeWeight[detail.match_type] || 0), 0);
    const confidence = confidenceWeight[classification.confidence] || 1;
    if (allocatedMs <= 0) {
      return 0;
    }
    const minutes = Math.max(allocatedMs / 60000, 0.25);

    return ((confidence * 10) + specificity) * (1 + Math.log1p(minutes));
  }

  _confidenceForSession(session, fallback = 'low') {
    const confidences = session.classification_confidences || [];
    if (confidences.includes('high')) {
      return 'high';
    }
    if (confidences.includes('medium')) {
      return 'medium';
    }
    return fallback || 'low';
  }

  _formatDuration(minutes) {
    if (!minutes) {
      return '0m';
    }

    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;

    if (!hours) {
      return `${mins}m`;
    }

    if (!mins) {
      return `${hours}h`;
    }

    return `${hours}h ${mins}m`;
  }
}

function normalizeProcessName(value) {
  const text = String(value || '').trim().toLowerCase();
  if (!text) {
    return '';
  }
  const fileName = text.split(/[\\/]/).pop();
  return fileName.endsWith('.exe') ? fileName : `${fileName}.exe`;
}

function normalizeComparableTitle(value) {
  return normalizeWindowTitle(value)
    .toLowerCase()
    .replace(/https?:\/\/\S+/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\b(?:google chrome|microsoft edge|mozilla firefox|visual studio code|excel|word|powerpoint)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 180);
}

function titlesAreSimilar(left, right) {
  if (!left || !right) {
    return false;
  }
  if (left === right || left.includes(right) || right.includes(left)) {
    return true;
  }
  const leftTokens = titleTokens(left);
  const rightTokens = titleTokens(right);
  if (!leftTokens.length || !rightTokens.length) {
    return false;
  }
  const rightSet = new Set(rightTokens);
  const shared = leftTokens.filter((token) => rightSet.has(token)).length;
  return shared >= Math.min(3, Math.max(1, Math.min(leftTokens.length, rightTokens.length)));
}

function titleTokens(value) {
  return String(value || '')
    .split(/\s+/)
    .filter((token) => token.length >= 3)
    .slice(0, 24);
}

function normalizeManualKind(value) {
  const normalized = String(value || '').trim().toLowerCase();
  return ['work', 'meeting', 'break', 'other'].includes(normalized) ? normalized : '';
}

function localDateKeyFromMs(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) {
    return '';
  }
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function singleLocalDateKeyForRange(startMs, endMs) {
  if (!Number.isFinite(Number(startMs)) || !Number.isFinite(Number(endMs)) || Number(endMs) <= Number(startMs)) {
    return '';
  }
  const startKey = localDateKeyFromMs(startMs);
  const endKey = localDateKeyFromMs(Number(endMs) - 1);
  return startKey && startKey === endKey ? startKey : '';
}

function manualRecordBelongsToDate(record = {}, dateKey = '') {
  if (!dateKey) {
    return true;
  }
  const explicit = String(record.manual_local_date_key || '').trim();
  if (explicit) {
    return explicit === dateKey;
  }
  return localDateKeyFromMs(record.timestamp_start || record.timestamp || record.timestamp_end || 0) === dateKey;
}

module.exports = { DailySummaryService };
