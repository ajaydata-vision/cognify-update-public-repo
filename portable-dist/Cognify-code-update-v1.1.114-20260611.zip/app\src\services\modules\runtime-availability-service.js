const fs = require('fs');
const path = require('path');

const SCHEMA_VERSION = 1;
const DEFAULT_PULSE_MS = 15 * 1000;
const DEFAULT_MAX_BRIDGE_MS = 5 * 60 * 1000;
const MINUTE_MS = 60 * 1000;

class RuntimeAvailabilityService {
  constructor(storagePath, options = {}) {
    this.basePath = path.join(storagePath, 'runtime-availability');
    this.pulseMs = Number(options.pulseMs || DEFAULT_PULSE_MS);
    this.maxBridgeMs = Number(options.maxBridgeMs || DEFAULT_MAX_BRIDGE_MS);
    this.timer = null;
    this.lastPulseMs = 0;
    this.lastMinuteKey = '';
    fs.mkdirSync(this.basePath, { recursive: true });
  }

  start() {
    if (this.timer) {
      return { started: false, already_running: true };
    }
    this.recordPulse(new Date());
    this.timer = setInterval(() => this.recordPulse(new Date()), this.pulseMs);
    this.timer.unref?.();
    return { started: true, pulse_ms: this.pulseMs };
  }

  stop() {
    if (!this.timer) {
      return { stopped: false };
    }
    clearInterval(this.timer);
    this.timer = null;
    this.recordPulse(new Date());
    return { stopped: true };
  }

  recordPulse(now = new Date()) {
    const nowMs = new Date(now).getTime();
    if (!Number.isFinite(nowMs)) {
      return { recorded: false, reason: 'invalid_time' };
    }
    const minuteStarts = this._minuteStartsForPulse(nowMs);
    if (!minuteStarts.length) {
      return { recorded: false, reason: 'duplicate_minute' };
    }
    const byDate = new Map();
    minuteStarts.forEach((minuteMs) => {
      const key = this._minuteKey(minuteMs);
      const date = this._dateKey(minuteMs);
      if (!byDate.has(date)) {
        byDate.set(date, []);
      }
      byDate.get(date).push(key);
    });
    byDate.forEach((keys, date) => this._addMinuteKeys(date, keys));
    this.lastPulseMs = nowMs;
    this.lastMinuteKey = this._minuteKey(nowMs);
    return { recorded: true, minute_count: minuteStarts.length };
  }

  getIntervalsInRange(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return [];
    }
    const minuteKeys = Array.from(new Set(this._datesForRange(startMs, endMs)
      .flatMap((date) => this._loadDay(date).minutes || [])
      .filter((key) => {
        const minuteMs = new Date(key).getTime();
        return Number.isFinite(minuteMs) && minuteMs < endMs && (minuteMs + MINUTE_MS) > startMs;
      })))
      .sort();

    const intervals = [];
    let current = null;
    minuteKeys.forEach((key) => {
      const minuteMs = new Date(key).getTime();
      if (!Number.isFinite(minuteMs)) {
        return;
      }
      const start = Math.max(startMs, minuteMs);
      const end = Math.min(endMs, minuteMs + MINUTE_MS);
      if (!current || start > current.endMs) {
        current = { startMs: start, endMs: end };
        intervals.push(current);
        return;
      }
      current.endMs = Math.max(current.endMs, end);
    });

    return intervals.map((interval) => ({
      start: new Date(interval.startMs).toISOString(),
      end: new Date(interval.endMs).toISOString(),
      source: 'cognify_runtime'
    }));
  }

  getAvailableMinutes(startTime, endTime) {
    return Math.round(this.getIntervalsInRange(startTime, endTime).reduce((sum, interval) => {
      const startMs = new Date(interval.start).getTime();
      const endMs = new Date(interval.end).getTime();
      return sum + Math.max(0, endMs - startMs);
    }, 0) / MINUTE_MS);
  }

  getHealth() {
    const ageMs = this.lastPulseMs ? Date.now() - this.lastPulseMs : null;
    const stale = !this.timer ||
      !this.lastPulseMs ||
      (Number.isFinite(ageMs) && ageMs > Math.max(this.pulseMs * 4, MINUTE_MS));
    return {
      ok: !stale,
      status: !this.timer ? 'stopped' : (stale ? 'stale' : 'ok'),
      label: 'Runtime Availability',
      detail: this.timer
        ? (stale
          ? 'Runtime availability pulse is stale.'
          : `Recording Cognify runtime availability every ${Math.round(this.pulseMs / 1000)}s.`)
        : 'Runtime availability pulse is not running.',
      last_pulse_at: this.lastPulseMs ? new Date(this.lastPulseMs).toISOString() : null,
      age_ms: ageMs
    };
  }

  _minuteStartsForPulse(nowMs) {
    const currentMinuteMs = this._minuteStartMs(nowMs);
    const currentMinuteKey = this._minuteKey(currentMinuteMs);
    if (currentMinuteKey === this.lastMinuteKey) {
      return [];
    }
    if (!this.lastPulseMs || (nowMs - this.lastPulseMs) > this.maxBridgeMs) {
      return [currentMinuteMs];
    }
    const starts = [];
    for (
      let cursor = this._minuteStartMs(this.lastPulseMs) + MINUTE_MS;
      cursor <= currentMinuteMs;
      cursor += MINUTE_MS
    ) {
      starts.push(cursor);
    }
    return starts.filter((minuteMs, index, list) => list.indexOf(minuteMs) === index);
  }

  _addMinuteKeys(date, keys = []) {
    if (!keys.length) {
      return;
    }
    const day = this._loadDay(date);
    const merged = new Set(day.minutes || []);
    keys.forEach((key) => merged.add(key));
    day.minutes = Array.from(merged).sort();
    day.updated_at = new Date().toISOString();
    this._saveDay(day);
  }

  _loadDay(date) {
    const filePath = this._dayPath(date);
    if (fs.existsSync(filePath)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        if (parsed?.schema_version === SCHEMA_VERSION && parsed.date === date) {
          return { ...parsed, minutes: Array.isArray(parsed.minutes) ? parsed.minutes : [] };
        }
      } catch {
        // Rebuild corrupt runtime availability state lazily.
      }
    }
    return {
      schema_version: SCHEMA_VERSION,
      date,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      minutes: []
    };
  }

  _saveDay(day) {
    fs.mkdirSync(this.basePath, { recursive: true });
    const filePath = this._dayPath(day.date);
    const tempPath = `${filePath}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(day, null, 2), 'utf8');
    fs.renameSync(tempPath, filePath);
  }

  _datesForRange(startMs, endMs) {
    const dates = new Set();
    const cursor = new Date(startMs);
    cursor.setHours(0, 0, 0, 0);
    while (cursor.getTime() < endMs) {
      dates.add(this._dateKey(cursor));
      cursor.setDate(cursor.getDate() + 1);
    }

    // Read legacy UTC-day files written before runtime minutes were grouped by
    // local day, so early-morning local availability is not orphaned.
    const utcCursor = new Date(startMs);
    utcCursor.setUTCHours(0, 0, 0, 0);
    while (utcCursor.getTime() < endMs) {
      dates.add(this._utcDateKey(utcCursor));
      utcCursor.setUTCDate(utcCursor.getUTCDate() + 1);
    }
    return Array.from(dates).sort();
  }

  _minuteStartMs(value) {
    const date = new Date(value);
    date.setSeconds(0, 0);
    return date.getTime();
  }

  _minuteKey(value) {
    return new Date(this._minuteStartMs(value)).toISOString();
  }

  _dateKey(value = new Date()) {
    const date = new Date(value);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }

  _utcDateKey(value = new Date()) {
    return new Date(value).toISOString().slice(0, 10);
  }

  _dayPath(date) {
    return path.join(this.basePath, `${date}.json`);
  }
}

module.exports = { RuntimeAvailabilityService };
