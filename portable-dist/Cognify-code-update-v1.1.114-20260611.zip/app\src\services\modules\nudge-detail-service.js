const { contextSwitchNudgeFromRecords } = require('./nudge-analysis-service');

async function buildNudgeDetails(nudge, providers = {}) {
  const base = {
    nudge,
    eyebrow: 'Nudge context',
    title: nudge?.title || 'Cognify Nudge',
    why: nudge?.message || 'Recent activity triggered this nudge.',
    generated_at: new Date(providers.nowMs || Date.now()).toISOString(),
    metrics: compactMetrics([
      { label: 'Signal', value: nudge?.metric || nudge?.severity || '-' },
      { label: 'Type', value: titleCaseToken(nudge?.type || 'nudge') },
      { label: 'Action', value: targetLabel(nudge?.target) }
    ]),
    evidence_title: 'Recent evidence',
    evidence: [],
    cta_label: targetCta(nudge?.target)
  };

  if (!nudge) {
    return base;
  }

  try {
    if (nudge.type === 'context-switching') {
      return buildContextSwitchNudgeDetails(nudge, base, providers);
    }
    if (nudge.type === 'idle') {
      return buildIdleNudgeDetails(nudge, base, providers);
    }
    if (nudge.type === 'idle-return') {
      return buildIdleReturnNudgeDetails(nudge, base);
    }
    if (nudge.type === 'health-tip' || nudge.type === 'work-hours-break') {
      return buildWorkHoursBreakNudgeDetails(nudge, base);
    }
    if (nudge.type === 'focus-drop') {
      return await buildFocusDropNudgeDetails(nudge, base, providers);
    }
    if (nudge.type === 'peak-productivity') {
      return buildPeakProductivityNudgeDetails(nudge, base);
    }
  } catch (error) {
    return {
      ...base,
      why: `${base.why} Live detail refresh failed: ${error.message}`,
      evidence: evidenceFromNudge(nudge)
    };
  }

  return {
    ...base,
    evidence: evidenceFromNudge(nudge)
  };
}

function targetLabel(target) {
  if (target === 'reports') return 'Reports';
  if (target === 'manual-block') return 'Manual block';
  if (target === 'work-hours') return 'Work Hours';
  if (target === 'profile') return 'Profile';
  return 'Snapshot';
}

function targetCta(target) {
  if (target === 'reports') return 'Open reports';
  if (target === 'manual-block') return 'Add manual block';
  if (target === 'work-hours') return 'Open Work Hours';
  if (target === 'profile') return 'Open profile';
  return 'Open snapshot';
}

function buildContextSwitchNudgeDetails(nudge, base, providers = {}) {
  const nowMs = Number(providers.nowMs || Date.now());
  const end = new Date(nowMs);
  const start = new Date(nowMs - (15 * 60 * 1000));
  const records = providers.queryActivityRange
    ? providers.queryActivityRange(start.toISOString(), end.toISOString())
    : [];
  const liveNudge = contextSwitchNudgeFromRecords(records, {
    startMs: start.getTime(),
    endMs: end.getTime()
  });
  const analysis = liveNudge?.analysis || nudge.analysis || {};
  const segments = analysis.segments || [];
  const recentSegments = segments.slice(-6);

  return {
    ...base,
    title: 'Context switching',
    why: `Cognify saw ${analysis.switches || 0} meaningful switches across ${analysis.unique_surface_count || 0} apps or sites in the last ${analysis.window_minutes || 15} minutes.`,
    metrics: compactMetrics([
      { label: 'Switches', value: String(analysis.switches || 0) },
      { label: 'Surfaces', value: String(analysis.unique_surface_count || 0) },
      { label: 'Window', value: `${analysis.window_minutes || 15}m` }
    ]),
    evidence_title: 'Recent surfaces',
    evidence: recentSegments.map((segment) => ({
      time: formatClockTime(segment.startMs),
      label: segment.label || segment.key || 'Unknown surface',
      meta: formatDurationMs(segment.durationMs)
    })),
    cta_label: 'Open reports'
  };
}

function buildIdleNudgeDetails(nudge, base, providers = {}) {
  const nowMs = Number(providers.nowMs || Date.now());
  const idleSummary = providers.getIdleSummary ? providers.getIdleSummary() : {};
  const activeSinceMs = new Date(idleSummary.active_since || nowMs).getTime();
  const idleMinutes = Number.isFinite(activeSinceMs)
    ? Math.floor((nowMs - activeSinceMs) / 60000)
    : Number.parseInt(nudge.metric, 10);

  return {
    ...base,
    why: `The PC has been idle for ${formatNudgeMinutes(idleMinutes)}. Cognify is holding this as idle time until activity resumes.`,
    metrics: compactMetrics([
      { label: 'Idle now', value: formatNudgeMinutes(idleMinutes) },
      { label: 'Since', value: formatClockTime(activeSinceMs) },
      { label: 'Today idle', value: formatNudgeMinutes(totalIdleMinutes(idleSummary)) }
    ]),
    evidence: latestIdleIntervals(idleSummary).map((interval) => ({
      time: formatClockTime(new Date(interval.start).getTime()),
      label: 'Idle interval',
      meta: formatNudgeMinutes(Number(interval.duration_seconds || 0) / 60)
    })),
    cta_label: 'Open snapshot'
  };
}

function buildIdleReturnNudgeDetails(nudge, base) {
  const block = nudge.manual_block || {};
  const start = formatClockTime(block.startTime);
  const end = formatClockTime(block.endTime);
  return {
    ...base,
    why: `${nudge.metric || 'Idle time'} was recorded as PC idle. If you were working away from the PC, save it from the nudge as a Manual Timing Block.`,
    metrics: compactMetrics([
      { label: 'Idle slot', value: nudge.metric || '-' },
      { label: 'From', value: start || '-' },
      { label: 'To', value: end || '-' }
    ]),
    evidence: evidenceFromNudge(nudge),
    cta_label: 'Use nudge'
  };
}

function buildWorkHoursBreakNudgeDetails(nudge, base) {
  const workMinutes = Math.max(0, Math.round(Number(nudge.work_minutes || 0)));
  const workLabel = nudge.metric || formatNudgeMinutes(workMinutes);

  return {
    ...base,
    why: `Cognify is basing this reminder on ${workLabel} of Work Hours today, not PC Available time.`,
    metrics: compactMetrics([
      { label: 'Work Hours', value: workLabel },
      { label: 'Basis', value: 'Work Hours only' },
      { label: 'Suggestion', value: 'Stretch' }
    ]),
    evidence: [
      {
        time: 'Today',
        label: 'Final Work Hours',
        meta: workLabel
      },
      {
        time: 'Formula',
        label: 'PC Available - Idle deducted + Manual work/meeting restored',
        meta: 'Missing/no evidence is review-only'
      }
    ],
    cta_label: 'Open Work Hours'
  };
}

async function buildFocusDropNudgeDetails(nudge, base, providers = {}) {
  const nowMs = Number(providers.nowMs || Date.now());
  const end = new Date(nowMs);
  const start = new Date(nowMs - (60 * 60 * 1000));
  const todayStats = providers.getTodayStats ? await providers.getTodayStats() : {};
  const buckets = classifiedMinutesFromSummaryItems(
    todayStats?.summary?.app_timeline || [],
    start.getTime(),
    end.getTime()
  );

  return {
    ...base,
    why: `The last hour includes ${formatNudgeMinutes(buckets.social || 0)} of social or distraction-classified activity.`,
    metrics: compactMetrics([
      { label: 'Distraction', value: formatNudgeMinutes(buckets.social || 0) },
      { label: 'Work', value: formatNudgeMinutes(buckets.work || 0) },
      { label: 'Window', value: '1h' }
    ]),
    evidence: evidenceFromNudge(nudge),
    cta_label: 'Open reports'
  };
}

function buildPeakProductivityNudgeDetails(nudge, base) {
  const peak = nudge.peak_window || {};
  return {
    ...base,
    why: `Your recent focus trend points to ${peak.label || nudge.metric || 'this window'} as a strong deep-work period.`,
    metrics: compactMetrics([
      { label: 'Best window', value: peak.label || nudge.metric || '-' },
      { label: 'Signal', value: 'Focus' },
      { label: 'Range', value: '7d' }
    ]),
    evidence: evidenceFromNudge(nudge),
    cta_label: 'Open reports'
  };
}

function evidenceFromNudge(nudge = {}) {
  return [
    {
      time: 'Now',
      label: nudge.footer || nudge.message || 'Nudge signal',
      meta: nudge.metric || ''
    }
  ];
}

function formatNudgeMinutes(minutes) {
  const rounded = Math.max(0, Math.round(Number(minutes) || 0));
  if (rounded >= 60) {
    const hours = Math.floor(rounded / 60);
    const mins = rounded % 60;
    return mins ? `${hours}h ${mins}m` : `${hours}h`;
  }
  return `${rounded}m`;
}

function classifiedMinutesFromSummaryItems(appTimeline = [], startMs, endMs) {
  const buckets = { work: 0, meeting: 0, social: 0, other: 0, unclear: 0 };
  appTimeline.forEach((group) => {
    (group.items || []).forEach((item) => {
      const itemMs = new Date(item.timestamp).getTime();
      if (!Number.isFinite(itemMs) || itemMs < startMs || itemMs > endMs) {
        return;
      }
      Object.entries(item.classified_ms || {}).forEach(([key, value]) => {
        buckets[key] = (buckets[key] || 0) + (Number(value || 0) / 60000);
      });
    });
  });

  return buckets;
}

function compactMetrics(items = []) {
  return items.filter((item) => item && item.value !== undefined && item.value !== null);
}

function latestIdleIntervals(idleSummary = {}) {
  return (idleSummary.intervals || []).slice(-3).reverse();
}

function totalIdleMinutes(idleSummary = {}) {
  return (idleSummary.intervals || []).reduce((total, interval) => {
    return total + (Number(interval.duration_seconds || 0) / 60);
  }, 0);
}

function formatClockTime(value) {
  const date = typeof value === 'number' ? new Date(value) : new Date(value);
  if (!Number.isFinite(date.getTime())) {
    return '';
  }
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function formatDurationMs(ms) {
  return formatNudgeMinutes(Number(ms || 0) / 60000);
}

function titleCaseToken(value = '') {
  return String(value)
    .split(/[-_\s]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

module.exports = {
  buildNudgeDetails,
  classifiedMinutesFromSummaryItems,
  formatNudgeMinutes
};
