const crypto = require('crypto');
const fs = require('fs');

function loadMyWeeklyReportConfig(configPath) {
  const raw = fs.readFileSync(configPath, 'utf8');
  const config = JSON.parse(raw);
  validateConfig(config);
  return config;
}

function validateConfig(config = {}) {
  if (!config.version || typeof config.version !== 'string') {
    throw new Error('My weekly report config requires a string version.');
  }
  if (!config.role_focus || typeof config.role_focus !== 'object') {
    throw new Error('My weekly report config requires role_focus.');
  }
  if (!Array.isArray(config.role_focus.default) || !config.role_focus.default.length) {
    throw new Error('My weekly report config requires role_focus.default.');
  }
}

function buildMyWeeklyReport(evidence = {}, config = {}) {
  validateConfig(config);
  const roleId = evidence.role?.role_id || 'default';
  const focusTemplates = config.role_focus[roleId] || config.role_focus.default;
  const observed = buildObservedItems(evidence);
  const userProvided = buildUserProvidedItems(evidence.self_input);
  const inferred = focusTemplates.map((item) => ({
    label: item.label,
    text: renderTemplate(item.template, evidence),
    source: 'inferred',
    confidence: evidence.confidence?.level || 'low'
  }));
  const evidenceGaps = (evidence.evidence_gaps || []).map((text) => ({
    label: 'Evidence gap',
    text,
    source: 'gap',
    confidence: 'high'
  }));
  const suggestedNotes = (config.suggested_note_prompts || []).map((text) => ({
    label: 'Suggested note',
    text,
    source: 'prompt',
    confidence: 'n/a'
  }));

  return {
    generated_at: new Date().toISOString(),
    profile_id: 'my_weekly_report',
    title: config.title || 'My Weekly Report',
    config_version: config.version,
    config_hash: hashConfig(config),
    week: evidence.week || {},
    role: evidence.role || {},
    confidence: evidence.confidence || { score: 0, level: 'low' },
    totals: evidence.totals || {},
    sections: [
      {
        id: 'role_context',
        label: 'Role And Context Used',
        items: buildRoleContextItems(evidence)
      },
      {
        id: 'summary',
        label: 'Weekly Summary',
        items: buildSummaryItems(evidence)
      },
      {
        id: 'key_work',
        label: 'Key Work Done',
        items: observed
      },
      {
        id: 'role_impact',
        label: 'Role-Specific Impact',
        items: inferred
      },
      {
        id: 'blockers_followups',
        label: 'Blockers And Follow-Ups',
        items: buildBlockerFollowupItems(evidence)
      },
      {
        id: 'user_context',
        label: 'User-Provided Context',
        items: userProvided
      },
      {
        id: 'confidence',
        label: 'Evidence Confidence',
        items: [
          {
            label: 'Confidence',
            text: `${evidence.confidence?.level || 'low'} (${Number(evidence.confidence?.score || 0)}%)`,
            source: 'observed',
            confidence: evidence.confidence?.level || 'low'
          },
          ...evidenceGaps,
          ...suggestedNotes
        ]
      }
    ]
  };
}

function buildSummaryItems(evidence = {}) {
  const totals = evidence.totals || {};
  return [
    {
      label: 'Observed work pattern',
      text: `${Number(totals.active_days || 0)} active day(s), ${formatMinutes(totals.work_minutes || 0)} Work Hours, ${formatMinutes(totals.pc_available_minutes || totals.active_minutes || 0)} PC Available, ${formatMinutes(totals.meeting_minutes || 0)} meeting/chat.`,
      source: 'observed',
      confidence: evidence.confidence?.level || 'low'
    },
    {
      label: 'Main visible themes',
      text: listLabels(evidence.project_themes, 'No strong project themes detected.'),
      source: 'inferred',
      confidence: evidence.project_themes?.length ? 'medium' : 'low'
    }
  ];
}

function buildRoleContextItems(evidence = {}) {
  const role = evidence.role || {};
  const items = [];
  const roleLabel = role.role || 'Role not confirmed';
  const sourceLabel = role.role_source ? ` (${role.role_source.replace(/_/g, ' ')})` : '';
  items.push({
    label: 'Role profile',
    text: `${roleLabel}${sourceLabel}.`,
    source: role.role ? 'role_profile' : 'gap',
    confidence: role.role ? 'high' : 'low'
  });
  if (role.role_notes) {
    items.push({
      label: 'Role context',
      text: role.role_notes,
      source: 'role_profile',
      confidence: 'high'
    });
  } else {
    items.push({
      label: 'Role context missing',
      text: 'Add role context so Cognify can separate expected role behavior from distractions or low-value switching.',
      source: 'gap',
      confidence: 'high'
    });
  }
  items.push({
    label: 'Evidence boundary',
    text: 'This report explains visible PC activity and user-provided weekly context; decisions, calls, travel, business outcomes, and offline work must be added before using it as a complete work record.',
    source: 'guardrail',
    confidence: 'high'
  });
  return items;
}

function buildObservedItems(evidence = {}) {
  const items = [];
  const selfInput = evidence.self_input || {};
  (selfInput.completed_tasks || []).slice(0, 8).forEach((text) => {
    items.push({ label: 'Completed task', text, source: 'user_provided', confidence: 'high' });
  });
  items.push({
    label: 'Top apps',
    text: listUsage(evidence.top_apps, 'No app usage summary available.'),
    source: 'observed',
    confidence: evidence.top_apps?.length ? 'high' : 'low'
  });
  items.push({
    label: 'Top sites',
    text: listUsage(evidence.top_sites, 'No site usage summary available.'),
    source: 'observed',
    confidence: evidence.top_sites?.length ? 'high' : 'low'
  });
  items.push({
    label: 'Focus blocks',
    text: `${Number(evidence.focus?.block_count || 0)} focus block(s); longest ${Number(evidence.focus?.longest_block_minutes || 0)} minute(s).`,
    source: 'observed',
    confidence: evidence.focus?.block_count ? 'medium' : 'low'
  });
  return items;
}

function buildBlockerFollowupItems(evidence = {}) {
  const selfInput = evidence.self_input || {};
  const items = [];
  (selfInput.blockers || []).slice(0, 6).forEach((text) => {
    items.push({ label: 'Blocker', text, source: 'user_provided', confidence: 'high' });
  });
  if (selfInput.deadline_work) {
    items.push({ label: 'Deadline work', text: selfInput.deadline_work, source: 'user_provided', confidence: 'high' });
  }
  if (selfInput.misread_context) {
    items.push({ label: 'Context correction', text: selfInput.misread_context, source: 'user_provided', confidence: 'high' });
  }
  if (!items.length) {
    items.push({
      label: 'No blockers provided',
      text: 'No blockers or follow-ups were added for this week.',
      source: 'gap',
      confidence: 'high'
    });
  }
  return items;
}

function buildUserProvidedItems(selfInput = {}) {
  selfInput = selfInput || {};
  const items = [];
  if (selfInput.offline_work) {
    items.push({ label: 'Offline work', text: selfInput.offline_work, source: 'user_provided', confidence: 'high' });
  }
  if (selfInput.deadline_work) {
    items.push({ label: 'Urgent/deadline work', text: selfInput.deadline_work, source: 'user_provided', confidence: 'high' });
  }
  if (selfInput.misread_context) {
    items.push({ label: 'Cognify may misread', text: selfInput.misread_context, source: 'user_provided', confidence: 'high' });
  }
  if (!items.length) {
    items.push({
      label: 'Weekly context missing',
      text: 'Add weekly context to capture offline work, business outcomes, and corrections.',
      source: 'gap',
      confidence: 'high'
    });
  }
  return items;
}

function renderTemplate(template = '', evidence = {}) {
  const variables = templateVariables(evidence);
  return String(template).replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, key) => variables[key] || '');
}

function templateVariables(evidence = {}) {
  const totals = evidence.totals || {};
  return {
    active_days: String(totals.active_days || 0),
    work_minutes: String(totals.work_minutes || 0),
    meeting_minutes: String(totals.meeting_minutes || 0),
    manual_minutes: String(totals.manual_minutes || 0),
    project_themes: listLabels(evidence.project_themes, 'limited visible themes'),
    meeting_surfaces: listLabels(evidence.meetings_and_chat?.top_surfaces, 'limited meeting/chat surfaces'),
    top_apps: listUsage(evidence.top_apps, 'limited app evidence'),
    top_sites: listUsage(evidence.top_sites, 'limited site evidence'),
    focus_blocks: String(evidence.focus?.block_count || 0),
    context_switches: String(evidence.context_switching?.switches || 0),
    unique_surfaces: String(evidence.context_switching?.unique_surfaces || 0)
  };
}

function formatMinutes(value) {
  const minutes = Math.max(0, Math.round(Number(value) || 0));
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (!hours) return `${mins}m`;
  if (!mins) return `${hours}h`;
  return `${hours}h ${mins}m`;
}

function listLabels(items = [], fallback) {
  const labels = (items || []).slice(0, 5).map((item) => item.label).filter(Boolean);
  return labels.length ? labels.join(', ') : fallback;
}

function listUsage(items = [], fallback) {
  const labels = (items || [])
    .slice(0, 5)
    .map((item) => `${item.label}${Number.isFinite(Number(item.minutes)) ? ` (${item.minutes}m)` : ''}`)
    .filter(Boolean);
  return labels.length ? labels.join(', ') : fallback;
}

function hashConfig(config = {}) {
  return crypto.createHash('sha256').update(JSON.stringify(config)).digest('hex');
}

module.exports = {
  buildMyWeeklyReport,
  loadMyWeeklyReportConfig
};
