using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

public static class CognifyWindowsFocusHelperNative
{
    private const uint EVENT_SYSTEM_FOREGROUND = 0x0003;
    private const uint EVENT_OBJECT_NAMECHANGE = 0x800C;
    private const uint WINEVENT_OUTOFCONTEXT = 0x0000;
    private const uint WINEVENT_SKIPOWNPROCESS = 0x0002;
    private const int WH_KEYBOARD_LL = 13;
    private const int WH_MOUSE_LL = 14;
    private const int WM_KEYDOWN = 0x0100;
    private const int WM_SYSKEYDOWN = 0x0104;
    private const int WM_LBUTTONDOWN = 0x0201;
    private const int WM_RBUTTONDOWN = 0x0204;
    private const int WM_MBUTTONDOWN = 0x0207;
    private const int WM_MOUSEWHEEL = 0x020A;
    private const int WM_MOUSEMOVE = 0x0200;
    private const int MONITOR_DEFAULTTONEAREST = 2;
    private const int PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;

    private static WinEventDelegate _foregroundDelegate = HandleWinEvent;
    private static WinEventDelegate _nameDelegate = HandleWinEvent;
    private static LowLevelProc _keyboardProc = KeyboardHookCallback;
    private static LowLevelProc _mouseProc = MouseHookCallback;
    private static IntPtr _foregroundHook = IntPtr.Zero;
    private static IntPtr _nameHook = IntPtr.Zero;
    private static IntPtr _keyboardHook = IntPtr.Zero;
    private static IntPtr _mouseHook = IntPtr.Zero;
    private static System.Threading.Timer _idleTimer;
    private static bool _enableMouseHook = String.Equals(Environment.GetEnvironmentVariable("COGNIFY_FOCUS_MOUSE_HOOK"), "1", StringComparison.OrdinalIgnoreCase);
    private static bool _enableKeyboardHook = String.Equals(Environment.GetEnvironmentVariable("COGNIFY_FOCUS_KEYBOARD_HOOK"), "1", StringComparison.OrdinalIgnoreCase);
    private static bool _emitCursorCoordinates = String.Equals(Environment.GetEnvironmentVariable("COGNIFY_FOCUS_CURSOR_COORDS"), "1", StringComparison.OrdinalIgnoreCase);
    private static bool _emitExecutablePath = String.Equals(Environment.GetEnvironmentVariable("COGNIFY_FOCUS_EXECUTABLE_PATH"), "1", StringComparison.OrdinalIgnoreCase);
    private static bool _emitSessionUser = String.Equals(Environment.GetEnvironmentVariable("COGNIFY_FOCUS_SESSION_USER"), "1", StringComparison.OrdinalIgnoreCase);
    private static long _lastKeyboardEmit = 0;
    private static long _lastMouseMoveEmit = 0;
    private static long _lastMouseActionEmit = 0;
    private static string _lastIdleBucket = "";
    private static long _lastInputStateEmit = 0;
    private static IntPtr _lastInputStateHwnd = IntPtr.Zero;
    private static Dictionary<long, TitleState> _titleStates = new Dictionary<long, TitleState>();
    private static Dictionary<int, ProcessInfo> _processCache = new Dictionary<int, ProcessInfo>();
    private static readonly object _writeLock = new object();

    [STAThread]
    public static void Main(string[] args)
    {
        try
        {
            Console.OutputEncoding = new UTF8Encoding(false);
        }
        catch
        {
        }

        try
        {
            MainLoop();
        }
        finally
        {
            Stop();
        }
    }

    public static void MainLoop()
    {
        EmitSnapshot("helper_started", IntPtr.Zero, "");
        _foregroundHook = SetWinEventHook(EVENT_SYSTEM_FOREGROUND, EVENT_SYSTEM_FOREGROUND, IntPtr.Zero, _foregroundDelegate, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
        _nameHook = SetWinEventHook(EVENT_OBJECT_NAMECHANGE, EVENT_OBJECT_NAMECHANGE, IntPtr.Zero, _nameDelegate, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
        if (_enableKeyboardHook)
        {
            _keyboardHook = SetHook(WH_KEYBOARD_LL, _keyboardProc);
        }
        if (_enableMouseHook)
        {
            _mouseHook = SetHook(WH_MOUSE_LL, _mouseProc);
        }
        _idleTimer = new System.Threading.Timer(_ => EmitInputState(), null, 1000, 15000);
        EmitSnapshot("foreground_snapshot", GetForegroundWindow(), "");
        Application.Run();
    }

    public static void Stop()
    {
        if (_idleTimer != null) _idleTimer.Dispose();
        if (_foregroundHook != IntPtr.Zero) UnhookWinEvent(_foregroundHook);
        if (_nameHook != IntPtr.Zero) UnhookWinEvent(_nameHook);
        if (_keyboardHook != IntPtr.Zero) UnhookWindowsHookEx(_keyboardHook);
        if (_mouseHook != IntPtr.Zero) UnhookWindowsHookEx(_mouseHook);
    }

    private static IntPtr SetHook(int hookId, LowLevelProc proc)
    {
        try
        {
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
            {
                return SetWindowsHookEx(hookId, proc, GetModuleHandle(curModule.ModuleName), 0);
            }
        }
        catch
        {
            return IntPtr.Zero;
        }
    }

    private static void HandleWinEvent(IntPtr hWinEventHook, uint eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime)
    {
        if (idObject != 0 || hwnd == IntPtr.Zero) return;
        if (eventType == EVENT_SYSTEM_FOREGROUND)
        {
            EmitSnapshot("foreground_changed", hwnd, "");
            return;
        }
        if (eventType == EVENT_OBJECT_NAMECHANGE && hwnd == GetForegroundWindow())
        {
            long now = TickMs();
            string title = GetWindowText(hwnd);
            string titleKey = NormalizeTitleKey(title);
            long hwndKey = hwnd.ToInt64();
            TitleState state;
            if (!_titleStates.TryGetValue(hwndKey, out state))
            {
                state = new TitleState();
            }

            if (now - state.LastEmitMs < 15000)
            {
                return;
            }
            if (titleKey == state.LastTitleKey && now - state.LastEmitMs < 60000)
            {
                return;
            }
            state.LastTitleKey = titleKey;
            state.LastEmitMs = now;
            _titleStates[hwndKey] = state;
            if (_titleStates.Count > 128)
            {
                _titleStates.Clear();
                _titleStates[hwndKey] = state;
            }
            EmitSnapshot("foreground_title_changed", hwnd, "");
        }
    }

    private static IntPtr KeyboardHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            int message = wParam.ToInt32();
            if (message == WM_KEYDOWN || message == WM_SYSKEYDOWN)
            {
                long now = TickMs();
                if (now - _lastKeyboardEmit >= 1000)
                {
                    _lastKeyboardEmit = now;
                    EmitSnapshot("input_activity", GetForegroundWindow(), "keyboard");
                }
            }
        }
        return CallNextHookEx(_keyboardHook, nCode, wParam, lParam);
    }

    private static IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            int message = wParam.ToInt32();
            long now = TickMs();
            if (message == WM_MOUSEMOVE)
            {
                if (now - _lastMouseMoveEmit >= 2000)
                {
                    _lastMouseMoveEmit = now;
                    EmitSnapshot("input_activity", GetForegroundWindow(), "mouse_move");
                }
            }
            else if (message == WM_LBUTTONDOWN || message == WM_RBUTTONDOWN || message == WM_MBUTTONDOWN || message == WM_MOUSEWHEEL)
            {
                if (now - _lastMouseActionEmit >= 500)
                {
                    _lastMouseActionEmit = now;
                    EmitSnapshot("input_activity", GetForegroundWindow(), MouseActionName(message));
                }
            }
        }
        return CallNextHookEx(_mouseHook, nCode, wParam, lParam);
    }

    private static string MouseActionName(int message)
    {
        if (message == WM_LBUTTONDOWN) return "mouse_left";
        if (message == WM_RBUTTONDOWN) return "mouse_right";
        if (message == WM_MBUTTONDOWN) return "mouse_middle";
        if (message == WM_MOUSEWHEEL) return "mouse_wheel";
        return "mouse";
    }

    private static void EmitInputState()
    {
        long idleSeconds = GetIdleSeconds();
        string idleBucket = IdleBucket(idleSeconds);
        IntPtr hwnd = GetForegroundWindow();
        long now = TickMs();
        bool changed = idleBucket != _lastIdleBucket || hwnd != _lastInputStateHwnd;
        bool keepalive = now - _lastInputStateEmit >= 60000;
        if (!changed && !keepalive) return;
        _lastIdleBucket = idleBucket;
        _lastInputStateHwnd = hwnd;
        _lastInputStateEmit = now;
        EmitSnapshot("input_state", hwnd, "");
    }

    private static string IdleBucket(long idleSeconds)
    {
        if (idleSeconds < 5) return "active";
        if (idleSeconds < 60) return "recent_input";
        if (idleSeconds < 300) return "idle_1m";
        if (idleSeconds < 900) return "idle_5m";
        return "idle_15m";
    }

    private static void EmitSnapshot(string eventType, IntPtr hwnd, string inputKind)
    {
        try
        {
            if (hwnd == IntPtr.Zero) hwnd = GetForegroundWindow();
            uint pid = 0;
            uint threadId = hwnd == IntPtr.Zero ? 0 : GetWindowThreadProcessId(hwnd, out pid);
            RECT windowRect = new RECT();
            if (hwnd != IntPtr.Zero) GetWindowRect(hwnd, out windowRect);
            POINT cursor = new POINT();
            GetCursorPos(out cursor);
            IntPtr windowMonitor = hwnd == IntPtr.Zero ? IntPtr.Zero : MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
            IntPtr cursorMonitor = MonitorFromPoint(cursor, MONITOR_DEFAULTTONEAREST);
            MONITORINFOEX windowMonitorInfo = GetMonitorInfoEx(windowMonitor);
            MONITORINFOEX cursorMonitorInfo = GetMonitorInfoEx(cursorMonitor);
            ProcessInfo processInfo = GetProcessInfo((int)pid);
            long idleSeconds = GetIdleSeconds();

            string json = "{"
                + JsonProp("schema_version", "1") + ","
                + JsonProp("source", "windows_focus_helper") + ","
                + JsonProp("event_type", eventType) + ","
                + JsonProp("observed_at", DateTimeOffset.UtcNow.ToString("o")) + ","
                + JsonProp("session_user", _emitSessionUser ? Environment.UserName : "") + ","
                + JsonProp("hwnd", hwnd.ToInt64().ToString()) + ","
                + JsonProp("thread_id", threadId.ToString()) + ","
                + JsonProp("process_id", pid.ToString()) + ","
                + JsonProp("process_name", processInfo.Name) + ","
                + JsonProp("executable_path", _emitExecutablePath ? processInfo.Path : "") + ","
                + JsonProp("window_title", hwnd == IntPtr.Zero ? "" : GetWindowText(hwnd)) + ","
                + JsonProp("class_name", hwnd == IntPtr.Zero ? "" : GetClassNameSafe(hwnd)) + ","
                + JsonProp("input_kind", inputKind) + ","
                + JsonProp("idle_seconds", idleSeconds.ToString()) + ","
                + JsonProp("idle_bucket", IdleBucket(idleSeconds)) + ","
                + JsonProp("window_left", windowRect.Left.ToString()) + ","
                + JsonProp("window_top", windowRect.Top.ToString()) + ","
                + JsonProp("window_right", windowRect.Right.ToString()) + ","
                + JsonProp("window_bottom", windowRect.Bottom.ToString()) + ","
                + JsonProp("monitor_device", windowMonitorInfo.szDevice ?? "") + ","
                + JsonProp("monitor_left", windowMonitorInfo.rcMonitor.Left.ToString()) + ","
                + JsonProp("monitor_top", windowMonitorInfo.rcMonitor.Top.ToString()) + ","
                + JsonProp("monitor_right", windowMonitorInfo.rcMonitor.Right.ToString()) + ","
                + JsonProp("monitor_bottom", windowMonitorInfo.rcMonitor.Bottom.ToString()) + ","
                + JsonProp("cursor_x", _emitCursorCoordinates ? cursor.X.ToString() : "") + ","
                + JsonProp("cursor_y", _emitCursorCoordinates ? cursor.Y.ToString() : "") + ","
                + JsonProp("cursor_monitor_device", cursorMonitorInfo.szDevice ?? "")
                + "}";
            lock (_writeLock)
            {
                Console.WriteLine(json);
                Console.Out.Flush();
            }
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex.Message);
        }
    }

    private static ProcessInfo GetProcessInfo(int pid)
    {
        if (pid <= 0) return new ProcessInfo();
        long now = TickMs();
        ProcessInfo cached;
        if (_processCache.TryGetValue(pid, out cached) && cached.ExpiresAtMs > now)
        {
            return cached;
        }

        ProcessInfo info = new ProcessInfo();
        if (_emitExecutablePath)
        {
            info.Path = GetProcessPath(pid);
        }
        try
        {
            info.Name = Process.GetProcessById(pid).ProcessName + ".exe";
        }
        catch { }
        info.ExpiresAtMs = now + 60000;
        _processCache[pid] = info;
        if (_processCache.Count > 256)
        {
            _processCache.Clear();
            _processCache[pid] = info;
        }
        return info;
    }

    private static string JsonProp(string name, string value)
    {
        return "\"" + Escape(name) + "\":\"" + Escape(value ?? "") + "\"";
    }

    private static string Escape(string value)
    {
        return value.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "\\r").Replace("\n", "\\n");
    }

    private static string NormalizeTitleKey(string value)
    {
        if (String.IsNullOrEmpty(value)) return "";
        StringBuilder builder = new StringBuilder(value.Length);
        bool lastWasSpace = false;
        foreach (char c in value.ToLowerInvariant())
        {
            if (Char.IsLetterOrDigit(c))
            {
                builder.Append(c);
                lastWasSpace = false;
            }
            else if (!lastWasSpace)
            {
                builder.Append(' ');
                lastWasSpace = true;
            }
        }
        return builder.ToString().Trim();
    }

    private static string GetWindowText(IntPtr hwnd)
    {
        int length = GetWindowTextLength(hwnd);
        StringBuilder builder = new StringBuilder(Math.Max(length + 1, 256));
        GetWindowText(hwnd, builder, builder.Capacity);
        return builder.ToString();
    }

    private static string GetClassNameSafe(IntPtr hwnd)
    {
        StringBuilder builder = new StringBuilder(256);
        GetClassName(hwnd, builder, builder.Capacity);
        return builder.ToString();
    }

    private static string GetProcessPath(int pid)
    {
        if (pid <= 0) return "";
        IntPtr handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid);
        if (handle == IntPtr.Zero) return "";
        try
        {
            StringBuilder path = new StringBuilder(1024);
            int size = path.Capacity;
            return QueryFullProcessImageName(handle, 0, path, ref size) ? path.ToString() : "";
        }
        finally
        {
            CloseHandle(handle);
        }
    }

    private static long GetIdleSeconds()
    {
        LASTINPUTINFO info = new LASTINPUTINFO();
        info.cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO));
        if (!GetLastInputInfo(ref info)) return 0;
        uint elapsedMs = unchecked((uint)Environment.TickCount - info.dwTime);
        return Math.Max(0, elapsedMs / 1000);
    }

    private static long TickMs()
    {
        return (long)((Stopwatch.GetTimestamp() * 1000.0) / Stopwatch.Frequency);
    }

    private static MONITORINFOEX GetMonitorInfoEx(IntPtr monitor)
    {
        MONITORINFOEX info = new MONITORINFOEX();
        info.cbSize = Marshal.SizeOf(typeof(MONITORINFOEX));
        if (monitor != IntPtr.Zero) GetMonitorInfo(monitor, ref info);
        return info;
    }

    private delegate void WinEventDelegate(IntPtr hWinEventHook, uint eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime);
    private delegate IntPtr LowLevelProc(int nCode, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    [StructLayout(LayoutKind.Sequential)]
    private struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)]
    private struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    private struct MONITORINFOEX
    {
        public int cbSize;
        public RECT rcMonitor;
        public RECT rcWork;
        public int dwFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string szDevice;
    }

    private class ProcessInfo
    {
        public string Name = "";
        public string Path = "";
        public long ExpiresAtMs = 0;
    }

    private class TitleState
    {
        public string LastTitleKey = "";
        public long LastEmitMs = 0;
    }

    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetWindowTextLength(IntPtr hWnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetClassName(IntPtr hWnd, StringBuilder className, int maxCount);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
    [DllImport("user32.dll")] private static extern bool GetCursorPos(out POINT point);
    [DllImport("user32.dll")] private static extern IntPtr MonitorFromWindow(IntPtr hwnd, int flags);
    [DllImport("user32.dll")] private static extern IntPtr MonitorFromPoint(POINT point, int flags);
    [DllImport("user32.dll", CharSet = CharSet.Auto)] private static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFOEX lpmi);
    [DllImport("user32.dll")] private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
    [DllImport("user32.dll")] private static extern IntPtr SetWinEventHook(uint eventMin, uint eventMax, IntPtr hmodWinEventProc, WinEventDelegate lpfnWinEventProc, uint idProcess, uint idThread, uint dwFlags);
    [DllImport("user32.dll")] private static extern bool UnhookWinEvent(IntPtr hWinEventHook);
    [DllImport("user32.dll")] private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelProc lpfn, IntPtr hMod, uint dwThreadId);
    [DllImport("user32.dll")] private static extern bool UnhookWindowsHookEx(IntPtr hhk);
    [DllImport("user32.dll")] private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
    [DllImport("kernel32.dll", CharSet = CharSet.Auto)] private static extern IntPtr GetModuleHandle(string lpModuleName);
    [DllImport("kernel32.dll")] private static extern IntPtr OpenProcess(int access, bool inheritHandle, int processId);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern bool QueryFullProcessImageName(IntPtr hProcess, int flags, StringBuilder exeName, ref int size);
    [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr hObject);
}
