const eyebrow = document.getElementById('eyebrow');
const title = document.getElementById('title');
const why = document.getElementById('why');
const metrics = document.getElementById('metrics');
const evidence = document.getElementById('evidence');
const evidenceTitle = document.getElementById('evidenceTitle');
const updated = document.getElementById('updated');
const closeButton = document.getElementById('close');
const ctaButton = document.getElementById('cta');

function renderDetails(details = {}) {
  const nudge = details.nudge || {};
  eyebrow.textContent = details.eyebrow || 'Nudge context';
  title.textContent = details.title || nudge.title || 'Cognify Nudge';
  why.textContent = details.why || nudge.message || 'Recent activity triggered this nudge.';
  ctaButton.textContent = details.cta_label || 'Open details';
  evidenceTitle.textContent = details.evidence_title || 'Recent evidence';
  updated.textContent = details.generated_at ? `Updated ${formatClock(details.generated_at)}` : 'Updated now';

  metrics.innerHTML = '';
  (details.metrics || []).slice(0, 3).forEach((item) => {
    const node = document.createElement('div');
    node.className = 'metric';
    node.innerHTML = `
      <div class="metric-value"></div>
      <div class="metric-label"></div>
    `;
    node.querySelector('.metric-value').textContent = item.value || '-';
    node.querySelector('.metric-label').textContent = item.label || '';
    metrics.appendChild(node);
  });

  evidence.innerHTML = '';
  const rows = details.evidence || [];
  if (!rows.length) {
    const row = document.createElement('div');
    row.className = 'evidence-row';
    row.innerHTML = '<span class="evidence-time"></span><span class="evidence-label"></span><span class="evidence-meta"></span>';
    row.querySelector('.evidence-label').textContent = 'No additional evidence available yet.';
    evidence.appendChild(row);
    return;
  }

  rows.slice(0, 3).forEach((item) => {
    const row = document.createElement('div');
    row.className = 'evidence-row';
    row.innerHTML = '<span class="evidence-time"></span><span class="evidence-label"></span><span class="evidence-meta"></span>';
    row.querySelector('.evidence-time').textContent = item.time || '';
    row.querySelector('.evidence-label').textContent = item.label || '';
    row.querySelector('.evidence-meta').textContent = item.meta || '';
    evidence.appendChild(row);
  });
}

function formatClock(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) {
    return 'now';
  }
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

window.assistantApi.onNudgeDetailsUpdate(renderDetails);

window.assistantApi.getNudgeDetails()
  .then(renderDetails)
  .catch(() => renderDetails());

setInterval(() => {
  window.assistantApi.getNudgeDetails()
    .then(renderDetails)
    .catch(() => {});
}, 10000);

closeButton.addEventListener('click', () => {
  window.assistantApi.hideNudgeDetails();
});

ctaButton.addEventListener('click', () => {
  window.assistantApi.openNudgeTarget();
});
