const fs = require('fs');

const { ScreenpipeAdapter } = require('./modules/screenpipe-adapter');
const { PrivacyFilterService } = require('./modules/privacy-filter-service');
const { AIContextBuilder } = require('./modules/ai-context-builder');
const { ActivityQueryService } = require('./modules/activity-query-service');
const { ActivityStoreService } = require('./modules/activity-store-service');
const { SqliteActivityStoreService } = require('./modules/sqlite-activity-store-service');
const { DualWriteActivityStoreService } = require('./modules/dual-write-activity-store-service');
const { ActivityStoreComparisonService } = require('./modules/activity-store-comparison-service');
const { TaskExtractionService } = require('./modules/task-extraction-service');
const { DailySummaryService } = require('./modules/daily-summary-service');
const { ChatService } = require('./modules/chat-service');
const { SettingsService } = require('./modules/settings-service');
const { AuditLogService } = require('./modules/audit-log-service');
const { RetentionService } = require('./modules/retention-service');
const { WorkClassificationService } = require('./modules/work-classification-service');
const { SystemIdleService } = require('./modules/system-idle-service');
const { PayrollReportService } = require('./modules/payroll-report-service');
const { DailyLogService } = require('./modules/daily-log-service');
const { ActivityReportService } = require('./modules/activity-report-service');
const { ReportCacheService } = require('./modules/report-cache-service');
const { LiveDayTruthService } = require('./modules/live-day-truth-service');
const { WeeklySelfInputService } = require('./modules/weekly-self-input-service');
const { HodAppraisalReviewStoreService } = require('./modules/hod-appraisal-review-store-service');
const { FocusEventStoreService } = require('./modules/focus-event-store-service');
const { WindowsFocusService } = require('./modules/windows-focus-service');
const { RuntimeAvailabilityService } = require('./modules/runtime-availability-service');

function createServices(storagePath, options = {}) {
  if (!fs.existsSync(storagePath)) {
    fs.mkdirSync(storagePath, { recursive: true });
  }

  const settingsService = new SettingsService(storagePath);
  const auditLogService = new AuditLogService(storagePath);
  const jsonlActivityStoreService = new ActivityStoreService(storagePath);
  let sqliteActivityStoreService = null;
  let sqliteHealth = {
    ok: false,
    label: 'SQLite',
    detail: 'SQLite service not initialized.',
    informational: true
  };

  try {
    sqliteActivityStoreService = new SqliteActivityStoreService(storagePath, options.sqlite || {});
    sqliteHealth = {
      ...sqliteActivityStoreService.getHealth(),
      informational: true
    };
  } catch (error) {
    sqliteHealth = {
      ok: false,
      label: 'SQLite',
      detail: error?.message || String(error),
      informational: true
    };
  }
  const requestedStoreMode = String(process.env.COGNIFY_ACTIVITY_STORE || 'sqlite').trim().toLowerCase();
  const sqliteReady = Boolean(sqliteActivityStoreService && sqliteHealth.ok);
  const dualWriteErrors = [];
  const onDualWriteError = (payload) => {
    dualWriteErrors.push(payload);
    if (dualWriteErrors.length > 20) {
      dualWriteErrors.shift();
    }
  };
  let activityStoreMode = 'jsonl';
  let activityStoreService = jsonlActivityStoreService;

  if (requestedStoreMode === 'sqlite' && sqliteReady) {
    activityStoreMode = 'sqlite';
    activityStoreService = new DualWriteActivityStoreService(sqliteActivityStoreService, jsonlActivityStoreService, {
      primaryName: 'sqlite',
      secondaryName: 'jsonl',
      onSecondaryError: onDualWriteError
    });
  } else if (requestedStoreMode === 'dual' && sqliteReady) {
    activityStoreMode = 'dual';
    activityStoreService = new DualWriteActivityStoreService(jsonlActivityStoreService, sqliteActivityStoreService, {
      primaryName: 'jsonl',
      secondaryName: 'sqlite',
      onSecondaryError: onDualWriteError
    });
  }

  const screenpipeAdapter = new ScreenpipeAdapter(settingsService.getSettings());
  const privacyFilterService = new PrivacyFilterService(settingsService.getSettings());
  const activityQueryService = new ActivityQueryService(
    screenpipeAdapter,
    privacyFilterService,
    auditLogService,
    activityStoreService,
    options.activity || {}
  );
  const aiContextBuilder = new AIContextBuilder();
  const taskExtractionService = new TaskExtractionService();
  const workClassificationService = new WorkClassificationService(settingsService.getSettings().classification || {});
  const dailySummaryService = new DailySummaryService(taskExtractionService, workClassificationService);
  const focusEventStoreService = new FocusEventStoreService(storagePath);
  const windowsFocusService = new WindowsFocusService(focusEventStoreService, options.windowsFocus || {});
  const runtimeAvailabilityService = new RuntimeAvailabilityService(storagePath, options.runtimeAvailability || {});
  const retentionService = new RetentionService(settingsService, auditLogService, activityStoreService, focusEventStoreService);
  const systemIdleService = new SystemIdleService(storagePath, {
    ...(options.systemIdle || {}),
    activityStore: activityStoreService
  });
  const payrollReportService = new PayrollReportService(settingsService);
  const activityReportService = new ActivityReportService();
  const weeklySelfInputService = new WeeklySelfInputService(storagePath);
  const hodAppraisalReviewStoreService = new HodAppraisalReviewStoreService(storagePath);

  const chatService = new ChatService(
    activityQueryService,
    aiContextBuilder,
    dailySummaryService,
    taskExtractionService,
    auditLogService,
    systemIdleService,
    focusEventStoreService
  );

  const services = {
    screenpipe: screenpipeAdapter,
    activity: activityQueryService,
    aiContextBuilder,
    tasks: taskExtractionService,
    dailySummary: dailySummaryService,
    chat: chatService,
    settings: settingsService,
    auditLog: auditLogService,
    activityStore: activityStoreService,
    jsonlActivityStore: jsonlActivityStoreService,
    sqliteActivityStore: sqliteActivityStoreService,
    activityStoreMode,
    requestedActivityStoreMode: requestedStoreMode,
    activityStoreFallbackReason: requestedStoreMode !== activityStoreMode
      ? (sqliteReady ? `Unsupported activity store mode: ${requestedStoreMode}` : sqliteHealth.detail)
      : null,
    activityStoreHealth: () => ({
      mode: activityStoreMode,
      requestedMode: requestedStoreMode,
      fallbackReason: requestedStoreMode !== activityStoreMode
        ? (sqliteReady ? `Unsupported activity store mode: ${requestedStoreMode}` : sqliteHealth.detail)
        : null,
      dualWrite: activityStoreService.getDualWriteHealth
        ? activityStoreService.getDualWriteHealth()
        : null,
      recentDualWriteErrors: dualWriteErrors.slice()
    }),
    compareActivityStores: (startTime, endTime) => {
      if (!sqliteActivityStoreService) {
        throw new Error(sqliteHealth.detail || 'SQLite service is not initialized.');
      }
      return new ActivityStoreComparisonService(jsonlActivityStoreService, sqliteActivityStoreService, {
        leftName: 'jsonl',
        rightName: 'sqlite'
      }).compareRange(startTime, endTime);
    },
    sqliteHealth: () => {
      if (!sqliteActivityStoreService) {
        return sqliteHealth;
      }
      return {
        ...sqliteActivityStoreService.getHealth(),
        informational: true
      };
    },
    sqliteImportJsonl: (basePath, options) => {
      if (!sqliteActivityStoreService) {
        throw new Error(sqliteHealth.detail || 'SQLite service is not initialized.');
      }
      return sqliteActivityStoreService.importJsonlStore(basePath, options);
    },
    retention: retentionService,
    systemIdle: systemIdleService,
    payroll: payrollReportService,
    activityReport: activityReportService,
    weeklySelfInput: weeklySelfInputService,
    hodAppraisalReviews: hodAppraisalReviewStoreService,
    focusEvents: focusEventStoreService,
    windowsFocus: windowsFocusService,
    runtimeAvailability: runtimeAvailabilityService,
    classifier: workClassificationService
  };

  services.reportCache = new ReportCacheService(storagePath, services);
  services.liveTruth = new LiveDayTruthService(storagePath, services, options.liveTruth || {});
  services.dailyLog = new DailyLogService(storagePath, services);
  return services;
}

module.exports = { createServices };
