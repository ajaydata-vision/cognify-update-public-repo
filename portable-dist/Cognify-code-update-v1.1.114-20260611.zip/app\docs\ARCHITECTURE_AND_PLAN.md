# Screenpipe Companion (Windows-first) — Architecture, MVP Scope, and Plan

## Recommended stack

- **Electron + vanilla JS (MVP now)**
  - fastest path to Windows floating always-on-top widget + frameless panel
  - easy IPC boundary for local privacy controls
  - no GPU-heavy UI stack needed for MVP
- Future migration option: Tauri + React once feature set stabilizes and footprint optimization becomes higher priority.

## Final technical architecture

### Runtime flow

`Screenpipe daemon (127.0.0.1:3030)`  
→ `ScreenpipeAdapter`  
→ `ActivityQueryService`  
→ `PrivacyFilterService`  
→ `AIContextBuilder`  
→ `ChatService` / `DailySummaryService` / `TaskExtractionService`  
→ `FloatingWidgetUI + Chat Panel`

### Internal modules

1. ScreenpipeAdapter
2. ActivityQueryService
3. PrivacyFilterService
4. AIContextBuilder
5. ChatService
6. DailySummaryService
7. TaskExtractionService
8. FloatingWidgetUI (renderer widget + panel)
9. SettingsService
10. AuditLogService

## Activity schema (normalized)

```json
{
  "id": "string",
  "timestamp_start": "ISO 8601",
  "timestamp_end": "ISO 8601",
  "app_name": "string",
  "window_title": "string",
  "url_if_available": "string|null",
  "ocr_text": "string|null",
  "transcript_text": "string|null",
  "file_path_if_available": "string|null",
  "activity_type": "ocr|audio|input|accessibility|mixed",
  "sensitivity_level": "normal|high",
  "source": "screenpipe",
  "confidence_score": 0.0
}
```

## Privacy and security design

- Default text-only context building (OCR/transcripts/metadata), no screenshot upload path in MVP.
- PII redaction pass before AI context assembly.
- App/domain exclusion list applied before downstream reasoning.
- Explicit pause/resume and delete-range controls.
- Audit log stores every suggestion and user-triggered action.
- Suggestion-only action mode: no autonomous clicking/typing/sending/deleting/uploading.

## Failure handling

- Screenpipe offline: UI shows offline state + setup guide link.
- API unavailable/timeouts: graceful null-safe adapter returns.
- No data found: user-facing empty-state message.
- Missing OCR/audio: summary still generated from available modalities.
- AI failure: fallback heuristic summaries.
- Offline user: local heuristics continue.
- Slow queries: scoped windows (`last 2h`) and capped limits.

## Folder structure

```text
.
├─ docs/
│  ├─ SCREENPIPE_DISCOVERY_REPORT.md
│  └─ ARCHITECTURE_AND_PLAN.md
├─ scripts/
│  └─ smoke-test.js
├─ src/
│  ├─ main.js
│  ├─ preload.js
│  ├─ services/
│  │  └─ index.js
│  └─ renderer/
│     ├─ index.html
│     ├─ app.js
│     ├─ panel.html
│     └─ panel.js
└─ package.json
```

## MVP roadmap

1. **Done now**: floating widget + panel shell, Screenpipe status checks, query pipeline, summaries/tasks, pause/resume/delete hooks, privacy filters, audit log.
2. **Next**: integrate real LLM provider with strict redaction pipeline.
3. **Next**: richer timeline view + source drilldown.
4. **Next**: exclusions UI + retention scheduler + conflict-free delete confirmations.
5. **Next**: optional MCP mode for agent interoperability.

## Production roadmap

- Native installer + signed updates.
- End-to-end encrypted optional cloud sync with user-managed keys.
- Policy engine for regulated environments (DLP rules + admin config).
- Better entity extraction, meeting segmentation, and decision detection.
- Plugin ecosystem for assistant-side skills.

## Working prototype implementation plan

1. Install Screenpipe desktop app on Windows and verify `/health`.
2. Start this Electron app (`npm install && npm start`).
3. Ensure floating orb stays always-on-top and opens panel on click.
4. Validate last-2-hours query using `/search` time window.
5. Validate summaries/tasks and audit log writes.
6. Configure exclusions and retest context outputs.

## Windows local setup instructions

1. Install Node.js 20+.
2. Install Screenpipe app (or CLI + .NET 8 runtime).
3. Ensure Screenpipe is running: `curl http://127.0.0.1:3030/health`.
4. In this project:
   - `npm install`
   - `npm start`
5. Double-click floating orb to open assistant panel.

## Testing checklist

- [ ] Widget visible and draggable/always-on-top.
- [ ] Status indicator reflects Screenpipe health.
- [ ] “What did I do in last 2 hours?” returns contextual response.
- [ ] Daily summary output includes apps/sites/tasks/follow-ups.
- [ ] Task extraction returns timestamped action items.
- [ ] Pause/resume buttons hit adapter and update audit log.
- [ ] Delete-range path calls adapter endpoint.
- [ ] Excluded apps/domains are filtered out.
- [ ] No raw screenshot bytes passed into AI context by default.
- [ ] Suggestions only (no autonomous desktop actions).

## Known limitations and risks

- Endpoint behavior may vary by Screenpipe version.
- Current MVP uses heuristic summarization, not production-grade LLM orchestration.
- Delete-range endpoint compatibility may differ across versions.
- No bundled screenshot evidence in this environment because browser screenshot tool is unavailable.
- Runtime performance is a product requirement. Follow `docs/PERFORMANCE_CONTRACT.md` for every timer, refresh, IPC handler, report path, and background job.

## Implementation update (v0.2)

- Service layer is now physically split into dedicated module files under `src/services/modules/` to keep Screenpipe integration isolated and maintainable.
- Widget now supports drag via `-webkit-app-region: drag` and explicit collapse/expand control.
- Panel now supports explicit time-range querying and privacy exclusion editing from UI.
