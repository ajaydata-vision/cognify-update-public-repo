const { evaluatePerformanceRules } = require('./performance-rule-engine');

function buildHodAppraisalDraft(evidencePack = {}, rulesConfig = {}, options = {}) {
  const profileId = options.profileId || 'hod_appraisal';
  const profile = rulesConfig.output_profiles?.[profileId];
  if (!profile) {
    throw new Error(`HOD appraisal output profile not found: ${profileId}`);
  }

  const evaluated = options.evaluatedRules || evaluatePerformanceRules(evidencePack, rulesConfig);
  const sourceById = new Map((evaluated.categories || []).map((category) => [category.category_id, category]));
  const categories = profile.categories.map((field) => {
    const source = sourceById.get(field.source_category);
    if (!source) {
      throw new Error(`HOD field ${field.field_id} maps to missing category: ${field.source_category}`);
    }
    return mapHodField(field, source, profile);
  });

  return {
    generated_at: new Date().toISOString(),
    profile_id: profileId,
    profile_label: profile.label || 'HOD Appraisal Review Draft',
    week: evidencePack.week || {},
    role: evidencePack.role || {},
    role_fit: buildRoleFit(evidencePack.role || {}, profileId),
    rules_version: evaluated.rules_version,
    rules_hash: evaluated.rules_hash,
    evidence_confidence: evaluated.evidence_confidence,
    categories,
    overall_remark: buildOverallRemark(profile, evidencePack, categories)
  };
}

function buildRoleFit(role = {}, profileId = '') {
  if (profileId !== 'hod_appraisal') {
    return { level: 'neutral', message: 'Report role fit was not evaluated for this profile.' };
  }
  const roleId = String(role.role_id || '').trim();
  const reviewerRoleIds = new Set(['manager-hod', 'hr', 'admin-operations', 'c-level-executive']);
  if (reviewerRoleIds.has(roleId)) {
    return {
      level: 'appropriate',
      message: 'This draft is useful as a reviewer aid for appraisal wording, but final text still needs human judgment, outcomes, and offline context.'
    };
  }
  if (!roleId) {
    return {
      level: 'needs_role',
      message: 'Confirm the user role before relying on this HOD draft; appraisal wording depends on reviewer context.'
    };
  }
  return {
    level: 'limited',
    message: 'This HOD draft may not match the confirmed role. Use My Weekly Report for personal evidence, or have an HOD/HR reviewer complete this draft.'
  };
}

function mapHodField(field, source, profile) {
  const forcedReview = Boolean(field.force_review);
  const highRisk = (field.risk_level || source.risk_level) === 'high';
  const reviewRequired = Boolean(source.review_required || forcedReview);
  const reviewReasons = [
    ...(source.review_reasons || []),
    ...(forcedReview ? ['This HOD field is configured for human review.'] : [])
  ];
  const feedbackKey = reviewRequired
    ? ((forcedReview || source.evidence_strength === 'low') ? 'needs_review' : 'neutral')
    : 'positive';
  return {
    field_id: field.field_id,
    label: field.label,
    source_category: field.source_category,
    risk_level: field.risk_level || source.risk_level || 'medium',
    feedback_type: profile.feedback_types?.[feedbackKey] || feedbackKey,
    draft: source.draft,
    confidence: source.evidence_strength || 'low',
    review_required: reviewRequired,
    copy_allowed: Boolean(source.copy_allowed && !reviewRequired && !highRisk),
    review_reasons: reviewReasons,
    evidence: source.evidence || [],
    missing_context_prompt: reviewRequired ? (source.missing_context_prompt || field.missing_context_prompt || '') : '',
    language_flags: source.language_flags || []
  };
}

function buildOverallRemark(profile, evidencePack, categories) {
  const template = profile.remark?.template || 'Observed evidence for {role} is available for HOD review.';
  const draft = renderRemark(template, evidencePack);
  const reviewReasons = [];
  if ((evidencePack.confidence?.level || 'low') !== 'high') {
    reviewReasons.push('Overall evidence is not high confidence.');
  }
  if (categories.some((category) => category.review_required)) {
    reviewReasons.push('One or more appraisal fields require HOD review.');
  }
  return {
    label: profile.remark?.label || 'Remark',
    draft,
    confidence: evidencePack.confidence?.level || 'low',
    review_required: true,
    copy_allowed: false,
    review_reasons: reviewReasons.length ? reviewReasons : ['Overall appraisal remark must include HOD judgment and outcome quality.'],
    evidence: [
      ...(evidencePack.project_themes || []).slice(0, 3).map((item) => ({ label: `${item.label} (${item.count})`, source: 'project_theme' })),
      ...(evidencePack.top_apps || []).slice(0, 3).map((item) => ({ label: `${item.label} (${item.minutes}m)`, source: 'top_app' }))
    ]
  };
}

function renderRemark(template, evidencePack = {}) {
  const variables = {
    role: evidencePack.role?.role || 'unconfirmed role',
    project_themes: (evidencePack.project_themes || []).slice(0, 3).map((item) => item.label).join(', ') || 'limited visible themes',
    active_days: String(evidencePack.totals?.active_days || 0),
    work_minutes: String(evidencePack.totals?.work_minutes || 0)
  };
  return String(template).replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, key) => variables[key] || '');
}

module.exports = {
  buildHodAppraisalDraft
};
