# Cognify Handoff - 2026-05-12

## Current Goal State

This handoff captures the current installer/distribution state for Cognify so work can resume later without losing context.

Primary focus in this session:
- build a real Windows installer `.exe`, not a zip
- ensure installer carries Cognify, Screenpipe, FFmpeg, and runtime/bootstrap dependencies
- test the installer locally on this PC
- expose the installer over a Python HTTP download URL

## Current Version

- App version: `1.1.40`

## Final Built Artifact

- Installer EXE:
  [portable-dist/Cognify-Setup-v1.1.40.exe](</I:/companion-agent-windows/companion-agent/portable-dist/Cognify-Setup-v1.1.40.exe>)
- Setup ZIP still exists as the stage payload:
  [portable-dist/Cognify-Setup-v1.1.40.zip](</I:/companion-agent-windows/companion-agent/portable-dist/Cognify-Setup-v1.1.40.zip>)

Installer EXE facts:
- Size: `205,417,984` bytes
- SHA256: `A282566C2A0E009367C21CE25989F073B55C60EED7B0C87FE4654E732CB27C08`
- Status: built and locally tested successfully

## Download Server

Python download server script:
- [portable-dist/serve-cognify-download.py](</I:/companion-agent-windows/companion-agent/portable-dist/serve-cognify-download.py>)

Current served file:
- `Cognify-Setup-v1.1.40.exe`

Verified URLs during this session:
- `http://10.11.13.179:18899/Cognify-Setup-v1.1.40.exe`
- `http://10.11.13.179:18899/download`
- alternate adapter:
  `http://10.11.13.192:18899/Cognify-Setup-v1.1.40.exe`

The server was verified with HTTP `HEAD` and returns `200`.

## What Changed In Code

### 1. New EXE builder

Added:
- [scripts/make-setup-exe.ps1](</I:/companion-agent-windows/companion-agent/scripts/make-setup-exe.ps1>)

What it does:
- runs `make-setup.ps1`
- takes the produced setup zip
- compiles a small C# bootstrapper with classic .NET Framework `csc.exe`
- embeds the setup zip as a resource
- generated EXE extracts the zip to temp, runs `Install-Cognify.cmd`, waits for completion, and returns the install exit code

Reason for this approach:
- earlier 7-Zip self-extracting EXE attempts were unreliable and got stuck
- the actual setup payload was working; only the wrapper was failing

### 2. Package script

Updated:
- [package.json](</I:/companion-agent-windows/companion-agent/package.json>)

Added script:
- `dist:setup:exe`

### 3. Setup script improvements

Updated:
- [scripts/make-setup.ps1](</I:/companion-agent-windows/companion-agent/scripts/make-setup.ps1>)

Important improvements:
- generated `Setup-Cognify.ps1` now honors environment overrides:
  - `COGNIFY_INSTALL_DIR`
  - `COGNIFY_NO_AUTOSTART`
  - `COGNIFY_NO_LAUNCH`
  - `COGNIFY_NO_STARTMENU_SHORTCUT`
  - `COGNIFY_NO_DESKTOP_SHORTCUT`
- generated `Install-Cognify.cmd` remains a simple launcher for `Setup-Cognify.ps1`
- generated `README.txt` documents those env overrides

This made local non-destructive installer testing possible.

## Local Installer Test Performed

The installer EXE was tested on this PC with a temp install target:
- install target:
  `I:\tmp\Cognify-Installer-Test`

Test method:
- launched `Cognify-Setup-v1.1.40.exe`
- set env vars so it would:
  - install into temp folder
  - not autostart
  - not launch app
  - not create start menu shortcut
  - not create desktop shortcut

Observed result:
- installer exit code: `0`

Verified installed files:
- `I:\tmp\Cognify-Installer-Test\Cognify.exe`
- `I:\tmp\Cognify-Installer-Test\Cognify.bat`
- `I:\tmp\Cognify-Installer-Test\Launch-Cognify.ps1`
- `I:\tmp\Cognify-Installer-Test\app\node_modules\@screenpipe\cli-win32-x64\bin\screenpipe.exe`
- `I:\tmp\Cognify-Installer-Test\app\node_modules\@screenpipe\cli-win32-x64\bin\ffmpeg.exe`
- `I:\tmp\Cognify-Installer-Test\Uninstall-Cognify.ps1`
- version file contains `1.1.40`

Conclusion:
- installer is distributable and functionally working on this machine

## Dependency / Runtime Behavior

Bundled in installer payload:
- Cognify app
- Screenpipe binaries
- FFmpeg binaries

Handled during installation:
- checks for `.NET 8 Desktop Runtime`
- checks for `.NET 8 ASP.NET Core Runtime`
- if missing, setup tries to install them

This means the installer is intended to bootstrap a usable system without separately handing users Screenpipe/FFmpeg.

## Validation Run

Verified after changes:
- `npm run lint` passed
- `npm test` passed
- setup EXE build succeeded
- local installer execution succeeded
- download URL responded correctly

## Important Known History

### Updater / release state before installer work

Recent updater release work already completed earlier:
- updater release version: `1.1.40`
- bundle URL bug was fixed so old clients do not download a Git LFS pointer instead of the zip

Relevant earlier points:
- updater manifest uses an absolute raw GitHub URL for bundle download
- users on old versions should update to `1.1.40`

### Failed approach that should not be retried first

Multiple 7-Zip SFX wrapper attempts were made before the C# bootstrapper:
- `portable-dist/Cognify-Setup-v1.1.40.exe`
- `portable-dist/Cognify-Setup-v1.1.40-r2.exe`
- `portable-dist/Cognify-Setup-v1.1.40-r3.exe`

Those wrappers were unreliable:
- process hangs
- extract/install not completing reliably

Recommendation:
- keep the C# bootstrap EXE approach
- do not spend more time on 7-Zip SFX unless there is a strong reason

## Current Working Tree Status

At the end of this session, expected repo changes are:
- modified: `package.json`
- modified: `scripts/make-setup.ps1`
- added: `scripts/make-setup-exe.ps1`
- modified: `portable-dist/serve-cognify-download.py`
- added: this handoff doc

Portable build outputs under `portable-dist` were regenerated during testing.

## Distribution Status

What is ready now:
- distributable installer EXE exists locally
- direct browser-download URL via Python server is working

What is not ready yet:
- installer is **not code-signed**

This matters because:
- unsigned EXE may trigger SmartScreen / trust warnings
- user explicitly asked earlier for a Windows signed EXE

## Pending Tasks

### High priority

1. Sign the installer EXE
- needs code signing certificate and `signtool`
- ideally sign:
  - `Cognify-Setup-v1.1.40.exe`
  - `Cognify.exe`
  - any helper EXEs that are directly shipped

2. Publish the installer baseline release
- this EXE should become the stable bootstrap installer
- future normal releases should continue via the in-app updater

3. Commit current installer work
- current installer work was built and tested locally
- source changes should be committed once user wants to persist them formally in git

### Medium priority

4. Add release checklist for baseline-installer compatibility
- fresh install from setup EXE
- complete onboarding
- update through updater
- confirm user data retained
- confirm setup does not reopen unnecessarily on update

5. Add a smoke test for:
- baseline install
- relaunch
- updater flow

6. Decide whether to clean old failed setup EXE experiments from `portable-dist`
- they are only historical artifacts and not needed for distribution

### Lower priority

7. Improve installer UX further
- branded installer flow
- cleaner progress/reporting
- more explicit prerequisite messaging if runtime install fails

## Recommended Next Resume Point

When resuming later, start here:

1. inspect git diff
2. commit:
   - `package.json`
   - `scripts/make-setup.ps1`
   - `scripts/make-setup-exe.ps1`
   - `portable-dist/serve-cognify-download.py`
   - this handoff file
3. if signing material is available, add signing step to EXE build
4. publish installer EXE as the bootstrap baseline release

## Commands Used Successfully

Useful commands that worked in this session:

```powershell
npm run dist:setup:exe
npm run lint
npm test
```

Download server:

```powershell
I:\python\python.exe I:\companion-agent-windows\companion-agent\portable-dist\serve-cognify-download.py
```

## Short Summary

The real blocker was never Cognify setup itself. The setup payload was fine; the EXE wrapper was the failure point. That is now replaced with a compiled bootstrapper, and the installer has been built and proven locally. The remaining meaningful gap is code signing and then publishing this EXE as the long-lived installer baseline.
