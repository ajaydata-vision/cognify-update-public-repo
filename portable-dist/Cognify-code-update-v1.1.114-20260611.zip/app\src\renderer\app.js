const orb = document.getElementById('orb');
const shell = document.getElementById('shell');
const inputSurface = shell || orb;

function startupTrace(message, payload = {}) {
  try {
    window.assistantApi?.startupTrace?.(message, payload);
  } catch {
    // Startup tracing must never affect orb input.
  }
}

startupTrace('widget_script_loaded', { readyState: document.readyState });

let dragging = false;
let pointerDown = false;
let pointerStart = null;
let latestStatus = null;
let lastCaptureTimestamp = 0;
let hasCaptureBaseline = false;
let pulseTimer = null;
let statusTimer = null;
let pulseRefreshTimer = null;

function movementDistance(event) {
  if (!pointerStart) {
    return 0;
  }

  const deltaX = event.screenX - pointerStart.screenX;
  const deltaY = event.screenY - pointerStart.screenY;
  return Math.hypot(deltaX, deltaY);
}

function setVisualState({ running, paused }) {
  const nextState = paused ? 'paused' : (running ? 'active' : 'idle');
  document.body.classList.remove('idle', 'active', 'paused');
  document.body.classList.add(nextState);
  document.body.classList.toggle('insight-ready', Boolean(running && !paused));
}

async function refreshStatus() {
  if (document.hidden) {
    return;
  }

  try {
    latestStatus = await window.assistantApi.getStatus();
    setVisualState(latestStatus);
  } catch {
    latestStatus = { running: false, paused: false };
    setVisualState(latestStatus);
  }
}

function recordTimestampMs(record = {}) {
  return new Date(record.timestamp_start || record.timestamp || record.timestamp_end || 0).getTime();
}

function triggerCapturePulse() {
  document.body.classList.remove('capture-pulse');
  window.requestAnimationFrame(() => {
    document.body.classList.add('capture-pulse');
    clearTimeout(pulseTimer);
    pulseTimer = setTimeout(() => {
      document.body.classList.remove('capture-pulse');
    }, 820);
  });
}

async function refreshCapturePulse() {
  if (document.hidden) {
    return;
  }

  if (!latestStatus?.running || latestStatus?.paused) {
    return;
  }

  const result = await window.assistantApi.getRecentActivity(0.04, { sync: false });
  const records = Array.isArray(result) ? result : (result?.records || []);
  const newest = records.reduce((max, record) => Math.max(max, recordTimestampMs(record)), 0);
  if (!newest) {
    return;
  }

  if (!hasCaptureBaseline) {
    hasCaptureBaseline = true;
    lastCaptureTimestamp = newest;
    return;
  }

  if (newest > lastCaptureTimestamp) {
    lastCaptureTimestamp = newest;
    triggerCapturePulse();
  }
}

inputSurface.addEventListener('mouseenter', () => {
  document.body.classList.add('hovering');
});

inputSurface.addEventListener('mouseleave', () => {
  document.body.classList.remove('hovering');
});

inputSurface.addEventListener('mousedown', (event) => {
  if (event.button !== 0) {
    return;
  }

  startupTrace('widget_pointer_down', { button: event.button });
  pointerDown = true;
  dragging = false;
  pointerStart = {
    screenX: event.screenX,
    screenY: event.screenY
  };
  window.assistantApi.startDrag(pointerStart);
});

window.addEventListener('mousemove', (event) => {
  if (!pointerDown || !pointerStart) {
    return;
  }

  if (!dragging && movementDistance(event) > 4) {
    dragging = true;
  }

  if (dragging) {
    window.assistantApi.dragMove({
      screenX: event.screenX,
      screenY: event.screenY
    });
  }
});

window.addEventListener('mouseup', async (event) => {
  if (!pointerDown) {
    return;
  }

  startupTrace('widget_pointer_up', { button: event.button, dragging });
  pointerDown = false;
  window.assistantApi.endDrag();

  const wasDragging = dragging;
  dragging = false;
  pointerStart = null;

  if (!wasDragging && event.button === 0) {
    const startedAt = performance.now();
    await window.assistantApi.togglePanel();
    startupTrace('widget_toggle_returned', {
      duration_ms: Math.round(performance.now() - startedAt)
    });
  }
});

statusTimer = setInterval(refreshStatus, 60000);
pulseRefreshTimer = setInterval(refreshCapturePulse, 120000);
setTimeout(refreshStatus, 1000);
startupTrace('widget_listeners_attached');

window.addEventListener('beforeunload', () => {
  clearInterval(statusTimer);
  clearInterval(pulseRefreshTimer);
});
