# Session Handoff

Last saved: 2026-05-22

## Current Release State

- Source repo: `ajaydata-vision/companion-agent`
- Source release commit: `6d388fd Release Cognify 1.1.102 payroll retry hardening`
- Public update repo commit: `82e26e7 Publish Cognify 1.1.102 update`
- Current released version: `1.1.102`
- Update type: app-only
- Bundle: `portable-dist/Cognify-app-update-v1.1.102-20260522.zip`
- SHA256: `63d73cfe71a02e0bc6d73fa1b4680b1f8607b58e1ee4ce4fed435676fc2f1e93`

Validation for `1.1.102` before release:

- `npm test` passed
- `npm run lint` passed
- Release script rebuilt the Electron SQLite native module and passed the SQLite Electron check.
- Bundle built locally and public-update commit was pushed.
- GitHub API verification passed in the release script.
- Branch raw manifest was still serving a cached `1.1.101` immediately after publish; GitHub API verification passed for `1.1.102`.
- Bundle size/hash from generated update manifest: 82,116,425 bytes, SHA256 `63d73cfe71a02e0bc6d73fa1b4680b1f8607b58e1ee4ce4fed435676fc2f1e93`.

## Released 1.1.102 Behavior

Payroll daily-log retry hardening:

- Payroll daily-log sends now validate the response body, not just HTTP status.
- HTTP `200` responses with failure text such as `An error occurred while updating the entries. See the inner exception for details.` are treated as failed sends.
- JSON responses with `status: false`, `ok: false`, `success: false`, or error-like response codes are also treated as failed sends.
- Failed daily-log sends stay in `failed` state with normal backoff and retry, instead of being marked `sent`.
- Regression coverage simulates the exact 21 May payroll API failure and verifies the day retries after backoff.

Incident note:

- `21/05/2026` was automatically posted at `2026-05-22T01:02:57Z`, but payroll returned HTTP `200` with the internal-error text above.
- The exact same `21/05/2026` payload was manually retried on 2026-05-22 and payroll returned `Congnify Log Successfully Submitted.`

Real-data Work Summary verification on this PC before release:

- Today `2026-05-22`: official active `130m`, Work Summary detail `130m`, final work `129m`.
- Yesterday `2026-05-21`: official active `415m`, Work Summary detail `415m`, final work `419m`.

## Released 1.1.101 Behavior

Work Summary modal from Final Work Hours:

- `Final Work Hours` in Work Hours Details is clickable and opens a wider `Work Summary` modal.
- The modal has `Today: <date>` and `Yesterday` options.
- It shows app, window title, URL/name, duration, first seen, last seen, and source for active-PC detail rows.
- Detail rows reconcile to the canonical active-PC total used by Work Hours, so row totals match the official activity minutes instead of overcounting short focus intervals.
- Focus-backed detail includes short intervals and intervals with partial window metadata, using process/title fallbacks instead of dropping valid active time.

## Released 1.1.100 Behavior

Cross-midnight keep-idle accounting:

- `Keep idle` still only dismisses the nudge; it does not add a manual work record.
- Closed system-idle intervals now invalidate Report Cache and refresh Live Truth across every local day they touch.
- Report Cache no longer accepts a partial Live Truth hour for a full requested report hour; it rebuilds from local idle/runtime evidence instead.
- Regression coverage simulates a 51-minute stale Live Truth hour for a 60-minute report hour and verifies the final report keeps all 60 minutes as idle with 0 work minutes.

## Released 1.1.98 Behavior

Idle-block dropdown readability:

- Fixes the Work Hours Details idle-block dropdown when the native options menu opens with a white background.
- Explicit option text/background colors prevent white text from merging into the white menu.

## Released 1.1.97 Behavior

Manual idle-block picker:

- The Work Hours Details manual entry form no longer asks users to type `From` and `To` times.
- The main panel manual block modal also no longer asks users to type arbitrary time ranges.
- Both manual-entry surfaces now show a dropdown of Cognify-detected idle blocks for the current day.
- Saving manual work, meeting, break, or other context uses the selected idle block's exact start/end timestamps.
- This reduces wrong-time entry errors and gives users a clear view of the idle slots Cognify found before they add manual context.

## Released 1.1.96 Behavior

Strict idle accounting:

- OS input idle is always deducted from official Work Hours.
- Foreground passive-work evidence is kept as diagnostic context only; it no longer reduces `input_idle_minutes` or automatically counts idle PC time as work.
- Manual work/meeting entry remains the only way to restore legitimate work or meeting time that happened during OS-idle periods.
- Legacy summaries with `raw_input_idle_minutes` greater than `input_idle_minutes` are normalized on read so old passive-preserved idle cannot continue inflating reports.
- Report Cache schema is bumped to rebuild stale daily-report cache entries under the strict idle rule.
- Regression coverage asserts passive-work evidence stays visible but idle is still deducted unless manually restored.

## Released 1.1.95 Behavior

Idle-return Low RAM guarantee:

- The Back From Idle manual work/meeting prompt is now isolated in `showIdleReturnNudge()` and documented as payroll-critical.
- This nudge is intentionally not Low RAM gated, because it is how users restore legitimate work/meeting time from deducted idle after returning to the PC.
- The optional productivity nudge monitor can still be skipped in Low RAM Mode, but the event-driven idle-return path remains active through `SystemIdleService.onIntervalClosed`.
- Regression coverage asserts the idle-return nudge path exists, remains wired to `onIntervalClosed`, and does not include Low RAM gate checks.

## Released 1.1.94 Behavior

Payroll daily-log delivery hardening:

- `1.1.93` removed the Low RAM Mode background gate from the automatic daily payroll sender, so payroll delivery is no longer treated as optional background work.
- `1.1.94` supersedes `1.1.93` and adds catch-up for recent days that are not already marked `sent` in `daily-log-state.json`.
- Catch-up posts recent unsent days oldest first during the same morning window, and skips days already recorded as sent to avoid duplicates.
- The automatic sender now calls `DailyLogService.sendPendingIfDue()` and logs `sent_count` / `failed_count`.
- Regression coverage asserts the low-RAM skip marker is gone and that catch-up sends only unsent days while preserving already-sent days.

## Pending Adversarial Engineering Tasks

Remaining items after the `1.1.92` canonical coverage release:

- Pending next: Activity Report can still be heavy on low-RAM PCs because user-triggered full activity reports can run full activity sync and canonical day-summary work together. Add caps/gating without changing hour math.
- Pending next: Daily Summary uses stale cache data for speed but does not yet make cache completeness obvious enough in the UI. Show incomplete/stale coverage clearly before users trust a partial total.
- Pending next: Weekly/HOD still loads full raw 7-day records for evidence. Prefer summary-first and `queryRangeLite()`/bounded sampling to reduce memory pressure.
- Pending next: Canonical daily-summary failures during range merge are logged and skipped. Surface failed/missing days and avoid labeling mixed/partial output as fully live-truth sourced.
- Pending next: Weekly/HOD confidence and evidence-gap wording still depends on raw legacy record count, so it can warn about low sample size even when canonical hour totals are correct.
- Pending next: Ask Evidence and Tasks still use legacy evidence paths. Mark them as evidence-only or move them behind canonical report summaries where possible.

## Released 1.1.92 Behavior

Canonical coverage hardening added in `1.1.92`:

- Activity Report official `Work Hours` now uses the canonical work total directly. It no longer falls back from a canonical `0m` to legacy `category('Work')`.
- Activity Report official hour rows now carry canonical range coverage and display `partial`, `Unavailable`, or `Not available` instead of silently showing a confident zero when canonical coverage is incomplete.
- Weekly/HOD evidence treats covered canonical daily summaries as authoritative, including legitimate `0m` `PC Available` or `Work Hours`.
- Weekly/HOD evidence falls back to legacy raw records only for uncovered days when canonical range coverage is partial, avoiding both overstatement on covered zero days and undercounting on failed/missing days.
- Release notes in `update.txt` call out the canonical-zero and partial-coverage behavior so users and support can distinguish true zero from incomplete evidence.

Validation:

- `npm test` passed.
- `npm run lint` passed.
- Release script rebuilt the Electron SQLite native module and verified the public GitHub API/raw manifest plus remote bundle hash and size.

## Released 1.1.91 Behavior

Daily Summary zero-hours diagnosis on this PC:

- User selected the Reports `Daily Summary` action for yesterday just after midnight IST on 2026-05-21.
- Panel log showed `panel_action_started summary`, not `dailyReport`, at `2026-05-20T19:35:49Z` and `2026-05-20T19:36:13Z`.
- Local `activity_records` SQLite data had zero rows for the selected local day, but Live Truth had the actual day ledger.
- Local Live Truth for 2026-05-20 contained 24 hours covered: `PC Available 1434m`, `Idle 1227m`, `Work 207m`, `activity_events 721`.
- Root cause: `Daily Summary` still called `assistantApi.ask({ message: 'Summarise my day' })`, which uses the legacy activity-record path instead of the Report Cache / Live Truth accounting path.

Fix released in `1.1.91`:

- `src/renderer/panel.js`: Reports `Daily Summary` now calls `assistantApi.dailyReportCached()` with `includeTasks:false`, `sync:false`, and `staleOk:true`, matching the Live Truth backed daily-report accounting path.
- `src/renderer/panel.js`: Daily Summary output now explicitly displays `Work Hours`, `PC Available`, and `Idle deducted` so zero totals are visible as accounting failures instead of hidden behind focus/app rows.
- `src/services/modules/live-day-truth-service.js`: `getAccountedHour()` now accepts a partial final hour when Live Truth proves the app captured part of that requested hour. This prevents a valid last-hour `capturing` entry from falling back to empty legacy activity records.
- `src/main.js`: Timeline, Full Activity, My Weekly Report, HOD evidence, and the legacy `assistant:dailySummary` IPC now pull canonical daily summaries from Report Cache / Live Truth for official hour totals.
- `src/services/modules/activity-report-service.js`: Activity reports preserve captured timeline evidence separately from official PC Available / Work Hours / Idle rows.
- `src/services/modules/weekly-performance-evidence-service.js`: Weekly evidence can use canonical daily summaries for active days, PC Available, idle, and Work Hours even when legacy activity rows are empty.
- `scripts/unit-test.js`: Added regression coverage for a partial final hour, canonical activity report totals with no legacy records, and weekly evidence built from daily summaries.

Validation:

- `npm run lint` passed.
- `npm test` passed.
- Local Report Cache probe for 2026-05-20 using `staleOk:true` returned `Work 207m`, `PC Available 1434m`, `Idle 1227m`, 24/24 hours covered, and did not call the legacy activity path.
- Local cross-report probe for 2026-05-20 confirmed Daily/Report Cache, Activity/Timeline official rows, and Weekly totals all returned the same canonical `Work 207m`, `PC Available 1434m`, and `Idle 1227m`.

## Released 1.1.90 Behavior

Updater hardening added in `1.1.90`:

- Canonical update paths are now explicit: GitHub Contents API is the release source-of-truth for `update.txt`; `raw.githubusercontent.com/.../main/update.txt` is the app default manifest; public bundles are emitted as GitHub `/raw/main/portable-dist/<zip>`.
- `/raw/refs/heads/main/` must not be emitted by bundle scripts or release verification because it served stale `update.txt` during release verification.
- App update checks now read trusted manifest endpoints in parallel and choose the newest valid version from `raw.githubusercontent.com`, GitHub `/raw/main/`, and GitHub Contents API.
- This prevents a stale raw CDN response from hiding a newer update when GitHub API already has the new `update.txt`.
- Relative bundle paths still resolve against the raw manifest route, while absolute bundle URLs remain restricted to trusted GitHub hosts.
- Release verification now uses GitHub Contents API as the hard source-of-truth for `update.txt`.
- Release verification retries raw manifest propagation and remote bundle availability instead of failing immediately on CDN lag.
- After `1.1.90`, raw manifest propagation is only a short warning check; API manifest plus remote bundle hash/size are the release gates.
- Guardrail: Work Hours, PC Available, Idle, manual restored time, focus, idle telemetry, and runtime availability accounting were not changed in this release.

## Released 1.1.89 Behavior

Work Hours nudge correction added in `1.1.89`:

- The automatic break nudge now uses final Work Hours only. It no longer uses PC Available time, `last_idle_ended_at`, or any active-streak duration.
- The nudge says "You have logged X of Work Hours today" and carries `work_minutes` as the evidence value.
- Clicking the nudge opens the Work Hours breakdown, not the generic snapshot.
- Nudge details label the basis as "Work Hours only" and include the official formula: PC Available - Idle deducted + Manual work/meeting restored.
- Unit tests assert that the Work Hours break nudge details do not contain active wording.

Updater route hardening added in `1.1.89`:

- Future update checks default to `raw.githubusercontent.com/.../main/update.txt` for the manifest.
- Generated public bundle URLs now use GitHub `/raw/main/` instead of `/raw/refs/heads/main/`; the latter served stale manifest content during release verification.
- `1.1.88` was published first with the nudge correction, then superseded by `1.1.89` to use a fresh bundle path after the updater-route hardening.

## Released 1.1.87 Behavior

Low-RAM hardening added in `1.1.87`:

- Adds automatic Low RAM Mode for PCs with roughly 8 GB RAM or less, with `COGNIFY_LOW_RAM_MODE=0/1` override.
- Keeps the hour-critical core unchanged: runtime availability pulse, system idle telemetry, lock/suspend handling, manual entry storage, and focus event collection remain active.
- Moves non-core background work to demand/idle/memory-gated behavior: report cache warmer, readiness warming, live-truth repair, report cache backfill, and background productivity nudges do not run continuously in Low RAM Mode.
- Popup/nudge/report windows are destroyed sooner after hiding in Low RAM Mode so hidden renderers do not keep memory resident.
- Windows Focus now prefers a compiled native helper process and falls back to the legacy PowerShell helper if compilation fails. This keeps focus evidence available while reducing continuous PowerShell RAM usage on supported machines.
- SQLite startup migration now imports JSONL in batches instead of loading a full day file into memory, and Low RAM Mode uses file-backed SQLite temp storage.
- Health diagnostics show the active Low RAM Mode profile and the focus helper kind.
- Guardrail: Work Hours math is unchanged. `PC Available`, `Idle`, manual restored work/meeting, missing/no-evidence, and final Work Hours definitions remain the same as `1.1.80+`.

## Released 1.1.86 Behavior

Reports redesign added in `1.1.86`:

- Reports now open as an Outlook-style workspace: left report list, right selected-report pane.
- The top bar stays compact with profile, More Settings, Listening, Recording, and Close controls.
- Profile editing moved into a modal opened from the profile chip.
- From and To filters are visible inside Reports and default to yesterday.
- Yesterday, Today, and Last 7 Days presets sit in one row below the date fields and only set the date range.
- Selecting a report does not run it; the user reviews the date range and clicks Run.
- Manual Block was removed from the Reports toolbar because manual entry already exists in the dedicated manual flows.
- Reviewed HOD Drafts is available from the Reports list.

Release note hardening in `1.1.86`:

- A first `1.1.85` publish reused the same same-day ZIP path after release notes changed, and GitHub still served the older ZIP for that path during verification.
- To avoid any client-side hash mismatch, the final public release was bumped to `1.1.86`, producing a fresh bundle path and passing remote verification.

## Released 1.1.73 Behavior

Telemetry hardening added in `1.1.73`:

- Windows focus helper now has a stale-event watchdog.
- If the helper process is alive but stops emitting focus events for several minutes after startup grace, Cognify restarts it internally.
- Snapshot health now includes Windows Focus and Idle Telemetry health, not only Screenpipe/ffmpeg.
- Work Hours modal shows missing/no-evidence as a review-only row; it must not show a telemetry warning for ordinary historical missing evidence.
- Idle telemetry exposes polling health so `0m idle` with no idle evidence can be detected as a collector issue.

Post-release adversarial hardening after `1.1.73`:

- Stale focus-helper restarts now use the same hourly restart limit as crash restarts, so a bad helper cannot enter an unlimited kill/start loop.
- Focus-helper process exit handling is guarded against old-child exit races; an exiting stale child cannot clear or restart over a newly started helper.
- Idle telemetry now has an `ensureFresh()` repair path and the same watchdog restarts/polls it if its timer stops or health goes stale.
- Live Snapshot cheap diagnostics cache is capped at 30 seconds for telemetry health so focus/idle failures become visible quickly.
- Unit tests now cover stale helper restart, restart-limit behavior, and idle telemetry watchdog start.

Follow-up warning correction in `1.1.75`:

- A local screenshot at 2026-05-18 19:30 showed `Telemetry needs attention` for only `12m` missing/no-evidence out of `19h 21m` PC Available.
- Logs showed current focus telemetry was healthy; the 12m came from historical focus sample gaps at 17:21-17:33 IST and 18:28-18:30 IST.
- Work hours were not reduced by this missing/no-evidence row, but the warning copy made it look like an active telemetry failure.
- The Work Hours modal warning was removed for missing/no-evidence. Missing/no-evidence remains a review row, not a telemetry alert and not a work-hours deduction.

Adversarial correction in `1.1.76`:

- A follow-up check after updating to `1.1.75` showed the current hour could still be marked `offline` while Windows Focus was actively writing events.
- Cause: Live Truth trusted Screenpipe cached status during update/startup warmup and did not re-finalize existing current-hour JSON entries from local focus/idle evidence.
- Fix: current hours with local focus, idle, captured, or manual evidence are displayed as `capturing`, not `offline`.
- Fix: `getTodayState()` re-finalizes already-written current-hour entries so stale `offline` JSON does not keep the UI red.
- Fix at the time: older cached summaries stopped allowing missing/no-evidence to reduce PC Available or Work Hours. Later post-`1.1.78` hardening explicitly forbids `range_minutes` alone from being treated as PC Available.
- On the local 2026-05-18 ledger, the corrected read evaluates the day at the 19:54 snapshot as Live Truth `ok`, current hour `capturing`, PC Available `19h 54m`, Idle `17h 17m`, Missing/no evidence `14m`, and Work Hours `2h 37m`.

Adversarial correction after `1.1.76`:

- Deeper local-ledger review found a closed hour with focus/activity/idle evidence could still be excluded from the live-day rollup if its status stayed `offline`, `gap`, `partial`, or `stale`.
- Local example: on 2026-05-18, hour `19` had 60m PC Available, 13m idle, 47m work, and focus-backed events, but status `offline` plus 5m missing evidence caused the day rollup to drop the whole hour.
- Fix: locally evidenced closed hours now contribute to `PC Available`, `Idle`, `Work Hours`, and `active_minutes` even while their verification status remains a review gap.
- Fix: closed review gaps no longer turn Live Truth health into `attention`; only current capture offline remains an attention state. Historical incomplete rows remain visible as `checking`/review.
- Guardrail: a closed stale/gap hour with no local activity, focus, idle, manual, or captured evidence is still not counted as PC Available, so startup repair cannot inflate hours before Cognify was actually measuring.

Adversarial correction in `1.1.78`:

- Deeper missed-hours review found one remaining dependency problem: if focus, Screenpipe, and idle evidence all fail for a period, `1.1.77` has no independent proof that Cognify was awake, so PC Available can still be missed.
- Fix: add `RuntimeAvailabilityService`, a minute-level Cognify runtime pulse that records when the app process is awake.
- Live Truth now counts runtime-backed minutes as `PC Available` even with zero focus/Screenpipe/idle evidence.
- Report Cache can reuse runtime-backed Live Truth hours for daily reports, so the same accounting path is used outside the Live Snapshot.
- Guardrail: runtime pulses are only written while Cognify is awake; sleep/off-PC time does not get backfilled across long gaps.

Adversarial correction in `1.1.80`:

- Runtime availability minutes are now stored by the user's local day, with legacy UTC-day read support for `1.1.78` files. This prevents early-morning local PC Available minutes from being orphaned under the previous UTC date.
- Activity-store/Screenpipe gaps are diagnostics only. They are exposed as evidence gaps and are no longer returned as system-idle intervals, so missing capture evidence cannot deduct Work Hours.
- Work Hours ledger math is centralized around the safety invariant: `Final work hours <= PC Available`.
- Manual work/meeting time can only restore deducted idle minutes. If stale or malformed data reports more manual-added minutes than idle deducted, the restored amount is clamped to idle deducted.
- Renderer fallbacks in Live Snapshot and the panel no longer infer PC Available or Work Hours from `range_minutes`/`accounted_minutes` alone. `range_minutes` is only a bound; runtime availability or concrete active/idle/captured evidence is required.
- Detected non-work remains review-only under the released policy. It is not subtracted from Work Hours unless product policy is explicitly changed later.

Adversarial correction in `1.1.81`:

- Local 2026-05-19 diagnosis found Live Snapshot could temporarily show extra missing/no-evidence minutes while Cognify was running.
- Cause: `getTodayState()` merged the day through current wall-clock time, but a stale current-hour entry could stop several minutes earlier than the runtime availability pulses.
- Example: hour `06` had runtime pulses for `06:58` and `06:59`, but the stored entry stopped at `06:57:36` until the heavier repair timer closed the hour. The merged day could show those minutes as missing even though PC Available evidence existed.
- Fix: when reading live state, stale current/closed hour entries are extended from lightweight runtime availability before PC Available and missing/no-evidence are calculated.
- Guardrail: the read-time extension only happens when runtime availability exists; it does not infer PC Available from `range_minutes` alone and does not start Screenpipe or OCR work.

Adversarial correction in `1.1.82`:

- Manual entry is now handled through a separate attached `Work Hours Details` window instead of an overlay inside Live Snapshot.
- Manual entry validation is stricter: valid type, valid time range, minimum 1 minute, maximum 12 hours, no future blocks, and a short note are required.
- Manual work/meeting restores Work Hours only for minutes that overlap deducted idle after passive-work preservation. Raw idle that was already preserved as passive work is not counted as restorable manual time.
- Manual break/other entries are saved as evidence only and do not add Work Hours.
- Duplicate manual saves are reported as already saved and are not added again.
- After a manual save, Live Truth rebuilds the affected stored hour(s) from local activity-store, idle, focus, and runtime evidence without starting Screenpipe/OCR sync work.
- Guardrail: the rebuild covers full overlapping hour ranges, not just the manual entry slice, so manual saves cannot shrink an existing hour's PC Available range.
- User-facing save errors and partial-storage warnings are now shown inline in the Work Hours window, the panel manual modal, and idle-return nudge save flow.

## Released Hours Policy

Live Snapshot has a Work Hours details window:

- Click the `Hours Today / Work Hours` tile.
- Attached window title: `Work Hours Details`.
- Released labels/formula include:
  - `Work Hours = PC Available - Idle deducted + Manual work/meeting restored from idle`
  - PC Available
  - Idle deducted
  - Detected non-work
  - Manual added
  - Missing/no evidence
  - Final work hours
- The window reads Live Truth state and supports manual entry for today's work/meeting/break/other blocks.
- Manual save uses the local activity store and local Live Truth rebuild. It does not start OCR or Screenpipe sync work.

Daily Report has detection-only non-work observations:

- Added `summary.non_work_observations`.
- Detects likely `Shopping`, `Entertainment`, `Social`, `News`, and `Games` from existing app/title/domain evidence.
- Displayed in Daily Report as review-only evidence.
- Does not reduce payroll work-hours calculation.
- Report cache schema bumped from `8` to `9` in released `1.1.72` and remains current in `1.1.73`.

## Update Compatibility

- Public updates are cumulative app payloads. A user on `1.1.71` can update directly to `1.1.82` and receive the app-code benefits from `1.1.72` through `1.1.82`; intermediate installs are not required.
- New telemetry benefits only start after the update runs. For example, `1.1.80` cannot recreate runtime availability pulses for historical time before the runtime pulse service existed.
- The `1.1.82` public update is app-only and includes the Screenpipe runtime pieces needed by the existing baseline install; it does not include Electron, full `node_modules`, or .NET.

Important: released `1.1.73` does not deduct confirmed non-work from work hours.

```text
released work_minutes = gross_pc_available_minutes - idle_minutes + manual_work_or_meeting_minutes_from_idle_slots
```

The released app changed non-work from a payroll deduction into review-only evidence.

```text
released work_minutes = gross_pc_available_minutes - idle_minutes + manual_work_or_meeting_minutes_from_idle_slots
```

This wording is intentional:

- Product-level `gross_pc_available_minutes` means total time Cognify identifies the PC as on/available in the measured range, before idle deduction.
- Code-level `active_minutes` remains idle-adjusted PC-active time, so do not use it interchangeably with gross PC time.
- Released code now emits `gross_pc_available_minutes` and the Work Hours details UI displays it as `PC Available`.
- Manual time does not increase code-level `active_minutes`.
- Manual work/meeting time only increases final `work_minutes` when it fills a slot that would otherwise be idle/non-active.
- Confirmed/detected non-work remains visible for review, but is not subtracted from work hours.

The released Work Hours details label is now `Detected non-work`, not `Non-work deducted`.
Report cache schema is bumped from `8` to `9` so cached reports rebuild under the new policy.

Validation for `1.1.73` source before release:

- `npm test` passed
- `npm run lint` passed

## Metric Definitions

These definitions are current through released `1.1.82`.

`gross_pc_available_minutes` / `PC Available`

- Product concept: total time Cognify identifies the PC as on/available in the selected range.
- This is PC availability, not keyboard/mouse/app activity.
- This is broader than app/focus activity and exists before idle is deducted.
- This is the starting pool for work-hours calculation.
- For newly built local summaries, runtime availability is the preferred source. Without runtime pulses, PC Available falls back only to concrete local collector evidence, not to missing evidence gaps.
- `range_minutes` is only the selected/reporting window size. It is not evidence that the PC was available and must not create PC Available or Work Hours by itself.
- Live Truth rollups include verified hours, the current capturing hour, and closed review-gap hours when local telemetry evidence exists in that hour.
- Live Truth rollups do not count a stale/gap/offline closed hour that has no local activity, focus, idle, manual, or captured evidence.
- In `1.1.78+`, Cognify runtime availability pulses are first-class PC Available evidence, independent of focus, Screenpipe, and idle telemetry.
- Runtime pulses are written only while the Cognify process is awake; long gaps are not backfilled across sleep/off periods.
- Do not calculate this from `active_minutes`.
- `missing_minutes` remains diagnostics only; it should not reduce `PC Available`.
- In user-facing explanations this can be described as PC-on time, not final work time.
- This is emitted as `gross_pc_available_minutes`.
- Required UI label: `PC Available`.

`active_minutes` / `estimated_active_minutes`

- Current code field for PC-derived active minutes inside the selected range after idle/exclusion handling.
- Counts minutes where the app has PC/focus/window activity evidence after OS idle and exclusion handling.
- Does not include manual-only work or manual-only meeting blocks.
- Should not be increased by manual timing.
- In user-facing language, this should be treated as idle-adjusted active PC time.
- Adversarial note: this field is activity/evidence-derived. Do not rename this field itself to `PC Available`; use `gross_pc_available_minutes`.

`idle_minutes` / `input_idle_minutes`

- OS input-idle/lock time deducted from PC activity evidence.
- This is not "time the PC was powered on"; it is time treated as inactive because the OS/user-input evidence says idle.
- Activity-store/Screenpipe gaps are not idle. They are missing/evidence-gap diagnostics and must not reduce work hours.
- Manual timing can explain work during idle/off-PC periods, but it should not turn those minutes into code-level `active_minutes`.
- Passive work evidence can prevent raw idle from being treated as deducted idle when the system has strong evidence that the user was still working.

`raw_input_idle_minutes`

- Raw OS idle/lock minutes before passive-work or other evidence adjustments.
- Useful for diagnostics when users say they were reading/thinking/meeting while the machine looked idle.

`manual_net_added_work_minutes`

- Manual work or manual meeting minutes from slots that would otherwise be idle/non-active.
- Adds to final `work_minutes`.
- Does not add to `active_minutes`.
- In released code, manual work/meeting is net-added only when it overlaps an idle slot.
- In `1.1.82+`, this uses deducted idle after passive-work preservation, not raw idle that the ledger already preserved as work.
- Safety invariant: manual restored minutes must be clamped to idle deducted minutes, so final work cannot exceed PC Available.
- Prevents double counting when the user manually logs time that overlaps already-counted non-idle PC work time.
- Includes manual meeting minutes because meetings are work time unless policy says otherwise.
- Manual break/other is evidence only; it must not add Work Hours.
- Manual entries require a note and valid non-future range. Save errors must be shown inline where the user entered the time.

`work_minutes`

- Payroll/report work-hours total.
- This is not app-classified deep work, and it is not legacy `active_minutes`.
- Released policy:

```text
work_minutes = gross_pc_available_minutes - idle_minutes + manual_work_or_meeting_minutes_from_idle_slots
```

- Under the released policy, app/title classification does not reduce this number.
- Meeting/chat time is always work time.
- `work_minutes` can be greater than code-level `active_minutes` because PC Available is not constrained to captured app/focus activity, and manual work/meeting can fill idle slots.
- Do not implement this as `active_minutes + manual_net_added_work_minutes`; that can undercount PC Available time when activity evidence is incomplete.

`pc_work_minutes`

- Classification breakdown for PC-active minutes that look like focused/deep work.
- This is a subset of PC-active evidence, not the payroll total.
- Should not be used as the only work-hours total for developers, because meetings, chats, browser work, unclear work, and other active PC minutes may still be valid work.

`meeting_minutes` / `messaging_minutes` / `pc_messaging_minutes`

- Meeting/chat breakdown, not extra time to add on top of work hours.
- `pc_messaging_minutes` is PC-detected meeting/chat activity.
- Manual meeting minutes are shown in `messaging_minutes` as declared meeting/chat breakdown.
- Manual meeting minutes add to `work_minutes` only when they overlap an idle slot, to prevent double counting.
- Meeting/chat time is always included in `work_minutes`; do not add it again.

`confirmed_non_work_minutes`

- High-confidence non-work classification from app/title/domain evidence.
- Released `1.1.73` keeps this as review-only evidence and does not deduct it.
- User-facing label should be `Detected non-work`, not `Non-work deducted`.

`missing_minutes`

- Minutes in the selected range without enough activity/idle/manual evidence to fully explain the time.
- Missing/no-evidence is diagnostics and review context, not a deduction from `PC Available` or `work_minutes`.
- High missing time points to evidence coverage problems: focus helper, activity store sync, Screenpipe/focus records, or live-truth gaps.

## Adversarial Review Findings

The previous handoff wording was misleading in several ways:

- It wrote `work_minutes = active_minutes + manual_net_added_work_minutes` without saying code-level `active_minutes` is already idle-adjusted. That made it sound like manual time modifies active time, which is wrong.
- It used `pc_active_minutes` ambiguously. Product policy should be phrased as gross PC availability minus idle plus manual work/meeting from idle slots.
- It used `Non-work deducted` for current behavior even after changing non-work to review-only. The UI and docs should say `Detected non-work`.
- It did not clearly state that meeting/chat is always work time and is shown as a breakdown inside work hours, not another number to add on top of work hours.
- It did not clearly separate released behavior from local unreleased behavior.

Additional adversarial code finding and resolution:

- Current `active_minutes` is still calculated from activity/classification evidence after idle filtering in `daily-summary-service`, `live-day-truth-service`, and `report-cache-service`.
- Therefore, simply renaming `active_minutes` would be wrong.
- Released code now adds `gross_pc_available_minutes` and displays that as `PC Available`.
- A later correction changed new `gross_pc_available_minutes` from `accounted_minutes` to runtime/local collector availability. Runtime availability is preferred; without runtime pulses, summaries fall back only to concrete active/idle/captured evidence.
- Old summaries with explicit `gross_pc_available_minutes` are still read, but new calculations must not infer idle or PC Available from missing Screenpipe/activity gaps.
- Manual net-added semantics were tightened: manual work/meeting adds back only idle-overlap minutes, not every manual minute that lacks active evidence.
- A follow-up adversarial review found stale `summary.work_minutes` could still win in weekly evidence and some renderer category paths. These now recompute from `gross_pc_available_minutes` when that field exists.
- A final adversarial pass found the Live Snapshot modal had row labels but not the equation. It now displays `Work Hours = PC Available - Idle deducted + Manual added`, and explicitly says detected non-work and missing/no evidence are review rows, not deductions.
- The Live Snapshot bucket display now uses `PC Available`/official work accounting instead of clamping official work rows to legacy `active_minutes`.
- A deeper post-`1.1.76` adversarial pass found Live Truth rollup eligibility could still let a historical review status erase a locally evidenced hour. The rollup now counts locally evidenced review-gap hours and keeps no-evidence stale gaps out.
- The `1.1.82` adversarial pass found manual save confirmations could become misleading if they used raw idle instead of the ledger's deducted-idle view. The save path now subtracts passive-work-preserved idle before reporting restored minutes.
- The same pass moved manual entry into the Work Hours details window and made save failures visible inline, so employees can add away-from-PC work/meeting time without accidentally overriding already-counted PC-active minutes.
- Work-hours calculation should then use the explicit product formula:

```text
work_minutes = gross_pc_available_minutes - idle_minutes + manual_work_or_meeting_minutes_from_idle_slots
```

- Released code now uses this explicit formula in Daily Summary, Live Day Truth, Report Cache, renderer fallbacks, activity reports, and daily log fallback.

## Important Hours Review Findings

The current user complaint is that some users on `1.1.70` say work hours are lower than the hours they actually worked on PC.

Known facts:

- CPU/mouse slowness fix is working after disabling Screenpipe vision by default in `1.1.69`.
- `1.1.70` improved active-hours logic:
  - focus active threshold changed from 60 seconds to the OS idle threshold of 5 minutes
  - `idle_1m` is no longer treated as inactive
  - Live Snapshot/report helpers now mostly trust canonical `work_minutes`
- `1.1.70` and released `1.1.71` still deducted confirmed non-work from work hours.
- Released `1.1.72+` changes that behavior: detected non-work is review-only and not deducted.

If hours are still low after `1.1.73`, classification is no longer the first suspect.
Inspect:

- High `Idle deducted`: OS idle/lock behavior, lunch, reading/thinking time, long passive meetings.
- High `Missing/no evidence`: focus helper, activity store sync, Screenpipe/focus records, live-truth gaps.
- Low `PC Available`: PC-on/availability detection coverage.
- Low current `active_minutes`: app/focus/activity capture coverage, not necessarily PC availability.
- Low `Manual added`: expected manual work/meeting time from idle/non-active slots was not logged or did not parse as manual work/meeting.

## How To Test Released 1.1.82

For an installed app:

1. Let Cognify update to `1.1.82`.
2. Restart Cognify.
3. Open Live Snapshot.
4. Click the `Hours Today / Work Hours` tile.
5. Confirm the attached `Work Hours Details` window opens.
6. Save a manual work/meeting block that overlaps deducted idle and confirm `Manual added` and `Final work hours` update without changing `PC Available`.
7. Try saving with a blank note or invalid time range and confirm the inline error stays visible.

For local dev testing:

```powershell
cd I:\companion-agent-windows\companion-agent
npm run electron:dev
```

Then open Live Snapshot and click the Work Hours tile.

For affected PCs, capture:

```text
PC Available:
Idle deducted:
Detected non-work:
Manual added:
Missing/no evidence:
Final work hours:
Verified till:
Gap hours:
```

Interpretation:

- In released `1.1.82`, detected non-work and missing/no-evidence are review-only and not deducted.
- High idle means inspect idle/lock/passive-work handling.
- High missing means inspect evidence coverage.
- Non-zero detected non-work means inspect policy/classification quality, not payroll deduction under the released policy.
- Manual added should only restore deducted idle and must never make Final work hours exceed PC Available.

## Next Release Decision

The canonical coverage hardening for Activity Report and Weekly/HOD evidence is released in `1.1.92`.

Next decision:

- Address the remaining low-RAM report path: user-triggered Activity Report can still run full activity sync and canonical day-summary work together.
- Then add clearer Daily Summary cache completeness UI and reduce Weekly/HOD raw-record memory pressure.

## Files Touched In Latest Release Work

- `docs/SESSION_HANDOFF.md`
- `VERSION`
- `package.json`
- `package-lock.json`
- `update.txt`
- `src/renderer/panel.js`
- `src/services/modules/activity-report-service.js`
- `src/services/modules/weekly-performance-evidence-service.js`
- `src/main.js`
- `scripts/make-app-update-bundle.ps1`
- `scripts/unit-test.js`

## Known Repo Notes

- Source repo working tree should be clean after committing/pushing `Release Cognify 1.1.92 canonical coverage hardening`.
- The old `Cognify-code-update-v1.1.13-20260501.zip` file was explicitly requested for removal from update tracking context and is no longer expected as a tracked release artifact.
