const fs = require('fs');
const path = require('path');

class FocusEventStoreService {
  constructor(storagePath, options = {}) {
    this.storagePath = storagePath;
    this.dbPath = options.dbPath || path.join(storagePath, 'cognify.db');
    this.jsonlPath = path.join(storagePath, 'focus-events');
    this.lastError = null;
    this.mode = 'sqlite';
    this.sessionEventCount = 0;
    this.latestEventAt = null;
    fs.mkdirSync(storagePath, { recursive: true });
    fs.mkdirSync(this.jsonlPath, { recursive: true });

    try {
      const Database = options.Database || require('better-sqlite3');
      this.db = new Database(this.dbPath);
      this._configure();
      this._migrate();
      this._prepareStatements();
    } catch (error) {
      this.db = null;
      this.mode = 'jsonl';
      this.lastError = error?.message || String(error);
    }
  }

  ingest(event = {}) {
    return this.ingestMany([event]);
  }

  ingestMany(events = []) {
    const rows = events
      .map((event) => this._eventRow(event))
      .filter(Boolean);
    if (!rows.length) {
      return { inserted: 0 };
    }

    if (!this.db) {
      this._appendJsonlRows(rows);
      this._recordRows(rows);
      return { inserted: rows.length, mode: 'jsonl' };
    }

    this.stmts.insertMany(rows);
    this._recordRows(rows);
    return { inserted: rows.length, mode: 'sqlite' };
  }

  latest(limit = 50) {
    const safeLimit = Math.min(500, Math.max(1, Math.round(Number(limit) || 50)));
    if (!this.db) {
      return this._latestJsonl(safeLimit);
    }
    return this.stmts.latest.all({ limit: safeLimit }).map((row) => this._rowToEvent(row));
  }

  queryRange(startTime, endTime, options = {}) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return [];
    }
    const limit = Math.min(20000, Math.max(1, Math.round(Number(options.limit) || 5000)));
    if (!this.db) {
      return this._queryJsonl(startMs, endMs, limit);
    }
    return this.stmts.range.all({ startMs, endMs, limit }).map((row) => this._rowToEvent(row));
  }

  getActiveIntervals(startTime, endTime, options = {}) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return [];
    }
    const lookbackMs = Math.max(0, Number(options.lookbackMs || 2 * 60 * 1000));
    const maxGapMs = Math.max(1000, Number(options.maxGapMs || 75 * 1000));
    const idleThresholdSeconds = Math.max(1, Number(options.idleThresholdSeconds || 5 * 60));
    const queryStart = new Date(Math.max(0, startMs - lookbackMs)).toISOString();
    const events = this.queryRange(queryStart, endTime, {
      limit: Math.max(1000, Number(options.limit || 20000))
    })
      .map((event) => ({
        ...event,
        observedMs: new Date(event.observed_at).getTime()
      }))
      .filter((event) => Number.isFinite(event.observedMs))
      .sort((left, right) => left.observedMs - right.observedMs);

    const intervals = [];
    const suppressedIdleResets = new Set();
    for (let index = 0; index < events.length; index += 1) {
      const event = events[index];
      const signature = this._focusSignature(event);
      if (this._isIdleFocusEvent(event, idleThresholdSeconds)) {
        suppressedIdleResets.delete(signature);
      }
      if (!this._isActiveFocusEvent(event, idleThresholdSeconds)) {
        continue;
      }
      if (this._isIdleResetInputState(event, events[index - 1], idleThresholdSeconds)) {
        suppressedIdleResets.add(signature);
        continue;
      }
      if (suppressedIdleResets.has(signature)) {
        if (this._isDirectInputEvent(event)) {
          suppressedIdleResets.delete(signature);
        } else {
          continue;
        }
      }
      const nextMs = events[index + 1]?.observedMs;
      const intervalStartMs = Math.max(startMs, event.observedMs);
      const intervalEndMs = Math.min(
        endMs,
        Number.isFinite(nextMs) && nextMs > event.observedMs
          ? nextMs
          : event.observedMs + maxGapMs,
        event.observedMs + maxGapMs
      );
      if (intervalEndMs <= intervalStartMs) {
        continue;
      }
      intervals.push({
        startMs: intervalStartMs,
        endMs: intervalEndMs,
        start: new Date(intervalStartMs).toISOString(),
        end: new Date(intervalEndMs).toISOString(),
        process_name: event.process_name || '',
        window_title: event.window_title || '',
        class_name: event.class_name || '',
        hwnd: event.hwnd || '',
        monitor_device: event.monitor_device || '',
        cursor_monitor_device: event.cursor_monitor_device || '',
        event_type: event.event_type || '',
        idle_seconds: Number(event.idle_seconds || 0)
      });
    }

    return intervals;
  }

  getPassiveWorkIntervals(startTime, endTime, options = {}) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs <= startMs) {
      return [];
    }
    const classifier = options.classifier || null;
    if (!classifier?.classifyRecord) {
      return [];
    }
    const lookbackMs = Math.max(0, Number(options.lookbackMs || 2 * 60 * 1000));
    const maxGapMs = Math.max(1000, Number(options.maxGapMs || 75 * 1000));
    const minIdleSeconds = Math.max(60, Number(options.minIdleSeconds || 5 * 60));
    const maxIdleSeconds = Math.max(minIdleSeconds, Number(options.maxIdleSeconds || 45 * 60));
    const queryStart = new Date(Math.max(0, startMs - lookbackMs)).toISOString();
    const events = this.queryRange(queryStart, endTime, {
      limit: Math.max(1000, Number(options.limit || 20000))
    })
      .map((event) => ({
        ...event,
        observedMs: new Date(event.observed_at).getTime()
      }))
      .filter((event) => Number.isFinite(event.observedMs))
      .sort((left, right) => left.observedMs - right.observedMs);

    const intervals = [];
    for (let index = 0; index < events.length; index += 1) {
      const event = events[index];
      if (!this._isPassiveFocusEvent(event, minIdleSeconds, maxIdleSeconds)) {
        continue;
      }
      const classification = this._classifyFocusEvent(event, classifier);
      if (!this._isPassiveWorkClassification(classification)) {
        continue;
      }

      const nextMs = events[index + 1]?.observedMs;
      const intervalStartMs = Math.max(startMs, event.observedMs);
      const intervalEndMs = Math.min(
        endMs,
        Number.isFinite(nextMs) && nextMs > event.observedMs
          ? nextMs
          : event.observedMs + maxGapMs,
        event.observedMs + maxGapMs
      );
      if (intervalEndMs <= intervalStartMs) {
        continue;
      }
      intervals.push({
        startMs: intervalStartMs,
        endMs: intervalEndMs,
        start: new Date(intervalStartMs).toISOString(),
        end: new Date(intervalEndMs).toISOString(),
        process_name: event.process_name || '',
        window_title: event.window_title || '',
        class_name: event.class_name || '',
        hwnd: event.hwnd || '',
        event_type: event.event_type || '',
        idle_seconds: Number(event.idle_seconds || 0),
        classification: classification.classification,
        classification_confidence: classification.confidence,
        passive_work_evidence: true,
        source: 'focus_idle_work_evidence'
      });
    }

    return this._mergeCompatibleIntervals(intervals);
  }

  prune(cutoffMs) {
    if (!Number.isFinite(cutoffMs)) {
      return { prunedRows: 0, prunedFiles: 0 };
    }
    if (!this.db) {
      const cutoffDay = new Date(cutoffMs).toISOString().slice(0, 10);
      const files = fs.existsSync(this.jsonlPath) ? fs.readdirSync(this.jsonlPath) : [];
      let prunedFiles = 0;
      files.forEach((name) => {
        const match = name.match(/^(\d{4}-\d{2}-\d{2})\.jsonl$/);
        if (match && match[1] < cutoffDay) {
          fs.unlinkSync(path.join(this.jsonlPath, name));
          prunedFiles += 1;
        }
      });
      return { prunedRows: 0, prunedFiles };
    }
    const prunedRows = this.stmts.prune.run({ cutoffMs }).changes;
    return { prunedRows, prunedFiles: 0 };
  }

  getHealth() {
    if (!this.db) {
      const latestEventAt = this.latestEventAt || this._latestJsonl(1)[0]?.observed_at || null;
      return {
        ok: true,
        informational: true,
        label: 'Focus Events',
        mode: 'jsonl',
        detail: `Focus telemetry using JSONL fallback${this.lastError ? `: ${this.lastError}` : '.'}`,
        session_event_count: this.sessionEventCount,
        latest_event_at: latestEventAt
      };
    }

    const latest = this.latestEventAt
      ? { observed_at: this.latestEventAt }
      : this.stmts.latest.get({ limit: 1 });
    return {
      ok: true,
      informational: true,
      label: 'Focus Events',
      mode: 'sqlite',
      detail: `Focus telemetry ready, ${this.sessionEventCount} session event(s).`,
      dbPath: this.dbPath,
      session_event_count: this.sessionEventCount,
      latest_event_at: latest?.observed_at || null
    };
  }

  close() {
    if (this.db?.open) {
      this.db.close();
    }
  }

  _configure() {
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('synchronous = NORMAL');
  }

  _migrate() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS focus_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        observed_at TEXT NOT NULL,
        observed_at_ms INTEGER NOT NULL,
        event_type TEXT NOT NULL,
        source TEXT NOT NULL,
        session_user TEXT,
        hwnd TEXT,
        thread_id INTEGER,
        process_id INTEGER,
        process_name TEXT,
        executable_path TEXT,
        window_title TEXT,
        class_name TEXT,
        input_kind TEXT,
        idle_seconds INTEGER,
        idle_bucket TEXT,
        window_left INTEGER,
        window_top INTEGER,
        window_right INTEGER,
        window_bottom INTEGER,
        monitor_device TEXT,
        monitor_left INTEGER,
        monitor_top INTEGER,
        monitor_right INTEGER,
        monitor_bottom INTEGER,
        cursor_x INTEGER,
        cursor_y INTEGER,
        cursor_monitor_device TEXT,
        raw_json TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_focus_events_time
        ON focus_events(observed_at_ms);
      CREATE INDEX IF NOT EXISTS idx_focus_events_type_time
        ON focus_events(event_type, observed_at_ms);
      CREATE INDEX IF NOT EXISTS idx_focus_events_process_time
        ON focus_events(process_name, observed_at_ms);
      CREATE INDEX IF NOT EXISTS idx_focus_events_monitor_time
        ON focus_events(monitor_device, observed_at_ms);
    `);

    const columns = new Set(this.db.prepare('PRAGMA table_info(focus_events)').all().map((column) => column.name));
    if (!columns.has('idle_bucket')) {
      this.db.exec('ALTER TABLE focus_events ADD COLUMN idle_bucket TEXT');
    }
  }

  _prepareStatements() {
    this.stmts = {
      insert: this.db.prepare(`
        INSERT INTO focus_events (
          observed_at, observed_at_ms, event_type, source, session_user, hwnd,
          thread_id, process_id, process_name, executable_path, window_title,
          class_name, input_kind, idle_seconds, idle_bucket, window_left, window_top,
          window_right, window_bottom, monitor_device, monitor_left, monitor_top,
          monitor_right, monitor_bottom, cursor_x, cursor_y, cursor_monitor_device,
          raw_json, created_at
        ) VALUES (
          @observed_at, @observed_at_ms, @event_type, @source, @session_user, @hwnd,
          @thread_id, @process_id, @process_name, @executable_path, @window_title,
          @class_name, @input_kind, @idle_seconds, @idle_bucket, @window_left, @window_top,
          @window_right, @window_bottom, @monitor_device, @monitor_left, @monitor_top,
          @monitor_right, @monitor_bottom, @cursor_x, @cursor_y, @cursor_monitor_device,
          @raw_json, @created_at
        )
      `),
      latest: this.db.prepare('SELECT * FROM focus_events ORDER BY observed_at_ms DESC, id DESC LIMIT @limit'),
      range: this.db.prepare(`
        SELECT * FROM focus_events
        WHERE observed_at_ms >= @startMs AND observed_at_ms <= @endMs
        ORDER BY observed_at_ms ASC, id ASC
        LIMIT @limit
      `),
      prune: this.db.prepare('DELETE FROM focus_events WHERE observed_at_ms < @cutoffMs'),
      insertMany: this.db.transaction((rows) => {
        rows.forEach((row) => this.stmts.insert.run(row));
      })
    };
  }

  _recordRows(rows = []) {
    this.sessionEventCount += rows.length;
    const latest = rows.reduce((selected, row) => (
      !selected || row.observed_at_ms > selected.observed_at_ms ? row : selected
    ), null);
    if (latest) {
      this.latestEventAt = latest.observed_at;
    }
  }

  _eventRow(event = {}) {
    const observedAt = event.observed_at || new Date().toISOString();
    const observedAtMs = new Date(observedAt).getTime();
    if (!Number.isFinite(observedAtMs)) {
      return null;
    }
    const source = String(event.source || 'windows_focus_helper').slice(0, 80);
    const eventType = String(event.event_type || 'focus_event').slice(0, 80);
    const numberOrNull = (value) => {
      if (value === '' || value === null || value === undefined) {
        return null;
      }
      const number = Number(value);
      return Number.isFinite(number) ? Math.round(number) : null;
    };

    return {
      observed_at: new Date(observedAtMs).toISOString(),
      observed_at_ms: observedAtMs,
      event_type: eventType,
      source,
      session_user: this._text(event.session_user, 160),
      hwnd: this._text(event.hwnd, 64),
      thread_id: numberOrNull(event.thread_id),
      process_id: numberOrNull(event.process_id),
      process_name: this._text(event.process_name, 260),
      executable_path: this._text(event.executable_path, 1024),
      window_title: this._text(event.window_title, 2048),
      class_name: this._text(event.class_name, 260),
      input_kind: this._text(event.input_kind, 80),
      idle_seconds: numberOrNull(event.idle_seconds),
      idle_bucket: this._text(event.idle_bucket, 40),
      window_left: numberOrNull(event.window_left),
      window_top: numberOrNull(event.window_top),
      window_right: numberOrNull(event.window_right),
      window_bottom: numberOrNull(event.window_bottom),
      monitor_device: this._text(event.monitor_device, 120),
      monitor_left: numberOrNull(event.monitor_left),
      monitor_top: numberOrNull(event.monitor_top),
      monitor_right: numberOrNull(event.monitor_right),
      monitor_bottom: numberOrNull(event.monitor_bottom),
      cursor_x: numberOrNull(event.cursor_x),
      cursor_y: numberOrNull(event.cursor_y),
      cursor_monitor_device: this._text(event.cursor_monitor_device, 120),
      raw_json: JSON.stringify(event),
      created_at: new Date().toISOString()
    };
  }

  _rowToEvent(row = {}) {
    let raw = {};
    try {
      raw = JSON.parse(row.raw_json || '{}');
    } catch {
      raw = {};
    }
    return {
      ...raw,
      observed_at: row.observed_at,
      event_type: row.event_type,
      source: row.source,
      process_name: row.process_name,
      window_title: row.window_title,
      idle_seconds: row.idle_seconds,
      idle_bucket: row.idle_bucket
    };
  }

  _isActiveFocusEvent(event = {}, idleThresholdSeconds) {
    if (!event.process_name && !event.window_title) {
      return false;
    }
    if (String(event.hwnd || '') === '0') {
      return false;
    }
    const idleSeconds = Number(event.idle_seconds);
    if (Number.isFinite(idleSeconds) && idleSeconds >= idleThresholdSeconds) {
      return false;
    }
    const idleBucket = String(event.idle_bucket || '').toLowerCase();
    if (!Number.isFinite(idleSeconds) && /^idle_(5m|15m|30m|60m|[1-9]\d+m)/.test(idleBucket)) {
      return false;
    }
    return true;
  }

  _isIdleFocusEvent(event = {}, idleThresholdSeconds) {
    const idleSeconds = Number(event.idle_seconds);
    if (Number.isFinite(idleSeconds) && idleSeconds >= idleThresholdSeconds) {
      return true;
    }
    const idleBucket = String(event.idle_bucket || '').toLowerCase();
    return /^idle_(5m|15m|30m|60m|[1-9]\d+m)/.test(idleBucket);
  }

  _isIdleResetInputState(event = {}, previousEvent = {}, idleThresholdSeconds) {
    if (String(event.event_type || '').toLowerCase() !== 'input_state') {
      return false;
    }
    if (this._isDirectInputEvent(event)) {
      return false;
    }
    if (!previousEvent || !this._sameFocusSurface(event, previousEvent)) {
      return false;
    }
    const currentIdleSeconds = Number(event.idle_seconds);
    if (!Number.isFinite(currentIdleSeconds) || currentIdleSeconds >= idleThresholdSeconds) {
      return false;
    }
    return this._isIdleFocusEvent(previousEvent, idleThresholdSeconds);
  }

  _isDirectInputEvent(event = {}) {
    return String(event.event_type || '').toLowerCase() === 'input_activity';
  }

  _sameFocusSurface(left = {}, right = {}) {
    const leftHwnd = String(left.hwnd || '').trim();
    const rightHwnd = String(right.hwnd || '').trim();
    if (leftHwnd && rightHwnd && leftHwnd !== '0' && rightHwnd !== '0') {
      return leftHwnd === rightHwnd;
    }
    return this._focusSignature(left) === this._focusSignature(right);
  }

  _focusSignature(event = {}) {
    const hwnd = String(event.hwnd || '').trim();
    if (hwnd && hwnd !== '0') {
      return `hwnd:${hwnd}`;
    }
    return [
      String(event.process_name || '').trim().toLowerCase(),
      String(event.window_title || '').trim().toLowerCase()
    ].join('|');
  }

  _isPassiveFocusEvent(event = {}, minIdleSeconds, maxIdleSeconds) {
    if (!event.process_name && !event.window_title) {
      return false;
    }
    if (String(event.hwnd || '') === '0') {
      return false;
    }
    const idleSeconds = Number(event.idle_seconds || 0);
    if (!Number.isFinite(idleSeconds) || idleSeconds < minIdleSeconds || idleSeconds > maxIdleSeconds) {
      return false;
    }
    const idleBucket = String(event.idle_bucket || '').toLowerCase();
    return /^idle_/.test(idleBucket) || idleSeconds >= minIdleSeconds;
  }

  _classifyFocusEvent(event = {}, classifier) {
    try {
      return classifier.classifyRecord({
        source: 'windows_focus_evidence',
        activity_type: 'focus_evidence',
        app_name: event.process_name || '',
        window_title: event.window_title || '',
        timestamp_start: event.observed_at
      }) || {};
    } catch {
      return {};
    }
  }

  _isPassiveWorkClassification(result = {}) {
    const classification = String(result.classification || '').toLowerCase();
    if (classification !== 'work' && classification !== 'meeting') {
      return false;
    }
    return String(result.confidence || '').toLowerCase() === 'high';
  }

  _mergeCompatibleIntervals(intervals = []) {
    const sorted = intervals
      .filter((interval) => Number.isFinite(interval.startMs) && Number.isFinite(interval.endMs) && interval.endMs > interval.startMs)
      .sort((left, right) => left.startMs - right.startMs);
    const merged = [];
    sorted.forEach((interval) => {
      const last = merged[merged.length - 1];
      const sameSurface = last &&
        last.process_name === interval.process_name &&
        last.window_title === interval.window_title &&
        last.classification === interval.classification;
      if (!sameSurface || interval.startMs > last.endMs + 1000) {
        merged.push({ ...interval });
        return;
      }
      last.endMs = Math.max(last.endMs, interval.endMs);
      last.end = new Date(last.endMs).toISOString();
      last.idle_seconds = Math.max(Number(last.idle_seconds || 0), Number(interval.idle_seconds || 0));
    });
    return merged;
  }

  _appendJsonlRows(rows = []) {
    const byDate = new Map();
    rows.forEach((row) => {
      const date = String(row.observed_at).slice(0, 10);
      const existing = byDate.get(date) || [];
      existing.push(row.raw_json);
      byDate.set(date, existing);
    });
    byDate.forEach((lines, date) => {
      const filePath = path.join(this.jsonlPath, `${date}.jsonl`);
      fs.appendFileSync(filePath, `${lines.join('\n')}\n`, 'utf8');
    });
  }

  _latestJsonl(limit) {
    if (!fs.existsSync(this.jsonlPath)) {
      return [];
    }
    const files = fs.readdirSync(this.jsonlPath)
      .filter((name) => /^\d{4}-\d{2}-\d{2}\.jsonl$/.test(name))
      .sort()
      .reverse();
    const rows = [];
    for (const file of files) {
      const lines = fs.readFileSync(path.join(this.jsonlPath, file), 'utf8').split('\n').filter(Boolean).reverse();
      for (const line of lines) {
        try {
          rows.push(JSON.parse(line));
        } catch {
          // Skip malformed focus rows.
        }
        if (rows.length >= limit) {
          return rows;
        }
      }
    }
    return rows;
  }

  _queryJsonl(startMs, endMs, limit) {
    const rows = [];
    const cursor = new Date(startMs);
    cursor.setUTCHours(0, 0, 0, 0);
    const endDay = new Date(endMs);
    endDay.setUTCHours(0, 0, 0, 0);
    while (cursor <= endDay && rows.length < limit) {
      const filePath = path.join(this.jsonlPath, `${cursor.toISOString().slice(0, 10)}.jsonl`);
      if (fs.existsSync(filePath)) {
        const lines = fs.readFileSync(filePath, 'utf8').split('\n').filter(Boolean);
        for (const line of lines) {
          try {
            const event = JSON.parse(line);
            const observedMs = new Date(event.observed_at).getTime();
            if (observedMs >= startMs && observedMs <= endMs) {
              rows.push(event);
            }
          } catch {
            // Skip malformed focus rows.
          }
          if (rows.length >= limit) {
            break;
          }
        }
      }
      cursor.setUTCDate(cursor.getUTCDate() + 1);
    }
    return rows;
  }

  _text(value, maxLength) {
    const text = value == null ? '' : String(value);
    return text.length > maxLength ? text.slice(0, maxLength) : text;
  }
}

module.exports = { FocusEventStoreService };
