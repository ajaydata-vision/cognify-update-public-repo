const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { normalizeActivity } = require('./activity-schema');

const SCHEMA_VERSION = '3';
const MAX_RECORD_OVERLAP_LOOKBACK_MS = 12 * 60 * 60 * 1000;
const MIGRATIONS = [
  {
    version: 1,
    up(db) {
      db.exec(`
        CREATE TABLE IF NOT EXISTS schema_meta (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS activity_records (
          record_key TEXT PRIMARY KEY,
          source TEXT NOT NULL DEFAULT 'screenpipe',
          source_id TEXT,
          timestamp_start TEXT NOT NULL,
          timestamp_end TEXT,
          timestamp_start_ms INTEGER NOT NULL,
          timestamp_end_ms INTEGER,
          day_key TEXT NOT NULL,
          app_name TEXT,
          app_name_norm TEXT,
          window_title TEXT,
          url_if_available TEXT,
          url_host TEXT,
          activity_type TEXT,
          ocr_text TEXT,
          transcript_text TEXT,
          classification TEXT,
          classification_confidence REAL,
          meeting_flag INTEGER NOT NULL DEFAULT 0,
          social_flag INTEGER NOT NULL DEFAULT 0,
          duration_ms_estimate INTEGER,
          raw_json TEXT NOT NULL,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_activity_time
          ON activity_records(timestamp_start_ms);
        CREATE INDEX IF NOT EXISTS idx_activity_day_time
          ON activity_records(day_key, timestamp_start_ms);
        CREATE INDEX IF NOT EXISTS idx_activity_app_time
          ON activity_records(app_name_norm, timestamp_start_ms);
        CREATE INDEX IF NOT EXISTS idx_activity_host_time
          ON activity_records(url_host, timestamp_start_ms);
        CREATE INDEX IF NOT EXISTS idx_activity_class_time
          ON activity_records(classification, timestamp_start_ms);
        CREATE INDEX IF NOT EXISTS idx_activity_flags_time
          ON activity_records(social_flag, meeting_flag, timestamp_start_ms);

        CREATE TABLE IF NOT EXISTS sync_windows (
          window_key TEXT PRIMARY KEY,
          start_time TEXT NOT NULL,
          end_time TEXT NOT NULL,
          start_ms INTEGER NOT NULL,
          end_ms INTEGER NOT NULL,
          fetched_count INTEGER NOT NULL DEFAULT 0,
          limit_value INTEGER NOT NULL DEFAULT 0,
          limit_hit INTEGER NOT NULL DEFAULT 0,
          complete INTEGER NOT NULL DEFAULT 0,
          fetch_failed INTEGER NOT NULL DEFAULT 0,
          depth INTEGER NOT NULL DEFAULT 0,
          purpose TEXT NOT NULL DEFAULT 'range',
          updated_at TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_sync_time
          ON sync_windows(start_ms, end_ms);
        CREATE INDEX IF NOT EXISTS idx_sync_complete_time
          ON sync_windows(complete, start_ms, end_ms);
        CREATE INDEX IF NOT EXISTS idx_sync_purpose_time
          ON sync_windows(purpose, start_ms, end_ms);

        CREATE TABLE IF NOT EXISTS migration_progress (
          file_key TEXT PRIMARY KEY,
          file_path TEXT NOT NULL,
          size_bytes INTEGER NOT NULL,
          mtime_ms INTEGER NOT NULL,
          status TEXT NOT NULL,
          imported_count INTEGER NOT NULL DEFAULT 0,
          inserted_count INTEGER NOT NULL DEFAULT 0,
          deduped_count INTEGER NOT NULL DEFAULT 0,
          replaced_count INTEGER NOT NULL DEFAULT 0,
          malformed_count INTEGER NOT NULL DEFAULT 0,
          error_message TEXT,
          updated_at TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_migration_progress_status
          ON migration_progress(status, updated_at);
      `);
    }
  },
  {
    version: 2,
    up(db) {
      db.exec(`
        CREATE TABLE IF NOT EXISTS deletion_tombstones (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          start_time TEXT NOT NULL,
          end_time TEXT NOT NULL,
          start_ms INTEGER NOT NULL,
          end_ms INTEGER NOT NULL,
          reason TEXT NOT NULL DEFAULT 'user_delete_range',
          created_at TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_deletion_tombstones_time
          ON deletion_tombstones(start_ms, end_ms);
      `);
    }
  },
  {
    version: 3,
    up(db) {
      db.exec(`
        CREATE INDEX IF NOT EXISTS idx_activity_end_start
          ON activity_records(timestamp_end_ms, timestamp_start_ms);
      `);
    }
  }
];

class SqliteActivityStoreService {
  constructor(storagePath, options = {}) {
    this.basePath = path.join(storagePath, 'activity-store');
    this.dbPath = options.dbPath || path.join(storagePath, 'cognify.db');
    this.lowMemory = Boolean(options.lowMemory || process.env.COGNIFY_SQLITE_LOW_MEMORY === '1');
    const importBatchSize = Number(options.importBatchSize || (this.lowMemory ? 100 : 500));
    this.importBatchSize = Number.isFinite(importBatchSize) ? Math.max(25, importBatchSize) : (this.lowMemory ? 100 : 500);
    fs.mkdirSync(path.dirname(this.dbPath), { recursive: true });
    fs.mkdirSync(this.basePath, { recursive: true });

    const Database = options.Database || require('better-sqlite3');
    this.db = new Database(this.dbPath);
    this._configure();
    this._migrate();
    this._prepareStatements();
  }

  close() {
    if (this.db?.open) {
      this.db.close();
    }
  }

  ingest(records = []) {
    if (!Array.isArray(records) || records.length === 0) {
      return { inserted: 0, deduped: 0, replaced: 0 };
    }

    const normalized = records
      .map((record) => this._prepareRecord(record))
      .filter((record) => record && record.timestamp_start);
    const allowed = normalized.filter((record) => !this._isRecordDeleted(record));
    const skippedDeleted = normalized.length - allowed.length;

    let inserted = 0;
    let deduped = 0;
    let replaced = 0;

    const write = this.db.transaction((rows) => {
      rows.forEach((record) => {
        const existing = this.stmts.getRecord.get(record.record_key);
        if (!existing) {
          this.stmts.upsertRecord.run(this._recordRow(record));
          inserted += 1;
          return;
        }

        const existingRecord = this._rowToRecord(existing);
        if (this._shouldReplace(existingRecord, record)) {
          this.stmts.upsertRecord.run(this._recordRow(record));
          replaced += 1;
          return;
        }

        deduped += 1;
      });
    });

    write(allowed);
    return { inserted, deduped, replaced, skipped_deleted: skippedDeleted };
  }

  queryRange(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return [];
    }

    return this.stmts.queryRange.all({ lookupStartMs: overlapLookupStartMs(startMs), startMs, endMs })
      .map((row) => this._rowToRecord(row));
  }

  queryRangeLite(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return [];
    }

    return this.stmts.queryRangeLite.all({ lookupStartMs: overlapLookupStartMs(startMs), startMs, endMs })
      .map((row) => this._rowToLiteRecord(row));
  }

  deleteRange(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return { deleted: 0, touched_days: 0 };
    }

    const lookupStartMs = overlapLookupStartMs(startMs);
    const days = new Set(this.stmts.queryDaysInRange.all({ lookupStartMs, startMs, endMs }).map((row) => row.day_key));
    const deleted = this.db.transaction(() => {
      const deletedRows = this.stmts.deleteRange.run({ lookupStartMs, startMs, endMs }).changes;
      this._addTombstone(startTime, endTime, startMs, endMs);
      this._removeSyncWindowsInRange(startMs, endMs);
      return deletedRows;
    })();
    return { deleted, touched_days: days.size, tombstoned: true };
  }

  filterDeletedRecords(records = []) {
    if (!Array.isArray(records) || records.length === 0) {
      return [];
    }
    return records.filter((record) => !this._isRecordDeleted(record));
  }

  recordSyncWindows(windows = []) {
    if (!Array.isArray(windows) || windows.length === 0) {
      return { updated: 0 };
    }

    let updated = 0;
    const write = this.db.transaction((items) => {
      items.forEach((window) => {
        if (!window?.start_time || !window?.end_time) {
          return;
        }

        const startMs = new Date(window.start_time).getTime();
        const endMs = new Date(window.end_time).getTime();
        if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) {
          return;
        }

        this.stmts.upsertSyncWindow.run({
          window_key: `${window.start_time}|${window.end_time}`,
          start_time: window.start_time,
          end_time: window.end_time,
          start_ms: startMs,
          end_ms: endMs,
          fetched_count: Number(window.fetched_count || 0),
          limit_value: Number(window.limit || window.limit_value || 0),
          limit_hit: window.limit_hit ? 1 : 0,
          complete: window.complete ? 1 : 0,
          fetch_failed: window.fetch_failed ? 1 : 0,
          depth: Number(window.depth || 0),
          purpose: String(window.purpose || 'range'),
          updated_at: new Date().toISOString()
        });
        updated += 1;
      });
    });

    write(windows);
    return { updated };
  }

  getSyncSummary(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return {
        complete: false,
        incomplete_window_count: 0,
        windows: []
      };
    }

    const windows = this.stmts.querySyncWindows.all({ startMs, endMs }).map((row) => ({
      start_time: row.start_time,
      end_time: row.end_time,
      fetched_count: row.fetched_count,
      limit: row.limit_value,
      limit_hit: Boolean(row.limit_hit),
      complete: Boolean(row.complete),
      fetch_failed: Boolean(row.fetch_failed),
      depth: row.depth,
      purpose: row.purpose,
      updated_at: row.updated_at
    }));
    const incompleteCount = windows.filter((window) => !window.complete).length;
    return {
      complete: windows.length > 0 && incompleteCount === 0,
      incomplete_window_count: incompleteCount,
      windows
    };
  }

  prune(cutoffMs) {
    if (!Number.isFinite(cutoffMs)) {
      return { prunedFiles: 0, prunedSyncWindows: 0, prunedRows: 0 };
    }

    const prunedRows = this.stmts.pruneRecords.run({ cutoffMs }).changes;
    const prunedSyncWindows = this.stmts.pruneSyncWindows.run({ cutoffMs }).changes;
    return { prunedFiles: 0, prunedSyncWindows, prunedRows };
  }

  latestTimestamp() {
    const row = this.stmts.latestTimestamp.get();
    return row?.timestamp_start || null;
  }

  getHealth() {
    try {
      const schema = this.stmts.getSchemaVersion.get();
      const recordCount = this.stmts.countRecords.get().count;
      const syncWindowCount = this.stmts.countSyncWindows.get().count;
      const migrationFileCount = this.stmts.countMigrationProgress.get().count;
      return {
        ok: schema?.value === SCHEMA_VERSION,
        label: 'SQLite',
        detail: schema?.value === SCHEMA_VERSION
          ? `SQLite ready, ${recordCount} activity row(s).`
          : `SQLite schema mismatch: ${schema?.value || 'missing'}`,
        dbPath: this.dbPath,
        schemaVersion: schema?.value || null,
        expectedSchemaVersion: SCHEMA_VERSION,
        recordCount,
        syncWindowCount,
        migrationFileCount
      };
    } catch (error) {
      return {
        ok: false,
        label: 'SQLite',
        detail: error?.message || String(error),
        dbPath: this.dbPath,
        schemaVersion: null,
        expectedSchemaVersion: SCHEMA_VERSION,
        recordCount: 0,
        syncWindowCount: 0,
        migrationFileCount: 0
      };
    }
  }

  importJsonlStore(jsonlBasePath = this.basePath, options = {}) {
    if (jsonlBasePath && typeof jsonlBasePath === 'object') {
      options = jsonlBasePath;
      jsonlBasePath = this.basePath;
    }
    if (!fs.existsSync(jsonlBasePath)) {
      return {
        files: 0,
        skipped: 0,
        skipped_out_of_window: 0,
        imported: 0,
        inserted: 0,
        deduped: 0,
        replaced: 0,
        malformed: 0,
        changed_ranges: []
      };
    }

    const cutoffDay = this._jsonlImportCutoffDay(options);
    const files = fs.readdirSync(jsonlBasePath)
      .filter((name) => /^\d{4}-\d{2}-\d{2}\.jsonl$/.test(name))
      .filter((name) => !cutoffDay || name.slice(0, 10) >= cutoffDay)
      .sort();
    const allJsonlCount = fs.readdirSync(jsonlBasePath)
      .filter((name) => /^\d{4}-\d{2}-\d{2}\.jsonl$/.test(name))
      .length;
    const totals = {
      files: 0,
      skipped: 0,
      skipped_out_of_window: allJsonlCount - files.length,
      imported: 0,
      inserted: 0,
      deduped: 0,
      replaced: 0,
      malformed: 0,
      changed_ranges: []
    };

    files.forEach((name) => {
      const filePath = path.join(jsonlBasePath, name);
      const stat = fs.statSync(filePath);
      const fileKey = path.resolve(filePath).toLowerCase();
      const existingProgress = this.stmts.getMigrationProgress.get(fileKey);
      if (
        existingProgress &&
        existingProgress.status === 'completed' &&
        existingProgress.size_bytes === stat.size &&
        existingProgress.mtime_ms === Math.round(stat.mtimeMs)
      ) {
        totals.skipped += 1;
        return;
      }

      this.stmts.upsertMigrationProgress.run({
        file_key: fileKey,
        file_path: filePath,
        size_bytes: stat.size,
        mtime_ms: Math.round(stat.mtimeMs),
        status: 'started',
        imported_count: 0,
        inserted_count: 0,
        deduped_count: 0,
        replaced_count: 0,
        malformed_count: 0,
        error_message: null,
        updated_at: new Date().toISOString()
      });

      try {
        const fileResult = this._importJsonlFile(filePath);
        const result = fileResult.result;
        const fileMalformed = fileResult.malformed;
        totals.files += 1;
        totals.imported += fileResult.imported;
        totals.malformed += fileMalformed;
        totals.inserted += result.inserted;
        totals.deduped += result.deduped;
        totals.replaced += result.replaced;
        if (fileResult.changed_range) {
          totals.changed_ranges.push(fileResult.changed_range);
        }

        this.stmts.upsertMigrationProgress.run({
          file_key: fileKey,
          file_path: filePath,
          size_bytes: stat.size,
          mtime_ms: Math.round(stat.mtimeMs),
          status: 'completed',
          imported_count: fileResult.imported,
          inserted_count: result.inserted,
          deduped_count: result.deduped,
          replaced_count: result.replaced,
          malformed_count: fileMalformed,
          error_message: null,
          updated_at: new Date().toISOString()
        });
      } catch (error) {
        this.stmts.upsertMigrationProgress.run({
          file_key: fileKey,
          file_path: filePath,
          size_bytes: stat.size,
          mtime_ms: Math.round(stat.mtimeMs),
          status: 'failed',
          imported_count: 0,
          inserted_count: 0,
          deduped_count: 0,
          replaced_count: 0,
          malformed_count: 0,
          error_message: error?.message || String(error),
          updated_at: new Date().toISOString()
        });
        throw error;
      }
    });

    totals.syncWindows = this.importJsonlSyncState(jsonlBasePath, { cutoffDay });
    return totals;
  }

  _jsonlImportCutoffDay(options = {}) {
    const explicit = String(options.sinceDay || options.sinceDate || '').slice(0, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(explicit)) {
      return explicit;
    }

    const maxDays = Math.floor(Number(options.maxDays || 0));
    if (!Number.isFinite(maxDays) || maxDays <= 0) {
      return null;
    }

    const now = options.now ? new Date(options.now) : new Date();
    if (!Number.isFinite(now.getTime())) {
      return null;
    }
    const cutoff = new Date(now.getTime() - Math.max(0, maxDays - 1) * 24 * 60 * 60 * 1000);
    return cutoff.toISOString().slice(0, 10);
  }

  _recordsTimeRange(records = []) {
    let minStartMs = Infinity;
    let maxEndMs = -Infinity;
    records.forEach((record) => {
      const interval = recordIntervalMs(record);
      if (!Number.isFinite(interval.startMs)) {
        return;
      }
      minStartMs = Math.min(minStartMs, interval.startMs);
      maxEndMs = Math.max(maxEndMs, Number.isFinite(interval.endMs) ? interval.endMs : interval.startMs);
    });

    if (!Number.isFinite(minStartMs) || !Number.isFinite(maxEndMs)) {
      return null;
    }

    return {
      startTime: new Date(minStartMs).toISOString(),
      endTime: new Date(Math.max(maxEndMs, minStartMs) + 1000).toISOString()
    };
  }

  importJsonlSyncState(jsonlBasePath = this.basePath, options = {}) {
    const syncPath = path.join(jsonlBasePath, 'sync-state.json');
    if (!fs.existsSync(syncPath)) {
      return { imported: 0, updated: 0, skipped_out_of_window: 0 };
    }

    let parsed;
    try {
      parsed = JSON.parse(fs.readFileSync(syncPath, 'utf8'));
    } catch {
      return { imported: 0, updated: 0, skipped_out_of_window: 0, malformed: true };
    }

    const cutoffDay = String(options.cutoffDay || '').slice(0, 10);
    const cutoffMs = /^\d{4}-\d{2}-\d{2}$/.test(cutoffDay)
      ? Date.parse(`${cutoffDay}T00:00:00.000Z`)
      : Number.NaN;
    const allWindows = Object.values(parsed || {})
      .filter((window) => window?.start_time && window?.end_time);
    const windows = allWindows
      .filter((window) => {
        if (!Number.isFinite(cutoffMs)) {
          return true;
        }
        const endMs = new Date(window.end_time).getTime();
        return Number.isFinite(endMs) && endMs >= cutoffMs;
      });
    const result = this.recordSyncWindows(windows);
    return {
      imported: windows.length,
      updated: result.updated || 0,
      skipped_out_of_window: allWindows.length - windows.length
    };
  }

  _configure() {
    this.db.pragma('journal_mode = WAL');
    this.db.pragma('synchronous = NORMAL');
    this.db.pragma('foreign_keys = ON');
    this.db.pragma(`temp_store = ${this.lowMemory ? 'FILE' : 'MEMORY'}`);
  }

  _importJsonlFile(filePath) {
    const aggregate = {
      inserted: 0,
      deduped: 0,
      replaced: 0,
      skipped_deleted: 0
    };
    let imported = 0;
    let malformed = 0;
    let range = null;
    let batch = [];
    let carry = '';
    const buffer = Buffer.alloc(64 * 1024);
    const fd = fs.openSync(filePath, 'r');

    const flush = () => {
      if (!batch.length) {
        return;
      }
      const result = this.ingest(batch);
      aggregate.inserted += Number(result.inserted || 0);
      aggregate.deduped += Number(result.deduped || 0);
      aggregate.replaced += Number(result.replaced || 0);
      aggregate.skipped_deleted += Number(result.skipped_deleted || 0);
      if (Number(result.inserted || 0) > 0 || Number(result.replaced || 0) > 0) {
        range = this._mergeRecordRanges(range, this._recordsTimeRange(batch));
      }
      batch = [];
    };

    const consumeLine = (line) => {
      const text = String(line || '').trim();
      if (!text) {
        return;
      }
      try {
        batch.push(JSON.parse(text));
        imported += 1;
        if (batch.length >= this.importBatchSize) {
          flush();
        }
      } catch {
        malformed += 1;
      }
    };

    try {
      let bytesRead = 0;
      do {
        bytesRead = fs.readSync(fd, buffer, 0, buffer.length, null);
        if (bytesRead <= 0) {
          break;
        }
        const chunk = carry + buffer.toString('utf8', 0, bytesRead);
        const lines = chunk.split(/\r?\n/);
        carry = lines.pop() || '';
        lines.forEach(consumeLine);
      } while (bytesRead > 0);
      consumeLine(carry);
      flush();
      return {
        imported,
        malformed,
        result: aggregate,
        changed_range: range
      };
    } finally {
      fs.closeSync(fd);
    }
  }

  _mergeRecordRanges(left, right) {
    if (!left) {
      return right || null;
    }
    if (!right) {
      return left;
    }
    const startMs = Math.min(new Date(left.startTime).getTime(), new Date(right.startTime).getTime());
    const endMs = Math.max(new Date(left.endTime).getTime(), new Date(right.endTime).getTime());
    if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) {
      return left || right;
    }
    return {
      startTime: new Date(startMs).toISOString(),
      endTime: new Date(endMs).toISOString()
    };
  }

  _migrate() {
    this.db.exec('CREATE TABLE IF NOT EXISTS schema_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);');
    const row = this.db.prepare("SELECT value FROM schema_meta WHERE key = 'activity_schema_version'").get();
    const currentVersion = Number(row?.value || 0);
    const pending = MIGRATIONS.filter((migration) => migration.version > currentVersion)
      .sort((left, right) => left.version - right.version);

    const apply = this.db.transaction(() => {
      pending.forEach((migration) => {
        migration.up(this.db);
        this.db.prepare(`
          INSERT INTO schema_meta (key, value)
          VALUES ('activity_schema_version', ?)
          ON CONFLICT(key) DO UPDATE SET value = excluded.value
        `).run(String(migration.version));
      });
    });

    apply();
  }

  _prepareStatements() {
    this.stmts = {
      getRecord: this.db.prepare('SELECT * FROM activity_records WHERE record_key = ?'),
      upsertRecord: this.db.prepare(`
        INSERT INTO activity_records (
          record_key, source, source_id, timestamp_start, timestamp_end,
          timestamp_start_ms, timestamp_end_ms, day_key, app_name, app_name_norm,
          window_title, url_if_available, url_host, activity_type, ocr_text,
          transcript_text, classification, classification_confidence, meeting_flag,
          social_flag, duration_ms_estimate, raw_json, created_at, updated_at
        ) VALUES (
          @record_key, @source, @source_id, @timestamp_start, @timestamp_end,
          @timestamp_start_ms, @timestamp_end_ms, @day_key, @app_name, @app_name_norm,
          @window_title, @url_if_available, @url_host, @activity_type, @ocr_text,
          @transcript_text, @classification, @classification_confidence, @meeting_flag,
          @social_flag, @duration_ms_estimate, @raw_json, @created_at, @updated_at
        )
        ON CONFLICT(record_key) DO UPDATE SET
          source = excluded.source,
          source_id = excluded.source_id,
          timestamp_start = excluded.timestamp_start,
          timestamp_end = excluded.timestamp_end,
          timestamp_start_ms = excluded.timestamp_start_ms,
          timestamp_end_ms = excluded.timestamp_end_ms,
          day_key = excluded.day_key,
          app_name = excluded.app_name,
          app_name_norm = excluded.app_name_norm,
          window_title = excluded.window_title,
          url_if_available = excluded.url_if_available,
          url_host = excluded.url_host,
          activity_type = excluded.activity_type,
          ocr_text = excluded.ocr_text,
          transcript_text = excluded.transcript_text,
          classification = excluded.classification,
          classification_confidence = excluded.classification_confidence,
          meeting_flag = excluded.meeting_flag,
          social_flag = excluded.social_flag,
          duration_ms_estimate = excluded.duration_ms_estimate,
          raw_json = excluded.raw_json,
          updated_at = excluded.updated_at
      `),
      queryRange: this.db.prepare(`
        SELECT * FROM activity_records
        WHERE timestamp_start_ms >= @lookupStartMs
          AND timestamp_start_ms <= @endMs
          AND COALESCE(timestamp_end_ms, timestamp_start_ms) >= @startMs
        ORDER BY timestamp_start_ms ASC
      `),
      queryRangeLite: this.db.prepare(`
        SELECT
          record_key, source, source_id, timestamp_start, timestamp_end,
          app_name, window_title, url_if_available, url_host, activity_type,
          classification, meeting_flag, social_flag, duration_ms_estimate,
          created_at, updated_at
        FROM activity_records
        WHERE timestamp_start_ms >= @lookupStartMs
          AND timestamp_start_ms <= @endMs
          AND COALESCE(timestamp_end_ms, timestamp_start_ms) >= @startMs
        ORDER BY timestamp_start_ms ASC
      `),
      queryDaysInRange: this.db.prepare(`
        SELECT DISTINCT day_key FROM activity_records
        WHERE timestamp_start_ms >= @lookupStartMs
          AND timestamp_start_ms <= @endMs
          AND COALESCE(timestamp_end_ms, timestamp_start_ms) >= @startMs
      `),
      deleteRange: this.db.prepare(`
        DELETE FROM activity_records
        WHERE timestamp_start_ms >= @lookupStartMs
          AND timestamp_start_ms <= @endMs
          AND COALESCE(timestamp_end_ms, timestamp_start_ms) >= @startMs
      `),
      upsertSyncWindow: this.db.prepare(`
        INSERT INTO sync_windows (
          window_key, start_time, end_time, start_ms, end_ms, fetched_count,
          limit_value, limit_hit, complete, fetch_failed, depth, purpose, updated_at
        ) VALUES (
          @window_key, @start_time, @end_time, @start_ms, @end_ms, @fetched_count,
          @limit_value, @limit_hit, @complete, @fetch_failed, @depth, @purpose, @updated_at
        )
        ON CONFLICT(window_key) DO UPDATE SET
          fetched_count = excluded.fetched_count,
          limit_value = excluded.limit_value,
          limit_hit = excluded.limit_hit,
          complete = excluded.complete,
          fetch_failed = excluded.fetch_failed,
          depth = excluded.depth,
          purpose = excluded.purpose,
          updated_at = excluded.updated_at
      `),
      querySyncWindows: this.db.prepare(`
        SELECT * FROM sync_windows
        WHERE start_ms <= @endMs AND end_ms >= @startMs
        ORDER BY start_ms ASC
      `),
      removeSyncWindowsInRange: this.db.prepare(`
        DELETE FROM sync_windows
        WHERE start_ms <= @endMs AND end_ms >= @startMs
      `),
      findDeletionTombstone: this.db.prepare(`
        SELECT id FROM deletion_tombstones
        WHERE start_ms <= @recordEndMs AND end_ms >= @recordStartMs
        LIMIT 1
      `),
      insertDeletionTombstone: this.db.prepare(`
        INSERT INTO deletion_tombstones (start_time, end_time, start_ms, end_ms, reason, created_at)
        VALUES (@start_time, @end_time, @start_ms, @end_ms, @reason, @created_at)
      `),
      pruneRecords: this.db.prepare('DELETE FROM activity_records WHERE timestamp_start_ms < @cutoffMs'),
      pruneSyncWindows: this.db.prepare('DELETE FROM sync_windows WHERE end_ms < @cutoffMs'),
      latestTimestamp: this.db.prepare('SELECT timestamp_start FROM activity_records ORDER BY timestamp_start_ms DESC LIMIT 1'),
      getSchemaVersion: this.db.prepare("SELECT value FROM schema_meta WHERE key = 'activity_schema_version'"),
      countRecords: this.db.prepare('SELECT COUNT(*) AS count FROM activity_records'),
      countSyncWindows: this.db.prepare('SELECT COUNT(*) AS count FROM sync_windows'),
      countMigrationProgress: this.db.prepare('SELECT COUNT(*) AS count FROM migration_progress'),
      getMigrationProgress: this.db.prepare('SELECT * FROM migration_progress WHERE file_key = ?'),
      upsertMigrationProgress: this.db.prepare(`
        INSERT INTO migration_progress (
          file_key, file_path, size_bytes, mtime_ms, status, imported_count,
          inserted_count, deduped_count, replaced_count, malformed_count,
          error_message, updated_at
        ) VALUES (
          @file_key, @file_path, @size_bytes, @mtime_ms, @status, @imported_count,
          @inserted_count, @deduped_count, @replaced_count, @malformed_count,
          @error_message, @updated_at
        )
        ON CONFLICT(file_key) DO UPDATE SET
          file_path = excluded.file_path,
          size_bytes = excluded.size_bytes,
          mtime_ms = excluded.mtime_ms,
          status = excluded.status,
          imported_count = excluded.imported_count,
          inserted_count = excluded.inserted_count,
          deduped_count = excluded.deduped_count,
          replaced_count = excluded.replaced_count,
          malformed_count = excluded.malformed_count,
          error_message = excluded.error_message,
          updated_at = excluded.updated_at
      `)
    };
  }

  _prepareRecord(record) {
    const normalized = normalizeActivity(record);
    if (!normalized.timestamp_start) {
      return null;
    }

    const interval = recordIntervalMs(normalized);
    const timestampEnd = normalized.timestamp_end || (
      Number.isFinite(interval.startMs) &&
      Number.isFinite(interval.endMs) &&
      interval.endMs > interval.startMs
        ? new Date(interval.endMs).toISOString()
        : normalized.timestamp_end
    );
    const nextRecord = {
      ...normalized,
      timestamp_end: timestampEnd,
      created_at: record.created_at || normalized.created_at,
      updated_at: record.updated_at || normalized.updated_at,
    };
    return {
      ...nextRecord,
      record_key: this._recordKey(nextRecord)
    };
  }

  _recordRow(record) {
    const interval = recordIntervalMs(record);
    const startMs = interval.startMs;
    const endMs = interval.endMs;
    const now = new Date().toISOString();
    const sourceId = record.id ? String(record.id) : null;

    return {
      record_key: record.record_key,
      source: String(record.source || 'screenpipe'),
      source_id: sourceId,
      timestamp_start: record.timestamp_start,
      timestamp_end: record.timestamp_end || (endMs > startMs ? new Date(endMs).toISOString() : null),
      timestamp_start_ms: startMs,
      timestamp_end_ms: Number.isFinite(endMs) ? endMs : null,
      day_key: String(record.timestamp_start).slice(0, 10),
      app_name: record.app_name || null,
      app_name_norm: record.app_name ? String(record.app_name).trim().toLowerCase() : null,
      window_title: record.window_title || null,
      url_if_available: record.url_if_available || null,
      url_host: this._urlHost(record.url_if_available),
      activity_type: record.activity_type || null,
      ocr_text: record.ocr_text || null,
      transcript_text: record.transcript_text || null,
      classification: record.classification || null,
      classification_confidence: Number.isFinite(Number(record.classification_confidence))
        ? Number(record.classification_confidence)
        : null,
      meeting_flag: record.meeting_flag ? 1 : 0,
      social_flag: record.social_flag ? 1 : 0,
      duration_ms_estimate: Number.isFinite(Number(record.duration_ms_estimate))
        ? Number(record.duration_ms_estimate)
        : null,
      raw_json: JSON.stringify(record),
      created_at: record.created_at || now,
      updated_at: now
    };
  }

  _addTombstone(startTime, endTime, startMs, endMs) {
    this.stmts.insertDeletionTombstone.run({
      start_time: startTime,
      end_time: endTime,
      start_ms: startMs,
      end_ms: endMs,
      reason: 'user_delete_range',
      created_at: new Date().toISOString()
    });
  }

  _isRecordDeleted(record) {
    const interval = recordIntervalMs(record);
    if (!Number.isFinite(interval.startMs) || !Number.isFinite(interval.endMs)) {
      return false;
    }
    return Boolean(this.stmts.findDeletionTombstone.get({
      recordStartMs: interval.startMs,
      recordEndMs: interval.endMs
    }));
  }

  _rowToRecord(row) {
    try {
      const parsed = JSON.parse(row.raw_json);
      return {
        ...parsed,
        timestamp_start: row.timestamp_start || parsed.timestamp_start,
        timestamp_end: row.timestamp_end || parsed.timestamp_end || null,
        duration_ms_estimate: parsed.duration_ms_estimate ?? row.duration_ms_estimate,
        created_at: row.created_at,
        updated_at: row.updated_at
      };
    } catch {
      return {
        record_key: row.record_key,
        source: row.source,
        id: row.source_id,
        timestamp_start: row.timestamp_start,
        timestamp_end: row.timestamp_end,
        app_name: row.app_name,
        window_title: row.window_title,
        url_if_available: row.url_if_available,
        activity_type: row.activity_type,
        ocr_text: row.ocr_text,
        transcript_text: row.transcript_text
      };
    }
  }

  _rowToLiteRecord(row) {
    return {
      record_key: row.record_key,
      source: row.source,
      id: row.source_id,
      timestamp_start: row.timestamp_start || null,
      timestamp_end: row.timestamp_end || null,
      duration_ms_estimate: row.duration_ms_estimate ?? null,
      app_name: row.app_name || '',
      window_title: row.window_title || '',
      url_if_available: row.url_if_available || '',
      url_host: row.url_host || '',
      activity_type: row.activity_type || '',
      classification: row.classification || '',
      meeting_flag: Boolean(row.meeting_flag),
      social_flag: Boolean(row.social_flag),
      created_at: row.created_at,
      updated_at: row.updated_at
    };
  }

  _recordKey(record) {
    if (record.id) {
      return `${record.source || 'screenpipe'}:${record.id}`;
    }

    return crypto
      .createHash('sha1')
      .update(JSON.stringify([
        record.timestamp_start,
        record.timestamp_end,
        record.app_name,
        record.window_title,
        record.url_if_available,
        record.activity_type,
        record.ocr_text,
        record.transcript_text
      ]))
      .digest('hex');
  }

  _shouldReplace(existing, incoming) {
    const incomingScore = this._recordRichness(incoming);
    const existingScore = this._recordRichness(existing);
    if (incomingScore !== existingScore) {
      return incomingScore > existingScore;
    }

    const incomingEnd = recordIntervalMs(incoming).endMs;
    const existingEnd = recordIntervalMs(existing).endMs;
    if (Number.isFinite(incomingEnd) && Number.isFinite(existingEnd) && incomingEnd !== existingEnd) {
      return incomingEnd > existingEnd;
    }

    const incomingStart = new Date(incoming.timestamp_start).getTime();
    const existingStart = new Date(existing.timestamp_start).getTime();
    if (Number.isFinite(incomingStart) && Number.isFinite(existingStart) && incomingStart !== existingStart) {
      return incomingStart > existingStart;
    }

    return false;
  }

  _recordRichness(record = {}) {
    let score = 0;
    if (record.app_name) score += 3;
    if (record.window_title) score += 2;
    if (record.url_if_available) score += 2;
    if (record.ocr_text) score += 1;
    if (record.transcript_text) score += 1;
    return score;
  }

  _removeSyncWindowsInRange(startMs, endMs) {
    return this.stmts.removeSyncWindowsInRange.run({ startMs, endMs }).changes;
  }

  _urlHost(url) {
    try {
      return new URL(url).hostname.replace(/^www\./i, '').toLowerCase();
    } catch {
      return null;
    }
  }
}

function overlapLookupStartMs(startMs) {
  return startMs - MAX_RECORD_OVERLAP_LOOKBACK_MS;
}

function recordIntervalMs(record = {}) {
  const startMs = new Date(record.timestamp_start || record.timestamp || record.timestamp_end || 0).getTime();
  if (!Number.isFinite(startMs)) {
    return { startMs: Number.NaN, endMs: Number.NaN };
  }

  const explicitEndMs = new Date(record.timestamp_end || 0).getTime();
  const durationMs = Number(record.duration_ms_estimate || 0);
  let endMs = Number.isFinite(explicitEndMs) ? explicitEndMs : startMs;
  if (shouldUseDurationEnd(record) && durationMs > 0) {
    endMs = Math.max(endMs, startMs + durationMs);
  }
  if (!Number.isFinite(endMs) || endMs < startMs) {
    endMs = startMs;
  }
  return { startMs, endMs };
}

function shouldUseDurationEnd(record = {}) {
  const source = String(record.source || '').toLowerCase();
  const activityType = String(record.activity_type || record.type || '').toLowerCase();
  return (
    source === 'manual' ||
    activityType === 'manual' ||
    source === 'windows_focus_evidence' ||
    activityType === 'focus_evidence'
  );
}

module.exports = { SqliteActivityStoreService };
