# SQLite Activity Store Plan

## Purpose

Cognify currently stores local activity in JSONL day files under `activity-store` and tracks sync windows in `sync-state.json`. This has become expensive as daily files grow. The app repeatedly reads multi-megabyte files and calls Screenpipe for ranges already present locally. Moving Cognify's local activity store to SQLite should make dashboard, report, focus, social, meeting, idle, and nudge calculations faster and should reduce pressure on Screenpipe.

Screenpipe remains the capture engine. SQLite becomes Cognify's local query and aggregation layer.

## Current Pain

- JSONL day files are growing into multi-megabyte files.
- `sync-state.json` is large and contains many overlapping windows.
- `ActivityQueryService.getRangeData()` always calls Screenpipe before reading local data.
- Live Snapshot and background jobs can cause frequent `/search` calls.
- Screenpipe logs show high API usage, including spikes near 900 requests per 5 minutes.
- Full-day summaries repeatedly process thousands of records.

## Target Architecture

Screenpipe should only be used for capture and bounded sync.

Cognify should:

- Ingest Screenpipe records into a local SQLite database.
- Read dashboards, reports, nudges, focus trends, idle correction, social classification, and meeting classification from SQLite.
- Sync only missing or recent delta windows from Screenpipe.
- Avoid Screenpipe calls for background analytics when local data is available.

## SQLite File

Use one DB file in user data:

```text
%APPDATA%\cognify\cognify.db
```

Keep the old JSONL folder during rollout:

```text
%APPDATA%\cognify\activity-store\
```

Do not delete JSONL automatically in the first release.

## Driver Choice

Preferred package:

```text
better-sqlite3
```

Reason:

- Simple synchronous API.
- Good for Electron main-process local reads.
- No server.
- Reliable transactions.
- Easy prepared statements.

Risk:

- Native dependency must be compatible with the Electron/runtime packaging.
- Normal Windows install can be disrupted by the existing Screenpipe package postinstall script. Use the repo scripts below instead of relying on a plain reinstall.

Fallback:

- `sqlite3` package if native build friction appears.
- Keep JSONL service as fallback until packaging is proven.

Repo scripts:

```text
npm run rebuild:sqlite
npm run rebuild:sqlite:electron
npm run check:sqlite-electron
```

`rebuild:sqlite` rebuilds only the SQLite native binding for the current Node runtime. `rebuild:sqlite:electron` rebuilds the binding for Electron. `check:sqlite-electron` verifies that Electron can load `better-sqlite3`, create a DB, insert a row, and pass the SQLite service health check.

Important: the local Node runtime and Electron can require different native module ABI versions. If `npm test` reports a `NODE_MODULE_VERSION` mismatch after an Electron rebuild, run `npm run rebuild:sqlite` before Node-only tests. Before launching or bundling the Electron app, run `npm run rebuild:sqlite:electron` and `npm run check:sqlite-electron`.

Current rollout flags:

```powershell
$env:COGNIFY_ACTIVITY_STORE = "jsonl"   # rollback mode, JSONL reads/writes
$env:COGNIFY_ACTIVITY_STORE = "dual"    # JSONL reads, JSONL + SQLite writes
$env:COGNIFY_ACTIVITY_STORE = "sqlite"  # default, SQLite reads, SQLite + JSONL writes, only if SQLite health is OK
```

If SQLite is unavailable or unhealthy, Cognify falls back to JSONL and exposes the requested/actual mode plus fallback reason in diagnostics. SQLite mode intentionally keeps JSONL as a live rollback copy by writing every mutation to both stores.

Use the comparison tool before switching reads:

```powershell
npm run compare:activity-stores -- --date 2026-04-30
npm run compare:activity-stores -- --start 2026-04-30T00:00:00.000Z --end 2026-05-01T00:00:00.000Z
npm run compare:activity-stores -- "%APPDATA%\Cognify" 2026-04-30
```

The comparison runs under Electron so it uses the same native SQLite ABI as the app.

## Schema

### `schema_meta`

Tracks schema version.

```sql
CREATE TABLE IF NOT EXISTS schema_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
```

Set:

```text
activity_schema_version = 1
```

### `activity_records`

Canonical local activity rows.

```sql
CREATE TABLE IF NOT EXISTS activity_records (
  record_key TEXT PRIMARY KEY,
  source TEXT NOT NULL DEFAULT 'screenpipe',
  source_id TEXT,

  timestamp_start TEXT NOT NULL,
  timestamp_end TEXT,
  timestamp_start_ms INTEGER NOT NULL,
  timestamp_end_ms INTEGER,
  day_key TEXT NOT NULL,

  app_name TEXT,
  app_name_norm TEXT,
  window_title TEXT,
  url_if_available TEXT,
  url_host TEXT,
  activity_type TEXT,

  ocr_text TEXT,
  transcript_text TEXT,

  classification TEXT,
  classification_confidence REAL,
  meeting_flag INTEGER NOT NULL DEFAULT 0,
  social_flag INTEGER NOT NULL DEFAULT 0,

  duration_ms_estimate INTEGER,
  raw_json TEXT NOT NULL,

  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
```

Indexes:

```sql
CREATE INDEX IF NOT EXISTS idx_activity_time
  ON activity_records(timestamp_start_ms);

CREATE INDEX IF NOT EXISTS idx_activity_day_time
  ON activity_records(day_key, timestamp_start_ms);

CREATE INDEX IF NOT EXISTS idx_activity_app_time
  ON activity_records(app_name_norm, timestamp_start_ms);

CREATE INDEX IF NOT EXISTS idx_activity_host_time
  ON activity_records(url_host, timestamp_start_ms);

CREATE INDEX IF NOT EXISTS idx_activity_class_time
  ON activity_records(classification, timestamp_start_ms);

CREATE INDEX IF NOT EXISTS idx_activity_flags_time
  ON activity_records(social_flag, meeting_flag, timestamp_start_ms);
```

Notes:

- Store `raw_json` so current render/report code can keep receiving normalized record objects.
- Store extracted/indexed fields for fast grouping and filtering.
- `record_key` must match current JSONL dedupe behavior.

### `sync_windows`

Tracks local coverage of Screenpipe sync.

```sql
CREATE TABLE IF NOT EXISTS sync_windows (
  window_key TEXT PRIMARY KEY,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  start_ms INTEGER NOT NULL,
  end_ms INTEGER NOT NULL,
  fetched_count INTEGER NOT NULL DEFAULT 0,
  limit_value INTEGER NOT NULL DEFAULT 0,
  limit_hit INTEGER NOT NULL DEFAULT 0,
  complete INTEGER NOT NULL DEFAULT 0,
  fetch_failed INTEGER NOT NULL DEFAULT 0,
  depth INTEGER NOT NULL DEFAULT 0,
  purpose TEXT NOT NULL DEFAULT 'range',
  updated_at TEXT NOT NULL
);
```

Indexes:

```sql
CREATE INDEX IF NOT EXISTS idx_sync_time
  ON sync_windows(start_ms, end_ms);

CREATE INDEX IF NOT EXISTS idx_sync_complete_time
  ON sync_windows(complete, start_ms, end_ms);

CREATE INDEX IF NOT EXISTS idx_sync_purpose_time
  ON sync_windows(purpose, start_ms, end_ms);
```

### `migration_progress`

Tracks idempotent JSONL imports so large migrations can safely resume and unchanged files can be skipped.

```sql
CREATE TABLE IF NOT EXISTS migration_progress (
  file_key TEXT PRIMARY KEY,
  file_path TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  mtime_ms INTEGER NOT NULL,
  status TEXT NOT NULL,
  imported_count INTEGER NOT NULL DEFAULT 0,
  inserted_count INTEGER NOT NULL DEFAULT 0,
  deduped_count INTEGER NOT NULL DEFAULT 0,
  replaced_count INTEGER NOT NULL DEFAULT 0,
  malformed_count INTEGER NOT NULL DEFAULT 0,
  error_message TEXT,
  updated_at TEXT NOT NULL
);
```

Files with matching path, size, mtime, and `completed` status can be skipped on the next import run.

Important:

- Do not store tiny orb/pulse windows as durable sync coverage.
- Use `purpose` values:
  - `report`
  - `dashboard`
  - `backfill`
  - `delta`
  - `health`

### `daily_rollups`

Optional but recommended after base migration is stable.

```sql
CREATE TABLE IF NOT EXISTS daily_rollups (
  day_key TEXT PRIMARY KEY,
  active_minutes REAL NOT NULL DEFAULT 0,
  idle_minutes REAL NOT NULL DEFAULT 0,
  work_minutes REAL NOT NULL DEFAULT 0,
  meeting_minutes REAL NOT NULL DEFAULT 0,
  social_minutes REAL NOT NULL DEFAULT 0,
  other_minutes REAL NOT NULL DEFAULT 0,
  unclear_minutes REAL NOT NULL DEFAULT 0,
  focus_score_percent REAL NOT NULL DEFAULT 0,
  app_count INTEGER NOT NULL DEFAULT 0,
  site_count INTEGER NOT NULL DEFAULT 0,
  event_count INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);
```

This is phase two. Do not block the initial SQLite migration on rollups.

## Service Boundary

Keep the current interface so most of the app does not change.

Current methods to preserve:

```js
ingest(records)
queryRange(startTime, endTime)
recordSyncWindows(windows)
getSyncSummary(startTime, endTime)
deleteRange(startTime, endTime)
prune(cutoffMs)
```

Add optional methods:

```js
latestTimestamp()
getHealth()
hasCoverage(startTime, endTime)
missingWindows(startTime, endTime, options)
compactSyncWindows()
queryStats(startTime, endTime)
```

New file:

```text
src/services/modules/sqlite-activity-store-service.js
```

Initial wiring:

```js
const activityStoreService = new SqliteActivityStoreService(storagePath);
```

Keep JSONL service available as:

```text
src/services/modules/jsonl-activity-store-service.js
```

or leave existing `activity-store-service.js` as the fallback and introduce SQLite behind a feature flag first.

## Local-First Query Strategy

Change `ActivityQueryService.getRangeData()` from "Screenpipe first" to "local first plus bounded sync".

Recommended behavior:

1. Query SQLite for requested range.
2. Determine whether requested range is fully covered by complete sync windows.
3. If range is covered and not explicitly forced, return SQLite data.
4. If range is not covered:
   - For dashboards: sync only recent delta, not the whole day.
   - For reports: sync missing windows, then query SQLite.
   - For focus trend/nudges: use local data only in background.
5. Record durable sync windows only for meaningful report/backfill/delta ranges.

Suggested policy:

```text
dashboard:
  use local store
  sync last 3-5 minutes at most
  cache result 30 seconds

orb:
  no Screenpipe query
  use activityStore.latestTimestamp()

health:
  /health only by default
  /search auth check cached 60 seconds or forced from Health window

daily report:
  sync missing windows for selected range
  then report from SQLite

weekly focus:
  local-only in background
  explicit report can sync if needed

nudge:
  local-only
```

## Migration Strategy

### Phase 1: SQLite Store Beside JSONL

- Add SQLite dependency.
- Add schema bootstrap.
- Add `SqliteActivityStoreService`.
- Preserve current public method contract.
- Add tests for:
  - insert
  - dedupe
  - replace richer record
  - query range
  - sync windows
  - delete range
  - retention prune

No behavior change yet.

### Phase 2: Dual Write

- Keep JSONL as current source of truth.
- On `ingest`, write to JSONL and SQLite.
- Add startup migration from JSONL to SQLite.
- Add audit log:

```text
sqlite_migration_started
sqlite_migration_completed
sqlite_migration_failed
sqlite_dual_write_mismatch
```

Success condition:

- Unit tests pass.
- SQLite record count matches JSONL imported count within expected privacy/dedupe rules.

### Phase 3: SQLite Read Path

- Switch `queryRange`, `getSyncSummary`, and `latestTimestamp` reads to SQLite.
- Keep JSONL write fallback for one release.
- Add a setting or env flag:

```text
COGNIFY_ACTIVITY_STORE=jsonl|sqlite|dual
```

Default after validation:

```text
sqlite
```

### Phase 4: Local-First Screenpipe Sync

- Update `ActivityQueryService.getRangeData()` to avoid Screenpipe when SQLite coverage exists.
- Add `forceSync` and `purpose` options.
- Update callers:
  - Live Snapshot: dashboard purpose, no full-day forced sync.
  - Daily Report: report purpose, sync missing windows.
  - Nudge/focus trend: local-only background.
  - Orb pulse: latest local timestamp.

### Phase 5: Sync Window Compaction

Compact overlapping complete sync windows.

Example:

- Many 2-minute windows inside a complete 1-hour window should collapse into the 1-hour window.
- Do not keep dashboard/pulse windows forever.

Suggested retention:

```text
health windows: do not store
dashboard delta windows: keep 24 hours
report/backfill windows: keep under normal retention policy
```

### Phase 6: Remove JSONL Dependency

Only after at least one stable update:

- Stop writing JSONL by default.
- Keep import support.
- Keep retention cleanup for legacy files.
- Provide "repair/rebuild SQLite from JSONL" developer action if JSONL exists.

## Performance Targets

After SQLite and local-first sync:

- Screenpipe API usage should drop below 60 requests per 5 minutes during idle dashboard use.
- Orb should add 0 Screenpipe requests.
- Snapshot refresh should usually add 0 Screenpipe requests, except recent delta sync.
- Daily Report should sync only missing windows.
- Today dashboard refresh should complete under 500ms from local DB after warm-up.
- Focus trend local calculation should complete under 1s for 7 days after warm-up.

## Risk Controls

### Data Correctness

Risk:

- Local-first may miss recent Screenpipe records.

Control:

- Always sync a small recent delta for user-visible reports.
- Show `sync.complete` and `last_synced_at` internally.
- Manual Refresh can force sync.

### Packaging

Risk:

- SQLite native dependency may fail in portable/Electron bundle.

Control:

- Verify portable build before enabling SQLite default.
- Run `npm run check:sqlite-electron` after install/rebuild.
- Run `npm run rebuild:sqlite:electron` after dependency restore if Electron cannot load the binding.
- Run `npm run rebuild:sqlite` before Node-only tests if the binding was last rebuilt for Electron.
- Keep JSONL fallback.
- Add startup health field for SQLite availability.

### DB Corruption

Risk:

- Local DB may corrupt on crash.

Control:

- Enable WAL mode.
- Use transactions for ingest.
- Keep JSONL import fallback during rollout.
- Backup before destructive migration is not needed if JSONL remains.

Recommended SQLite pragmas:

```sql
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;
PRAGMA temp_store = MEMORY;
```

### Privacy

Risk:

- SQLite stores OCR/transcript text in a single DB.

Control:

- Apply privacy filter before ingest, same as current store.
- Retention must delete rows by timestamp.
- Delete range must delete DB rows.
- Future note/password locking must stay separate from activity DB.

### Report Accuracy

Risk:

- Reports may use stale local data.

Control:

- Daily Report calls `getRangeData(..., { purpose: 'report', forceSyncMissing: true })`.
- If sync fails, report should clearly state partial data.

## Test Plan

Unit tests:

- SQLite schema initializes.
- Ingest inserts records.
- Duplicate ingest dedupes.
- Richer duplicate replaces poorer record.
- Query range returns sorted normalized records.
- Query excludes out-of-range rows.
- Sync windows are saved and summarized.
- Delete range removes rows and sync windows.
- Prune removes old rows/windows.
- JSONL import handles malformed lines safely.

Integration tests:

- ActivityQueryService local-first skips adapter when coverage exists.
- ActivityQueryService syncs missing recent delta.
- Daily Report forces missing sync.
- Nudge/focus trend does not call adapter in background mode.

Manual tests:

- Start Cognify fresh.
- Confirm DB file appears.
- Run Daily Summary.
- Run Daily Report.
- Visit X/LinkedIn and confirm Social classification still appears.
- Check Screenpipe `api_usage_5min` falls.
- Restart app and confirm data persists.
- Run retention cleanup and verify DB row deletion.

## Implementation Order

1. Add SQLite dependency and validate packaging locally.
2. Add SQLite service with same public contract as current store.
3. Add migration/import from JSONL.
4. Add tests for SQLite service.
5. Add feature flag and dual-write mode.
6. Switch local reads to SQLite.
7. Implement local-first sync policy.
8. Remove orb Screenpipe polling.
9. Split health `/health` from `/search` auth verification.
10. Add sync-window compaction.
11. Validate Screenpipe API request reduction.
12. Bundle only after local validation.

## Open Decisions

- Use `better-sqlite3` or `sqlite3` after packaging test.
- Keep `raw_json` compressed or plain text. Start with plain text.
- Whether to store classification at ingest time or calculate lazily. Start with lazy classification; add cached classification later.
- Whether to keep daily rollups in phase one. Recommendation: no, add in phase two.
- How long to keep JSONL fallback. Recommendation: at least one stable release cycle.

## First Code Change Recommendation

Do not start with a full migration.

Start with:

1. Add SQLite service and tests.
2. Add JSONL import into SQLite.
3. Keep behavior unchanged.

Then switch one read path:

```text
orb latest timestamp -> SQLite/local store
```

After that, switch dashboard/report paths.
