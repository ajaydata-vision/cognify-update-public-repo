# Cognify Setup Release Progress - 2026-05-07

## Current State

- Version bumped to `1.1.18`.
- Final setup artifact built:
  - `portable-dist/Cognify-Setup-v1.1.18.zip`
- Final setup smoke test passed:
  - Extracted setup zip into a temporary folder.
  - Installed into `I:\tmp\CognifyInstallDryRun`.
  - Used `-NoLaunch -NoAutoStart -NoStartMenuShortcut -NoDesktopShortcut`.
  - Verified installed `Cognify.exe`, `app/VERSION`, task extraction config, and Cognify brand/report assets.
  - Cleaned temporary smoke folders.
- Follow-up setup smoke test passed after profile-isolation fix:
  - Rebuilt `portable-dist/Cognify-Setup-v1.1.18.zip`.
  - Installed into `I:\tmp\cginst118`.
  - Used `-NoLaunch -NoAutoStart -NoStartMenuShortcut -NoDesktopShortcut`.
  - Verified installed app includes per-user Screenpipe `--data-dir` and generated base URL defaults.
  - Cleaned temporary smoke folders.
- Adversarial follow-up smoke test passed:
  - Rebuilt `portable-dist/Cognify-Setup-v1.1.18.zip`.
  - Installed into `I:\tmp\cginst118adv`.
  - Used `-NoLaunch -NoAutoStart -NoStartMenuShortcut -NoDesktopShortcut`.
  - Verified installed app includes current-user Screenpipe process checks, free-port selection, and runtime adapter setting refresh.
  - Cleaned temporary smoke folders.
- Second adversarial flow smoke test passed:
  - Rebuilt `portable-dist/Cognify-Setup-v1.1.18.zip`.
  - Installed into `I:\tmp\cginst118flow2`.
  - Used `-NoLaunch -NoAutoStart -NoStartMenuShortcut -NoDesktopShortcut`.
  - Verified installed app includes loopback-only Screenpipe settings, narrowed process matching, and the PowerShell uninstaller.
  - Ran the installed uninstaller and verified it removed the install directory.
  - Cleaned temporary smoke folders.

## Verification Completed

- `npm run lint` passed.
- `npm test` passed.
- `npm run dist:setup` passed.
- Installer smoke install passed for version `1.1.18`.
- `npm run lint` and `npm test` passed again after profile-isolation changes.
- Rebuilt setup artifact and smoke-tested the rebuilt artifact.
- Re-ran `npm run lint`, `npm test`, `npm run dist:setup`, and setup smoke after adversarial profile-isolation hardening.
- Re-ran `npm run lint`, `npm test`, `npm run dist:setup`, and setup install/uninstall smoke after the second adversarial review.

## Main Changes Made

- Added setup packaging flow through `scripts/make-setup.ps1`.
- Added `dist:setup` npm script.
- Added setup installer contents:
  - `Setup-Cognify.ps1`
  - `Install-Cognify.cmd`
  - setup README
- Installer defaults:
  - Installs under `%LOCALAPPDATA%\Programs\Cognify`.
  - Creates Start Menu and Desktop shortcuts.
  - Configures Windows startup.
  - Launches Cognify after install.
- Installer advanced switches:
  - `-InstallDir`
  - `-NoAutoStart`
  - `-NoLaunch`
  - `-NoStartMenuShortcut`
  - `-NoDesktopShortcut`
- Included `config/` in portable and code-update bundles.
- Added editable task extraction rules at `config/task-extraction-rules.json`.
- Added Cognify setup/onboarding wizard:
  - Welcome screen with Cognify logo.
  - Profile, role, context, and finish steps.
  - Exit option.
  - No skip path through setup.
  - Finish keeps only the Cognify orb visible and shows a small setup-complete nudge.
- Added startup enablement on onboarding completion.
- Added setup prefill support through `COGNIFY_SETUP_PREFILL_PATH` for testing only.
- Added per-Windows-user Screenpipe endpoint defaults:
  - Settings now derive a stable local port and API key from Electron `userData`.
  - Legacy `http://127.0.0.1:3030` / `http://localhost:3030` defaults migrate to the per-user endpoint.
  - Screenpipe starts with a per-user `--data-dir` under Electron `userData`.
  - Screenpipe restarts only stop matching current-user Screenpipe processes instead of killing every `screenpipe.exe`.
  - Startup now refuses to trust a reachable Screenpipe endpoint unless it belongs to the current user, uses Cognify's per-user data directory, and matches the configured port.
  - If the configured local port is already occupied by another process/profile, Cognify moves to another free local port before launching Screenpipe.
  - Runtime diagnostics now report the current user's Cognify-managed Screenpipe process rather than any machine-wide `screenpipe.exe`.
  - Screenpipe settings now reject non-loopback base URLs so runtime capture cannot silently point at another host.
  - Restart/memory matching now requires current user, Cognify's per-user data directory, and the configured port.
  - Legacy 3030 cleanup is limited to Cognify's bundled Screenpipe executable.
  - Uninstall now includes a PowerShell cleanup step for the current user's Cognify-owned Screenpipe process.
  - Existing users keep their current per-user Screenpipe raw store at `%USERPROFILE%\.screenpipe`; new users without that store use Cognify's `userData\screenpipe-data`.
- Added Cognify brand assets under `src/renderer/assets/`.
- Reworked report window toolbar and on-screen report branding.
- Removed report DOC/PDF export UI for now.
- Improved task extraction confidence/evidence reporting using configurable rules.

## Additional Hardening on 2026-05-07

- Gated first-launch UI surfaces behind onboarding:
  - Widget starts hidden until onboarding is complete.
  - Snapshot, report, health, notes, and nudge windows refuse to show before onboarding.
  - Onboarding panel remains the only first-launch surface.
- Replaced startup `.cmd` entry with a per-user `Cognify.lnk` startup shortcut so Windows shows the Cognify icon/name instead of a generic command file.
- Added per-user Windows app registration under `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\Cognify` so Cognify can appear in Windows Installed apps with display icon and uninstall command.
- Removed bundled `dotnet-runtime\` from the setup/portable payload.
- Moved .NET 8 requirement handling to setup:
  - Setup checks for .NET 8 runtime and ASP.NET Core runtime before launch.
  - If missing, setup tries WinGet first, then Microsoft's `dotnet-install.ps1` into `%LOCALAPPDATA%\Cognify\dotnet`.
  - Portable launcher keeps the same fallback for manually copied portable folders.
- Latest setup artifact rebuilt at `portable-dist\Cognify-Setup-v1.1.18.zip`.
- Verification:
  - `npm run lint` passed.
  - `npm test` passed.
  - `npm run dist:setup` passed.
  - Setup smoke install/uninstall passed with `-NoAutoStart -NoLaunch -NoDesktopShortcut`.
  - Verified rebuilt setup zip does not contain `dotnet-runtime`.
- Reduced setup package size:
  - Removed duplicate `app\node_modules\electron` from portable payload; root `Cognify.exe` supplies Electron runtime.
  - Removed duplicate root `ffmpeg\` and `app\node_modules\ffmpeg-static`; Screenpipe's packaged `ffmpeg.exe` is used instead.
  - Removed non-Windows-x64 ONNX runtime payloads from the portable package.
  - Removed stale Screenpipe ONNX backup DLL from the package.
  - Rebuilt `portable-dist\Cognify-Setup-v1.1.18.zip` at `279,206,998` bytes.
  - Verified pruned setup still contains Screenpipe `ffmpeg.exe`, `ffprobe.exe`, and ONNX `win32\x64`.
- Follow-up adversarial review fixes:
  - .NET prerequisite detection now requires `Microsoft.WindowsDesktop.App 8.x` plus `Microsoft.AspNetCore.App 8.x`; the previous check could pass without Desktop runtime.
  - WinGet fallback now includes `Microsoft.DotNet.DesktopRuntime.8`.
  - Setup checks/install .NET before moving an existing Cognify install aside.
  - Existing install replacement now restores the backup if copying the new payload fails.
  - Rebuilt `portable-dist\Cognify-Setup-v1.1.18.zip` at `279,207,336` bytes.
- CPU/memory and weekly-report adversarial review fixes:
  - Fixed `My Weekly Report` crash when weekly self-input is missing/null.
  - Added regression coverage for missing weekly self-input.
  - Snapshot refresh now skips while hidden and refreshes every 2 minutes instead of every 45 seconds.
  - Orb status/capture pulse polling reduced from 15/30 seconds to 60/120 seconds.
  - Panel idle/runtime background polling reduced from 30/60 seconds to 120/300 seconds.
  - Startup now stops stale same-user Cognify/companion-agent Screenpipe processes that do not match the current configured data-dir and port.
  - Rebuilt `portable-dist\Cognify-Setup-v1.1.18.zip` at `279,207,762` bytes.
- Report usefulness adversarial review fixes:
  - `My Weekly Report` now includes a `Role And Context Used` section with the confirmed role, role notes, and an explicit evidence boundary.
  - HOD appraisal drafts now include a role-fit note so appraisal wording is clearly positioned as a reviewer aid, not equally appropriate for every profile.
  - Daily report UI now shows a role/context interpretation note and warns that executive/manager switching or low focus score needs outcome/offline context before judgment.
  - Task report copy no longer claims role evidence is used by extraction when the extractor only uses screen, transcript, context, and repeated evidence.
  - Rebuilt `portable-dist\Cognify-Setup-v1.1.18.zip` at `279,209,460` bytes.
- Report hang/deep performance review fixes:
  - Confirmed from logs that some Daily Report actions spent 27-39 seconds in the panel even when main-process `dailyReportCached` was much faster, pointing to renderer formatting and report-window payload cloning.
  - Daily Report is now limited to one day in both renderer and main process; multi-day review should use Timeline or My Weekly Report.
  - Report actions now run one at a time from the panel, with a visible still-generating message after 10 seconds.
  - Report window payloads are compacted so Daily Report no longer clones the full cached summary/app timeline into the second window; only the compact payroll payload is sent.
  - Payroll payload rows, task lists, focus trend, and summary are capped/compacted to avoid oversized IPC/API payloads.
  - Daily report row splitting is memoized so rendering and payroll payload construction do not repeat the same expensive grouping work.
  - Timeline rendering is capped to 300 rows with a visible note to narrow the range for more detail.
  - System Process debug logs render lazily only when opened and are capped/truncated to avoid hidden modal DOM work during report generation.
  - Added `daily_report_data_ready` and `daily_report_render_ready` debug events to separate data build time from renderer/payload time in future logs.
  - Rebuilt `portable-dist\Cognify-Setup-v1.1.18.zip` at `279,211,444` bytes.
- Snapshot/Search API health follow-up:
  - Split cheap runtime health from Screenpipe search-readiness checks.
  - Passive diagnostics now use `/health` and process ownership only; they no longer block on `/search?limit=1`.
  - Search readiness probes are bounded to the last 15 minutes, cached for 5 minutes, and use a 1.5s timeout when explicitly requested.
  - `Search API not verified` is now informational instead of making the snapshot card show `Needs attention`.
  - Screenpipe restart logic no longer restarts capture just because search verification was deferred; only a confirmed search failure can influence restart.
- Adversarial performance/race follow-up:
  - Coalesced concurrent explicit Search API probes so manual health checks cannot stack `/search` calls.
  - Made report-cache background/current-hour paths truly skip task extraction when `includeTasks: false`.
  - Removed duplicate per-hour task extraction in daily report cache builds by passing the already-built task list into `DailySummaryService`.
  - Serialized same-day report cache builds to avoid warmer/user-report races overwriting the same cache JSON file.
  - Added unit coverage for deferred search probes, task-skip behavior, duplicate extraction prevention, and same-day cache serialization.
- Startup/branding follow-up:
  - Portable `Cognify.bat` now launches `Cognify.exe` directly instead of routing normal startup through hidden PowerShell.
  - Startup creates the orb/tray first and lazy-creates panel, snapshot, health, and notes windows only when opened.
  - Retention, SQLite import, Screenpipe supervision, nudge/memory monitors, report cache warming, and silent updates start after the orb is ready.
  - Added generated Cognify Windows icon assets and wired the icon into Electron windows, tray, startup shortcut, user task, setup shortcuts, and app registration.

## Dirty Worktree At Handoff

Modified:

- `VERSION`
- `package-lock.json`
- `package.json`
- `scripts/make-code-update-bundle.ps1`
- `scripts/make-portable.ps1`
- `src/main.js`
- `src/preload.js`
- `src/renderer/panel.html`
- `src/renderer/panel.js`
- `src/renderer/report.html`
- `src/renderer/report.js`
- `src/services/modules/settings-service.js`
- `src/services/modules/task-extraction-service.js`

Untracked:

- `config/task-extraction-rules.json`
- `scripts/make-setup.ps1`
- `src/renderer/assets/`
- `docs/progress-2026-05-07-setup-release.md`

## Next Suggested Steps

1. Review the dirty diff once more before committing.
2. Commit setup/onboarding/report/task-extraction changes.
3. Push to git.
4. Optionally run the final setup on a clean Windows user profile or VM before external distribution.
5. Decide whether to publish `portable-dist/Cognify-Setup-v1.1.18.zip` as the release artifact.
