const BROWSER_APP_PATTERN = /chrome|msedge|edge|firefox|brave|opera|browser/i;
const { meaningfulWindowTitle } = require('./window-title-normalizer');

const ROLE_PROFILES = [
  {
    id: 'developer',
    label: 'Developer / Engineering',
    app: /code|visual studio|terminal|powershell|cmd|git|node|python|postman|docker/i,
    text: /github|gitlab|bitbucket|api|localhost|stack overflow|jira|bug|commit|pull request|repository/i
  },
  {
    id: 'finance',
    label: 'Finance / Accounts',
    app: /excel|tally|busy|sap|account|payroll/i,
    text: /invoice|ledger|payroll|salary|bank|gst|tds|vendor|payment|statement|balance/i
  },
  {
    id: 'admin-operations',
    label: 'Admin / Operations',
    app: /excel|word|chrome|edge|xgen|portal|teams|outlook/i,
    text: /admin|portal|approval|dispatch|order|process|operation|workflow|status|data entry|team portal|hodapproval/i
  },
  {
    id: 'hr',
    label: 'HR',
    app: /excel|word|chrome|edge/i,
    text: /hr|employee|attendance|leave|appraisal|performance|policy|joining|salary|recruit|interview|onboarding/i
  },
  {
    id: 'customer-support',
    label: 'Customer Support / CS',
    app: /anydesk|teamviewer|remote desktop|mstsc|xgen|whatsapp|teams|slack|chrome|edge/i,
    text: /ticket|support|customer|issue|complaint|remote|resolve|helpdesk|chat|xgen im/i
  },
  {
    id: 'sales',
    label: 'Sales',
    app: /crm|excel|powerpoint|chrome|edge|outlook|whatsapp/i,
    text: /crm|lead|prospect|proposal|quotation|customer|deal|follow.?up|sales|pipeline|meeting/i
  },
  {
    id: 'marketing',
    label: 'Marketing',
    app: /analytics|ads|canva|figma|photoshop|powerpoint|excel|chrome|edge|wordpress|mailchimp/i,
    text: /campaign|marketing|seo|analytics|brand|content|landing page|newsletter|adwords|google ads|meta ads|keyword/i
  },
  {
    id: 'legal',
    label: 'Legal / Compliance',
    app: /word|excel|pdf|adobe|chrome|edge|outlook/i,
    text: /legal|compliance|contract|agreement|clause|policy|notice|case|court|audit|nda|terms|regulation/i
  },
  {
    id: 'business-analyst',
    label: 'Business Analyst',
    app: /excel|word|powerpoint|visio|figma|jira|chrome|edge|teams|outlook/i,
    text: /requirement|brd|frd|user story|workflow|process map|stakeholder|analysis|dashboard|specification|acceptance criteria/i
  },
  {
    id: 'designer',
    label: 'Designer / Creative',
    app: /figma|photoshop|illustrator|canva|xd|sketch|after effects|premiere|blender/i,
    text: /design|prototype|wireframe|mockup|creative|brand|asset|layout|ui|ux|banner|logo|visual/i
  },
  {
    id: 'social-media',
    label: 'Social Media',
    app: /instagram|facebook|meta|twitter|\bx\b|linkedin|youtube|canva|buffer|hootsuite|chrome|edge/i,
    text: /social media|instagram|facebook|linkedin|youtube|\bx\b|post|reel|engagement|caption|hashtag|content calendar|publish/i
  },
  {
    id: 'manager-hod',
    label: 'Manager / HOD',
    app: /teams|zoom|meet|excel|powerpoint|chrome|edge|outlook/i,
    text: /approval|review|dashboard|meeting|team|performance|appraisal|hod|report|status|delegate/i
  },
  {
    id: 'c-level-executive',
    label: 'C-Level / Executive',
    app: /teams|zoom|meet|excel|powerpoint|chrome|edge|outlook|slack/i,
    text: /ceo|cto|cfo|coo|cmo|chro|ciso|cpo|chief executive|chief technology|chief financial|chief operating|chief marketing|chief human|chief information|board|strategy|okr|kpi|investor|budget|revenue|forecast|leadership|executive review|business review/i
  }
];

function classifyRoleFromRecords(records = [], options = {}) {
  const nowMs = Number(options.nowMs || Date.now());
  const minRecords = Number(options.minRecords || 60);
  const scoredRecords = records
    .filter((record) => record?.timestamp_start || record?.timestamp)
    .map((record) => ({
      ...record,
      timeMs: new Date(record.timestamp_start || record.timestamp).getTime()
    }))
    .filter((record) => Number.isFinite(record.timeMs))
    .sort((left, right) => left.timeMs - right.timeMs);

  const enoughData = scoredRecords.length >= minRecords;
  const roleScores = new Map(ROLE_PROFILES.map((role) => [role.id, {
    id: role.id,
    label: role.label,
    score: 0,
    evidence: new Map()
  }]));

  let browserRecords = 0;
  let surfaceSwitches = 0;
  let lastSurface = '';

  scoredRecords.forEach((record) => {
    const app = String(record.app_name || '').trim();
    const host = normalizeHost(record.url_host || hostFromUrl(record.url_if_available));
    const title = meaningfulWindowTitle(record);
    const text = `${app} ${host} ${title} ${record.ocr_text || ''}`.toLowerCase();
    const surface = host && BROWSER_APP_PATTERN.test(app) ? `web:${host}` : `app:${app.toLowerCase()}`;
    if (surface && lastSurface && surface !== lastSurface) {
      surfaceSwitches += 1;
    }
    lastSurface = surface || lastSurface;
    if (host && BROWSER_APP_PATTERN.test(app)) {
      browserRecords += 1;
    }

    ROLE_PROFILES.forEach((role) => {
      let delta = 0;
      const evidence = [];
      if (role.app.test(app)) {
        delta += 2;
        evidence.push(app.replace(/\.exe$/i, ''));
      }
      if (role.text.test(text)) {
        delta += 3;
        evidence.push(host || title || app);
      }
      if (delta > 0) {
        const score = roleScores.get(role.id);
        score.score += delta;
        evidence.filter(Boolean).slice(0, 2).forEach((item) => {
          const key = String(item).slice(0, 60);
          score.evidence.set(key, (score.evidence.get(key) || 0) + 1);
        });
      }
    });
  });

  if (surfaceSwitches >= 40) {
    addScore(roleScores, 'customer-support', 10, 'frequent work context changes');
    addScore(roleScores, 'admin-operations', 8, 'frequent work context changes');
    addScore(roleScores, 'manager-hod', 6, 'frequent work context changes');
    addScore(roleScores, 'c-level-executive', 4, 'frequent executive context changes');
  }
  if (browserRecords / Math.max(1, scoredRecords.length) > 0.65) {
    addScore(roleScores, 'admin-operations', 6, 'browser portal heavy work');
    addScore(roleScores, 'hr', 5, 'browser portal heavy work');
  }
  const executiveSignalCount = scoredRecords.filter((record) => {
    const text = `${record.app_name || ''} ${record.url_host || hostFromUrl(record.url_if_available)} ${meaningfulWindowTitle(record)} ${record.ocr_text || ''}`.toLowerCase();
    return /\b(ceo|cto|cfo|coo|cmo|chro|ciso|cpo|chief|board|strategy|okr|kpi|investor|revenue forecast|executive review|business review)\b/i.test(text);
  }).length;
  if (executiveSignalCount >= Math.max(8, scoredRecords.length * 0.18)) {
    addScore(roleScores, 'c-level-executive', 24, 'executive strategy signals');
  }

  const ranked = Array.from(roleScores.values())
    .map((role) => ({
      ...role,
      evidence: Array.from(role.evidence.entries())
        .sort((left, right) => right[1] - left[1])
        .slice(0, 5)
        .map(([label, count]) => ({ label, count }))
    }))
    .sort((left, right) => right.score - left.score);
  const top = ranked[0] || { id: 'unknown', label: 'Unknown', score: 0, evidence: [] };
  const runnerUp = ranked[1] || { score: 0 };
  const totalScore = ranked.reduce((sum, role) => sum + role.score, 0);
  const share = totalScore ? top.score / totalScore : 0;
  const separation = top.score ? Math.max(0, (top.score - runnerUp.score) / top.score) : 0;
  const dataFactor = Math.min(1, scoredRecords.length / minRecords);
  const confidence = Math.round(Math.min(98, Math.max(0, ((share * 70) + (separation * 30)) * dataFactor)));

  return {
    detected_at: new Date(nowMs).toISOString(),
    role_id: top.id,
    role_label: top.label,
    confidence,
    enough_data: enoughData,
    record_count: scoredRecords.length,
    surface_switches: surfaceSwitches,
    evidence: top.evidence,
    candidates: ranked.slice(0, 4).map((role) => ({
      role_id: role.id,
      role_label: role.label,
      score: role.score
    }))
  };
}

function confirmedRoleConfidence(classification, confirmedRoleId) {
  if (!classification || !confirmedRoleId) {
    return 0;
  }
  if (classification.role_id === confirmedRoleId) {
    return classification.confidence;
  }
  const candidate = (classification.candidates || []).find((item) => item.role_id === confirmedRoleId);
  if (!candidate) {
    return 0;
  }
  const total = (classification.candidates || []).reduce((sum, item) => sum + item.score, 0);
  return Math.round((candidate.score / Math.max(1, total)) * 100);
}

function addScore(roleScores, roleId, points, evidenceLabel) {
  const score = roleScores.get(roleId);
  if (!score) {
    return;
  }
  score.score += points;
  score.evidence.set(evidenceLabel, (score.evidence.get(evidenceLabel) || 0) + 1);
}

function hostFromUrl(value = '') {
  if (!value) {
    return '';
  }
  try {
    return new URL(value).hostname;
  } catch {
    return '';
  }
}

function normalizeHost(value = '') {
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/^www\./, '');
}

module.exports = {
  ROLE_PROFILES,
  classifyRoleFromRecords,
  confirmedRoleConfidence
};
