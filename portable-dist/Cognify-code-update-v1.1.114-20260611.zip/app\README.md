# Cognify

Windows desktop work-intelligence assistant built on top of [Screenpipe](https://screenpi.pe).
Internal company tool — installed on each PC via the setup bundle; updates are delivered
automatically through the public update repo (see `AGENTS.md` for the rules on that repo).

Current version: see `VERSION` (must always match `package.json` — enforced by the unit tests).

## What it does

- Floating always-on-top orb with recording status, snapshot panel, and full dashboard
- Activity capture via Screenpipe (OCR + audio), classified into work/meeting/social/other
  using the rules in `docs/WORKRULES.md` and `config/`
- Daily/hourly work-summary reports, work-hours ledger, manual time blocks, idle tracking
- Productivity nudges, notes, health/diagnostics panels
- Morning daily-log digest shipped to the payroll backend (configurable in settings)
- Privacy filters (excluded apps/domains, redaction), pause/resume, delete-range
- Audit logging of assistant suggestions/actions, local SQLite storage with retention

## Prerequisites

- Windows 10/11
- Node.js 20+
- Screenpipe — bundled via the `screenpipe` npm package (the app manages the daemon itself);
  verify with `curl http://127.0.0.1:3030/health` once the app is running
- .NET Framework 4.5+ (Windows focus helper; compile with
  `src/helpers/compile-windows-focus-helper.ps1` if `windows-focus-helper.exe` is missing)
- Optional: SQL Server + IIS only if you deploy the receiving API in `daily-report-api-net45/`

## Develop

```bash
npm install --script-shell "<path-to-git>\bin\bash.exe"   # screenpipe's postinstall needs a POSIX shell on Windows
npm run rebuild:sqlite:electron   # rebuild better-sqlite3 for the Electron ABI (uses prebuilds; no VS toolchain needed)
npm start
```

## Verify

```bash
npm run lint   # syntax check of all entry points and service modules
npm test       # unit tests + SQLite-in-Electron check + smoke test
```

## Build & release

| Command | Purpose |
|---|---|
| `npm run dist:portable` | Portable bundle in `portable-dist/` |
| `npm run dist:setup` / `dist:setup:exe` | Installer |
| `npm run dist:update` / `dist:update:app` / `dist:update:code` | Update bundles |
| `npm run release:update` | Publish an update to the public update repo |

Bump `VERSION` **and** `package.json` together before releasing.

## Docs

- Architecture and plan: `docs/ARCHITECTURE_AND_PLAN.md`
- Performance rules (binding for all timers/IPC/report paths): `docs/PERFORMANCE_CONTRACT.md`
- Work classification policy: `docs/WORKRULES.md`
- SQLite activity-store migration: `docs/SQLITE_ACTIVITY_STORE_PLAN.md`
- Code navigation for AI agents: `Project-Code-Graph/AGENT_GUIDE.md` (regenerate with `python claude_index.py`)
