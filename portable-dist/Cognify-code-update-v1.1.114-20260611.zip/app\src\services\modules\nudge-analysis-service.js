const BROWSER_APP_PATTERN = /chrome|msedge|edge|firefox|brave|opera|browser/i;
const MIN_CONTEXT_SURFACE_MS = 60 * 1000;
const DEFAULT_WINDOW_MS = 15 * 60 * 1000;

function contextSwitchAnalysis(records = [], options = {}) {
  const nowMs = Number(options.nowMs || Date.now());
  const windowMs = Number(options.windowMs || DEFAULT_WINDOW_MS);
  const startMs = Number(options.startMs || (nowMs - windowMs));
  const endMs = Number(options.endMs || nowMs);
  const minSurfaceMs = Number(options.minSurfaceMs || MIN_CONTEXT_SURFACE_MS);

  const sorted = records
    .filter((record) => record?.timestamp_start && !/system process/i.test(record.app_name || ''))
    .map((record) => ({
      ...record,
      startMs: new Date(record.timestamp_start).getTime()
    }))
    .filter((record) => Number.isFinite(record.startMs) && record.startMs >= startMs && record.startMs <= endMs)
    .sort((left, right) => left.startMs - right.startMs);

  const rawSegments = [];
  sorted.forEach((record, index) => {
    const surface = meaningfulSurfaceKey(record);
    if (!surface) {
      return;
    }

    const nextRecord = sorted[index + 1];
    const segmentEndMs = Math.min(
      endMs,
      Number.isFinite(nextRecord?.startMs) ? nextRecord.startMs : endMs
    );
    const segmentStartMs = Math.max(startMs, record.startMs);
    if (segmentEndMs <= segmentStartMs) {
      return;
    }

    const previous = rawSegments[rawSegments.length - 1];
    if (previous && previous.key === surface.key) {
      previous.endMs = Math.max(previous.endMs, segmentEndMs);
      previous.durationMs = previous.endMs - previous.startMs;
      return;
    }

    rawSegments.push({
      key: surface.key,
      label: surface.label,
      startMs: segmentStartMs,
      endMs: segmentEndMs,
      durationMs: segmentEndMs - segmentStartMs
    });
  });

  const meaningfulSegments = rawSegments.filter((segment) => segment.durationMs >= minSurfaceMs);
  const uniqueSurfaces = new Set(meaningfulSegments.map((segment) => segment.key));
  const switches = Math.max(0, meaningfulSegments.length - 1);

  return {
    window_minutes: Math.round((endMs - startMs) / 60000),
    min_surface_seconds: Math.round(minSurfaceMs / 1000),
    record_count: sorted.length,
    raw_segment_count: rawSegments.length,
    meaningful_segment_count: meaningfulSegments.length,
    unique_surface_count: uniqueSurfaces.size,
    switches,
    segments: meaningfulSegments
  };
}

function contextSwitchNudgeFromRecords(records = [], options = {}) {
  const analysis = contextSwitchAnalysis(records, options);
  const enoughSurfaces = analysis.unique_surface_count >= 4;
  const enoughSwitches = analysis.switches >= 8;
  const heavySwitching = analysis.unique_surface_count >= 5 && analysis.switches >= 6;

  if ((!enoughSwitches && !heavySwitching) || !enoughSurfaces || analysis.record_count < 12) {
    return null;
  }

  return {
    type: 'context-switching',
    severity: analysis.switches >= 12 ? 'warning' : 'attention',
    title: 'Context switching',
    message: 'Too much context switching detected.',
    footer: `${analysis.switches} meaningful switches in ${analysis.window_minutes} minutes`,
    metric: String(analysis.switches),
    target: 'reports',
    analysis
  };
}

function meaningfulSurfaceKey(record = {}) {
  const appName = String(record.app_name || 'Unknown').trim();
  const normalizedApp = normalizeToken(appName.replace(/\.exe$/i, ''));
  if (!normalizedApp || normalizedApp === 'unknown') {
    return null;
  }

  const host = normalizeHost(record.url_host || hostFromUrl(record.url_if_available));
  if (host && BROWSER_APP_PATTERN.test(appName)) {
    return {
      key: `web:${registrableHost(host)}`,
      label: registrableHost(host)
    };
  }

  return {
    key: `app:${normalizedApp}`,
    label: appName.replace(/\.exe$/i, '')
  };
}

function hostFromUrl(value = '') {
  if (!value) {
    return '';
  }
  try {
    return new URL(value).hostname;
  } catch {
    return '';
  }
}

function normalizeHost(value = '') {
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/^www\./, '');
}

function registrableHost(host = '') {
  const normalized = normalizeHost(host);
  const parts = normalized.split('.').filter(Boolean);
  if (parts.length <= 2) {
    return normalized;
  }
  return parts.slice(-2).join('.');
}

function normalizeToken(value = '') {
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}

module.exports = {
  contextSwitchAnalysis,
  contextSwitchNudgeFromRecords,
  meaningfulSurfaceKey
};
