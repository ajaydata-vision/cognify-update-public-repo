const title = document.getElementById('title');
const metric = document.getElementById('metric');
const message = document.getElementById('message');
const footer = document.getElementById('footer');
const closeButton = document.getElementById('close');
const openTarget = document.getElementById('openTarget');
const manualForm = document.getElementById('manualForm');
const manualTitle = document.getElementById('manualTitle');
const manualMetric = document.getElementById('manualMetric');
const manualSlot = document.getElementById('manualSlot');
const manualKindRow = document.getElementById('manualKindRow');
const manualNoteInline = document.getElementById('manualNoteInline');
const manualSaveInline = document.getElementById('manualSaveInline');
const manualKeepIdleInline = document.getElementById('manualKeepIdleInline');
const manualStatusInline = document.getElementById('manualStatusInline');

let currentNudge = null;
let selectedManualKind = 'work';

function isManualInlineNudge(nudge = {}) {
  return nudge.type === 'idle-return'
    && nudge.manual_block?.startTime
    && nudge.manual_block?.endTime;
}

function formatClock(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) {
    return '';
  }
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function formatManualSlot(block = {}) {
  const start = formatClock(block.startTime);
  const end = formatClock(block.endTime);
  if (!start || !end) {
    return '--';
  }
  return `${start} - ${end}`;
}

function setManualStatus(message = '', tone = '') {
  manualStatusInline.textContent = message;
  manualStatusInline.dataset.tone = tone;
}

function setManualBusy(isBusy) {
  manualSaveInline.disabled = isBusy;
  manualKeepIdleInline.disabled = isBusy;
  manualKindRow.querySelectorAll('button').forEach((button) => {
    button.disabled = isBusy;
  });
  manualNoteInline.disabled = isBusy;
}

function selectManualKind(kind = 'work') {
  selectedManualKind = kind === 'meeting' ? 'meeting' : 'work';
  manualKindRow.querySelectorAll('button').forEach((button) => {
    button.classList.toggle('selected', button.dataset.kind === selectedManualKind);
  });
}

function applyNudge(payload = {}) {
  const nudge = payload.nudge || {};
  const manualInline = isManualInlineNudge(nudge);
  currentNudge = nudge;
  document.body.classList.remove('insight', 'attention', 'warning', 'pointer-left', 'pointer-right');
  document.body.classList.add(nudge.severity || 'attention');
  document.body.classList.add(payload.side === 'right' ? 'pointer-left' : 'pointer-right');
  document.body.classList.toggle('manual-inline', manualInline);
  title.textContent = nudge.title || 'Cognify Nudge';
  metric.textContent = nudge.metric || '';
  metric.style.display = nudge.metric ? 'inline-flex' : 'none';
  message.textContent = nudge.message || 'A productivity nudge is available.';
  footer.textContent = nudge.footer || 'Open Cognify';

  if (manualInline) {
    manualForm.setAttribute('aria-hidden', 'false');
    manualTitle.textContent = nudge.title || 'Back From Idle';
    manualMetric.textContent = nudge.metric || '';
    manualMetric.style.display = nudge.metric ? 'inline-flex' : 'none';
    manualSlot.textContent = formatManualSlot(nudge.manual_block);
    selectManualKind(nudge.manual_block.kind);
    manualNoteInline.value = '';
    setManualStatus('');
    setManualBusy(false);
    setTimeout(() => manualNoteInline.focus(), 80);
  } else {
    manualForm.setAttribute('aria-hidden', 'true');
  }
}

window.assistantApi.onNudgeUpdate(applyNudge);

window.assistantApi.getCurrentNudge()
  .then((nudge) => {
    if (nudge) {
      applyNudge({ nudge, side: 'right' });
    }
  })
  .catch(() => {});

closeButton.addEventListener('click', (event) => {
  event.stopPropagation();
  window.assistantApi.dismissNudge();
});

openTarget.addEventListener('click', () => {
  if (isManualInlineNudge(currentNudge)) {
    return;
  }
  window.assistantApi.openNudgeTarget();
});

manualKindRow.addEventListener('click', (event) => {
  event.stopPropagation();
  const button = event.target.closest('button[data-kind]');
  if (!button) {
    return;
  }
  selectManualKind(button.dataset.kind);
});

manualNoteInline.addEventListener('click', (event) => {
  event.stopPropagation();
});

manualNoteInline.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
    event.preventDefault();
    manualSaveInline.click();
  }
});

manualSaveInline.addEventListener('click', async (event) => {
  event.stopPropagation();
  const block = currentNudge?.manual_block || {};
  const note = manualNoteInline.value.trim();
  if (!block.startTime || !block.endTime) {
    setManualStatus('Idle slot missing.', 'error');
    return;
  }
  if (!note) {
    setManualStatus('Add a short note before saving.', 'error');
    manualNoteInline.focus();
    return;
  }

  setManualBusy(true);
  setManualStatus('Saving...');
  try {
    const result = await window.assistantApi.addManualActivityBlock({
      kind: selectedManualKind,
      startTime: block.startTime,
      endTime: block.endTime,
      note
    });
    const tone = result?.status === 'saved_with_warning' ? 'warn' : 'success';
    setManualStatus(result?.message || 'Manual block saved.', tone);
    setTimeout(() => window.assistantApi.dismissNudge(), 650);
  } catch (error) {
    setManualBusy(false);
    setManualStatus(error?.message || 'Could not save manual block.', 'error');
  }
});

manualKeepIdleInline.addEventListener('click', (event) => {
  event.stopPropagation();
  window.assistantApi.dismissNudge();
});
