const closeButton = document.getElementById('close');
const manualToggle = document.getElementById('manualToggle');
const summaryNode = document.getElementById('summary');
const manualForm = document.getElementById('manualForm');
const kindRow = document.getElementById('kindRow');
const idleBlockSelect = document.getElementById('idleBlockSelect');
const manualNote = document.getElementById('manualNote');
const manualSave = document.getElementById('manualSave');
const manualStatus = document.getElementById('manualStatus');
const recentManual = document.getElementById('recentManual');
const workSummaryModal = document.getElementById('workSummaryModal');
const workSummaryClose = document.getElementById('workSummaryClose');
const workSummaryTabs = document.getElementById('workSummaryTabs');
const workSummaryDateLabel = document.getElementById('workSummaryDateLabel');
const workSummaryStats = document.getElementById('workSummaryStats');
const workSummaryMeta = document.getElementById('workSummaryMeta');
const workSummaryTableWrap = document.getElementById('workSummaryTableWrap');

let selectedKind = 'work';
let idleBlocks = [];
let refreshTimer = null;
let refreshInFlight = null;
let refreshSequence = 0;
let workSummaryPreset = 'today';
let workSummaryInFlight = null;
const MIN_MANUAL_IDLE_BLOCK_MINUTES = 5;

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatMinutes(minutes) {
  const rounded = Math.max(0, Math.round(Number(minutes) || 0));
  if (rounded >= 60) {
    const hours = Math.floor(rounded / 60);
    const mins = rounded % 60;
    return mins ? `${hours}h ${mins}m` : `${hours}h`;
  }
  return `${rounded}m`;
}

function finiteNumber(...values) {
  for (const value of values) {
    if (value === null || value === undefined || value === '') {
      continue;
    }
    const number = Number(value);
    if (Number.isFinite(number)) {
      return number;
    }
  }
  return null;
}

function clampMinutes(minutes, rangeMinutes = null) {
  const value = Math.max(0, Math.round(Number(minutes) || 0));
  const range = Number(rangeMinutes);
  if (!Number.isFinite(range) || range <= 0) {
    return value;
  }
  return Math.min(Math.max(0, Math.round(range)), value);
}

function canonicalActiveMinutes(summary = {}) {
  return Math.max(0, Math.round(finiteNumber(summary.active_minutes, summary.estimated_active_minutes) || 0));
}

function canonicalIdleMinutes(summary = {}) {
  return Math.max(0, Math.round(finiteNumber(summary.idle_minutes, summary.input_idle_minutes) || 0));
}

function canonicalPcAvailableMinutes(summary = {}) {
  const active = canonicalActiveMinutes(summary);
  const idle = canonicalIdleMinutes(summary);
  const captured = Math.max(0, Math.round(Number(summary.captured_minutes_estimate || 0)));
  const range = finiteNumber(summary.range_minutes);
  const localEvidence = clampMinutes(Math.max(active + idle, captured), range);
  const runtime = finiteNumber(summary.runtime_available_minutes);
  const explicit = finiteNumber(
    summary.gross_pc_available_minutes,
    summary.work_minutes_breakdown?.gross_pc_available_minutes
  );

  if (explicit !== null) {
    const trustedExplicit = Boolean(summary.pc_available_source) ||
      (runtime !== null && runtime > 0) ||
      summary.source === 'cognify-runtime-availability' ||
      summary.official_time_source === 'cognify-runtime-availability';
    return trustedExplicit
      ? clampMinutes(explicit, range)
      : clampMinutes(Math.min(explicit, localEvidence), range);
  }
  if (runtime !== null && runtime > 0) {
    return clampMinutes(runtime, range);
  }
  return localEvidence;
}

function canonicalManualAddedMinutes(summary = {}) {
  const manual = summary.manual_timing_blocks || {};
  const value = finiteNumber(
    summary.manual_net_added_work_minutes,
    Number(manual.net_added_minutes || manual.net_added_work_minutes || 0) +
      Number(manual.net_added_meeting_minutes || 0)
  ) || 0;
  return Math.min(canonicalIdleMinutes(summary), Math.max(0, Math.round(value)));
}

function canonicalConfirmedNonWorkMinutes(summary = {}) {
  return Math.max(0, Math.round(finiteNumber(
    summary.confirmed_non_work_minutes,
    summary.work_minutes_breakdown?.confirmed_non_work_minutes
  ) || 0));
}

function canonicalMissingMinutes(summary = {}) {
  return Math.max(0, Math.round(finiteNumber(
    summary.missing_minutes,
    summary.minute_partition?.missing_minutes
  ) || 0));
}

function canonicalWorkMinutes(summary = {}) {
  const available = canonicalPcAvailableMinutes(summary);
  const idleDeducted = Math.min(available, canonicalIdleMinutes(summary));
  const manualRestored = Math.min(idleDeducted, canonicalManualAddedMinutes(summary));
  return Math.min(available, Math.max(0, available - idleDeducted + manualRestored));
}

function formatClock(iso) {
  const date = new Date(iso || 0);
  if (!Number.isFinite(date.getTime())) {
    return '--';
  }
  return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function formatShortClock(iso) {
  const date = new Date(iso || 0);
  if (!Number.isFinite(date.getTime())) {
    return '--';
  }
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
}

function formatDateLabel(dateKey = '', preset = 'today') {
  const date = new Date(`${dateKey || new Date().toISOString().slice(0, 10)}T00:00:00`);
  const label = Number.isFinite(date.getTime())
    ? date.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })
    : dateKey;
  return `${preset === 'yesterday' ? 'Yesterday' : 'Today'}: ${label}`;
}

function dateKeyForPreset(preset = 'today') {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  if (preset === 'yesterday') {
    date.setDate(date.getDate() - 1);
  }
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function sourceLabel(source = '') {
  if (source === 'captured_activity') {
    return 'Captured activity';
  }
  if (source === 'captured-activity-records') {
    return 'Captured activity';
  }
  if (source === 'captured-and-focus-evidence') {
    return 'Captured + focus';
  }
  if (source === 'windows_focus_evidence') {
    return 'Windows focus';
  }
  if (source === 'windows-focus-evidence') {
    return 'Windows focus';
  }
  if (source === 'mixed') {
    return 'Mixed';
  }
  return 'No detail';
}

function setManualStatus(message = '', tone = '') {
  manualStatus.textContent = message;
  manualStatus.dataset.tone = tone;
}

function setManualBusy(busy) {
  manualSave.disabled = busy;
  manualNote.disabled = busy;
  idleBlockSelect.disabled = busy || idleBlocks.length === 0;
  kindRow.querySelectorAll('button').forEach((button) => {
    button.disabled = busy;
  });
}

function renderSummary(summary = {}) {
  const rows = [
    { label: 'PC Available', minutes: canonicalPcAvailableMinutes(summary), tone: 'var(--blue)' },
    { label: 'Idle deducted', minutes: Math.min(canonicalPcAvailableMinutes(summary), canonicalIdleMinutes(summary)), tone: 'var(--amber)' },
    { label: 'Detected non-work', minutes: canonicalConfirmedNonWorkMinutes(summary), tone: 'var(--pink)' },
    { label: 'Manual added', minutes: canonicalManualAddedMinutes(summary), tone: 'var(--green)' },
    { label: 'Missing/no evidence', minutes: canonicalMissingMinutes(summary), tone: 'var(--bad)' },
    { label: 'Final work hours', minutes: canonicalWorkMinutes(summary), tone: 'var(--cyan)' }
  ];
  const maxMinutes = Math.max(1, ...rows.map((row) => row.minutes));
  summaryNode.innerHTML = rows.map((row) => `
    ${row.label === 'Final work hours' ? '<button class="row row-button" type="button" data-work-summary="true" title="View Work Summary">' : '<div class="row">'}
      <div class="row-label">${escapeHtml(row.label)}</div>
      <div class="row-value">${escapeHtml(formatMinutes(row.minutes))}</div>
      <div class="track"><span class="fill" style="--width:${Math.round((row.minutes / maxMinutes) * 100)}%;--tone:${row.tone};"></span></div>
    ${row.label === 'Final work hours' ? '</button>' : '</div>'}
  `).join('');
}

function renderWorkSummaryLoading(preset = workSummaryPreset) {
  workSummaryDateLabel.textContent = formatDateLabel(dateKeyForPreset(preset), preset);
  workSummaryStats.innerHTML = [
    'Final Work Hours',
    'PC Available',
    'Idle Deducted',
    'Manual Restored',
    'Activity on PC'
  ].map((label) => `
    <div class="summary-stat">
      <div class="summary-stat-label">${escapeHtml(label)}</div>
      <div class="summary-stat-value">--</div>
    </div>
  `).join('');
  workSummaryMeta.innerHTML = '<span>Loading report...</span><span></span>';
  workSummaryTableWrap.innerHTML = '<div class="summary-loading">Loading Work Summary...</div>';
}

function manualKindLabel(kind = '') {
  const normalized = String(kind || '').toLowerCase();
  if (normalized === 'work') return 'Work';
  if (normalized === 'meeting') return 'Meeting';
  if (normalized === 'break') return 'Break';
  if (normalized === 'other') return 'Other';
  return 'Manual';
}

function renderManualSummarySection(blocks = {}) {
  const items = Array.isArray(blocks.items) ? blocks.items : [];
  if (!items.length) {
    return '';
  }
  const sorted = [...items].sort((left, right) => new Date(left.start || 0).getTime() - new Date(right.start || 0).getTime());
  return `<div class="summary-section">
    <div class="summary-section-title">Manual Entries</div>
    <table class="summary-table summary-manual-table">
      <thead>
        <tr>
          <th class="col-duration">Duration</th>
          <th class="col-app">Type</th>
          <th>Entry</th>
          <th class="col-seen">First</th>
          <th class="col-seen">Last</th>
          <th class="col-source">Impact</th>
        </tr>
      </thead>
      <tbody>
        ${sorted.map((item) => {
          const netAdded = Math.max(0, Math.round(Number(item.net_added_minutes || 0)));
          return `<tr>
            <td>${escapeHtml(formatMinutes(item.minutes || 0))}</td>
            <td>${escapeHtml(manualKindLabel(item.kind))}</td>
            <td>${escapeHtml(item.title || 'Manual entry')}</td>
            <td>${escapeHtml(formatShortClock(item.start))}</td>
            <td>${escapeHtml(formatShortClock(item.end))}</td>
            <td>${escapeHtml(netAdded > 0 ? `${formatMinutes(netAdded)} restored` : 'Evidence only')}</td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>
  </div>`;
}

function renderWorkSummaryReport(report = {}) {
  const summary = report.summary || {};
  const rows = Array.isArray(report.rows) ? report.rows : [];
  const appTotals = Array.isArray(report.app_totals) ? report.app_totals : [];
  const manualBlocks = report.manual_timing_blocks || summary.manual_timing_blocks || {};
  workSummaryPreset = report.preset || workSummaryPreset;
  workSummaryDateLabel.textContent = formatDateLabel(report.date, workSummaryPreset);
  workSummaryTabs.querySelectorAll('.summary-tab').forEach((button) => {
    button.classList.toggle('active', button.dataset.preset === workSummaryPreset);
  });

  const stats = [
    { label: 'Final Work Hours', value: canonicalWorkMinutes(summary) },
    { label: 'PC Available', value: canonicalPcAvailableMinutes(summary) },
    { label: 'Idle Deducted', value: Math.min(canonicalPcAvailableMinutes(summary), canonicalIdleMinutes(summary)) },
    { label: 'Manual Restored', value: canonicalManualAddedMinutes(summary) },
    { label: 'Activity on PC', value: report.activity_minutes || 0 }
  ];
  workSummaryStats.innerHTML = stats.map((stat) => `
    <div class="summary-stat">
      <div class="summary-stat-label">${escapeHtml(stat.label)}</div>
      <div class="summary-stat-value">${escapeHtml(formatMinutes(stat.value))}</div>
    </div>
  `).join('');

  const coverage = report.canonical_coverage || {};
  const coverageText = coverage.complete === false
    ? `Coverage incomplete: ${(coverage.missing_dates || []).concat(coverage.incomplete_dates || []).join(', ') || 'some hours need review'}`
    : 'Coverage complete';
  workSummaryMeta.innerHTML = `
    <span>${escapeHtml(sourceLabel(report.source))} | ${escapeHtml(String(rows.length))} title row(s) | ${escapeHtml(formatMinutes(report.activity_minutes || 0))} active PC detail</span>
    <span>${escapeHtml(coverageText)}</span>
  `;

  const appTotalsHtml = appTotals.length
    ? `<div class="summary-section">
        <div class="summary-section-title">App Totals</div>
        <table class="summary-table summary-app-table">
          <thead>
            <tr>
              <th class="col-duration">Duration</th>
              <th>App</th>
            </tr>
          </thead>
          <tbody>
            ${appTotals.map((row) => `
              <tr>
                <td>${escapeHtml(formatMinutes(row.minutes || 0))}</td>
                <td>${escapeHtml(row.app_name || 'Unknown app')}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>`
    : '';

  const detailHtml = rows.length
    ? `<div class="summary-section">
        <div class="summary-section-title">Title Detail</div>
        <table class="summary-table">
        <thead>
          <tr>
            <th class="col-duration">Duration</th>
            <th class="col-app">App</th>
            <th>Window Title</th>
            <th>URL / Name</th>
            <th class="col-seen">First</th>
            <th class="col-seen">Last</th>
            <th class="col-source">Source</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map((row) => `
            <tr>
              <td>${escapeHtml(formatMinutes(row.minutes || row.duration_minutes || 0))}</td>
              <td>${escapeHtml(row.app_name || 'Unknown app')}</td>
              <td>${escapeHtml(row.window_title || 'Untitled activity')}</td>
              <td>${escapeHtml(row.latest_url || row.url_or_name || row.window_title || row.app_name || '')}</td>
              <td>${escapeHtml(formatShortClock(row.first_seen))}</td>
              <td>${escapeHtml(formatShortClock(row.last_seen))}</td>
              <td>${escapeHtml(sourceLabel(row.source))}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      </div>`
    : '<div class="summary-empty">No active PC title detail found for this date.</div>';
  const manualHtml = renderManualSummarySection(manualBlocks);
  workSummaryTableWrap.innerHTML = `${appTotalsHtml}${detailHtml}${manualHtml}`;
}

async function loadWorkSummary(preset = workSummaryPreset) {
  if (workSummaryInFlight) {
    return workSummaryInFlight;
  }
  workSummaryPreset = preset === 'yesterday' ? 'yesterday' : 'today';
  renderWorkSummaryLoading(workSummaryPreset);
  workSummaryInFlight = window.assistantApi.getWorkSummaryReport({ preset: workSummaryPreset })
    .then((report) => {
      renderWorkSummaryReport(report || {});
      return report;
    })
    .catch((error) => {
      workSummaryMeta.innerHTML = '<span>Report failed</span><span></span>';
      workSummaryTableWrap.innerHTML = `<div class="summary-empty">${escapeHtml(error?.message || 'Unable to load Work Summary.')}</div>`;
      return null;
    })
    .finally(() => {
      workSummaryInFlight = null;
    });
  return workSummaryInFlight;
}

async function openWorkSummary(preset = 'today') {
  workSummaryModal.hidden = false;
  document.body.classList.add('summary-expanded');
  renderWorkSummaryLoading(preset);
  try {
    await window.assistantApi.setWorkHoursSummaryExpanded?.(true);
  } catch {
    // The report still works if window resizing is unavailable.
  }
  await loadWorkSummary(preset);
}

async function closeWorkSummary() {
  document.body.classList.remove('summary-expanded');
  workSummaryModal.hidden = true;
  try {
    await window.assistantApi.setWorkHoursSummaryExpanded?.(false);
  } catch {
    // Ignore resize cleanup failures while closing the modal.
  }
}

function renderRecentManual(summary = {}) {
  const items = [...(summary.manual_timing_blocks?.items || [])]
    .sort((left, right) => new Date(right.start || 0).getTime() - new Date(left.start || 0).getTime())
    .slice(0, 8);
  recentManual.innerHTML = items.length
    ? items.map((item) => `
      <div class="entry">
        <div class="entry-main">
          <div class="entry-title">${escapeHtml(item.title || 'Manual entry')}</div>
          <div class="entry-minutes">${escapeHtml(formatMinutes(item.minutes || 0))}</div>
        </div>
        <div class="entry-meta">${escapeHtml([
          item.kind || 'manual',
          `${formatClock(item.start)}-${formatClock(item.end)}`,
          Number(item.net_added_minutes || 0) > 0 ? `${formatMinutes(item.net_added_minutes)} restored` : 'evidence only'
        ].filter(Boolean).join(' | '))}</div>
      </div>
    `).join('')
    : '<div class="entry"><div class="entry-title">No manual entries today</div><div class="entry-meta">Saved entries appear here</div></div>';
}

function consumedSlotKeys(summary = {}) {
  return new Set((Array.isArray(summary?.manual_consumed_slots) ? summary.manual_consumed_slots : [])
    .map((slot) => slot?.key || `${slot?.start || ''}|${slot?.end || ''}`)
    .filter((key) => key && key !== '|'));
}

function normalizeIdleBlocks(summary = {}) {
  const intervals = Array.isArray(summary?.intervals) ? summary.intervals : [];
  const consumed = consumedSlotKeys(summary);
  return intervals
    .map((interval, index) => {
      const start = new Date(interval.start || interval.start_time || 0);
      const end = new Date(interval.end || interval.end_time || 0);
      if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
        return null;
      }
      const slotKey = `${start.toISOString()}|${end.toISOString()}`;
      if (consumed.has(slotKey)) {
        return null;
      }
      const minutes = Math.max(1, Math.round((end.getTime() - start.getTime()) / 60000));
      if (minutes < MIN_MANUAL_IDLE_BLOCK_MINUTES) {
        return null;
      }
      return {
        id: `${start.toISOString()}|${end.toISOString()}|${index}`,
        slotKey,
        startTime: start.toISOString(),
        endTime: end.toISOString(),
        minutes,
        label: `${formatClock(start.toISOString())}-${formatClock(end.toISOString())} (${formatMinutes(minutes)})`
      };
    })
    .filter(Boolean)
    .sort((left, right) => new Date(right.startTime).getTime() - new Date(left.startTime).getTime());
}

function renderIdleBlocks(idleSummary = {}) {
  const previous = idleBlockSelect.value;
  idleBlocks = normalizeIdleBlocks(idleSummary);
  if (!idleBlocks.length) {
    const hasConsumedSlots = consumedSlotKeys(idleSummary).size > 0;
    idleBlockSelect.innerHTML = hasConsumedSlots
      ? '<option value="">No unused idle blocks available today</option>'
      : '<option value="">No idle blocks detected today</option>';
    idleBlockSelect.disabled = true;
    manualSave.disabled = true;
    setManualStatus(hasConsumedSlots
      ? 'All detected idle blocks already have manual entries.'
      : 'No idle blocks are available to restore. Manual work/meeting can only restore detected idle.', 'warn');
    return;
  }

  idleBlockSelect.innerHTML = idleBlocks.map((block) => (
    `<option value="${escapeHtml(block.id)}">${escapeHtml(block.label)}</option>`
  )).join('');
  const preferred = idleBlocks.some((block) => block.id === previous)
    ? previous
    : idleBlocks[0].id;
  idleBlockSelect.value = preferred;
  idleBlockSelect.disabled = false;
  manualSave.disabled = false;
  if (!manualStatus.textContent || manualStatus.dataset.tone === 'warn') {
    setManualStatus('Pick an idle block Cognify detected. Manual work/meeting restores deducted idle only.');
  }
}

function selectedIdleBlock() {
  return idleBlocks.find((block) => block.id === idleBlockSelect.value) || null;
}

async function refresh(options = {}) {
  const force = Boolean(options.force);
  if (document.hidden) {
    return null;
  }
  if (!force && refreshInFlight) {
    return refreshInFlight;
  }
  const sequence = ++refreshSequence;
  refreshInFlight = Promise.all([
    window.assistantApi.getLiveDayTruth(),
    window.assistantApi.getIdleSummary()
  ])
    .then(([truth, idleSummary]) => {
      if (sequence !== refreshSequence) {
        return truth;
      }
      const summary = truth?.summary || {};
      renderSummary(summary);
      renderRecentManual(summary);
      renderIdleBlocks(idleSummary);
      return truth;
    })
    .catch((error) => {
      setManualStatus(error?.message || 'Could not refresh work hours.', 'error');
      return null;
    })
    .finally(() => {
      if (sequence === refreshSequence) {
        refreshInFlight = null;
      }
    });
  return refreshInFlight;
}

function selectKind(kind = 'work') {
  selectedKind = ['work', 'meeting', 'break', 'other'].includes(kind) ? kind : 'work';
  kindRow.querySelectorAll('button').forEach((button) => {
    button.classList.toggle('selected', button.dataset.kind === selectedKind);
  });
}

async function saveManual() {
  const block = selectedIdleBlock();
  const note = manualNote.value.trim();
  if (!block) {
    setManualStatus('Choose one of the detected idle blocks before saving.', 'error');
    return;
  }
  if (!note) {
    setManualStatus('Add a short note before saving.', 'error');
    manualNote.focus();
    return;
  }

  setManualBusy(true);
  setManualStatus('Saving...');
  try {
    const result = await window.assistantApi.addManualActivityBlock({
      kind: selectedKind,
      startTime: block.startTime,
      endTime: block.endTime,
      note
    });
    const tone = result.status === 'saved_with_warning' ? 'warn' : 'success';
    setManualStatus(result.message || 'Manual entry saved.', tone);
    manualNote.value = '';
    await refresh({ force: true });
  } catch (error) {
    setManualStatus(error?.message || 'Manual entry was not saved.', 'error');
  } finally {
    setManualBusy(false);
  }
}

closeButton.addEventListener('click', () => {
  window.assistantApi.hideWorkHours();
});

summaryNode.addEventListener('click', (event) => {
  const button = event.target.closest('[data-work-summary="true"]');
  if (button) {
    openWorkSummary('today');
  }
});

workSummaryClose.addEventListener('click', closeWorkSummary);

workSummaryTabs.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-preset]');
  if (button) {
    loadWorkSummary(button.dataset.preset);
  }
});

manualToggle.addEventListener('click', () => {
  manualForm.scrollIntoView({ block: 'nearest' });
  manualNote.focus();
});

kindRow.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-kind]');
  if (button) {
    selectKind(button.dataset.kind);
  }
});

idleBlockSelect.addEventListener('change', () => {
  const block = selectedIdleBlock();
  if (block) {
    setManualStatus(`Selected ${block.label}. Add a note, then save.`);
  }
});

manualSave.addEventListener('click', saveManual);

manualNote.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
    event.preventDefault();
    saveManual();
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    if (!workSummaryModal.hidden) {
      closeWorkSummary();
      return;
    }
    window.assistantApi.hideWorkHours();
  }
});

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    refresh();
  }
});

window.addEventListener('focus', () => {
  refresh();
});

refresh();
refreshTimer = setInterval(refresh, 120000);
window.addEventListener('beforeunload', () => {
  if (refreshTimer) {
    clearInterval(refreshTimer);
  }
});
