const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class HodAppraisalReviewStoreService {
  constructor(storagePath) {
    this.filePath = path.join(storagePath, 'hod-appraisal-drafts.json');
    this.items = this._load();
  }

  saveDraft(payload = {}) {
    const sourceDraft = payload.draft || {};
    validateSourceDraft(sourceDraft);
    const now = new Date().toISOString();
    const weekStart = sourceDraft.week?.start_time || payload.week_start || '';
    const weekEnd = sourceDraft.week?.end_time || payload.week_end || '';
    const reviewedCategories = normalizeReviewedCategories(
      payload.reviewed_categories || payload.reviewedCategories || [],
      sourceDraft
    );
    const overallRemark = normalizeReviewedText(payload.overall_remark || payload.overallRemark || sourceDraft.overall_remark?.draft || '');
    const sourceHash = stableHash({
      weekStart,
      weekEnd,
      rules_hash: sourceDraft.rules_hash || '',
      categories: (sourceDraft.categories || []).map((item) => ({
        field_id: item.field_id,
        draft: item.draft,
        feedback_type: item.feedback_type,
        review_required: item.review_required
      }))
    });
    const reviewedHash = stableHash({ reviewedCategories, overallRemark });
    const id = payload.id || `hod-draft-${Date.now()}-${crypto.randomBytes(4).toString('hex')}-${reviewedHash.slice(0, 10)}`;
    const next = {
      id,
      saved_at: now,
      week: {
        start_time: weekStart,
        end_time: weekEnd
      },
      role: sourceDraft.role || {},
      profile_id: sourceDraft.profile_id || 'hod_appraisal',
      profile_label: sourceDraft.profile_label || 'HOD Appraisal Review Draft',
      rules_version: sourceDraft.rules_version || '',
      rules_hash: sourceDraft.rules_hash || '',
      source_hash: sourceHash,
      reviewed_hash: reviewedHash,
      evidence_confidence: sourceDraft.evidence_confidence || {},
      reviewed_categories: reviewedCategories,
      overall_remark: overallRemark,
      review_summary: reviewSummary(reviewedCategories, overallRemark),
      source_snapshot: compactSourceSnapshot(sourceDraft)
    };

    const existing = this.items.findIndex((item) => item.id === id);
    if (existing >= 0) {
      next.created_at = this.items[existing].created_at || now;
      this.items[existing] = next;
    } else {
      next.created_at = now;
      this.items.push(next);
    }
    this.items.sort((left, right) => String(right.saved_at).localeCompare(String(left.saved_at)));
    this._save();
    return { draft: next, items: this.items.slice(0, 20) };
  }

  list(limit = 20) {
    return { items: this.items.slice(0, Math.max(1, Math.min(100, Number(limit) || 20))) };
  }

  get(id) {
    return this.items.find((item) => item.id === id) || null;
  }

  hash() {
    return stableHash(this.items);
  }

  _load() {
    if (!fs.existsSync(this.filePath)) {
      return [];
    }
    try {
      const parsed = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  _save() {
    fs.writeFileSync(this.filePath, JSON.stringify(this.items, null, 2), 'utf8');
  }
}

function normalizeReviewedCategories(items = [], sourceDraft = {}) {
  const sourceByField = new Map((sourceDraft.categories || []).map((item) => [item.field_id, item]));
  return (Array.isArray(items) ? items : [])
    .map((item) => normalizeReviewedCategory(item, sourceByField))
    .filter((item) => item && item.reviewed_text && (item.copy_allowed || item.reviewed))
    .slice(0, 20);
}

function normalizeReviewedCategory(item = {}, sourceByField) {
  const fieldId = String(item.field_id || '').trim();
  const source = sourceByField.get(fieldId);
  if (!fieldId || !source) {
    return null;
  }
  const reviewed = Boolean(item.reviewed);
  return {
    field_id: fieldId,
    label: String(source.label || item.label || '').trim(),
    feedback_type: String(source.feedback_type || item.feedback_type || '').trim(),
    generated_text: normalizeReviewedText(source.draft || ''),
    reviewed_text: normalizeReviewedText(item.reviewed_text || item.reviewedText || ''),
    reviewed,
    review_required: Boolean(source.review_required),
    copy_allowed: Boolean(source.copy_allowed)
  };
}

function normalizeReviewedText(value) {
  return String(value || '').trim().replace(/\s+\n/g, '\n').slice(0, 3000);
}

function reviewSummary(categories = [], overallRemark = '') {
  return {
    field_count: categories.length,
    reviewed_field_count: categories.filter((item) => item.reviewed).length,
    copy_allowed_count: categories.filter((item) => item.copy_allowed).length,
    has_overall_remark: Boolean(overallRemark)
  };
}

function validateSourceDraft(sourceDraft = {}) {
  if (!sourceDraft.week?.start_time || !sourceDraft.week?.end_time) {
    throw new Error('HOD draft week start and end are required before saving review.');
  }
  if (!sourceDraft.rules_hash) {
    throw new Error('HOD draft rules_hash is required before saving review.');
  }
  if (!Array.isArray(sourceDraft.categories) || !sourceDraft.categories.length) {
    throw new Error('HOD draft categories are required before saving review.');
  }
}

function compactSourceSnapshot(draft = {}) {
  return {
    generated_at: draft.generated_at || '',
    categories: (draft.categories || []).map((item) => ({
      field_id: item.field_id,
      label: item.label,
      source_category: item.source_category,
      confidence: item.confidence,
      review_required: item.review_required,
      review_reasons: item.review_reasons || [],
      evidence: item.evidence || []
    })),
    overall_remark: {
      confidence: draft.overall_remark?.confidence || '',
      review_required: Boolean(draft.overall_remark?.review_required),
      review_reasons: draft.overall_remark?.review_reasons || []
    }
  };
}

function stableHash(value) {
  return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

module.exports = {
  HodAppraisalReviewStoreService
};
