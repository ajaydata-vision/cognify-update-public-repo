const fs = require('fs');
const path = require('path');

class AuditLogService {
  constructor(storagePath) {
    this.logPath = path.join(storagePath, 'audit-log.jsonl');
  }

  async log(event, payload = {}) {
    const row = JSON.stringify({ timestamp: new Date().toISOString(), event, payload });
    try {
      fs.appendFileSync(this.logPath, `${row}\n`, 'utf8');
    } catch (error) {
      if (error && (error.code === 'EPERM' || error.code === 'EBUSY')) {
        return;
      }
      throw error;
    }
  }
}

module.exports = { AuditLogService };
