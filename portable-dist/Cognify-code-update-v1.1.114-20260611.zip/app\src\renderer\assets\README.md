# Cognify Brand Assets

- `cognify-logo.svg`: full horizontal setup/welcome logo with animated pulse.
- `cognify-mark.svg`: compact C + pulse mark for report headers, tray-adjacent UI, cards, and small spaces.
- `cognify-mark-static.svg`: non-animated compact mark for reading-heavy surfaces such as report chrome.
- `cognify-mark.ico`: multi-size Windows shell icon for taskbar, tray, shortcuts, and app registration.
- `cognify-mark-256.png`: 256px raster source generated alongside the Windows icon.
- `cognify-wordmark.svg`: Cognify wordmark when the mark is already present elsewhere.
- `cognify-report-lockup.svg`: compact report header lockup for Daily, Weekly, HOD, and task reports.
- `cognify-pulse.svg`: standalone animated pulse accent for dividers, loading states, live status, and report section headers.

Use the full logo for onboarding and installer-facing screens. Use the mark or report lockup inside reports so branding stays present without dominating the content.
