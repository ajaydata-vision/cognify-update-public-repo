# Pending Audio Optimization

Status: pending for tomorrow.

Cognify now forces audio listening off at startup because Screenpipe audio crossed the RAM guard threshold repeatedly during testing. Keep screen capture enabled, but do not auto-enable audio until the Screenpipe audio path is revalidated.

Next checks:
- Re-test Screenpipe with `whisper-tiny-quantized`.
- Confirm explicit `--audio-device` behavior for mic-only and mic+speaker.
- Decide whether Meeting Only should remain the default audio mode.
- Keep the memory guard active before enabling audio by default again.
