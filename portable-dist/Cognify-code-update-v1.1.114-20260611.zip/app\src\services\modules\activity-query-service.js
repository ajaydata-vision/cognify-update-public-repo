const crypto = require('crypto');
const { normalizeActivity } = require('./activity-schema');

class ActivityQueryService {
  constructor(adapter, privacyFilter, auditLog, activityStore, options = {}) {
    this.adapter = adapter;
    this.privacyFilter = privacyFilter;
    this.auditLog = auditLog;
    this.activityStore = activityStore;
    this.onIngest = typeof options.onIngest === 'function' ? options.onIngest : null;
    this.paused = false;
    this.rangeInFlight = new Map();
  }

  _isSystemProcess(record) {
    return String(record?.app_name || '').trim().toLowerCase() === 'system process';
  }

  async recent(hours = 2, options = {}) {
    const end = new Date();
    const start = new Date(end.getTime() - hours * 60 * 60 * 1000);
    return this.byRange(start.toISOString(), end.toISOString(), options);
  }

  async byRange(startTime, endTime, options = {}) {
    const result = await this.getRangeData(startTime, endTime, options);
    return result.records;
  }

  async getRangeData(startTime, endTime, options = {}) {
    const key = JSON.stringify({
      startTime,
      endTime,
      sync: options.sync !== false,
      maxDurationMs: options.maxDurationMs || null,
      maxWindows: options.maxWindows || null
    });
    if (this.rangeInFlight.has(key)) {
      return this.rangeInFlight.get(key);
    }

    const promise = this._getRangeData(startTime, endTime, options);
    this.rangeInFlight.set(key, promise);
    try {
      return await promise;
    } finally {
      if (this.rangeInFlight.get(key) === promise) {
        this.rangeInFlight.delete(key);
      }
    }
  }

  async _getRangeData(startTime, endTime, options = {}) {
    const shouldSync = options.sync !== false;
    const syncResult = shouldSync
      ? await this.adapter.queryActivityChunked({
        startTime,
        endTime,
        limit: 500,
        maxDurationMs: options.maxDurationMs,
        maxWindows: options.maxWindows
      })
      : { records: [], windows: [] };
    const raw = syncResult.records || [];
    const privacyFiltered = this.privacyFilter.apply(raw);
    const filtered = this.activityStore.filterDeletedRecords
      ? this.activityStore.filterDeletedRecords(privacyFiltered)
      : privacyFiltered;

    if (filtered.length) {
      const ingest = this.activityStore.ingest(filtered);
      await this.auditLog.log('activity_store_ingest', {
        startTime,
        endTime,
        fetched_count: raw.length,
        stored_count: filtered.length,
        skipped_deleted_count: privacyFiltered.length - filtered.length + Number(ingest.skipped_deleted || 0),
        inserted_count: ingest.inserted,
        deduped_count: ingest.deduped,
        replaced_count: ingest.replaced || 0
      });
      if (Number(ingest.inserted || 0) > 0 || Number(ingest.replaced || 0) > 0) {
        this.onIngest?.({
          startTime,
          endTime,
          inserted: ingest.inserted || 0,
          replaced: ingest.replaced || 0,
          stored: filtered.length
        });
      }
    }

    this.activityStore.recordSyncWindows(syncResult.windows || []);
    const storedRecords = this.privacyFilter.apply(this.activityStore.queryRange(startTime, endTime));
    const freshRecords = filtered.map((record) => normalizeActivity(record));
    const mergedRecords = this._mergeRangeRecords(storedRecords, freshRecords);
    const systemProcessRecords = mergedRecords.filter((record) => this._isSystemProcess(record));
    const records = mergedRecords.filter((record) => !this._isSystemProcess(record));
    const sync = this.activityStore.getSyncSummary(startTime, endTime);

    return {
      records,
      sync,
      system_process_records: systemProcessRecords
    };
  }

  _mergeRangeRecords(storedRecords = [], freshRecords = []) {
    const merged = new Map();

    storedRecords.forEach((record) => {
      merged.set(this._recordKey(record), record);
    });

    freshRecords.forEach((record) => {
      const key = this._recordKey(record);
      const existing = merged.get(key);
      if (!existing || this._recordRichness(record) >= this._recordRichness(existing)) {
        merged.set(key, record);
      }
    });

    return Array.from(merged.values())
      .sort((a, b) => new Date(a.timestamp_start).getTime() - new Date(b.timestamp_start).getTime());
  }

  _recordKey(record = {}) {
    if (record.id) {
      return `${record.source || 'screenpipe'}:${record.id}`;
    }

    return crypto
      .createHash('sha1')
      .update(JSON.stringify([
        record.timestamp_start,
        record.timestamp_end,
        record.app_name,
        record.window_title,
        record.url_if_available,
        record.activity_type,
        record.ocr_text,
        record.transcript_text
      ]))
      .digest('hex');
  }

  _recordRichness(record = {}) {
    let score = 0;
    if (record.app_name) score += 3;
    if (record.window_title) score += 2;
    if (record.url_if_available) score += 2;
    if (record.ocr_text) score += 1;
    if (record.transcript_text) score += 1;
    return score;
  }

  async pauseCapture() {
    this.paused = true;
    await this.adapter.pause();
    await this.auditLog.log('capture_pause_requested', { source: 'user' });
    return { paused: true };
  }

  async resumeCapture() {
    this.paused = false;
    await this.adapter.resume();
    await this.auditLog.log('capture_resume_requested', { source: 'user' });
    return { paused: false };
  }

  isPaused() {
    return this.paused;
  }

  async deleteRange(range) {
    let adapterDelete = { ok: true };
    try {
      adapterDelete = await this.adapter.deleteRange(range);
    } catch (error) {
      adapterDelete = {
        ok: false,
        error: error?.message || String(error)
      };
    }
    const local = this.activityStore.deleteRange(range.startTime, range.endTime);
    await this.auditLog.log('capture_delete_range_requested', {
      ...range,
      adapter_delete: adapterDelete,
      local
    });
    return { deleted: true, local, adapter_delete: adapterDelete };
  }
}

module.exports = { ActivityQueryService };
