const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

class WindowsFocusService {
  constructor(focusEventStore, options = {}) {
    this.focusEventStore = focusEventStore;
    this.helperPath = options.helperPath || path.join(__dirname, '..', '..', 'helpers', 'windows-focus-helper.ps1');
    this.nativeSourcePath = options.nativeSourcePath || path.join(__dirname, '..', '..', 'helpers', 'windows-focus-helper.cs');
    this.nativeCompilerPath = options.nativeCompilerPath || path.join(__dirname, '..', '..', 'helpers', 'compile-windows-focus-helper.ps1');
    this.nativeExePath = options.nativeExePath || path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'Cognify', 'WindowsFocusHelper.exe');
    this.nativeHashPath = options.nativeHashPath || `${this.nativeExePath}.sha256`;
    this.helperMode = String(options.helperMode || process.env.COGNIFY_FOCUS_HELPER_MODE || 'native-first').trim().toLowerCase();
    this.enabled = options.enabled !== false && process.env.COGNIFY_WINDOWS_FOCUS !== '0';
    this.helperOptions = {
      enableMouseHook: true,
      enableKeyboardHook: true,
      ...(options.helperOptions || {})
    };
    this.flushIntervalMs = Math.max(1000, Number(options.flushIntervalMs || 5000));
    this.flushMaxEvents = Math.max(1, Number(options.flushMaxEvents || 50));
    this.maxRestartsPerHour = Math.max(0, Number(options.maxRestartsPerHour || process.env.COGNIFY_FOCUS_MAX_RESTARTS_PER_HOUR || 6));
    this.process = null;
    this.buffer = '';
    this.stopping = false;
    this.restartTimer = null;
    this.restartCount = 0;
    this.restartWindow = [];
    this.disabledByFailures = false;
    this.eventCount = 0;
    this.flushCount = 0;
    this.ingestQueue = [];
    this.flushTimer = null;
    this.lastEventAt = null;
    this.lastError = null;
    this.startedAt = null;
    this.lastRestartReason = null;
    this.helperKind = null;
    this.nativeCompileError = null;
  }

  start() {
    if (!this.enabled) {
      this.lastError = 'Windows focus helper is disabled.';
      return { started: false, reason: 'disabled' };
    }
    if (this.disabledByFailures) {
      return { started: false, reason: 'disabled_after_failures' };
    }
    if (process.platform !== 'win32') {
      this.lastError = 'Windows focus helper is only available on Windows.';
      return { started: false, reason: 'unsupported_platform' };
    }
    if (this.process) {
      return { started: true, alreadyRunning: true };
    }

    this.stopping = false;
    this.startedAt = new Date().toISOString();
    const command = this._resolveHelperCommand();
    this.helperKind = command.kind;
    this.process = spawn(command.file, command.args, {
      windowsHide: true,
      env: this._helperEnv(),
      stdio: ['ignore', 'pipe', 'pipe']
    });

    const child = this.process;
    this.lastError = command.warning || null;
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk) => this._handleStdout(chunk));
    child.stderr.setEncoding('utf8');
    child.stderr.on('data', (chunk) => {
      const text = String(chunk || '').trim();
      if (text) {
        this.lastError = text.slice(0, 1000);
      }
    });
    child.on('error', (error) => {
      this.lastError = error?.message || String(error);
    });
    child.on('exit', (code, signal) => {
      if (this.process && this.process !== child) {
        return;
      }
      if (this.process === child) {
        this.process = null;
      }
      this.buffer = '';
      if (!this.stopping) {
        this.lastError = `Focus helper exited: code ${code}, signal ${signal || 'none'}`;
        this._scheduleRestart('helper_exit');
      }
    });

    return { started: true, helper: command.kind, warning: command.warning || null };
  }

  stop() {
    this.stopping = true;
    if (this.restartTimer) {
      clearTimeout(this.restartTimer);
      this.restartTimer = null;
    }
    if (this.process) {
      const child = this.process;
      this.process = null;
      child.kill();
    }
    this._flushQueue();
  }

  getHealth() {
    const stale = this.isStale();
    return {
      ok: process.platform === 'win32' ? Boolean(this.process) && !stale : true,
      informational: process.platform !== 'win32',
      label: 'Windows Focus',
      running: Boolean(this.process),
      pid: this.process?.pid || null,
      event_count: this.eventCount,
      queued_events: this.ingestQueue.length,
      flush_count: this.flushCount,
      last_event_at: this.lastEventAt,
      started_at: this.startedAt,
      helper_kind: this.helperKind,
      native_compile_error: this.nativeCompileError,
      stale,
      restart_count: this.restartCount,
      last_restart_reason: this.lastRestartReason,
      disabled_by_failures: this.disabledByFailures,
      detail: stale
        ? `Windows focus helper is stale; last event ${this._ageLabel(this.lastEventAt)} ago.`
        : (this.process
        ? `Windows focus helper running (${this.helperKind || 'unknown'}), ${this.eventCount} event(s) captured.`
        : (this.lastError || 'Windows focus helper is not running.')),
      error: this.lastError
    };
  }

  isStale(options = {}) {
    if (!this.process || process.platform !== 'win32') {
      return false;
    }
    const staleAfterMs = Math.max(60 * 1000, Number(options.staleAfterMs || 3 * 60 * 1000));
    const startupGraceMs = Math.max(staleAfterMs, Number(options.startupGraceMs || 5 * 60 * 1000));
    const now = Date.now();
    const startedMs = new Date(this.startedAt || 0).getTime();
    if (Number.isFinite(startedMs) && now - startedMs < startupGraceMs) {
      return false;
    }
    const lastMs = new Date(this.lastEventAt || 0).getTime();
    return !Number.isFinite(lastMs) || (now - lastMs) > staleAfterMs;
  }

  ensureFresh(options = {}) {
    if (!this.enabled || this.disabledByFailures || process.platform !== 'win32') {
      return { ok: false, reason: 'disabled_or_unsupported' };
    }
    if (!this.process) {
      const started = this.start();
      return { ok: Boolean(started?.started), action: 'start', ...started };
    }
    if (!this.isStale(options)) {
      return { ok: true, action: 'none' };
    }
    if (!this._recordRestartAttempt('stale_focus_events')) {
      return {
        ok: false,
        action: 'disabled_after_failures',
        reason: 'restart_limit_exceeded',
        detail: this.lastError
      };
    }
    const pid = this.process?.pid || null;
    this.lastError = `Focus helper stale; restarting after last event ${this._ageLabel(this.lastEventAt)} ago.`;
    const child = this.process;
    this.process = null;
    child.kill();
    this.restartCount += 1;
    const started = this.start();
    return { ok: Boolean(started?.started), action: 'restart_stale', pid, ...started };
  }

  _scheduleRestart(reason = 'helper_exit') {
    if (this.restartTimer || this.stopping || process.platform !== 'win32') {
      return;
    }
    if (!this._recordRestartAttempt(reason)) {
      return;
    }
    const delayMs = Math.min(60000, 5000 + (this.restartCount * 5000));
    this.restartTimer = setTimeout(() => {
      this.restartTimer = null;
      this.restartCount += 1;
      this.start();
    }, delayMs);
  }

  _recordRestartAttempt(reason) {
    const now = Date.now();
    this.restartWindow = this.restartWindow.filter((timestamp) => now - timestamp < 60 * 60 * 1000);
    if (this.restartWindow.length >= this.maxRestartsPerHour) {
      this.disabledByFailures = true;
      this.lastRestartReason = reason;
      this.lastError = `Focus helper disabled after ${this.restartWindow.length} restart attempt(s) in one hour.`;
      return false;
    }
    this.restartWindow.push(now);
    this.lastRestartReason = reason;
    return true;
  }

  _resolveHelperCommand() {
    if (this.helperMode === 'powershell' || this.helperMode === 'legacy') {
      return this._powershellHelperCommand();
    }

    const native = this._ensureNativeHelper();
    if (native.ok) {
      return {
        kind: 'native',
        file: this.nativeExePath,
        args: []
      };
    }

    if (this.helperMode === 'native') {
      throw new Error(native.error || 'Native Windows focus helper is unavailable.');
    }

    this.nativeCompileError = native.error || 'Native Windows focus helper is unavailable.';
    return {
      ...this._powershellHelperCommand(),
      warning: `Native focus helper unavailable; using PowerShell fallback. ${this.nativeCompileError}`
    };
  }

  _powershellHelperCommand() {
    return {
      kind: 'powershell',
      file: 'powershell.exe',
      args: [
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        this.helperPath
      ]
    };
  }

  _ensureNativeHelper() {
    if (process.platform !== 'win32') {
      return { ok: false, error: 'Native focus helper is Windows-only.' };
    }
    if (!fs.existsSync(this.nativeSourcePath)) {
      return { ok: false, error: `Native focus helper source missing: ${this.nativeSourcePath}` };
    }
    if (!fs.existsSync(this.nativeCompilerPath)) {
      return { ok: false, error: `Native focus helper compiler missing: ${this.nativeCompilerPath}` };
    }

    let sourceHash = '';
    try {
      sourceHash = crypto
        .createHash('sha256')
        .update(fs.readFileSync(this.nativeSourcePath))
        .digest('hex');
      const cachedHash = fs.existsSync(this.nativeHashPath)
        ? String(fs.readFileSync(this.nativeHashPath, 'utf8')).trim()
        : '';
      if (cachedHash === sourceHash && fs.existsSync(this.nativeExePath)) {
        this.nativeCompileError = null;
        return { ok: true, cached: true };
      }
    } catch (error) {
      return { ok: false, error: error?.message || String(error) };
    }

    try {
      fs.mkdirSync(path.dirname(this.nativeExePath), { recursive: true });
      const result = spawnSync('powershell.exe', [
        '-NoProfile',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        this.nativeCompilerPath,
        '-SourcePath',
        this.nativeSourcePath,
        '-OutputPath',
        this.nativeExePath,
        '-HashPath',
        this.nativeHashPath
      ], {
        encoding: 'utf8',
        windowsHide: true,
        timeout: 30000
      });
      if (result.error) {
        return { ok: false, error: result.error.message || String(result.error) };
      }
      if (result.status !== 0 || !fs.existsSync(this.nativeExePath)) {
        const stderr = String(result.stderr || '').trim();
        const stdout = String(result.stdout || '').trim();
        return {
          ok: false,
          error: (stderr || stdout || `Native helper compiler exited with code ${result.status}`).slice(0, 1000)
        };
      }
      this.nativeCompileError = null;
      return { ok: true, compiled: true, hash: sourceHash };
    } catch (error) {
      return { ok: false, error: error?.message || String(error) };
    }
  }

  _ageLabel(iso) {
    const ms = new Date(iso || 0).getTime();
    if (!Number.isFinite(ms)) {
      return 'never';
    }
    const seconds = Math.max(0, Math.round((Date.now() - ms) / 1000));
    if (seconds >= 3600) {
      const hours = Math.floor(seconds / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      return minutes ? `${hours}h ${minutes}m` : `${hours}h`;
    }
    if (seconds >= 60) {
      return `${Math.floor(seconds / 60)}m`;
    }
    return `${seconds}s`;
  }

  _handleStdout(chunk) {
    this.buffer += chunk;
    const lines = this.buffer.split(/\r?\n/);
    this.buffer = lines.pop() || '';
    lines.forEach((line) => this._ingestLine(line));
  }

  _ingestLine(line) {
    const text = String(line || '').trim();
    if (!text) {
      return;
    }
    try {
      const event = JSON.parse(text);
      this._queueEvent(event);
      this.eventCount += 1;
      this.lastEventAt = event.observed_at || new Date().toISOString();
    } catch (error) {
      this.lastError = error?.message || String(error);
    }
  }

  _queueEvent(event) {
    this.ingestQueue.push(event);
    if (this.ingestQueue.length >= this.flushMaxEvents) {
      this._flushQueue();
      return;
    }
    if (!this.flushTimer) {
      this.flushTimer = setTimeout(() => {
        this.flushTimer = null;
        this._flushQueue();
      }, this.flushIntervalMs);
      this.flushTimer.unref?.();
    }
  }

  _flushQueue() {
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
      this.flushTimer = null;
    }
    if (!this.ingestQueue.length) {
      return;
    }
    const batch = this.ingestQueue.splice(0, this.ingestQueue.length);
    try {
      if (this.focusEventStore?.ingestMany) {
        this.focusEventStore.ingestMany(batch);
      } else {
        batch.forEach((event) => this.focusEventStore?.ingest?.(event));
      }
      this.flushCount += 1;
    } catch (error) {
      this.lastError = error?.message || String(error);
    }
  }

  _helperEnv() {
    const env = { ...process.env };
    if (this.helperOptions.enableMouseHook !== undefined) {
      env.COGNIFY_FOCUS_MOUSE_HOOK = this.helperOptions.enableMouseHook ? '1' : '0';
    }
    if (this.helperOptions.enableKeyboardHook !== undefined) {
      env.COGNIFY_FOCUS_KEYBOARD_HOOK = this.helperOptions.enableKeyboardHook ? '1' : '0';
    }
    return env;
  }
}

module.exports = { WindowsFocusService };
