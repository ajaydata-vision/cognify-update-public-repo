const title = document.getElementById('title');
const subtitle = document.getElementById('subtitle');
const content = document.getElementById('content');
const statusLine = document.getElementById('status');
const fitButton = document.getElementById('fit');
const closeButton = document.getElementById('close');

let currentReport = { title: 'Report', subtitle: '', html: '', text: '', data: null, kind: 'report' };
let expanded = false;

function setStatus(value) {
  statusLine.textContent = value || '';
}

function cssEscape(value) {
  if (window.CSS?.escape) {
    return window.CSS.escape(String(value ?? ''));
  }
  return String(value ?? '').replace(/["\\]/g, '\\$&');
}

function collectReviewedHodDraft() {
  const categoryInputs = [...document.querySelectorAll('.hod-review-text[data-hod-kind="category"]')];
  const overallInput = document.querySelector('.hod-review-text[data-hod-kind="overall"]');
  return {
    draft: currentReport.data || {},
    reviewed_categories: categoryInputs.map((input) => ({
      field_id: input.dataset.fieldId || '',
      label: input.dataset.label || '',
      feedback_type: input.dataset.feedbackType || '',
      review_required: input.dataset.reviewRequired === 'true',
      copy_allowed: input.dataset.copyAllowed === 'true',
      reviewed: isHodFieldReviewed(input.dataset.fieldId || ''),
      reviewed_text: input.value
    })),
    overall_remark: overallInput?.value || ''
  };
}

function isHodFieldReviewed(fieldId) {
  const checkbox = document.querySelector(`.hod-reviewed-checkbox[data-field-id="${cssEscape(fieldId)}"]`);
  return checkbox ? checkbox.checked : false;
}

function reviewedHodCategoriesForCopy() {
  return collectReviewedHodDraft().reviewed_categories.filter((item) => (
    item.reviewed_text && (item.copy_allowed || item.reviewed)
  ));
}

function formatReviewedHodDraftText() {
  const reviewed = collectReviewedHodDraft();
  const lines = reviewedHodCategoriesForCopy()
    .map((item) => `${item.label || item.field_id}: ${item.reviewed_text}`);
  if (reviewed.overall_remark) {
    lines.push(`Remark: ${reviewed.overall_remark}`);
  }
  return lines.join('\n\n');
}

window.panelActions = {
  async saveReviewedHodDraft() {
    if (currentReport.kind !== 'hod-draft' || !currentReport.data) {
      setStatus('Generate HOD Draft before saving a reviewed version.');
      return;
    }
    const result = await window.assistantApi.saveHodAppraisalDraft(collectReviewedHodDraft());
    setStatus(`Saved reviewed HOD draft: ${result.draft?.id || 'saved'}`);
  },
  async copyReviewedHodDraft() {
    await window.assistantApi.copyText(formatReviewedHodDraftText());
    setStatus('Reviewed draft copied.');
  },
  async copyReviewedHodField(encodedFieldId) {
    const fieldId = decodeURIComponent(encodedFieldId);
    const input = document.querySelector(`.hod-review-text[data-hod-kind="category"][data-field-id="${cssEscape(fieldId)}"]`);
    const copyAllowed = input?.dataset.copyAllowed === 'true';
    if (!copyAllowed && !isHodFieldReviewed(fieldId)) {
      setStatus('Mark this field as reviewed before copying it.');
      return;
    }
    await window.assistantApi.copyText(input?.value || '');
    setStatus('Field copied.');
  },
  async copyMyWeeklyReport() {
    await window.assistantApi.copyText(currentReport.text || content.innerText || '');
    setStatus('Report copied.');
  },
  async copySavedHodDraft() {
    await window.assistantApi.copyText(currentReport.text || content.innerText || '');
    setStatus('Saved draft copied.');
  },
  async sendPayrollReport() {
    if (currentReport.kind !== 'daily-report' || !currentReport.data?.payroll_payload) {
      setStatus('Generate Daily Report before sending it to payroll.');
      return;
    }
    const status = document.getElementById('payrollSendStatus');
    if (status) {
      status.textContent = 'Sending...';
    }
    const result = await window.assistantApi.sendPayrollReport(currentReport.data.payroll_payload);
    if (status) {
      status.textContent = `Sent (${result.status})`;
    }
    setStatus(`Payroll report sent to ${result.endpoint}`);
  }
};

async function toggleFit() {
  if (expanded) {
    await window.assistantApi.restoreReportWindow();
    expanded = false;
  } else {
    await window.assistantApi.expandReportWindow();
    expanded = true;
  }
  fitButton.textContent = expanded ? 'Fit' : 'Max';
}

function renderReport(payload = {}) {
  currentReport = {
    title: payload.title || 'Report',
    subtitle: payload.subtitle || '',
    html: payload.html || '',
    text: payload.text || '',
    data: payload.data || null,
    kind: payload.kind || 'report'
  };
  title.textContent = currentReport.title;
  subtitle.textContent = currentReport.subtitle;
  expanded = false;
  fitButton.textContent = 'Max';
  content.innerHTML = currentReport.html || '<div class="empty">No report content.</div>';
  content.scrollTop = 0;
  setStatus('');
}

fitButton.addEventListener('click', () => {
  toggleFit().catch((error) => setStatus(error?.message || String(error)));
});

closeButton.addEventListener('click', () => {
  window.assistantApi.hideReportWindow();
});

window.assistantApi.onReportRender(renderReport);
