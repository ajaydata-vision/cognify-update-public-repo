class DualWriteActivityStoreService {
  constructor(primaryStore, secondaryStore, options = {}) {
    if (!primaryStore) {
      throw new Error('DualWriteActivityStoreService requires a primary store.');
    }
    if (!secondaryStore) {
      throw new Error('DualWriteActivityStoreService requires a secondary store.');
    }

    this.primaryStore = primaryStore;
    this.secondaryStore = secondaryStore;
    this.primaryName = options.primaryName || 'primary';
    this.secondaryName = options.secondaryName || 'secondary';
    this.lastSecondaryError = null;
    this.secondaryErrorCount = 0;
    this.onSecondaryError = typeof options.onSecondaryError === 'function'
      ? options.onSecondaryError
      : () => {};
  }

  ingest(records = []) {
    const primaryResult = this.primaryStore.ingest(records);
    const secondaryResult = this._trySecondary('ingest', () => this.secondaryStore.ingest(records));
    return this._withSecondary(primaryResult, secondaryResult);
  }

  queryRange(startTime, endTime) {
    return this.primaryStore.queryRange(startTime, endTime);
  }

  queryRangeLite(startTime, endTime) {
    if (this.primaryStore.queryRangeLite) {
      return this.primaryStore.queryRangeLite(startTime, endTime);
    }
    return this.primaryStore.queryRange(startTime, endTime);
  }

  filterDeletedRecords(records = []) {
    return this.primaryStore.filterDeletedRecords
      ? this.primaryStore.filterDeletedRecords(records)
      : records;
  }

  deleteRange(startTime, endTime) {
    const primaryResult = this.primaryStore.deleteRange(startTime, endTime);
    const secondaryResult = this._trySecondary('deleteRange', () => this.secondaryStore.deleteRange(startTime, endTime));
    return this._withSecondary(primaryResult, secondaryResult);
  }

  recordSyncWindows(windows = []) {
    const primaryResult = this.primaryStore.recordSyncWindows(windows);
    const secondaryResult = this._trySecondary('recordSyncWindows', () => this.secondaryStore.recordSyncWindows(windows));
    return this._withSecondary(primaryResult, secondaryResult);
  }

  getSyncSummary(startTime, endTime) {
    return this.primaryStore.getSyncSummary(startTime, endTime);
  }

  prune(cutoffMs) {
    const primaryResult = this.primaryStore.prune(cutoffMs);
    const secondaryResult = this._trySecondary('prune', () => this.secondaryStore.prune(cutoffMs));
    return this._withSecondary(primaryResult, secondaryResult);
  }

  latestTimestamp() {
    return this.primaryStore.latestTimestamp ? this.primaryStore.latestTimestamp() : null;
  }

  close() {
    if (this.primaryStore?.close) {
      this.primaryStore.close();
    }
    if (this.secondaryStore?.close) {
      this.secondaryStore.close();
    }
  }

  _trySecondary(operation, action) {
    try {
      return {
        ok: true,
        store: this.secondaryName,
        result: action()
      };
    } catch (error) {
      const payload = {
        ok: false,
        store: this.secondaryName,
        operation,
        error: error?.message || String(error),
        at: new Date().toISOString()
      };
      this.lastSecondaryError = payload;
      this.secondaryErrorCount += 1;
      this.onSecondaryError(payload);
      return payload;
    }
  }

  getDualWriteHealth() {
    return {
      ok: !this.lastSecondaryError,
      primary: this.primaryName,
      secondary: this.secondaryName,
      secondary_error_count: this.secondaryErrorCount,
      last_secondary_error: this.lastSecondaryError
    };
  }

  _withSecondary(primaryResult, secondaryResult) {
    return {
      ...primaryResult,
      dual_write: {
        primary: this.primaryName,
        secondary: secondaryResult
      }
    };
  }
}

module.exports = { DualWriteActivityStoreService };
