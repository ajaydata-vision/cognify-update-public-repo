const fs = require('fs');
const path = require('path');

const CONFIDENCE_WEIGHT = {
  high: 3,
  medium: 2,
  low: 1
};

const MATCH_TYPE_WEIGHT = {
  domain: 5,
  domain_or_app: 4,
  app_or_title: 4,
  app_plus_text: 4,
  title_or_text: 3,
  app: 2,
  app_only: 2,
  fallback: 0
};

const RULE_ORDER = {
  'override.': 0,
  'other.office.': 12,
  'meeting.': 15,
  'work.app.': 20,
  'work.domain.': 20,
  'work.title.': 30,
  'social.': 35,
  'other.domain.': 40,
  'other.title.': 50,
  'work.browser.': 60,
  'work.file_': 60,
  'other.browser.': 70,
  'unclear.': 90
};

const MEETING_DOMAINS = [
  'meet.google.com',
  'zoom.us',
  'teams.microsoft.com',
  'webex.com',
  'jitsi.org',
  'meet.jit.si',
  'videomeet.in',
  'whatsapp.com',
  'web.whatsapp.com'
];

const MEETING_APPS = [
  'zoom.exe',
  'teams.exe',
  'ms-teams.exe',
  'webex.exe',
  'ciscocollabhost.exe',
  'jitsi.exe',
  'videomeet.exe',
  'whatsapp.exe'
];

const COMMUNICATION_DOMAINS = [
  'mail.google.com',
  'gmail.com',
  'outlook.office.com',
  'outlook.live.com',
  'mail.dil.net.in',
  'im.xgen.in',
  'web.whatsapp.com',
  'whatsapp.com',
  'slack.com',
  'teams.microsoft.com'
];

const COMMUNICATION_APPS = [
  'outlook.exe',
  'slack.exe',
  'whatsapp.exe',
  'telegram.exe'
];

const COMMUNICATION_TITLE_HINT = /\b(send email|compose email|new email|inbox|outbox|drafts?|mailbox|reply email|forward email|xgen\s*im)\b/i;
const BUSINESS_CHAT_TITLE_HINT = /\bxgen\s*im\b/i;

const SOCIAL_DOMAINS = [
  'facebook.com',
  'fb.com',
  'instagram.com',
  'threads.net',
  'x.com',
  'twitter.com',
  'linkedin.com',
  'reddit.com',
  'discord.com',
  'whatsapp.com',
  'web.whatsapp.com',
  'telegram.org',
  't.me',
  'snapchat.com',
  'pinterest.com',
  'tiktok.com',
  'youtube.com',
  'youtu.be'
];

const SOCIAL_APPS = [
  'discord.exe',
  'whatsapp.exe',
  'telegram.exe',
  'facebook.exe',
  'instagram.exe'
];

const OFFICE_APPS = [
  'excel.exe',
  'winword.exe',
  'powerpnt.exe',
  'onenote.exe',
  'outlook.exe',
  'msaccess.exe',
  'mspub.exe',
  'visio.exe',
  'winproj.exe'
];

const AI_APPS = [
  'chatgpt.exe',
  'claude.exe',
  'copilot.exe'
];

const AI_DOMAINS = [
  'chatgpt.com',
  'chat.openai.com',
  'platform.openai.com',
  'claude.ai',
  'console.anthropic.com',
  'gemini.google.com',
  'aistudio.google.com',
  'perplexity.ai',
  'poe.com',
  'copilot.microsoft.com'
];

const OFFICE_PERSONAL_TITLE_HINT = /\b(personal budget|household budget|family budget|wedding|vacation|holiday plan|recipe|personal expense|credit card statement|bank statement|resume|curriculum vitae)\b/i;

class WorkClassificationService {
  constructor(options = {}) {
    this.rulesPath = options.rulesPath || path.join(__dirname, '..', '..', '..', 'docs', 'WORKRULES.md');
    this.workDomains = this._normalizeDomains(options.workDomains || []);
    this.workTlds = this._normalizeTlds(options.workTlds || []);
    this._rulesCache = null;
    this._rulesMtimeMs = 0;
  }

  classifyRecord(record = {}) {
    const rules = this.loadRules();
    const normalized = this._normalizeRecord(record);

    const manualClassification = this._manualEntryClassification(normalized);
    if (manualClassification) {
      return manualClassification;
    }

    if (this._isSystemProcessName(normalized.app_name)) {
      return {
        classification: 'unclear',
        confidence: 'low',
        matched_rules: ['guardrail.system_process'],
        matched_rule_details: [],
        source: 'workrules'
      };
    }

    const matches = rules
      .map((rule) => this._evaluateRule(rule, normalized))
      .filter(Boolean)
      .concat(this._workDomainMatches(normalized))
      .concat(this._officePersonalMatches(normalized))
      .concat(this._workToolMatches(normalized))
      .concat(this._workLearningVideoMatches(normalized))
      .concat(this._meetingMatches(normalized))
      .concat(this._communicationMatches(normalized))
      .concat(this._socialMatches(normalized))
      .sort((left, right) => this._compareMatches(left, right));

    if (!matches.length) {
      return {
        classification: 'unclear',
        confidence: 'low',
        matched_rules: ['unclear.default'],
        matched_rule_details: [],
        source: 'workrules'
      };
    }

    const winner = matches[0];
    const samePriority = matches.filter((candidate) => this._isTie(winner, candidate));
    const conflicting = samePriority.some((candidate) => candidate.rule.classification !== winner.rule.classification);

    if (conflicting) {
      return {
        classification: 'unclear',
        confidence: winner.rule.confidence,
        matched_rules: samePriority.map((candidate) => candidate.rule.id),
        matched_rule_details: samePriority.map((candidate) => this._matchDetail(candidate)),
        source: 'workrules'
      };
    }

    return {
      classification: winner.rule.classification,
      confidence: winner.rule.confidence,
      matched_rules: samePriority.map((candidate) => candidate.rule.id),
      matched_rule_details: samePriority.map((candidate) => this._matchDetail(candidate)),
      source: 'workrules'
    };
  }

  _manualEntryClassification(record = {}) {
    if (record.activity_type !== 'manual' && record.source !== 'manual') {
      return null;
    }

    const text = `${record.app_name} ${record.window_title} ${record.ocr_text}`.toLowerCase();
    if (/\b(meeting|call|chat)\b/.test(text)) {
      return this._manualResult('meeting', 'manual.meeting');
    }
    if (/\b(break|lunch|walk|away)\b/.test(text)) {
      return this._manualResult('other', 'manual.break');
    }
    return this._manualResult('work', 'manual.work');
  }

  _manualResult(classification, ruleId) {
    return {
      classification,
      confidence: 'high',
      matched_rules: [ruleId],
      matched_rule_details: [],
      source: 'manual'
    };
  }

  loadRules() {
    const stat = fs.statSync(this.rulesPath);
    if (this._rulesCache && this._rulesMtimeMs === stat.mtimeMs) {
      return this._rulesCache;
    }

    const text = fs.readFileSync(this.rulesPath, 'utf8');
    const rules = [];
    const blocks = text.split(/^###\s+/m).slice(1);

    blocks.forEach((block) => {
      const lines = block.split(/\r?\n/);
      const heading = (lines.shift() || '').trim();
      const idMatch = heading.match(/^`([^`]+)`/);
      if (!idMatch) {
        return;
      }

      const rule = {
        id: idMatch[1],
        classification: null,
        confidence: 'low',
        match_type: 'fallback',
        patterns: [],
        notes: '',
        order: this._ruleOrder(idMatch[1])
      };

      let inPatterns = false;

      lines.forEach((rawLine) => {
        const line = rawLine.trim();
        if (!line) {
          return;
        }

        if (line.startsWith('- class:')) {
          rule.classification = this._extractTickValue(line) || line.split(':').slice(1).join(':').trim();
          inPatterns = false;
          return;
        }

        if (line.startsWith('- confidence:')) {
          rule.confidence = this._extractTickValue(line) || line.split(':').slice(1).join(':').trim();
          inPatterns = false;
          return;
        }

        if (line.startsWith('- match_type:')) {
          rule.match_type = this._extractTickValue(line) || line.split(':').slice(1).join(':').trim();
          inPatterns = false;
          return;
        }

        if (line.startsWith('- patterns:')) {
          inPatterns = true;
          return;
        }

        if (line.startsWith('- notes:')) {
          rule.notes = line.split(':').slice(1).join(':').trim();
          inPatterns = false;
          return;
        }

        if (inPatterns && line.startsWith('- ')) {
          const value = line.slice(2).trim();
          const extracted = this._extractTickValue(value);
          if (extracted) {
            rule.patterns.push(extracted);
          }
        }
      });

      if (rule.classification) {
        rules.push(rule);
      }
    });

    this._rulesCache = rules;
    this._rulesMtimeMs = stat.mtimeMs;
    return rules;
  }

  _normalizeRecord(record = {}) {
    const urlValue = String(record.url_if_available || '').trim();
    const host = this._extractHost(urlValue);
    const windowTitle = String(record.window_title || '').trim().toLowerCase();
    const ocrText = String(record.ocr_text || '').trim().toLowerCase();
    const transcriptText = String(record.transcript_text || '').trim().toLowerCase();

    return {
      app_name: String(record.app_name || '').trim().toLowerCase(),
      window_title: windowTitle,
      ocr_text: ocrText,
      transcript_text: transcriptText,
      url_if_available: urlValue.toLowerCase(),
      url_host: host,
      activity_type: String(record.activity_type || '').trim().toLowerCase(),
      source: String(record.source || '').trim().toLowerCase(),
      title_domains: this._extractDerivedDomains(windowTitle),
      derived_domains: this._extractDerivedDomains(`${windowTitle} ${ocrText} ${transcriptText}`)
    };
  }

  _isSystemProcessName(appName) {
    const normalized = String(appName || '').trim().toLowerCase().replace(/^\[|\]$/g, '');
    return normalized === 'system process';
  }

  _workDomainMatches(record) {
    if (!this.workDomains.length && !this.workTlds.length) {
      return [];
    }

    const matchedDomain = this.workDomains.find((domain) => this._recordHasDomain(record, domain));
    const matchedTld = this.workTlds.find((tld) => this._recordHasTld(record, tld));
    const pattern = matchedDomain || (matchedTld ? `.${matchedTld}` : '');
    if (!pattern) {
      return [];
    }

    return [{
      rule: {
        id: 'work.domain.configured',
        classification: 'work',
        confidence: 'high',
        match_type: 'domain',
        order: 20
      },
      pattern
    }];
  }

  _meetingMatches(record) {
    const matchedDomain = MEETING_DOMAINS.find((domain) => this._recordHasUrlDomain(record, domain));
    const matchedApp = MEETING_APPS.find((appName) => this._matchValue(record.app_name, appName));
    const browserTitle = this._isBrowserApp(record.app_name)
      && /\b(google meet|zoom meeting|webex|jitsi|videomeet|whatsapp call|teams meeting)\b/i.test(record.window_title);
    const pattern = matchedDomain || matchedApp || (browserTitle ? 'browser-meeting-title' : '');

    if (!pattern) {
      return [];
    }

    return [{
      rule: {
        id: 'meeting.av.builtin',
        classification: 'meeting',
        confidence: 'high',
        match_type: matchedDomain ? 'domain' : (matchedApp ? 'app' : 'title_or_text'),
        order: 15
      },
      pattern
    }];
  }

  _communicationMatches(record) {
    const matchedDomain = COMMUNICATION_DOMAINS.find((domain) => this._recordHasUrlDomain(record, domain));
    const matchedApp = COMMUNICATION_APPS.find((appName) => this._matchValue(record.app_name, appName));
    const text = `${record.window_title || ''} ${record.ocr_text || ''} ${record.transcript_text || ''}`;
    const titleText = `${record.app_name || ''} ${record.window_title || ''}`;
    const titleSignal = COMMUNICATION_TITLE_HINT.test(titleText);
    const businessChatTitle = BUSINESS_CHAT_TITLE_HINT.test(titleText);
    const pattern = matchedDomain || matchedApp || (titleSignal ? 'communication-title' : '');

    if (!pattern) {
      return [];
    }

    return [{
      rule: {
        id: matchedDomain ? 'meeting.chat.domain_builtin' : (matchedApp ? 'meeting.chat.app_builtin' : 'meeting.chat.title_builtin'),
        classification: 'meeting',
        confidence: matchedDomain || matchedApp || businessChatTitle ? 'high' : 'medium',
        match_type: matchedDomain ? 'domain' : (matchedApp ? 'app' : 'title_or_text'),
        order: businessChatTitle ? 9 : 14
      },
      pattern
    }];
  }

  _officePersonalMatches(record) {
    const matchedApp = OFFICE_APPS.find((appName) => this._matchValue(record.app_name, appName));
    if (!matchedApp) {
      return [];
    }

    const text = `${record.window_title || ''} ${record.ocr_text || ''} ${record.transcript_text || ''}`;
    const matchedTitle = text.match(OFFICE_PERSONAL_TITLE_HINT)?.[0] || '';
    if (!matchedTitle) {
      return [];
    }

    return [{
      rule: {
        id: 'other.office.personal_title',
        classification: 'other',
        confidence: 'high',
        match_type: 'title_or_text',
        order: 12
      },
      pattern: matchedTitle.toLowerCase()
    }];
  }

  _workToolMatches(record) {
    const matchedOfficeApp = OFFICE_APPS.find((appName) => this._matchValue(record.app_name, appName));
    if (matchedOfficeApp) {
      return [{
        rule: {
          id: 'work.app.office_builtin',
          classification: 'work',
          confidence: 'high',
          match_type: 'app',
          order: 20
        },
        pattern: matchedOfficeApp
      }];
    }

    const matchedAiApp = AI_APPS.find((appName) => this._matchValue(record.app_name, appName));
    const matchedAiDomain = AI_DOMAINS.find((domain) => this._recordHasDomain(record, domain));
    const pattern = matchedAiApp || matchedAiDomain;
    if (!pattern) {
      return [];
    }

    return [{
      rule: {
        id: matchedAiDomain ? 'work.domain.ai_builtin' : 'work.app.ai_builtin',
        classification: 'work',
        confidence: 'high',
        match_type: matchedAiDomain ? 'domain' : 'app',
        order: 20
      },
      pattern
    }];
  }

  _workLearningVideoMatches(record) {
    if (!this._recordHasUrlDomain(record, 'youtube.com') && !this._recordHasUrlDomain(record, 'youtu.be')) {
      return [];
    }

    const text = `${record.window_title || ''} ${record.ocr_text || ''} ${record.transcript_text || ''}`;
    if (!/\b(tutorial|documentation|api reference|how to fix|debug|debugging|error|exception|course|training|lecture|coding|programming|developer)\b/i.test(text)) {
      return [];
    }
    if (/\b(shorts|home feed|trending|watch later|music video|movie|episode|comedy|songs?)\b/i.test(text)) {
      return [];
    }

    return [{
      rule: {
        id: 'work.domain.youtube_learning_builtin',
        classification: 'work',
        confidence: 'high',
        match_type: 'domain',
        order: 8
      },
      pattern: 'youtube-learning-context'
    }];
  }

  _socialMatches(record) {
    if (COMMUNICATION_DOMAINS.some((domain) => this._recordHasDomain(record, domain)) ||
      COMMUNICATION_APPS.some((appName) => this._matchValue(record.app_name, appName))) {
      return [];
    }

    const matchedDomain = SOCIAL_DOMAINS.find((domain) => this._recordHasUrlDomain(record, domain));
    const matchedTitleDomain = this._isBrowserApp(record.app_name)
      ? SOCIAL_DOMAINS.find((domain) => (record.title_domains || []).some((titleDomain) => this._domainMatches(titleDomain, domain)))
      : '';
    const matchedDerivedDomain = this._isBrowserApp(record.app_name)
      ? SOCIAL_DOMAINS.find((domain) => (record.derived_domains || []).some((derivedDomain) => this._domainMatches(derivedDomain, domain)))
      : '';
    const matchedApp = SOCIAL_APPS.find((appName) => this._matchValue(record.app_name, appName));
    const browserText = `${record.window_title || ''} ${record.ocr_text || ''} ${record.transcript_text || ''}`;
    const activeSocialTitle = this._isBrowserApp(record.app_name)
      && (
        /\b(facebook|instagram|threads|twitter|reddit|discord|whatsapp|telegram|snapchat|pinterest|tiktok|youtube|linkedin)\b/i.test(record.window_title) ||
        /\bx\.com\b/i.test(record.window_title) ||
        this._isXBrowserTitle(record.window_title)
      );
    const onlyOcrSocialSignal = !matchedDomain && !matchedTitleDomain && !matchedApp && !activeSocialTitle;
    if (onlyOcrSocialSignal && this._isBackgroundTabListOcr(record.ocr_text)) {
      return [];
    }

    const socialBrowserTitle = this._isBrowserApp(record.app_name)
      && (
        /\b(facebook|instagram|threads|twitter|reddit|discord|whatsapp|telegram|snapchat|pinterest|tiktok|youtube|linkedin)\b/i.test(browserText) ||
        /\bx\.com\b/i.test(browserText) ||
        activeSocialTitle ||
        this._isXBrowserTitle(record.ocr_text)
      );
    const pattern = matchedDomain || matchedTitleDomain || matchedDerivedDomain || matchedApp || (socialBrowserTitle ? 'browser-social-title' : '');

    if (!pattern) {
      return [];
    }

    return [{
      rule: {
        id: 'social.builtin',
        classification: 'social',
        confidence: 'high',
        match_type: (matchedDomain || matchedTitleDomain || matchedDerivedDomain) ? 'domain' : (matchedApp ? 'app' : 'title_or_text'),
        order: (matchedDomain || matchedTitleDomain || activeSocialTitle) ? 10 : 35
      },
      pattern
    }];
  }

  _recordHasUrlDomain(record, pattern) {
    return Boolean(record.url_host && this._domainMatches(record.url_host, pattern));
  }

  _isBrowserApp(appName) {
    return /chrome|msedge|edge|firefox|brave|opera|browser/i.test(String(appName || ''));
  }

  _isXBrowserTitle(title) {
    const normalized = String(title || '')
      .trim()
      .toLowerCase()
      .replace(/^\(\d+\)\s*/, '');

    return normalized === 'x' ||
      /^x\s*([|/\\-]|$)/i.test(normalized) ||
      /([|/\\-]\s*)x$/i.test(normalized) ||
      /\b(home|notifications|messages|bookmarks|profile|explore|communities|premium)\s*([|/\\-])\s*x\b/i.test(normalized);
  }

  _isBackgroundTabListOcr(text) {
    const normalized = String(text || '').toLowerCase();
    return /\btab search\b/.test(normalized) &&
      /\b(memory usage|high memory usage)\b/.test(normalized);
  }

  _evaluateRule(rule, record) {
    if (rule.match_type === 'fallback') {
      if (!record.app_name || !record.window_title) {
        return { rule, pattern: '(fallback)' };
      }

      return null;
    }

    for (const pattern of rule.patterns) {
      if (this._matchesPattern(rule.match_type, pattern, record)) {
        return { rule, pattern };
      }
    }

    return null;
  }

  _matchesPattern(matchType, pattern, record) {
    const normalizedPattern = String(pattern || '').trim().toLowerCase();
    if (!normalizedPattern || normalizedPattern === 'user-maintained') {
      return false;
    }

    switch (matchType) {
      case 'domain':
        return this._matchDomain(normalizedPattern, record);
      case 'domain_or_app':
        return this._matchDomain(normalizedPattern, record) || this._matchValue(record.app_name, normalizedPattern);
      case 'app':
      case 'app_only':
        return this._matchValue(record.app_name, normalizedPattern);
      case 'app_or_title':
        return this._matchValue(record.app_name, normalizedPattern) || this._matchValue(record.window_title, normalizedPattern);
      case 'app_plus_text':
        return this._matchValue(record.app_name, normalizedPattern)
          && this._matchValue(`${record.window_title} ${record.ocr_text} ${record.transcript_text}`, normalizedPattern);
      case 'title_or_text':
        return this._matchValue(`${record.window_title} ${record.ocr_text} ${record.transcript_text}`, normalizedPattern);
      default:
        return this._matchValue(`${record.app_name} ${record.window_title} ${record.ocr_text} ${record.transcript_text} ${record.url_if_available}`, normalizedPattern);
    }
  }

  _matchDomain(pattern, record) {
    if (!record.url_if_available && !record.url_host && !record.derived_domains?.length) {
      return false;
    }

    if (record.url_host && this._domainMatches(record.url_host, pattern)) {
      return true;
    }

    if (this._matchValue(record.url_if_available, pattern)) {
      return true;
    }

    return (record.derived_domains || []).some((domain) => this._domainMatches(domain, pattern));
  }

  _recordHasDomain(record, pattern) {
    if (record.url_host && this._domainMatches(record.url_host, pattern)) {
      return true;
    }

    return (record.title_domains || []).some((domain) => this._domainMatches(domain, pattern));
  }

  _recordHasTld(record, tld) {
    const candidates = [record.url_host, ...(record.title_domains || [])].filter(Boolean);
    return candidates.some((domain) => this._domainHasTld(domain, tld));
  }

  _domainMatches(candidate, pattern) {
    const normalizedCandidate = this._normalizeDomain(candidate);
    const normalizedPattern = this._normalizeDomain(pattern);
    if (!normalizedCandidate || !normalizedPattern) {
      return false;
    }

    return normalizedCandidate === normalizedPattern || normalizedCandidate.endsWith(`.${normalizedPattern}`);
  }

  _domainHasTld(candidate, tld) {
    const normalizedCandidate = this._normalizeDomain(candidate);
    const normalizedTld = String(tld || '').trim().toLowerCase().replace(/^\./, '');
    if (!normalizedCandidate || !normalizedTld) {
      return false;
    }

    return normalizedCandidate.split('.').pop() === normalizedTld;
  }

  _matchValue(value, pattern) {
    const candidate = String(value || '').toLowerCase();
    if (!candidate) {
      return false;
    }

    if (pattern.includes('*')) {
      const escaped = pattern
        .replace(/[.+?^${}()|[\]\\]/g, '\\$&')
        .replace(/\*/g, '.*');
      return new RegExp(`^${escaped}$`, 'i').test(candidate);
    }

    return candidate.includes(pattern);
  }

  _extractHost(urlValue) {
    if (!urlValue) {
      return '';
    }

    try {
      return new URL(urlValue).hostname.replace(/^www\./i, '').toLowerCase();
    } catch {
      return '';
    }
  }

  _extractDerivedDomains(text) {
    const domains = new Set();
    const value = String(text || '').toLowerCase();
    const emailPattern = /[a-z0-9._%+-]+@([a-z0-9.-]+\.[a-z]{2,})/gi;
    const domainPattern = /\b((?:[a-z0-9-]+\.)+[a-z]{2,})(?:[/?#:]|$)?/gi;

    for (const match of value.matchAll(emailPattern)) {
      const domain = this._normalizeDomain(match[1]);
      if (domain) {
        domains.add(domain);
      }
    }

    for (const match of value.matchAll(domainPattern)) {
      const domain = this._normalizeDomain(match[1]);
      if (domain) {
        domains.add(domain);
      }
    }

    this._knownServiceDomains(value).forEach((domain) => domains.add(domain));
    return Array.from(domains);
  }

  _knownServiceDomains(text) {
    const services = {
      github: 'github.com',
      gitlab: 'gitlab.com',
      bitbucket: 'bitbucket.org'
    };

    return Object.entries(services)
      .filter(([label]) => new RegExp(`\\b${label}\\b`, 'i').test(text))
      .map(([, domain]) => domain);
  }

  _normalizeDomains(domains = []) {
    return [...new Set((domains || []).map((domain) => this._normalizeDomain(domain)).filter(Boolean))];
  }

  _normalizeTlds(tlds = []) {
    return [...new Set((tlds || [])
      .map((tld) => String(tld || '').trim().toLowerCase().replace(/^\./, ''))
      .filter(Boolean))];
  }

  _normalizeDomain(domain) {
    return String(domain || '')
      .trim()
      .toLowerCase()
      .replace(/^https?:\/\//, '')
      .replace(/^www\./, '')
      .replace(/[:/?#].*$/, '')
      .replace(/^\.+|\.+$/g, '');
  }

  _extractTickValue(line) {
    const match = String(line).match(/`([^`]+)`/);
    return match ? match[1] : '';
  }

  _compareMatches(left, right) {
    const orderDelta = (left.rule.order || 999) - (right.rule.order || 999);
    if (orderDelta !== 0) {
      return orderDelta;
    }

    const confidenceDelta = (CONFIDENCE_WEIGHT[right.rule.confidence] || 0) - (CONFIDENCE_WEIGHT[left.rule.confidence] || 0);
    if (confidenceDelta !== 0) {
      return confidenceDelta;
    }

    const specificityDelta = (MATCH_TYPE_WEIGHT[right.rule.match_type] || 0) - (MATCH_TYPE_WEIGHT[left.rule.match_type] || 0);
    if (specificityDelta !== 0) {
      return specificityDelta;
    }

    return left.rule.id.localeCompare(right.rule.id);
  }

  _isTie(left, right) {
    return (
      left.rule.order === right.rule.order &&
      left.rule.confidence === right.rule.confidence &&
      left.rule.match_type === right.rule.match_type
    );
  }

  _ruleOrder(ruleId) {
    const entry = Object.entries(RULE_ORDER).find(([prefix]) => ruleId.startsWith(prefix));
    return entry ? entry[1] : 80;
  }

  _matchDetail(candidate) {
    return {
      id: candidate.rule.id,
      classification: candidate.rule.classification,
      confidence: candidate.rule.confidence,
      match_type: candidate.rule.match_type,
      pattern: candidate.pattern
    };
  }
}

module.exports = { WorkClassificationService };
