const TERMINAL_APP_PATTERN = /\b(windowsterminal|terminal|powershell|pwsh|cmd)(?:\.exe)?\b/i;
const GENERIC_TERMINAL_TITLE_PATTERN = /^(?:windows powershell|powershell|terminal|cmd|command prompt|c:\\windows\\system32\\cmd\.exe)$/i;

function normalizeWindowTitle(value = '') {
  return String(value || '')
    .trim()
    .replace(/\s+/g, ' ')
    .replace(/^[\u2800-\u28ff]+\s*/u, '')
    .replace(/^[✳✱✲✶✹✺✻✼✽✾✿❋❖]+\s*/u, '')
    .replace(/^\[\s*[!.?*+\-xX]\s*\]\s*/u, '')
    .replace(/^action required\s*\|\s*/i, '')
    .trim();
}

function isTerminalAppName(appName = '') {
  return TERMINAL_APP_PATTERN.test(String(appName || '').replace(/\.exe$/i, ''));
}

function isGenericTerminalTitle(value = '') {
  return GENERIC_TERMINAL_TITLE_PATTERN.test(normalizeWindowTitle(value));
}

function meaningfulWindowTitle(record = {}) {
  const title = normalizeWindowTitle(record.window_title || record.window_name || record.title || '');
  if (isTerminalAppName(record.app_name) && isGenericTerminalTitle(title)) {
    return '';
  }
  return title;
}

module.exports = {
  normalizeWindowTitle,
  isTerminalAppName,
  isGenericTerminalTitle,
  meaningfulWindowTitle
};
