# Screenpipe Discovery Report (Phase 0)

Date: 2026-04-24 (UTC)

## Discovery method

- Attempted to clone latest repo: `git clone --depth 1 https://github.com/mediar-ai/screenpipe.git /tmp/screenpipe`.
- In this environment the GitHub clone path was blocked (`CONNECT tunnel failed, response 403`), so discovery used official Screenpipe docs and linked GitHub metadata.
- Source docs: https://docs.screenpi.pe and https://github.com/screenpipe/screenpipe.

## 1) Windows installation process

1. Preferred: install Screenpipe desktop app from screenpi.pe download page.
2. CLI path: `npx screenpipe@latest record`.
3. If CLI-only on Windows: install .NET 8 runtime if missing.

## 2) Start/stop locally

- Start recorder daemon: `npx screenpipe@latest record`.
- Health check: `curl http://127.0.0.1:3030/health`.
- API indicates audio start/stop endpoints:
  - `POST /audio/start`
  - `POST /audio/stop`
- Desktop app also controls start/stop.

## 3) APIs / CLI / SDK / ports / DB access

- Local REST API hosted on `127.0.0.1:3030`.
- Key endpoints in docs:
  - `GET /search`
  - `GET /search/keyword`
  - `GET /health`
  - `GET /frames/{id}` and `GET /frames/{id}/ocr`
  - `POST /raw_sql`
  - pipes endpoints (`/pipes`, `/pipes/{id}/run`, etc.)
- MCP integration:
  - stdio server: `npx -y screenpipe-mcp`
  - http transport: `npx -y screenpipe-mcp-http --port 3031`

## 4) Data captured

Screenpipe docs describe capture of:
- screenshots/frames (event-driven, not fixed FPS)
- OCR text
- accessibility text
- audio + transcriptions
- app/window activity
- browser URLs
- input events (typing/click/scroll/clipboard)
- timestamps and metadata

## 5) Storage location and format

- Local by default in `~/.screenpipe/`
- SQLite database: `~/.screenpipe/db.sqlite`
- Media files: `~/.screenpipe/data/` (e.g., JPEG frames, audio chunks)

## 6) Query/search capability

- Primary: `GET /search`
- Supports content type filters (`vision/ocr/audio/input/all` depending on interface).
- Supports app/window/url and time-range filtering (`start_time`, `end_time`).
- Keyword search endpoint: `GET /search/keyword`.

## 7) Plugin/pipe architecture

- Pipes are scheduled automations defined by markdown at `~/.screenpipe/pipes/<name>/pipe.md`.
- Pipes can be installed/managed from UI or local API.
- Pipe permissions model supports presets (`reader`, `writer`, `admin`) and custom allow/deny rules.

## 8) Known Windows limitations

From docs/troubleshooting:
- CLI may require .NET runtime when not using packaged desktop app.
- OCR/transcription throughput can lag on slower hardware.
- Port 3030 conflicts can prevent startup.
- Permission setup and device selection can cause “running but no capture” states.

## 9) Required permissions

- Screen recording permission.
- Microphone permission (if audio capture enabled).
- Device/monitor selection configured in app.

## 10) Best integration approach for external assistant

Recommended order:
1. Integrate via local REST API on `127.0.0.1:3030` for stability.
2. Optionally support MCP for LLM-tooling ecosystems.
3. Keep a dedicated `ScreenpipeAdapter` abstraction in assistant app.
4. Use text-first context (`ocr/accessibility/transcript/metadata`) and avoid screenshot upload by default.
5. Keep deletion/pause actions explicit and audited.

## Notes on uncertainty

Because direct source clone was blocked in this environment, endpoint and behavior details were validated from official docs, not from local source compilation.
