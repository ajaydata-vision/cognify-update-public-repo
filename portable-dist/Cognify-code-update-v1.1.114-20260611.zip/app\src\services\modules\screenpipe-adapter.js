const { execSync } = require('child_process');

const DEFAULT_SCREENPIPE_API_KEY = 'cognify-local-screenpipe-token';
const DEFAULT_QUERY_BUDGET_MS = 45000;
const DEFAULT_MAX_QUERY_WINDOWS = 120;

class ScreenpipeAdapter {
  constructor(settings) {
    this.baseUrl = settings.screenpipeBaseUrl || 'http://127.0.0.1:3030';
    this.apiKey = settings.screenpipeApiKey || process.env.SCREENPIPE_API_KEY || DEFAULT_SCREENPIPE_API_KEY;
    this.timeoutMs = 6000;
    this.lastError = null;
    this.statusCache = null;
    this.statusInFlight = null;
    this.searchStatusCache = null;
    this.searchStatusInFlight = null;
    this._installedCachedResult = undefined;
    this._healthFailureCount = 0;
  }

  updateSettings(settings = {}) {
    this.baseUrl = settings.screenpipeBaseUrl || this.baseUrl;
    this.apiKey = settings.screenpipeApiKey || process.env.SCREENPIPE_API_KEY || this.apiKey;
    this.invalidateStatusCache();
  }

  async getStatus({ force = false, verifySearch = false } = {}) {
    const nowMs = Date.now();
    if (!force && !verifySearch && this.statusCache && (nowMs - this.statusCache.createdAtMs) < 15000) {
      return this.statusCache.value;
    }

    if (!force && !verifySearch && this.statusInFlight) {
      return this.statusInFlight;
    }

    const promise = (async () => {
      const health = await this._safeFetch('/health');
      // Track consecutive failures so a single timeout (e.g. during Screenpipe
      // snapshot compaction which saturates CPU for 1-10s) does not immediately
      // show the health indicator as offline. Two consecutive failures required
      // before reporting unavailable — compaction never outlasts two 15s cycles.
      if (health) {
        this._healthFailureCount = 0;
      } else {
        this._healthFailureCount += 1;
      }
      const apiAvailable = !!health || this._healthFailureCount < 2;
      const searchStatus = apiAvailable
        ? await this._searchStatus({ force, verify: verifySearch })
        : { verified: false, ok: false, pending: false, error: this.lastError };
      const value = {
        installed: this._detectInstalled(),
        running: apiAvailable,
        apiAvailable,
        recording: apiAvailable,
        baseUrl: this.baseUrl,
        apiAuthenticated: searchStatus.ok,
        searchVerified: searchStatus.verified,
        searchPending: searchStatus.pending,
        searchLastCheckedAt: searchStatus.checkedAt || null,
        lastError: this.lastError,
        searchError: searchStatus.error || null,
        details: health || { message: 'Cognify capture API unreachable' }
      };
      this.statusCache = { createdAtMs: Date.now(), value };
      return value;
    })();

    this.statusInFlight = promise;
    try {
      return await promise;
    } finally {
      if (this.statusInFlight === promise) {
        this.statusInFlight = null;
      }
    }
  }

  getCachedStatus() {
    return this.statusCache?.value || {
      installed: null,
      running: false,
      apiAvailable: false,
      recording: false,
      baseUrl: this.baseUrl,
      apiAuthenticated: false,
      searchVerified: false,
      searchPending: true,
      searchLastCheckedAt: null,
      lastError: this.lastError,
      searchError: null,
      details: { message: 'Capture status has not been checked yet' },
      pending: true
    };
  }

  invalidateStatusCache() {
    this.statusCache = null;
    this.statusInFlight = null;
    this.searchStatusCache = null;
    this.searchStatusInFlight = null;
    this._healthFailureCount = 0;
  }

  async queryActivity({ startTime, endTime, limit = 200, contentType = 'all', timeoutMs = null }) {
    const query = new URLSearchParams({
      limit: String(limit),
      content_type: contentType,
      start_time: startTime,
      end_time: endTime
    });
    const fetchOptions = Number.isFinite(Number(timeoutMs)) ? { timeoutMs: Number(timeoutMs) } : {};
    const response = await this._safeFetch(`/search?${query.toString()}`, {}, fetchOptions);
    if (!response) {
      return null;
    }
    return response?.data || response?.results || [];
  }

  async getActivitySummary({ startTime, endTime, appName } = {}) {
    const query = new URLSearchParams();
    if (startTime) query.set('start_time', startTime);
    if (endTime) query.set('end_time', endTime);
    if (appName) query.set('app_name', appName);
    const suffix = query.toString() ? `?${query.toString()}` : '';
    return this._safeFetch(`/activity-summary${suffix}`);
  }

  async listAudioDevices() {
    const response = await this._safeFetch('/audio/list');
    return Array.isArray(response) ? response : [];
  }

  async _searchStatus({ force = false, verify = false } = {}) {
    const nowMs = Date.now();
    if (!verify && !force && this.searchStatusCache && (nowMs - this.searchStatusCache.createdAtMs) < (5 * 60 * 1000)) {
      return this.searchStatusCache.value;
    }
    if (!verify) {
      return this.searchStatusCache?.value || { verified: false, ok: false, pending: true, error: null };
    }
    if (this.searchStatusInFlight) {
      return this.searchStatusInFlight;
    }

    const promise = (async () => {
      const end = new Date();
      const start = new Date(end.getTime() - (15 * 60 * 1000));
      const query = new URLSearchParams({
        limit: '1',
        content_type: 'all',
        start_time: start.toISOString(),
        end_time: end.toISOString()
      });
      const response = await this._safeFetch(`/search?${query.toString()}`, {}, { timeoutMs: 1500 });
      const value = {
        verified: true,
        ok: Array.isArray(response?.data) || Array.isArray(response?.results),
        pending: false,
        checkedAt: new Date().toISOString(),
        error: this.lastError
      };
      this.searchStatusCache = { createdAtMs: Date.now(), value };
      return value;
    })();

    this.searchStatusInFlight = promise;
    try {
      return await promise;
    } finally {
      if (this.searchStatusInFlight === promise) {
        this.searchStatusInFlight = null;
      }
    }
  }

  async queryActivityChunked({
    startTime,
    endTime,
    limit = 500,
    contentType = 'all',
    chunkMinutes = 60,
    minChunkMinutes = 1,
    maxDurationMs = DEFAULT_QUERY_BUDGET_MS,
    maxWindows = DEFAULT_MAX_QUERY_WINDOWS
  }) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return { records: [], windows: [] };
    }

    const stepMs = Math.max(5, chunkMinutes) * 60 * 1000;
    const records = [];
    const windows = [];
    const requestedMaxDurationMs = Number(maxDurationMs);
    const requestedMaxWindows = Number(maxWindows);
    const budget = {
      startedAtMs: Date.now(),
      maxDurationMs: Number.isFinite(requestedMaxDurationMs)
        ? Math.max(1000, requestedMaxDurationMs)
        : DEFAULT_QUERY_BUDGET_MS,
      maxWindows: Number.isFinite(requestedMaxWindows)
        ? Math.max(1, requestedMaxWindows)
        : DEFAULT_MAX_QUERY_WINDOWS,
      windowCount: 0,
      exhaustedReason: null
    };

    for (let cursorMs = startMs; cursorMs <= endMs; cursorMs += stepMs) {
      if (this._queryBudgetExhausted(budget)) {
        windows.push(this._budgetWindow(cursorMs, endMs, limit, budget, 0));
        break;
      }

      const chunkEndMs = Math.min(endMs, cursorMs + stepMs - 1);
      const result = await this._queryChunkWindow({
        startMs: cursorMs,
        endMs: chunkEndMs,
        limit,
        contentType,
        minChunkMinutes,
        depth: 0,
        budget
      });

      records.push(...result.records);
      windows.push(...result.windows);
    }

    return { records, windows };
  }


  async getRecentActivity(hours = 2) {
    const end = new Date();
    const start = new Date(end.getTime() - (hours * 60 * 60 * 1000));
    return this.queryActivityChunked({
      startTime: start.toISOString(),
      endTime: end.toISOString(),
      limit: 500,
      contentType: 'all'
    });
  }

  async _queryChunkWindow({ startMs, endMs, limit, contentType, minChunkMinutes, depth, budget }) {
    if (this._queryBudgetExhausted(budget)) {
      return {
        records: [],
        windows: [this._budgetWindow(startMs, endMs, limit, budget, depth)]
      };
    }

    const startTime = new Date(startMs).toISOString();
    const endTime = new Date(endMs).toISOString();
    const timeoutMs = this._queryFetchTimeoutMs(budget);
    if (timeoutMs <= 0) {
      budget.exhaustedReason = 'time_budget';
      return {
        records: [],
        windows: [this._budgetWindow(startMs, endMs, limit, budget, depth)]
      };
    }
    budget.windowCount += 1;
    const batch = await this.queryActivity({ startTime, endTime, limit, contentType, timeoutMs });
    const fetchFailed = !Array.isArray(batch);
    const records = Array.isArray(batch) ? batch : [];
    const durationMinutes = Math.max(1, Math.ceil((endMs - startMs + 1) / 60000));
    const limitHit = records.length >= limit;
    const canSplit = limitHit && durationMinutes > Math.max(1, minChunkMinutes);

    if (canSplit && this._queryBudgetExhausted(budget)) {
      return {
        records,
        windows: [this._budgetWindow(startMs, endMs, limit, budget, depth, {
          fetchedCount: records.length,
          limitHit
        })]
      };
    }

    if (canSplit) {
      const midMs = startMs + Math.floor((endMs - startMs) / 2);
      const left = await this._queryChunkWindow({
        startMs,
        endMs: midMs,
        limit,
        contentType,
        minChunkMinutes,
        depth: depth + 1,
        budget
      });
      const right = await this._queryChunkWindow({
        startMs: midMs + 1,
        endMs,
        limit,
        contentType,
        minChunkMinutes,
        depth: depth + 1,
        budget
      });

      return {
        records: [...left.records, ...right.records],
        windows: [...left.windows, ...right.windows]
      };
    }

    return {
      records,
      windows: [{
        start_time: startTime,
        end_time: endTime,
        fetched_count: records.length,
        limit,
        limit_hit: limitHit,
        complete: !limitHit && !fetchFailed,
        fetch_failed: fetchFailed,
        depth
      }]
    };
  }

  _queryBudgetExhausted(budget = {}) {
    if (!budget) {
      return false;
    }
    if (budget.windowCount >= budget.maxWindows) {
      budget.exhaustedReason = 'window_budget';
      return true;
    }
    if ((Date.now() - budget.startedAtMs) >= budget.maxDurationMs) {
      budget.exhaustedReason = 'time_budget';
      return true;
    }
    return false;
  }

  _queryFetchTimeoutMs(budget = {}) {
    if (!budget || !Number.isFinite(Number(budget.maxDurationMs))) {
      return this.timeoutMs;
    }
    const elapsedMs = Date.now() - Number(budget.startedAtMs || Date.now());
    const remainingMs = Number(budget.maxDurationMs) - elapsedMs;
    if (remainingMs <= 100) {
      return 0;
    }
    return Math.max(100, Math.min(this.timeoutMs, remainingMs));
  }

  _budgetWindow(startMs, endMs, limit, budget = {}, depth = 0, options = {}) {
    return {
      start_time: new Date(startMs).toISOString(),
      end_time: new Date(endMs).toISOString(),
      fetched_count: Number(options.fetchedCount || 0),
      limit,
      limit_hit: Boolean(options.limitHit),
      complete: false,
      fetch_failed: true,
      depth,
      budget_exhausted: true,
      budget_reason: budget.exhaustedReason || 'query_budget'
    };
  }

  async pause() {
    return this._safeFetch('/audio/stop', { method: 'POST' });
  }

  async resume() {
    return this._safeFetch('/audio/start', { method: 'POST' });
  }

  getSetupInstructions() {
    return [
      "Install the Cognify capture service (recommended) or run: npx screenpipe@latest record",
      `Ensure the Cognify capture API is reachable at ${this.baseUrl}/health`,
      "Grant screen recording and microphone permissions in Windows settings",
      "If CLI mode fails on Windows, install .NET 8 runtime"
    ];
  }

  async getCapabilities() {
    return {
      supportsSearch: true,
      supportsPauseResume: true,
      supportsDeleteRange: true,
      transport: 'rest',
      baseUrl: this.baseUrl
    };
  }

  async deleteRange({ startTime, endTime }) {
    return this._safeFetch('/data/delete-range', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ start_time: startTime, end_time: endTime })
    });
  }

  _detectInstalled() {
    if (this._installedCachedResult !== undefined) {
      return this._installedCachedResult;
    }
    try {
      if (process.platform === 'win32') {
        execSync('where screenpipe', { stdio: 'ignore' });
      } else {
        execSync('command -v screenpipe', { stdio: 'ignore' });
      }
      this._installedCachedResult = true;
    } catch {
      this._installedCachedResult = false;
    }
    return this._installedCachedResult;
  }

  async _safeFetch(path, options = {}, fetchOptions = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), Number(fetchOptions.timeoutMs || this.timeoutMs));
    const headers = { ...(options.headers || {}) };

    if (this.apiKey) {
      headers.Authorization = `Bearer ${this.apiKey}`;
    }

    try {
      const response = await fetch(`${this.baseUrl}${path}`, {
        ...options,
        headers,
        signal: controller.signal
      });
      if (!response.ok) {
        const body = await response.text().catch(() => '');
        this.lastError = {
          path,
          status: response.status,
          message: body.slice(0, 500)
        };
        return null;
      }
      this.lastError = null;
      return response.json().catch(() => ({}));
    } catch {
      this.lastError = {
        path,
        status: 0,
        message: 'Request failed or timed out'
      };
      return null;
    } finally {
      clearTimeout(timeout);
    }
  }
}

module.exports = { ScreenpipeAdapter };
