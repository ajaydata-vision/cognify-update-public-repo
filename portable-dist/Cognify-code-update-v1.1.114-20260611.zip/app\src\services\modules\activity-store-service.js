const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { normalizeActivity } = require('./activity-schema');

const MAX_RECORD_OVERLAP_LOOKBACK_MS = 12 * 60 * 60 * 1000;

class ActivityStoreService {
  constructor(storagePath) {
    this.basePath = path.join(storagePath, 'activity-store');
    this.syncStatePath = path.join(this.basePath, 'sync-state.json');
    this.tombstonePath = path.join(this.basePath, 'deletion-tombstones.json');
    fs.mkdirSync(this.basePath, { recursive: true });
  }

  ingest(records = []) {
    if (!Array.isArray(records) || records.length === 0) {
      return { inserted: 0, deduped: 0, replaced: 0 };
    }

    const normalized = records
      .map((record) => this._prepareRecord(record))
      .filter((record) => record && record.timestamp_start);
    const tombstones = this._loadTombstones();
    const allowed = normalized.filter((record) => !this._isRecordDeleted(record, tombstones));
    const skippedDeleted = normalized.length - allowed.length;

    const byDay = new Map();
    allowed.forEach((record) => {
      const day = String(record.timestamp_start).slice(0, 10);
      if (!byDay.has(day)) {
        byDay.set(day, []);
      }
      byDay.get(day).push(record);
    });

    let inserted = 0;
    let deduped = 0;
    let replaced = 0;

    byDay.forEach((dayRecords, day) => {
      const existingRecords = this._loadDayRecords(day);
      const byKey = new Map(existingRecords.map((record) => [record.record_key, record]));
      let changed = false;

      dayRecords.forEach((record) => {
        const existing = byKey.get(record.record_key);
        if (!existing) {
          byKey.set(record.record_key, record);
          inserted += 1;
          changed = true;
          return;
        }

        if (this._shouldReplace(existing, record)) {
          byKey.set(record.record_key, record);
          replaced += 1;
          changed = true;
          return;
        }

        if (existing) {
          deduped += 1;
        }
      });

      if (changed) {
        const nextRecords = Array.from(byKey.values())
          .sort((a, b) => new Date(a.timestamp_start).getTime() - new Date(b.timestamp_start).getTime());
        this._rewriteDay(day, nextRecords);
      }
    });

    return { inserted, deduped, replaced, skipped_deleted: skippedDeleted };
  }

  queryRange(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return [];
    }

    const lookupStartMs = overlapLookupStartMs(startMs);
    const days = this._daysInRange(lookupStartMs, endMs);
    const results = [];

    days.forEach((day) => {
      const filePath = this._dayFilePath(day);
      if (!fs.existsSync(filePath)) {
        return;
      }

      const lines = fs.readFileSync(filePath, 'utf8').split('\n').filter(Boolean);
      lines.forEach((line) => {
        try {
          const record = JSON.parse(line);
          if (recordOverlapsRange(record, startMs, endMs)) {
            results.push(record);
          }
        } catch {
          // Skip malformed rows.
        }
      });
    });

    return this.filterDeletedRecords(results)
      .sort((a, b) => new Date(a.timestamp_start).getTime() - new Date(b.timestamp_start).getTime());
  }

  queryRangeLite(startTime, endTime) {
    return this.queryRange(startTime, endTime).map((record) => toLiteRecord(record));
  }

  deleteRange(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return { deleted: 0, touched_days: 0 };
    }

    const lookupStartMs = overlapLookupStartMs(startMs);
    const days = this._daysInRange(lookupStartMs, endMs);
    let deleted = 0;
    let touchedDays = 0;

    days.forEach((day) => {
      const filePath = this._dayFilePath(day);
      if (!fs.existsSync(filePath)) {
        return;
      }

      const keptRecords = [];
      const lines = fs.readFileSync(filePath, 'utf8').split('\n').filter(Boolean);
      lines.forEach((line) => {
        try {
          const record = JSON.parse(line);
          if (recordOverlapsRange(record, startMs, endMs)) {
            deleted += 1;
            return;
          }

          keptRecords.push(record);
        } catch {
          deleted += 1;
        }
      });

      this._rewriteDay(day, keptRecords);
      touchedDays += 1;
    });

    this._removeSyncWindowsInRange(startMs, endMs);
    this._addTombstone(startTime, endTime, startMs, endMs);
    return { deleted, touched_days: touchedDays, tombstoned: true };
  }

  filterDeletedRecords(records = []) {
    if (!Array.isArray(records) || records.length === 0) {
      return [];
    }

    const tombstones = this._loadTombstones();
    if (!tombstones.length) {
      return records;
    }

    return records.filter((record) => !this._isRecordDeleted(record, tombstones));
  }

  recordSyncWindows(windows = []) {
    if (!Array.isArray(windows) || windows.length === 0) {
      return { updated: 0 };
    }

    const state = this._loadSyncState();
    let updated = 0;

    windows.forEach((window) => {
      if (!window?.start_time || !window?.end_time) {
        return;
      }

      const key = `${window.start_time}|${window.end_time}`;
      state[key] = {
        start_time: window.start_time,
        end_time: window.end_time,
        fetched_count: window.fetched_count || 0,
        limit: window.limit || 0,
        limit_hit: Boolean(window.limit_hit),
        complete: Boolean(window.complete),
        fetch_failed: Boolean(window.fetch_failed),
        depth: window.depth || 0,
        updated_at: new Date().toISOString()
      };
      updated += 1;
    });

    this._saveSyncState(state);
    return { updated };
  }

  getSyncSummary(startTime, endTime) {
    const startMs = new Date(startTime).getTime();
    const endMs = new Date(endTime).getTime();

    if (!Number.isFinite(startMs) || !Number.isFinite(endMs) || endMs < startMs) {
      return {
        complete: false,
        incomplete_window_count: 0,
        windows: []
      };
    }

    const state = this._loadSyncState();
    const windows = Object.values(state)
      .filter((window) => this._overlaps(window.start_time, window.end_time, startMs, endMs))
      .sort((a, b) => new Date(a.start_time).getTime() - new Date(b.start_time).getTime());

    const incompleteCount = windows.filter((window) => !window.complete).length;
    return {
      complete: windows.length > 0 && incompleteCount === 0,
      incomplete_window_count: incompleteCount,
      windows
    };
  }

  prune(cutoffMs) {
    if (!Number.isFinite(cutoffMs) || !fs.existsSync(this.basePath)) {
      return { prunedFiles: 0, prunedSyncWindows: 0 };
    }

    const cutoffDay = new Date(cutoffMs).toISOString().slice(0, 10);
    const files = fs.readdirSync(this.basePath);
    let prunedFiles = 0;

    files.forEach((name) => {
      const match = name.match(/^(\d{4}-\d{2}-\d{2})\.(jsonl|index\.json)$/);
      if (!match) {
        return;
      }

      if (match[1] < cutoffDay) {
        fs.unlinkSync(path.join(this.basePath, name));
        prunedFiles += 1;
      }
    });

    const prunedSyncWindows = this._pruneSyncWindows(cutoffMs);
    return { prunedFiles, prunedSyncWindows };
  }

  _prepareRecord(record) {
    const normalized = normalizeActivity(record);
    if (!normalized.timestamp_start) {
      return null;
    }

    const interval = recordIntervalMs(normalized);
    const timestampEnd = normalized.timestamp_end || (
      Number.isFinite(interval.startMs) &&
      Number.isFinite(interval.endMs) &&
      interval.endMs > interval.startMs
        ? new Date(interval.endMs).toISOString()
        : normalized.timestamp_end
    );
    const nextRecord = {
      ...normalized,
      timestamp_end: timestampEnd
    };
    return {
      ...nextRecord,
      record_key: this._recordKey(nextRecord)
    };
  }

  _recordKey(record) {
    if (record.id) {
      return `${record.source}:${record.id}`;
    }

    return crypto
      .createHash('sha1')
      .update(JSON.stringify([
        record.timestamp_start,
        record.timestamp_end,
        record.app_name,
        record.window_title,
        record.url_if_available,
        record.activity_type,
        record.ocr_text,
        record.transcript_text
      ]))
      .digest('hex');
  }

  _dayFilePath(day) {
    return path.join(this.basePath, `${day}.jsonl`);
  }

  _dayIndexPath(day) {
    return path.join(this.basePath, `${day}.index.json`);
  }

  _loadDayIndex(day) {
    const filePath = this._dayIndexPath(day);
    if (!fs.existsSync(filePath)) {
      return new Set();
    }

    try {
      const values = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      return new Set(Array.isArray(values) ? values : []);
    } catch {
      return new Set();
    }
  }

  _loadDayRecords(day) {
    const filePath = this._dayFilePath(day);
    if (!fs.existsSync(filePath)) {
      return [];
    }

    return fs.readFileSync(filePath, 'utf8')
      .split('\n')
      .filter(Boolean)
      .map((line) => {
        try {
          return JSON.parse(line);
        } catch {
          return null;
        }
      })
      .filter(Boolean);
  }

  _saveDayIndex(day, seen) {
    fs.writeFileSync(this._dayIndexPath(day), JSON.stringify(Array.from(seen)), 'utf8');
  }

  _shouldReplace(existing, incoming) {
    const incomingScore = this._recordRichness(incoming);
    const existingScore = this._recordRichness(existing);
    if (incomingScore !== existingScore) {
      return incomingScore > existingScore;
    }

    const incomingEnd = recordIntervalMs(incoming).endMs;
    const existingEnd = recordIntervalMs(existing).endMs;
    if (Number.isFinite(incomingEnd) && Number.isFinite(existingEnd) && incomingEnd !== existingEnd) {
      return incomingEnd > existingEnd;
    }

    const incomingStart = new Date(incoming.timestamp_start).getTime();
    const existingStart = new Date(existing.timestamp_start).getTime();
    if (Number.isFinite(incomingStart) && Number.isFinite(existingStart) && incomingStart !== existingStart) {
      return incomingStart > existingStart;
    }

    return false;
  }

  _recordRichness(record = {}) {
    let score = 0;
    if (record.app_name) score += 3;
    if (record.window_title) score += 2;
    if (record.url_if_available) score += 2;
    if (record.ocr_text) score += 1;
    if (record.transcript_text) score += 1;
    return score;
  }

  _rewriteDay(day, records) {
    const filePath = this._dayFilePath(day);
    const indexPath = this._dayIndexPath(day);

    if (!records.length) {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
      if (fs.existsSync(indexPath)) {
        fs.unlinkSync(indexPath);
      }
      return;
    }

    fs.writeFileSync(filePath, `${records.map((record) => JSON.stringify(record)).join('\n')}\n`, 'utf8');
    fs.writeFileSync(indexPath, JSON.stringify(records.map((record) => record.record_key)), 'utf8');
  }

  _loadSyncState() {
    if (!fs.existsSync(this.syncStatePath)) {
      return {};
    }

    try {
      const data = JSON.parse(fs.readFileSync(this.syncStatePath, 'utf8'));
      return data && typeof data === 'object' ? data : {};
    } catch {
      return {};
    }
  }

  _saveSyncState(state) {
    fs.writeFileSync(this.syncStatePath, JSON.stringify(state, null, 2), 'utf8');
  }

  _loadTombstones() {
    if (!fs.existsSync(this.tombstonePath)) {
      return [];
    }

    try {
      const values = JSON.parse(fs.readFileSync(this.tombstonePath, 'utf8'));
      return Array.isArray(values)
        ? values.filter((item) => Number.isFinite(Number(item?.start_ms)) && Number.isFinite(Number(item?.end_ms)))
        : [];
    } catch {
      return [];
    }
  }

  _saveTombstones(tombstones) {
    fs.writeFileSync(this.tombstonePath, JSON.stringify(tombstones, null, 2), 'utf8');
  }

  _addTombstone(startTime, endTime, startMs, endMs) {
    const tombstones = this._loadTombstones();
    tombstones.push({
      start_time: startTime,
      end_time: endTime,
      start_ms: startMs,
      end_ms: endMs,
      created_at: new Date().toISOString(),
      reason: 'user_delete_range'
    });
    this._saveTombstones(this._mergeTombstones(tombstones));
  }

  _mergeTombstones(tombstones) {
    return tombstones
      .map((item) => ({
        ...item,
        start_ms: Number(item.start_ms),
        end_ms: Number(item.end_ms)
      }))
      .filter((item) => Number.isFinite(item.start_ms) && Number.isFinite(item.end_ms) && item.end_ms >= item.start_ms)
      .sort((left, right) => left.start_ms - right.start_ms)
      .reduce((merged, item) => {
        const previous = merged[merged.length - 1];
        if (previous && item.start_ms <= previous.end_ms + 1) {
          previous.end_ms = Math.max(previous.end_ms, item.end_ms);
          previous.end_time = new Date(previous.end_ms).toISOString();
          return merged;
        }
        merged.push(item);
        return merged;
      }, []);
  }

  _isRecordDeleted(record, tombstones) {
    const interval = recordIntervalMs(record);
    if (!Number.isFinite(interval.startMs) || !Number.isFinite(interval.endMs)) {
      return false;
    }
    return tombstones.some((item) => interval.startMs <= Number(item.end_ms) && interval.endMs >= Number(item.start_ms));
  }

  _pruneSyncWindows(cutoffMs) {
    const state = this._loadSyncState();
    let changed = 0;

    Object.entries(state).forEach(([key, window]) => {
      const endMs = new Date(window.end_time).getTime();
      if (!Number.isFinite(endMs) || endMs < cutoffMs) {
        delete state[key];
        changed += 1;
      }
    });

    if (changed > 0) {
      this._saveSyncState(state);
    }

    return changed;
  }

  _removeSyncWindowsInRange(startMs, endMs) {
    const state = this._loadSyncState();
    let changed = 0;

    Object.entries(state).forEach(([key, window]) => {
      if (this._overlaps(window.start_time, window.end_time, startMs, endMs)) {
        delete state[key];
        changed += 1;
      }
    });

    if (changed > 0) {
      this._saveSyncState(state);
    }
  }

  _overlaps(windowStart, windowEnd, startMs, endMs) {
    const windowStartMs = new Date(windowStart).getTime();
    const windowEndMs = new Date(windowEnd).getTime();

    if (!Number.isFinite(windowStartMs) || !Number.isFinite(windowEndMs)) {
      return false;
    }

    return windowStartMs <= endMs && windowEndMs >= startMs;
  }

  _daysInRange(startMs, endMs) {
    const days = [];
    const cursor = new Date(startMs);
    cursor.setUTCHours(0, 0, 0, 0);
    const end = new Date(endMs);
    end.setUTCHours(0, 0, 0, 0);

    while (cursor.getTime() <= end.getTime()) {
      days.push(cursor.toISOString().slice(0, 10));
      cursor.setUTCDate(cursor.getUTCDate() + 1);
    }

    return days;
  }
}

function overlapLookupStartMs(startMs) {
  return startMs - MAX_RECORD_OVERLAP_LOOKBACK_MS;
}

function toLiteRecord(record = {}) {
  return {
    source: record.source,
    id: record.id,
    record_key: record.record_key,
    timestamp_start: record.timestamp_start || null,
    timestamp_end: record.timestamp_end || null,
    duration_ms_estimate: record.duration_ms_estimate ?? null,
    app_name: record.app_name || '',
    window_title: record.window_title || '',
    url_if_available: record.url_if_available || '',
    url_host: record.url_host || '',
    activity_type: record.activity_type || '',
    classification: record.classification || '',
    meeting_flag: Boolean(record.meeting_flag),
    social_flag: Boolean(record.social_flag),
    type: record.type,
    created_at: record.created_at,
    updated_at: record.updated_at
  };
}

function recordOverlapsRange(record, startMs, endMs) {
  const interval = recordIntervalMs(record);
  if (!Number.isFinite(interval.startMs) || !Number.isFinite(interval.endMs)) {
    return false;
  }
  return interval.startMs <= endMs && interval.endMs >= startMs;
}

function recordIntervalMs(record = {}) {
  const startMs = new Date(record.timestamp_start || record.timestamp || record.timestamp_end || 0).getTime();
  if (!Number.isFinite(startMs)) {
    return { startMs: Number.NaN, endMs: Number.NaN };
  }

  const explicitEndMs = new Date(record.timestamp_end || 0).getTime();
  const durationMs = Number(record.duration_ms_estimate || 0);
  let endMs = Number.isFinite(explicitEndMs) ? explicitEndMs : startMs;
  if (shouldUseDurationEnd(record) && durationMs > 0) {
    endMs = Math.max(endMs, startMs + durationMs);
  }
  if (!Number.isFinite(endMs) || endMs < startMs) {
    endMs = startMs;
  }
  return { startMs, endMs };
}

function shouldUseDurationEnd(record = {}) {
  const source = String(record.source || '').toLowerCase();
  const activityType = String(record.activity_type || record.type || '').toLowerCase();
  return (
    source === 'manual' ||
    activityType === 'manual' ||
    source === 'windows_focus_evidence' ||
    activityType === 'focus_evidence'
  );
}

module.exports = { ActivityStoreService };
