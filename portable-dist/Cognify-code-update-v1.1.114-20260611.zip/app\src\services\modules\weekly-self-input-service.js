const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class WeeklySelfInputService {
  constructor(storagePath) {
    this.filePath = path.join(storagePath, 'weekly-self-input.json');
    this.items = this._load();
  }

  getWeek(weekStart) {
    const key = weekKey(weekStart);
    return this.items.find((item) => item.week_start === key) || null;
  }

  saveWeek(payload = {}) {
    const key = weekKey(payload.week_start || payload.weekStart || Date.now());
    const now = new Date().toISOString();
    const next = {
      id: `weekly-self-input-${key}`,
      week_start: key,
      completed_tasks: listFromText(payload.completed_tasks || payload.completedTasks),
      blockers: listFromText(payload.blockers),
      offline_work: String(payload.offline_work || payload.offlineWork || '').trim().slice(0, 2000),
      deadline_work: String(payload.deadline_work || payload.deadlineWork || '').trim().slice(0, 2000),
      misread_context: String(payload.misread_context || payload.misreadContext || '').trim().slice(0, 2000),
      updated_at: now
    };
    const existing = this.items.findIndex((item) => item.week_start === key);
    if (existing >= 0) {
      next.created_at = this.items[existing].created_at || now;
      this.items[existing] = next;
    } else {
      next.created_at = now;
      this.items.push(next);
    }
    this.items.sort((left, right) => right.week_start.localeCompare(left.week_start));
    this._save();
    return { self_input: next, items: this.items.slice(0, 20) };
  }

  list(limit = 20) {
    return { items: this.items.slice(0, Math.max(1, Math.min(100, Number(limit) || 20))) };
  }

  hash() {
    return crypto.createHash('sha256').update(JSON.stringify(this.items)).digest('hex');
  }

  _load() {
    if (!fs.existsSync(this.filePath)) {
      return [];
    }
    try {
      const parsed = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  _save() {
    fs.writeFileSync(this.filePath, JSON.stringify(this.items, null, 2), 'utf8');
  }
}

function weekKey(value) {
  const date = parseLocalDate(value);
  if (!Number.isFinite(date.getTime())) {
    return weekKey(Date.now());
  }
  date.setHours(0, 0, 0, 0);
  const day = date.getDay();
  const mondayOffset = day === 0 ? -6 : 1 - day;
  date.setDate(date.getDate() + mondayOffset);
  return localDateKey(date);
}

function parseLocalDate(value) {
  const match = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (match) {
    return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  }
  return new Date(value);
}

function localDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function listFromText(value) {
  if (Array.isArray(value)) {
    return value.map((item) => String(item || '').trim()).filter(Boolean).slice(0, 12);
  }
  return String(value || '')
    .split(/\r?\n|;/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 12);
}

module.exports = {
  WeeklySelfInputService,
  weekKey
};
