const fs = require('fs');

class RetentionService {
  constructor(settingsService, auditLogService, activityStoreService, focusEventStoreService = null) {
    this.settingsService = settingsService;
    this.auditLogService = auditLogService;
    this.activityStoreService = activityStoreService;
    this.focusEventStoreService = focusEventStoreService;
  }

  enforce() {
    const { retentionDays } = this.settingsService.getSettings();
    const cutoff = Date.now() - retentionDays * 24 * 60 * 60 * 1000;
    const file = this.auditLogService.logPath;
    const activity = this.activityStoreService.prune(cutoff);
    const focus = this.focusEventStoreService?.prune
      ? this.focusEventStoreService.prune(cutoff)
      : { prunedRows: 0, prunedFiles: 0 };

    if (!fs.existsSync(file)) {
      return {
        retention_days: retentionDays,
        cutoff_iso: new Date(cutoff).toISOString(),
        pruned: 0,
        remaining: 0,
        activity_pruned_files: activity.prunedFiles,
        activity_pruned_sync_windows: activity.prunedSyncWindows,
        focus_pruned_rows: focus.prunedRows || 0,
        focus_pruned_files: focus.prunedFiles || 0
      };
    }

    const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
    const kept = lines.filter((line) => {
      try {
        const row = JSON.parse(line);
        return new Date(row.timestamp).getTime() >= cutoff;
      } catch {
        return false;
      }
    });

    fs.writeFileSync(file, `${kept.join('\n')}${kept.length ? '\n' : ''}`, 'utf8');
    return {
      retention_days: retentionDays,
      cutoff_iso: new Date(cutoff).toISOString(),
      pruned: lines.length - kept.length,
      remaining: kept.length,
      activity_pruned_files: activity.prunedFiles,
      activity_pruned_sync_windows: activity.prunedSyncWindows,
      focus_pruned_rows: focus.prunedRows || 0,
      focus_pruned_files: focus.prunedFiles || 0
    };
  }
}

module.exports = { RetentionService };
