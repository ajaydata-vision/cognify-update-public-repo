# Activity Store Remediation Plan

## Goal

Make captured-activity summaries and timelines trustworthy over time by fixing:

- privacy-at-rest leaks
- local/store deletion gaps
- retention gaps
- silent truncation from capped Screenpipe queries
- long-run degradation from naive file scans

## Adversarial Review

### Finding 1: Local delete was inconsistent

`deleteRange` removed data upstream in Screenpipe but left matching rows in the local store. That meant deleted activity could still be shown later.

### Finding 2: Privacy only existed at display time

The local store originally persisted normalized raw activity before privacy rules were applied. Excluded apps, private windows, OCR text, and transcripts could therefore remain on disk even if they were filtered out in the UI.

### Finding 3: Retention depended on audit-log existence

Activity pruning never ran if `audit-log.jsonl` did not exist, so store files could accumulate indefinitely.

### Finding 4: Sync truncation was silent

A capped Screenpipe search window could return `limit` rows with no signal that more data existed. The app then treated that range as complete.

### Finding 5: File-backed scans will not scale indefinitely

Daily JSONL files and JSON dedupe indexes are acceptable as an intermediate step, but not as the final design for heavy OCR/browser histories.

## Implemented In This Pass

### 1. Privacy-at-rest

- Apply privacy filtering before local ingestion.
- Normalize from redacted top-level fields first so sanitized OCR/transcript text is what reaches disk.

### 2. Local deletion consistency

- Delete matching rows from the local activity store on `deleteRange`.
- Drop overlapping sync-window metadata so deleted ranges are not still marked complete.

### 3. Retention coverage

- Prune activity-store files and sync metadata even when the audit log is absent.

### 4. Sync completeness tracking

- Record sync-window metadata locally.
- Mark windows incomplete when a fetch fails or when a range still hits the result cap at the minimum chunk size.
- Recursively subdivide hot windows instead of assuming a capped hour is complete.

## Remaining Work

### 1. Surface completeness in the UI

- Show a visible warning when a selected range includes incomplete sync windows.
- Distinguish complete counts from partial counts in summaries.

### 2. Background repair

- Add a reconciler that revisits incomplete windows, prioritizing the last few hours and today.

### 3. Cursor-driven sync

- Move from request-driven fetches to a persisted forward-sync cursor.
- Separate user reads from ingestion so the UI always reads from the local store only.

### 4. SQLite migration

- Replace JSONL day files and JSON indexes with indexed tables for:
  - normalized activity events
  - sync windows
  - optional derived sessions
- Use indexed deletes and range scans instead of whole-file rewrites.

## Proposed Next Order

1. Add UI warnings for partial ranges.
2. Add background repair for incomplete windows.
3. Move sync state and events into SQLite.
4. Add derived session/materialized summary tables if needed for scale.
