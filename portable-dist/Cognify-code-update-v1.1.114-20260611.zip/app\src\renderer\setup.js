const ROLE_LABELS = {
  developer: 'Developer / Engineering',
  'admin-operations': 'Admin / Operations',
  hr: 'HR',
  finance: 'Finance / Accounts',
  sales: 'Sales',
  marketing: 'Marketing',
  legal: 'Legal / Compliance',
  'customer-support': 'Customer Support / CS',
  'business-analyst': 'Business Analyst',
  designer: 'Designer / Creative',
  'social-media': 'Social Media',
  'manager-hod': 'Manager / HOD',
  'c-level-executive': 'C-Level / Executive'
};

const ROLE_PLACEHOLDERS = {
  developer: 'Example: Senior Engineer building product features',
  'admin-operations': 'Example: Admin Manager handling approvals and vendor follow-ups',
  hr: 'Example: HR Manager handling hiring, payroll, and employee queries',
  finance: 'Example: Accounts lead handling billing, payments, and reconciliations',
  sales: 'Example: Sales manager handling leads, demos, and follow-ups',
  marketing: 'Example: Marketing lead handling campaigns and content planning',
  legal: 'Example: Legal officer handling contracts and compliance',
  'customer-support': 'Example: Support lead handling tickets and escalations',
  'business-analyst': 'Example: Business analyst preparing reports and requirement notes',
  designer: 'Example: Product designer working on UI, reviews, and assets',
  'social-media': 'Example: Social media manager handling posts and analytics',
  'manager-hod': 'Example: HOD reviewing team work and approvals',
  'c-level-executive': 'Example: Director reviewing dashboards and decisions',
  custom: 'Example: Designation plus the main work you handle'
};

const steps = [...document.querySelectorAll('[data-step]')];
const dots = [...document.querySelectorAll('[data-dot]')];
const setupName = document.getElementById('setupName');
const setupEmail = document.getElementById('setupEmail');
const setupRoleId = document.getElementById('setupRoleId');
const setupRole = document.getElementById('setupRole');
const setupRoleNotes = document.getElementById('setupRoleNotes');
const setupError = document.getElementById('setupError');
const setupStatus = document.getElementById('setupStatus');
const backButton = document.getElementById('back');
const nextButton = document.getElementById('next');
const finishButton = document.getElementById('finish');
const exitButton = document.getElementById('exitSetup');

let stepIndex = 0;
let finishing = false;

function setError(message = '') {
  setupError.textContent = message;
}

function setStatus(message = '') {
  setupStatus.textContent = message;
}

function selectedRoleLabel() {
  const selectedId = setupRoleId.value || '';
  if (selectedId && selectedId !== 'custom') {
    return ROLE_LABELS[selectedId] || selectedId;
  }
  return setupRole.value.trim();
}

function syncRoleField() {
  const selectedId = setupRoleId.value || '';
  const isCustom = !selectedId || selectedId === 'custom';
  setupRole.disabled = !isCustom;
  setupRole.placeholder = ROLE_PLACEHOLDERS[selectedId] || 'Example: Designation plus the main work you handle';
  if (!isCustom) {
    setupRole.value = ROLE_LABELS[selectedId] || '';
  }
}

function render() {
  steps.forEach((step) => {
    step.classList.toggle('active', Number(step.dataset.step) === stepIndex);
  });
  dots.forEach((dot) => {
    const index = Number(dot.dataset.dot);
    dot.classList.toggle('active', index === stepIndex);
    dot.classList.toggle('done', index < stepIndex);
  });
  backButton.disabled = stepIndex === 0 || finishing;
  nextButton.style.display = stepIndex >= 4 ? 'none' : '';
  finishButton.style.display = stepIndex >= 4 ? '' : 'none';
  finishButton.disabled = finishing;
  nextButton.disabled = finishing;
  setError('');

  const focusTargets = [nextButton, setupName, setupRoleId, setupRoleNotes, finishButton];
  setTimeout(() => focusTargets[stepIndex]?.focus(), 0);
}

function validateStep() {
  if (stepIndex === 1) {
    const name = setupName.value.trim();
    const email = setupEmail.value.trim();
    if (!name) {
      return 'Enter your name to continue.';
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return 'Enter a valid email address to continue.';
    }
  }
  if (stepIndex === 2 && !selectedRoleLabel()) {
    return 'Select a role or enter a custom role to continue.';
  }
  if (stepIndex === 3 && setupRoleNotes.value.trim().length < 20) {
    return 'Add a short work context note so Cognify can understand your role better.';
  }
  return '';
}

function nextStep() {
  const error = validateStep();
  if (error) {
    setError(error);
    return;
  }
  stepIndex = Math.min(4, stepIndex + 1);
  render();
}

function backStep() {
  stepIndex = Math.max(0, stepIndex - 1);
  render();
}

async function finishSetup() {
  if (finishing) {
    return;
  }
  const error = validateStep();
  if (error) {
    setError(error);
    return;
  }

  finishing = true;
  setError('');
  setStatus('Saving setup...');
  render();

  try {
    const roleId = setupRoleId.value || 'custom';
    await window.assistantApi.updateProfile({
      name: setupName.value.trim(),
      email: setupEmail.value.trim()
    });
    await window.assistantApi.updateRoleProfile({
      role: selectedRoleLabel(),
      roleId,
      roleSource: roleId === 'custom' ? 'custom' : 'confirmed_selected',
      roleNotes: setupRoleNotes.value.trim()
    });
    await window.assistantApi.completeOnboarding({ completedAt: true });
    setStatus('Starting Cognify...');
  } catch (error) {
    finishing = false;
    setStatus('');
    setError(error?.message || 'Saving setup failed.');
    render();
  }
}

async function bootstrap() {
  setStatus('Loading setup...');
  try {
    const settings = await window.assistantApi.getSettings();
    setupName.value = settings.profile?.name || '';
    setupEmail.value = settings.profile?.email || '';
    setupRoleId.value = settings.profile?.roleId || settings.profile?.roleDetection?.lastDetectedRoleId || '';
    if (setupRoleId.value && !ROLE_LABELS[setupRoleId.value]) {
      setupRoleId.value = settings.profile?.role ? 'custom' : '';
    }
    setupRole.value = settings.profile?.role || settings.profile?.roleDetection?.lastDetectedRole || '';
    setupRoleNotes.value = settings.profile?.roleNotes || '';
    syncRoleField();
    setStatus('');
  } catch (error) {
    setStatus('');
    setError(error?.message || 'Loading setup failed.');
  }
  render();
}

nextButton.addEventListener('click', nextStep);
backButton.addEventListener('click', backStep);
finishButton.addEventListener('click', finishSetup);
exitButton.addEventListener('click', () => window.assistantApi.quitApp());
setupRoleId.addEventListener('change', syncRoleField);
[setupName, setupEmail, setupRole].forEach((input) => {
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      nextStep();
    }
  });
});

bootstrap();
