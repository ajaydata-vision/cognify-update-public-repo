param(
  [Parameter(Mandatory = $true)]
  [string]$SourcePath,

  [Parameter(Mandatory = $true)]
  [string]$OutputPath,

  [Parameter(Mandatory = $true)]
  [string]$HashPath
)

$ErrorActionPreference = "Stop"

function Get-Sha256Hex {
  param([string]$Path)

  $stream = [System.IO.File]::OpenRead($Path)
  try {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
      return ([BitConverter]::ToString($sha.ComputeHash($stream)) -replace '-', '').ToLowerInvariant()
    } finally {
      $sha.Dispose()
    }
  } finally {
    $stream.Dispose()
  }
}

if (-not (Test-Path -LiteralPath $SourcePath)) {
  throw "Native focus helper source not found: $SourcePath"
}

$hash = Get-Sha256Hex -Path $SourcePath
$existingHash = if (Test-Path -LiteralPath $HashPath) {
  (Get-Content -LiteralPath $HashPath -Raw -ErrorAction SilentlyContinue).Trim()
} else {
  ""
}

if ($existingHash -eq $hash -and (Test-Path -LiteralPath $OutputPath)) {
  [pscustomobject]@{ ok = $true; cached = $true; output = $OutputPath } | ConvertTo-Json -Compress
  exit 0
}

$outputDir = Split-Path -Parent $OutputPath
if ($outputDir) {
  New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
}

if (Test-Path -LiteralPath $OutputPath) {
  Remove-Item -LiteralPath $OutputPath -Force
}

$source = Get-Content -LiteralPath $SourcePath -Raw
Add-Type `
  -TypeDefinition $source `
  -ReferencedAssemblies System.Windows.Forms `
  -OutputAssembly $OutputPath `
  -OutputType ConsoleApplication `
  -ErrorAction Stop

Set-Content -LiteralPath $HashPath -Value $hash -Encoding ASCII
[pscustomobject]@{ ok = $true; cached = $false; output = $OutputPath; hash = $hash } | ConvertTo-Json -Compress
